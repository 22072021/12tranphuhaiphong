# Kiểm tra bản xuất ngày13/11/2026

- npm install thành công với phụ thuộc ws và Node.js24.
- Máy chủ bản xuất khởi động ở cổng riêng, dùng cơ sở dữ liệu trống ngoài gói ZIP.
- Trình duyệt hoàn tất màn hình mở đầu, đăng ký và vào game; có canvas, không có lỗi JavaScript, tài nguyên404 hoặc yêu cầu về website gốc.
- Dựng10 khối nhà, toàn bộ campus và đối tượng NPC; kiểm tra nhân vật áo dài, hình học hữu hạn, tải tài nguyên trong gói.
- Đăng ký hồ sơ mới và cấp30k;2 tài khoản thử kết nối WebSocket, nhận chat chung.
- Công cụ cấp quyền admin chạy thành công trên tài khoản thử của bản cài riêng.
- Đã kiểm tra đường dẫn import các module, không thiếu dependency nội bộ.
- Không kèm ảnh/tư liệu tham chiếu gốc, dữ liệu vận hành, cookie/token, mật khẩu quản trị gốc hoặc lịch sử Git.
- PACKAGE-MANIFEST.json ghi kích thước và SHA-256. Chạy npm run check trước khi chỉnh sửa.

Đây là kiểm tra đóng gói và các luồng chính, không phải cam kết kiểm thử lại mọi tương tác game hoặc kiểm toán bảo mật độc lập cho bản tự triển khai.
