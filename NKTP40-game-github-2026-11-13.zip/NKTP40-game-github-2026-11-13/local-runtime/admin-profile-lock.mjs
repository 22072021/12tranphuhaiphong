import fs from 'node:fs';import path from 'node:path';import{randomBytes,scryptSync,timingSafeEqual,createHmac}from'node:crypto';
export function createAdminProfileLock({directory,clock=Date.now}={}){
 let config=null;try{config=JSON.parse(fs.readFileSync(path.join(directory,'admin-player-lock.json'),'utf8'));}catch{}
 const sessions=new Map(),attempts=new Map();const cookieId=req=>(req.headers.cookie||'').match(/(?:^|;\s*)nktp40-player=([a-f0-9]{64})(?:;|$)/)?.[1];
 const protectedId=id=>!!config&&id===config.playerId;
 const rememberedCookie='nktp40-admin-player',rememberMs=30*86400000;
 const signature=payload=>createHmac('sha256',config.codeHash).update('admin-player-v1:'+payload).digest('hex');
 function remembered(req,id){
  const raw=(req.headers.cookie||'').match(/(?:^|;\s*)nktp40-admin-player=([a-f0-9.]+)(?:;|$)/)?.[1];
  if(!raw||!protectedId(id))return false;
  const parts=raw.split('.');if(parts.length!==3||!/^[a-f0-9]{64}$/.test(parts[2]))return false;
  const expires=Number.parseInt(parts[0],16);if(!Number.isSafeInteger(expires)||expires<=clock()||expires>clock()+rememberMs)return false;
  const expected=Buffer.from(signature(id+':'+parts[0]+'.'+parts[1]),'hex'),received=Buffer.from(parts[2],'hex');
  return expected.length===received.length&&timingSafeEqual(expected,received);
 }
 const authorized=(id,token)=>{const session=sessions.get(String(token||''));return !!session&&session.id===id&&session.expires>clock();};
 return{isProtected:req=>protectedId(cookieId(req)),authorizePresence(req,token){const id=cookieId(req);return !protectedId(id)||remembered(req,id)||authorized(id,token);},async handle(req,res,url,id){
  if(!protectedId(id))return false;
  const reply=(status,data)=>{res.writeHead(status);res.end(JSON.stringify(data));return true;};
  if(url.searchParams.get('action')==='unlock'&&req.method==='POST'){
   const previous=attempts.get(id)||{count:0,until:0};if(previous.until>clock())return reply(429,{error:'Vui lòng chờ một phút trước khi thử lại.'});
   let input,body='';try{for await(const chunk of req){body+=chunk;if(body.length>1024)return reply(413,{error:'Thông tin quá dài.'});}input=JSON.parse(body);}catch{return reply(400,{error:'Mã chưa hợp lệ.'});}
   const hash=scryptSync(String(input.code||''),config.salt,32),expected=Buffer.from(config.codeHash,'hex');if(expected.length!==hash.length||!timingSafeEqual(hash,expected)){previous.count++;if(previous.count>=5){previous.until=clock()+60000;previous.count=0;}attempts.set(id,previous);return reply(403,{error:'Mã chưa đúng. Vui lòng kiểm tra lại.'});}
   attempts.delete(id);
   const payload=(clock()+rememberMs).toString(16)+'.'+randomBytes(16).toString('hex');
   const secure=req.headers['x-forwarded-proto']==='https'||/\.mango\.pro\.vn(?::\d+)?$/.test(req.headers.host||'');
   res.setHeader?.('Set-Cookie',rememberedCookie+'='+payload+'.'+signature(id+':'+payload)+'; HttpOnly; SameSite=Strict; Path=/; Max-Age='+rememberMs/1000+(secure?'; Secure':''));
   for(const[token,session]of sessions)if(session.expires<=clock())sessions.delete(token);const token=randomBytes(32).toString('hex');sessions.set(token,{id,expires:clock()+8*3600000});return reply(200,{adminToken:token});
  }
  if(!remembered(req,id)&&!authorized(id,req.headers['x-nktp-admin-token']))return reply(req.method==='GET'?200:401,{requiresAdminVerification:true});
  return false;
 }};
}
