const distance=(a,b)=>Math.hypot(a[0]-b[0],a[2]-b[2]);
export function createBicycles({catalog=[],clock=Date.now,canTravel=()=>false}={}){
 const homes=new Map(catalog.map(b=>[b.id,b])),rows=new Map(),riders=new Map();
 const send=(c,p)=>{if(c.ws.readyState===1)c.ws.send(JSON.stringify(p));},deny=(c,error)=>send(c,{type:'bicycle-error',error});
 function leave(client,now=clock()){const seat=riders.get(client.id);if(!seat)return;const b=rows.get(seat.bike);if(b)b[seat.rear?'passenger':'driver']=null;riders.delete(client.id);if(b&&!b.driver&&!b.passenger){b.abandonedAt=now;b.speed=0;}}
 function handle(client,raw,now=clock(),clients=new Map()){
  if(raw.type==='punishment-join'&&riders.has(client.id)){send(client,{type:'punishment-error',error:'Hãy xuống xe trước khi đứng phạt.'});return true;}if(typeof raw.type!=='string'||!raw.type.startsWith('bicycle-'))return false;
  if(raw.type==='bicycle-sync'){send(client,packet(client,now));return true;}
  if(raw.type==='bicycle-dismount'){const seat=riders.get(client.id),b=seat&&rows.get(seat.bike);if(b&&Array.isArray(raw.exit)&&raw.exit.length===3&&raw.exit.every(Number.isFinite)&&distance(raw.exit,b.root)<2.5&&Math.abs(raw.exit[1]-b.root[1])<1.5){if(client.state){client.state.root=[...raw.exit,client.state.root[3]];delete client.state.pose;}leave(client,now);send(client,{type:'bicycle-left',exit:raw.exit});}else if(b)deny(client,'Chưa có chỗ trống để xuống xe.');return true;}
  if(raw.type==='bicycle-travel'){
   const seat=riders.get(client.id),b=seat&&rows.get(seat.bike),r=raw.root;
   if(!b||!client.state?.active||now-client.last>4000||now-(client.bicycleTravelAt||0)<300||!canTravel(r,raw.destination,client)){deny(client,'Chưa thể đưa xe tới điểm này.');return true;}
   client.bicycleTravelAt=now;b.root=[...r];b.speed=0;b.updated=now;b.travelVersion=(b.travelVersion||0)+1;b.abandonedAt=null;
   for(const id of [b.driver,b.passenger]){const c=clients.get(id)||(id===client.id?client:null);if(c){if(c.state){c.state.root=[...r];delete c.state.pose;}send(c,packet(c,now));}}
   return true;
  }
  if(raw.type==='bicycle-mount'){

   const spec=homes.get(raw.id),b=rows.get(raw.id),root=b?.root||spec?.home;
   if(!spec||!client.state?.active||now-client.last>4000||riders.has(client.id)||client.punishment||client.state.food||!root||distance(client.state.root,root)>2||Math.abs(client.state.root[1]-root[1])>(spec.high?1.8:.8)){deny(client,'Hãy đến gần xe và rời chỗ ngồi/đứng phạt, ăn xong để lên xe.');return true;}
   const rear=raw.seat==='rear';if(rear?(!b?.driver||b.passenger):(!!b?.driver)){deny(client,rear?'Yên sau chưa trống hoặc chưa có người lái.':'Xe đã có người lái.');return true;}
   const row=b||{id:spec.id,root:[...spec.home],driver:null,passenger:null,phase:0,speed:0,updated:now,abandonedAt:null,travelVersion:0};row[rear?'passenger':'driver']=client.id;row.abandonedAt=null;row.updated=now;rows.set(row.id,row);riders.set(client.id,{bike:row.id,rear});send(client,packet(client,now));return true;
  }
  if(raw.type==='bicycle-move'){
   const seat=riders.get(client.id),b=seat&&rows.get(seat.bike),r=raw.root;
   if(!b||seat.rear)return true;if((raw.travelVersion||0)!==(b.travelVersion||0))return true;
   if(!Array.isArray(r)||r.length!==4||!r.every(Number.isFinite)||Math.abs(r[0])>500||Math.abs(r[2])>500||r[1]<-20||r[1]>100||!Number.isFinite(raw.speed)||Math.abs(raw.speed)>7.3){deny(client,'Trạng thái xe không hợp lệ.');return true;}
   const dt=Math.max(.05,Math.min(2,(now-b.updated)/1000)),d=distance(r,b.root);if(d>7.3*dt+.35||Math.abs(r[1]-b.root[1])>Math.max(.65,dt*12))return true;
   b.phase=(b.phase-Math.sign(raw.speed)*d*4)%(Math.PI*2);b.root=[...r];b.speed=raw.speed;b.updated=now;return true;
  }return true;
 }
 function sweep(clients,now=clock()){for(const id of riders.keys()){const c=clients.get(id);if(!c||!c.state?.active||now-c.last>15000)leave({id},now);}for(const [id,b]of rows)if(b.abandonedAt!==null&&!b.driver&&!b.passenger&&now-b.abandonedAt>=10000)rows.delete(id);}
 function packet(client,now=clock()){const p=client.state?.root;return{type:'bicycle-state',time:now,ownId:client.id,seat:riders.get(client.id)||null,away:[...rows.keys()],bikes:[...rows.values()].filter(b=>b.driver===client.id||b.passenger===client.id||p&&distance(p,b.root)<65).map(({id,root,driver,passenger,phase,speed,abandonedAt,travelVersion=0})=>({id,root,driver,passenger,phase,speed,abandonedAt,travelVersion}))};}
 return{handle,leave,sweep,packet,rows,riders};
}
