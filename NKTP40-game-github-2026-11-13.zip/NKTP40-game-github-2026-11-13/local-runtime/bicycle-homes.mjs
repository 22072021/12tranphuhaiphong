import * as T from '../public/vendor/three.module.js';
import {createBuildingGroup} from '../public/building-geometry.js';
import {disposeObject} from '../public/building-cache.js';
import {bicycleCatalog} from '../public/bicycle-catalog.js';
export function buildBicycleCatalog(layout){const extra=[];for(const [id,name,key,mini,color]of [['WC','wc-male-pink-mini-bicycle','wc:pink',true,'#d989b2'],['A2','A2-upside-down-porch-bicycle','roof:A2',false,'#853c3f']]){const b=layout.buildings.find(b=>b.id===id);if(!b)continue;const g=createBuildingGroup(b);g.updateMatrixWorld(true);const o=g.getObjectByName(name);if(o){const p=o.getWorldPosition(new T.Vector3()),box=new T.Box3().setFromObject(o);extra.push({id:key,mini,color,home:[p.x,box.min.y,p.z,-b.rotation*Math.PI/180],high:key==='roof:A2'});}disposeObject(g);}return bicycleCatalog(layout,extra);}
