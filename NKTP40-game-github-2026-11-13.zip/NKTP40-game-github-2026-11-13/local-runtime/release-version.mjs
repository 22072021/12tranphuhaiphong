import fs from 'node:fs';import path from 'node:path';
// Public release numbers are persisted separately from content hashes and survive restarts.
export function releaseVersion(directory,revision){
 const file=path.join(directory,'release-number.json');let previous;try{previous=JSON.parse(fs.readFileSync(file,'utf8'));}catch{}
 if(previous?.revision===revision&&Number.isSafeInteger(previous.version))return previous.version;
 const version=Number.isSafeInteger(previous?.version)?Math.max(1500,previous.version+1):1500;
 fs.mkdirSync(directory,{recursive:true});const temporary=file+'.tmp';fs.writeFileSync(temporary,JSON.stringify({version,revision})+'\n');fs.renameSync(temporary,file);return version;
}
