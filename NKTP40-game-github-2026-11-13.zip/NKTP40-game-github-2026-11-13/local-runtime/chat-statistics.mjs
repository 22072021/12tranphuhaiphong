// Aggregate only: no message text, names, account IDs or IP addresses.
export function createChatStatistics(db,{clock=Date.now}={}){
 db.exec(`CREATE TABLE IF NOT EXISTS chat_statistics_meta(id INTEGER PRIMARY KEY CHECK(id=1),started_at INTEGER NOT NULL,baseline_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS chat_statistics(day TEXT NOT NULL,channel TEXT NOT NULL,cohort TEXT NOT NULL,class_name TEXT NOT NULL,source TEXT NOT NULL,messages INTEGER NOT NULL,PRIMARY KEY(day,channel,cohort,class_name,source));`);
 const add=db.prepare('INSERT INTO chat_statistics VALUES(?,?,?,?,?,1) ON CONFLICT(day,channel,cohort,class_name,source) DO UPDATE SET messages=messages+1');
 const day=at=>new Date(at+7*3600000).toISOString().slice(0,10);
 function record({time,channel,grade='',className='',source='live'}){const cohort=/^(19|20)\d{2}$/.test(grade)?grade:'';add.run(day(time),channel,cohort,cohort?className:'',source);}
 if(!db.prepare('SELECT id FROM chat_statistics_meta WHERE id=1').get()){
  db.exec('BEGIN IMMEDIATE');try{
   const now=clock();db.prepare('INSERT INTO chat_statistics_meta VALUES(1,?,?)').run(now,now);
   for(const r of db.prepare('SELECT scope,sender,created_at FROM chat_message').all()){
    const scope=JSON.parse(r.scope),channel=scope[0]==='announcements'?'announcements':scope[1]==='room'?'room':scope[1]==='year'?'year':'class',m=channel==='announcements'?null:r.sender.match(/ - (.+) (\d{2})$/u);
    record({time:r.created_at,channel,grade:m?(+m[2]>=86?'19':'20')+m[2]:'',className:m?.[1]||'',source:'retained-baseline'});
   }db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');throw e;}
 }
 return{record};
}
