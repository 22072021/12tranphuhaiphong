import {randomBytes,createHash,timingSafeEqual,scrypt} from 'node:crypto';
import {promisify} from 'node:util';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

export const publicHosts=new Set((process.env.NKTP40_PUBLIC_HOSTS||'').split(',').map(s=>s.trim()).filter(Boolean));
export const clientIP=req=>String(req.headers['cf-connecting-ip']||req.socket?.remoteAddress||'unknown');
export const isPublic=req=>publicHosts.has((req.headers.host||'').split(':')[0]);
export const ownOrigin=req=>(isPublic(req)?'https':req.headers['x-forwarded-proto']==='https'?'https':'http')+'://'+req.headers.host;
export function sameOrigin(req){return req.headers.origin===ownOrigin(req);}
export function rateLimiter({clock=Date.now,maxKeys=10000}={}){
 const buckets=new Map();
 return (key,limit,window)=>{
  const now=clock();let b=buckets.get(key);
  if(!b||now>=b.until){if(buckets.size>=maxKeys){for(const[k,v]of buckets)if(now>=v.until)buckets.delete(k);if(buckets.size>=maxKeys)return false;}b={n:0,until:now+window};buckets.set(key,b);}
  return ++b.n<=limit;
 };
}
export function securityHeaders(req,res){
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');
 res.setHeader('X-Frame-Options','DENY');res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=(), payment=(), usb=()');
 if(isPublic(req))res.setHeader('Strict-Transport-Security','max-age=31536000');
 // Legacy editor/SDK script policy is initially report-only; the visitor game
 // enforces the complete script policy after browser regression checks.
 res.setHeader('Content-Security-Policy',"object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
 if((req.headers.host||'').split(':')[0]==='12tranphu.mango.pro.vn'||process.env.NKTP40_CSP_ENFORCE==='1')res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self' blob:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self' blob: data: ; media-src 'self' blob:; worker-src 'self' blob:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
 res.setHeader('Content-Security-Policy-Report-Only',"default-src 'self'; script-src 'self' blob:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self' blob: data: ; media-src 'self' blob:; worker-src 'self' blob:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");
}
const hash=s=>createHash('sha256').update(String(s)).digest('hex'),derive=promisify(scrypt);
export function createAdminSessions({directory,password,clock=Date.now}={}){
 fs.mkdirSync(directory,{recursive:true,mode:0o700});
 const file=path.join(directory,'security.sqlite'),db=new DatabaseSync(file);fs.chmodSync(file,0o600);
 db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS admin_session(hash TEXT PRIMARY KEY,origin TEXT NOT NULL,expires INTEGER NOT NULL,credential TEXT NOT NULL); CREATE TABLE IF NOT EXISTS admin_attempt(key TEXT PRIMARY KEY,count INTEGER NOT NULL,expires INTEGER NOT NULL);');
 const salt='nktp40-admin-session-v1',expected=derive(password,salt,32),credential=hash(password);
 const token=req=>(req.headers.cookie||'').match(/(?:^|;\s*)nktp40-admin=([a-f0-9]{64})(?:;|$)/)?.[1];
 const authenticated=req=>{const t=token(req);return !!(t&&db.prepare('SELECT 1 FROM admin_session WHERE hash=? AND origin=? AND expires>? AND credential=?').get(hash(t),ownOrigin(req),clock(),credential));};
 const attempt=(key,limit)=>{const now=clock();db.prepare('DELETE FROM admin_attempt WHERE expires<=?').run(now);const old=db.prepare('SELECT count FROM admin_attempt WHERE key=?').get(key);if((old?.count||0)>=limit)return false;db.prepare('INSERT INTO admin_attempt VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1').run(key,now+15*60000);return true;};
 let busy=0;
 return {authenticated,close:()=>db.close(),async handle(req,res,url){
  if(url.pathname!=='/api/admin-session')return false;
  res.setHeader('Cache-Control','no-store');const reply=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));return true;};
  if(req.method==='GET')return reply(authenticated(req)?200:401,{authenticated:authenticated(req)});
  if(!sameOrigin(req))return reply(403,{error:'Yêu cầu không hợp lệ.'});
  const cookie=(value,age)=>`nktp40-admin=${value}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${age}${isPublic(req)||ownOrigin(req).startsWith('https:')?'; Secure':''}`;
  if(req.method==='DELETE'){const t=token(req);if(t)db.prepare('DELETE FROM admin_session WHERE hash=?').run(hash(t));res.setHeader('Set-Cookie',cookie('',0));return reply(200,{ok:true});}
  if(req.method!=='POST')return reply(405,{error:'Method not allowed'});
  if(!attempt('ip:'+clientIP(req),5)||!attempt('global',50)||busy>=2){res.setHeader('Retry-After','900');return reply(429,{error:'Đã vượt số lần thử. Vui lòng thử lại sau 15 phút.'});}
  if(!req.headers['content-type']?.startsWith('application/json'))return reply(415,{error:'JSON required'});
  let body='',input;try{for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>1024)return reply(413,{error:'Thông tin quá dài.'});}input=JSON.parse(body);}catch{return reply(400,{error:'Thông tin không hợp lệ.'});}
  if(typeof input.code!=='string'||input.code.length>256)return reply(401,{error:'Mật khẩu không đúng.'});
  busy++;let valid=false;try{valid=timingSafeEqual(await derive(input.code,salt,32),await expected);}finally{busy--;}
  if(!valid)return reply(401,{error:'Mật khẩu không đúng.'});
  db.prepare('DELETE FROM admin_attempt WHERE key=?').run('ip:'+clientIP(req));
  db.prepare('DELETE FROM admin_session WHERE expires<=? OR credential<>?').run(clock(),credential);
  const t=randomBytes(32).toString('hex');db.prepare('INSERT INTO admin_session VALUES(?,?,?,?)').run(hash(t),ownOrigin(req),clock()+8*3600000,credential);res.setHeader('Set-Cookie',cookie(t,28800));return reply(200,{authenticated:true});
 }};
}

export function authorizeInlineScripts(res,html){
 const hashes=[];for(const match of html.matchAll(/<script\b([^>]*?)>([\s\S]*?)<\/script>/gi))if(!/\bsrc\s*=/i.test(match[1])&&match[2].trim())hashes.push("'sha256-"+createHash('sha256').update(match[2]).digest('base64')+"'");
 if(!hashes.length)return;for(const name of ['Content-Security-Policy','Content-Security-Policy-Report-Only']){const policy=res.getHeader(name);if(typeof policy==='string'&&policy.includes("script-src 'self' blob:"))res.setHeader(name,policy.replace("script-src 'self' blob:","script-src 'self' blob: "+hashes.join(' ')));}
}
