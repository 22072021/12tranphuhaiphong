import {DatabaseSync} from 'node:sqlite';import fs from 'node:fs';import path from 'node:path';
import {FENCE_CLIMB} from '../public/fence-climb-layout.js';
// Aggregate events only. No movement histories, names, IPs or account IDs are retained.
export function createGameStatistics({directory=process.env.NKTP40_DATA||path.resolve('.data'),clock=Date.now}={}){
 fs.mkdirSync(directory,{recursive:true,mode:0o700});const db=new DatabaseSync(path.join(directory,'game-statistics.sqlite'));
 db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS statistics_meta(id INTEGER PRIMARY KEY CHECK(id=1),started_at INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS event_totals(event TEXT PRIMARY KEY,total INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS completed_classes(class_name TEXT NOT NULL,year INTEGER NOT NULL,completed_at INTEGER NOT NULL,PRIMARY KEY(class_name,year));');db.prepare('INSERT OR IGNORE INTO statistics_meta VALUES(1,?)').run(clock());
 const classes=new Set(db.prepare('SELECT class_name,year FROM completed_classes').all().map(c=>c.class_name+':'+c.year)),attempts=new WeakMap(),add=db.prepare('INSERT INTO event_totals VALUES(?,1) ON CONFLICT(event) DO UPDATE SET total=total+1');
 return{completeClass(choice,now=clock()){if(!choice||now-choice.startedAt<4400)return;const key=choice.className+':'+choice.year;if(classes.has(key))return;db.prepare('INSERT OR IGNORE INTO completed_classes VALUES(?,?,?)').run(choice.className,choice.year,now);classes.add(key);},trackFence(client,now=clock()){
 const s=client.state,p=s?.root;if(!s?.active||!p||Math.abs(p[2]-FENCE_CLIMB.z)>1.2){attempts.delete(client);return;}const side=Math.sign(p[0]-FENCE_CLIMB.x),distance=Math.abs(p[0]-FENCE_CLIMB.x);let a=attempts.get(client);
 if(a&&now-a.start>30000){attempts.delete(client);a=null;}if(!a){if(distance>=.40&&distance<1.2&&p[1]>=-.15&&p[1]<.65)attempts.set(client,{side,start:now,top:false});return;}
 if(distance<1.1&&p[1]>FENCE_CLIMB.height-1.1)a.top=true;
 if(a.top&&side===-a.side&&distance>=.45&&distance<1.2&&p[1]<.65&&now-a.start>=8000){add.run('fence_climbs');attempts.delete(client);}
 },close(){db.close();}};
}
