import fs from 'node:fs';import path from 'node:path';import {DatabaseSync} from 'node:sqlite';import {punishmentPlan} from '../public/punishment-plan.js';
export function createPunishmentSlots({directory=process.env.NKTP40_DATA||path.resolve('.data'),clock=Date.now,layout=()=>JSON.parse(fs.readFileSync(new URL('../public/model-data.json',import.meta.url),'utf8'))}={}){
 const db=directory?(fs.mkdirSync(directory,{recursive:true}),new DatabaseSync(path.join(directory,'punishment.sqlite'))):null;
 db?.exec('PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS records(account TEXT PRIMARY KEY,name TEXT NOT NULL,seconds INTEGER NOT NULL)');
 db?.exec('CREATE TABLE IF NOT EXISTS punishment_totals(account TEXT PRIMARY KEY,milliseconds INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS punishment_totals_meta(id INTEGER PRIMARY KEY CHECK(id=1),started_at INTEGER NOT NULL)');db?.prepare('INSERT OR IGNORE INTO punishment_totals_meta VALUES(1,?)').run(clock());
 const records=new Map((db?.prepare('SELECT * FROM records').all()||[]).map(r=>[r.account,r]));
 function save(p,now){const from=p.lastCountedAt??p.startedAt,delta=Math.max(0,now-from);if(delta){db?.prepare('INSERT INTO punishment_totals VALUES(?,?) ON CONFLICT(account) DO UPDATE SET milliseconds=milliseconds+excluded.milliseconds').run(p.account,Math.floor(delta));p.lastCountedAt=now;}const seconds=Math.max(0,Math.floor((now-p.startedAt)/1000));if(seconds>(records.get(p.account)?.seconds||0)){const row={account:p.account,name:p.name,seconds};records.set(p.account,row);db?.prepare('INSERT INTO records VALUES(?,?,?) ON CONFLICT(account) DO UPDATE SET name=excluded.name,seconds=excluded.seconds').run(row.account,row.name,row.seconds);}}
 function ranking(){const rows=new Map([...records].map(([k,r])=>[k,{name:r.name,seconds:r.seconds}]));for(const p of slots.values()){const r=rows.get(p.account)||{name:p.name,seconds:0};rows.set(p.account,{...r,name:p.name,startedAt:p.startedAt});}return [...rows.values()].sort((a,b)=>Math.max(b.seconds,(clock()- (b.startedAt||clock()))/1000)-Math.max(a.seconds,(clock()-(a.startedAt||clock()))/1000)).slice(0,20);}
 const slots=new Map();const key=(room,slot)=>room+':'+slot;
 function leave(client,now=clock()){if(client.punishment){const k=key(client.punishment.room,client.punishment.slot);if(slots.get(k)?.id===client.id){save(client.punishment,now);slots.delete(k);}client.punishment=null;}}
 function handle(client,raw,trusted,now){if(raw.type==='punishment-leave'){leave(client,now);return true;}if(raw.type!=='punishment-join')return false;
 const send=message=>client.ws.send(JSON.stringify(message));const deny=error=>{send({type:'punishment-error',error});return true;};
 if(trusted?.role!=='student'||trusted?.isAdmin)return deny('Vị trí này dành cho học sinh.');
 if(!Number.isInteger(raw.slot)||raw.slot<0||raw.slot>=10)return deny('Vị trí không hợp lệ.');const point=punishmentPlan(layout())[raw.slot],r=client.state?.root;
 if(!point||!client.state?.active||now-client.last>3000||!r||Math.hypot(r[0]-point.x,r[2]-point.z)>.9||Math.abs(r[1]-point.feet)>.5)return deny('Hãy đứng vào chấm đỏ trước.');
 const k=key(client.room,raw.slot),existing=slots.get(k);if(existing&&existing.id!==client.id)return deny('Vị trí này đã có học sinh đứng.');
 if(client.punishment?.slot===raw.slot&&client.punishment?.room===client.room)return true;
 leave(client,now);for(const [otherKey,entry]of slots)if(entry.account===client.reactionKey){save(entry,now);slots.delete(otherKey);}
 const entry={id:client.id,account:client.reactionKey,slot:raw.slot,room:client.room,startedAt:now,name:[trusted.name,[trusted.className,trusted.grade?.slice(-2)].filter(Boolean).join(' ')].filter(Boolean).join(' - '),...point};slots.set(k,entry);client.punishment=entry;send({type:'punishment-joined',slot:raw.slot});return true;
 }
 function sweep(clients,now){for(const c of clients){const p=c.punishment;if(!p)continue;const r=c.state?.root;if(!c.state?.active||now-c.last>15000||c.room!==p.room||!r||Math.hypot(r[0]-p.x,r[2]-p.z)>1.4||Math.abs(r[1]-p.feet)>.6||slots.get(key(p.room,p.slot))?.id!==c.id)leave(c,Math.min(now,c.last+15000));}}
 let lastCheckpoint=clock();const checkpoint=setInterval(()=>{const now=clock();if(now-lastCheckpoint>=10000){for(const p of slots.values())save(p,now);lastCheckpoint=now;}},10000);checkpoint.unref();
 function snapshot(room){return [...slots.values()].filter(p=>p.room===room).map(({id,slot,startedAt})=>({id,slot,startedAt}));}
 return{handle,leave,sweep,snapshot,ranking,close(){clearInterval(checkpoint);for(const p of slots.values())save(p,clock());db?.close();}};
}
