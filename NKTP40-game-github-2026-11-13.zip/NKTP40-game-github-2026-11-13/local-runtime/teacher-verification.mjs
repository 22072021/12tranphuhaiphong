import {createHash,randomBytes} from 'node:crypto';
import {rateLimiter,clientIP,sameOrigin} from './security.mjs';
export const teacherFingerprint=t=>createHash('sha256').update(JSON.stringify([t?.name||'',t?.subject||''])).digest('hex');
export function createTeacherVerification({db,clock=Date.now}){
 db.exec('CREATE TABLE IF NOT EXISTS teacher_verification(id TEXT PRIMARY KEY,fingerprint TEXT NOT NULL,verified_at INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS teacher_verification_codes(hash TEXT PRIMARY KEY,player_id TEXT NOT NULL,fingerprint TEXT NOT NULL,expires INTEGER NOT NULL,used_at INTEGER);');
 const rate=rateLimiter({clock}),get=db.prepare('SELECT * FROM teacher_verification WHERE id=?');
 const verified=(id,t)=>get.get(id)?.fingerprint===teacherFingerprint(t);
 const reply=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));return true;};
 return{verified,invalidate(id){db.prepare('DELETE FROM teacher_verification WHERE id=?').run(id);db.prepare('DELETE FROM teacher_verification_codes WHERE player_id=?').run(id);},async handle(req,res,url){
  const admin=url.pathname==='/api/teacher-verifications';if(!admin&&url.pathname!=='/api/teacher-verification')return false;
  if(admin&&req.method==='GET'&&url.searchParams.has('reference')){
   const ref=(url.searchParams.get('reference')||'').trim().toLowerCase();if(!/^(?:[a-f0-9]{12}|[a-f0-9]{64})$/.test(ref))return reply(res,400,{error:'Mã thiết bị cần gồm 12 ký tự được hiển thị trong hồ sơ giáo viên.'});
   const rows=db.prepare("SELECT t.id,t.name,t.subject FROM teacher_identity t JOIN player_role r ON r.id=t.id AND r.role='teacher' WHERE substr(t.id,1,?)=? LIMIT 2").all(ref.length,ref);
   if(!rows.length)return reply(res,404,{error:'Không tìm thấy tài khoản giáo viên với mã này.'});if(rows.length!==1)return reply(res,409,{error:'Mã trùng nhiều tài khoản. Cần mã thiết bị đầy đủ để phân biệt.'});
   const t=rows[0];return reply(res,200,{teacher:{reference:t.id.slice(0,12),name:t.name,subject:t.subject,verified:verified(t.id,t),fingerprint:teacherFingerprint(t)}});
  }
  if(admin&&req.method==='GET')return reply(res,200,{teachers:db.prepare("SELECT t.id,t.name,t.subject FROM teacher_identity t JOIN player_role r ON r.id=t.id AND r.role='teacher' ORDER BY t.name").all().map(t=>({...t,verified:verified(t.id,t),reference:t.id.slice(0,12)}))});
  if(req.method!=='POST')return reply(res,405,{error:'Method not allowed'});
  if(!sameOrigin(req))return reply(res,403,{error:'Yêu cầu không hợp lệ.'});
  if(!rate('verify:'+clientIP(req),10,900000))return reply(res,429,{error:'Thầy/cô vui lòng thử lại sau 15 phút.'});
  let input,body='';try{for await(const c of req){body+=c;if(Buffer.byteLength(body)>1024)return reply(res,413,{error:'Thông tin quá dài.'});}input=JSON.parse(body);}catch{return reply(res,400,{error:'Thông tin chưa hợp lệ.'});}
  if(!input||typeof input!=='object'||Array.isArray(input))return reply(res,400,{error:'Thông tin chưa hợp lệ.'});
  let resolvedId=input.id;if(admin&&input.reference){const ref=String(input.reference).trim().toLowerCase();if(!/^(?:[a-f0-9]{12}|[a-f0-9]{64})$/.test(ref))return reply(res,400,{error:'Mã thiết bị không hợp lệ.'});const matches=db.prepare("SELECT id FROM teacher_identity WHERE substr(id,1,?)=? LIMIT 2").all(ref.length,ref);if(matches.length!==1)return reply(res,409,{error:'Không tìm thấy duy nhất một tài khoản. Vui lòng kiểm tra mã.'});resolvedId=matches[0].id;}
  const id=admin?String(resolvedId||''):(req.headers.cookie||'').match(/(?:^|;\s*)nktp40-player=([a-f0-9]{64})(?:;|$)/)?.[1];
  const teacher=id&&db.prepare("SELECT t.* FROM teacher_identity t JOIN player_role r ON r.id=t.id AND r.role='teacher' WHERE t.id=?").get(id);
  if(!teacher?.name||!teacher.subject)return reply(res,400,{error:'Kính mời thầy/cô lưu thông tin giáo viên trước khi xác minh.'});
  if(admin){
   if(input.action==='approve'){
    if(input.fingerprint!==teacherFingerprint(teacher))return reply(res,409,{error:'Thông tin giáo viên đã thay đổi. Vui lòng tra cứu lại trước khi duyệt.'});
    db.prepare('INSERT INTO teacher_verification(id,fingerprint,verified_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET fingerprint=excluded.fingerprint,verified_at=excluded.verified_at').run(id,teacherFingerprint(teacher),clock());
    db.prepare('DELETE FROM teacher_verification_codes WHERE player_id=?').run(id);return reply(res,200,{ok:true,verified:true});
   }
   if(input.action==='revoke'){db.prepare('DELETE FROM teacher_verification WHERE id=?').run(id);db.prepare('DELETE FROM teacher_verification_codes WHERE player_id=?').run(id);return reply(res,200,{ok:true});}
   if(input.action!=='issue')return reply(res,400,{error:'Thao tác chưa hợp lệ.'});
   const code=randomBytes(16).toString('hex'),expires=clock()+86400000;
   db.prepare('DELETE FROM teacher_verification_codes WHERE player_id=? OR expires<?').run(id,clock());
   db.prepare('INSERT INTO teacher_verification_codes(hash,player_id,fingerprint,expires) VALUES(?,?,?,?)').run(createHash('sha256').update(code).digest('hex'),id,teacherFingerprint(teacher),expires);
   return reply(res,200,{code,expires,reference:id.slice(0,12)});
  }
  const hash=createHash('sha256').update(String(input.code||'').trim()).digest('hex');
  const code=db.prepare('SELECT * FROM teacher_verification_codes WHERE hash=? AND player_id=? AND used_at IS NULL AND expires>?').get(hash,id,clock());
  if(!code||code.fingerprint!==teacherFingerprint(teacher))return reply(res,400,{error:'Mã xác minh chưa đúng, đã dùng hoặc đã hết hạn.'});
  db.exec('BEGIN IMMEDIATE');try{const used=db.prepare('UPDATE teacher_verification_codes SET used_at=? WHERE hash=? AND used_at IS NULL').run(clock(),hash);if(used.changes!==1)throw Error('used');db.prepare('INSERT INTO teacher_verification(id,fingerprint,verified_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET fingerprint=excluded.fingerprint,verified_at=excluded.verified_at').run(id,code.fingerprint,clock());db.exec('COMMIT');}catch{db.exec('ROLLBACK');return reply(res,400,{error:'Mã đã sử dụng.'});}
  return reply(res,200,{verified:true});
 }};
}
export function publicTeacherProfile(profile){return profile?.role==='teacher'&&profile.teacherVerified!==true?{chatMutedUntil:profile.chatMutedUntil||0,role:'teacher',teacherVerified:false,aoDaiColor:profile.aoDaiColor,name:'',subject:'',note:'',className:'',grade:''}:profile;}
