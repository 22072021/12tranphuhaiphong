import {DatabaseSync} from 'node:sqlite';
import {createHash} from 'node:crypto';
import fs from 'node:fs';import path from 'node:path';
import {sameOrigin,rateLimiter,clientIP} from './security.mjs';
import {inappropriateProfileText,MODERATION_MESSAGE} from '../public/profile-moderation.js';
const day=now=>new Date(now+7*3600000).toISOString().slice(0,10);
export function createGuestbook({identities,directory=process.env.NKTP40_DATA||path.resolve('.data'),clock=Date.now,isAdmin=()=>false}={}){
 fs.mkdirSync(directory,{recursive:true,mode:0o700});const db=new DatabaseSync(path.join(directory,'guestbook.sqlite'));db.exec(`PRAGMA journal_mode=WAL;PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS guestbook(id INTEGER PRIMARY KEY,owner TEXT NOT NULL,day TEXT NOT NULL,sender TEXT NOT NULL,grade TEXT NOT NULL,class_name TEXT NOT NULL,body TEXT NOT NULL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL,hidden INTEGER NOT NULL DEFAULT 0,UNIQUE(owner,day));CREATE INDEX IF NOT EXISTS guestbook_filter ON guestbook(grade,class_name,id);CREATE INDEX IF NOT EXISTS guestbook_owner ON guestbook(owner,id);`);
 db.exec("CREATE TABLE IF NOT EXISTS guestbook_reaction(entry_id INTEGER NOT NULL,actor TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('haha','heart')),PRIMARY KEY(entry_id,actor,kind));");
 function reactions(id,owner){const value={heart:0,haha:0,mine:[]};for(const r of db.prepare('SELECT kind,COUNT(*) n FROM guestbook_reaction WHERE entry_id=? GROUP BY kind').all(id))value[r.kind]=r.n;value.mine=db.prepare('SELECT kind FROM guestbook_reaction WHERE entry_id=? AND actor=?').all(id,owner).map(r=>r.kind);return value;}
 const rate=rateLimiter({clock});
 const rows=owner=>db.prepare('SELECT id,body AS text,created_at AS createdAt,updated_at AS updatedAt,hidden FROM guestbook WHERE owner=? ORDER BY id DESC').all(owner).map(r=>({...r,editable:!r.hidden&&clock()<r.createdAt+900000}));
 function status(owner){const mine=rows(owner),today=day(clock());return{mine,used:mine.length,max:3,canSend:mine.length<3&&!mine.some(r=>day(r.createdAt)===today),serverTime:clock(),nextResetAt:Date.parse(today+'T00:00:00+07:00')+86400000};}
 return{close(){db.close();},async handle(req,res,url){if(!['/api/guestbook','/api/admin-guestbook'].includes(url.pathname))return false;
 res.setHeader('Content-Type','application/json; charset=utf-8');res.setHeader('Cache-Control','no-store');const reply=(code,data)=>{res.writeHead(code);res.end(JSON.stringify(data));return true;};
 const adminRoute=url.pathname==='/api/admin-guestbook';if(adminRoute&&!isAdmin(req))return reply(401,{error:'Cần đăng nhập quản trị.'});
 if(!['GET','POST','PATCH','DELETE'].includes(req.method))return reply(405,{error:'Thao tác không được hỗ trợ.'});
 if(req.method!=='GET'&&!sameOrigin(req))return reply(403,{error:'Yêu cầu không hợp lệ.'});
 const id=(req.headers.cookie||'').match(/(?:^|;\s*)nktp40-player=([a-f0-9]{64})(?:;|$)/)?.[1];
 if(identities.isSuspended(req))return reply(403,{error:'Tài khoản đang bị khóa.'});
 const owner=id?createHash('sha256').update('guestbook:'+id).digest('hex'):null;
 if(!rate(owner||clientIP(req),req.method==='GET'?60:12,60000))return reply(429,{error:'Vui lòng chờ một chút rồi thử lại.'});
 if(req.method==='GET'){
  if(!owner)return reply(401,{error:'Vui lòng thiết lập nhân vật trước.'});
  const year=url.searchParams.get('year')||'',className=url.searchParams.get('class')||'',before=Number(url.searchParams.get('before')||0);
  if(year&&!/^(198[6-9]|199\d|20[01]\d|202[0-6])$/.test(year)||className.length>40||!Number.isSafeInteger(before)||before<0)return reply(400,{error:'Bộ lọc không hợp lệ.'});
  const data=db.prepare('SELECT id,sender,grade,class_name AS className,body AS text,created_at AS createdAt,updated_at AS updatedAt FROM guestbook WHERE hidden=0 AND (?=\'\' OR grade=?) AND (?=\'\' OR class_name=?) AND (?=0 OR id<?) ORDER BY id DESC LIMIT 21').all(year,year,className,className,before,before);
  const more=data.length>20;data.length=Math.min(data.length,20);return reply(200,{canDelete:!!(identities.roleIdentity(req)?.isAdmin&&identities.authorizePresence(req,req.headers['x-nktp-admin-token'])),entries:data.map(r=>({...r,reactions:reactions(r.id,owner)})),next:more?data.at(-1).id:null,...status(owner)});
 }
 let body='',input;try{for await(const c of req){body+=c;if(Buffer.byteLength(body)>12000)return reply(413,{error:'Nội dung quá dài.'});}input=JSON.parse(body);}catch{return reply(400,{error:'Dữ liệu không hợp lệ.'});}
 if(!input||typeof input!=='object'||Array.isArray(input))return reply(400,{error:'Dữ liệu không hợp lệ.'});
 if(adminRoute){if(req.method!=='DELETE'||!Number.isSafeInteger(input.id))return reply(400,{error:'Chọn lưu bút cần ẩn.'});db.prepare('UPDATE guestbook SET hidden=1 WHERE id=?').run(input.id);return reply(200,{ok:true});}
 if(!owner)return reply(401,{error:'Vui lòng thiết lập nhân vật trước.'});
 const profile=identities.roleIdentity(req);if(!profile?.name)return reply(403,{error:'Vui lòng hoàn tất hồ sơ trước khi viết lưu bút.'});
 if(profile.isAdmin&&!identities.authorizePresence(req,req.headers['x-nktp-admin-token']))return reply(403,{error:'Vui lòng xác minh tài khoản quản trị.'});
 if(req.method==='DELETE'){
  if(!profile.isAdmin||!identities.authorizePresence(req,req.headers['x-nktp-admin-token']))return reply(403,{error:'Chỉ admin đã xác minh mới được xóa lưu bút.'});
  if(!Number.isSafeInteger(input.id))return reply(400,{error:'Chọn lưu bút cần xóa.'});
  const result=db.prepare('UPDATE guestbook SET hidden=1 WHERE id=? AND hidden=0').run(input.id);
  if(!result.changes)return reply(404,{error:'Lưu bút không tồn tại hoặc đã được xóa.'});return reply(200,{ok:true});
 }
 if(profile.role!=='teacher'&&!profile.isAdmin&&(!profile.className||!/^\d{4}$/.test(profile.grade||'')))return reply(403,{error:'Vui lòng hoàn tất lớp và năm nhập học.'});
 if(input.action==='react'){
  if(req.method!=='POST'||!Number.isSafeInteger(input.id)||!['heart','haha'].includes(input.kind))return reply(400,{error:'Cảm xúc không hợp lệ.'});
  db.exec('BEGIN IMMEDIATE');try{if(!db.prepare('SELECT id FROM guestbook WHERE id=? AND hidden=0').get(input.id)){db.exec('ROLLBACK');return reply(404,{error:'Không tìm thấy lưu bút.'});}
   const own=db.prepare('SELECT 1 FROM guestbook_reaction WHERE entry_id=? AND actor=? AND kind=?').get(input.id,owner,input.kind);
   if(own)db.prepare('DELETE FROM guestbook_reaction WHERE entry_id=? AND actor=? AND kind=?').run(input.id,owner,input.kind);else db.prepare('INSERT INTO guestbook_reaction(entry_id,actor,kind) VALUES(?,?,?)').run(input.id,owner,input.kind);
   db.exec('COMMIT');return reply(200,{ok:true,reactions:reactions(input.id,owner)});
  }catch(e){db.exec('ROLLBACK');throw e;}
 }
 if(typeof input.text!=='string')return reply(400,{error:'Chỉ hỗ trợ văn bản.'});const text=input.text.normalize('NFC').replace(/[\u0000-\u0008\u000B-\u001F\u007F]/g,'').trim();
 if(!text||Array.from(text).length>1000)return reply(400,{error:'Lưu bút cần có từ 1 đến 1.000 ký tự.'});if(inappropriateProfileText(text))return reply(400,{error:MODERATION_MESSAGE});
 const now=clock();db.exec('BEGIN IMMEDIATE');try{
  if(req.method==='POST'){
   if(!status(owner).canSend){db.exec('ROLLBACK');return reply(409,{error:status(owner).used>=3?'Bạn đã dùng hết 3 lượt lưu bút.':'Bạn đã gửi lưu bút hôm nay. Được viết tiếp từ 00:00 giờ Việt Nam.',...status(owner)});}
   const teacher=profile.role==='teacher',sender=teacher&&!profile.teacherVerified?'Giáo viên (chưa xác minh)':teacher?'Giáo viên '+profile.name:profile.name;
   db.prepare('INSERT INTO guestbook(owner,day,sender,grade,class_name,body,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(owner,day(now),sender,teacher?'':profile.grade||'',teacher?'':profile.className||'',text,now,now);
  }else{
   if(!Number.isSafeInteger(input.id)){db.exec('ROLLBACK');return reply(400,{error:'Lưu bút không hợp lệ.'});}
   const row=db.prepare('SELECT * FROM guestbook WHERE id=? AND owner=? AND hidden=0').get(input.id,owner);
   if(!row){db.exec('ROLLBACK');return reply(404,{error:'Không tìm thấy lưu bút của bạn.'});}if(now>=row.created_at+900000){db.exec('ROLLBACK');return reply(409,{error:'Đã hết thời gian chỉnh sửa 15 phút.'});}
   db.prepare('UPDATE guestbook SET body=?,updated_at=? WHERE id=? AND owner=?').run(text,now,input.id,owner);
  }
  db.exec('COMMIT');return reply(200,{ok:true,...status(owner)});
 }catch(e){db.exec('ROLLBACK');throw e;}
 }};
}
