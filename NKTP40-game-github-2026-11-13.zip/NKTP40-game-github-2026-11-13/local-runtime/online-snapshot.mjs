// Same fresh active presence definition as multiplayer; deduplicate browser tabs.
export function onlineSnapshot(clients,now=Date.now()){
 const total=new Set(),rooms=new Map();let connections=0;
 for(const c of clients.values()){
  if(c.ws.readyState!==1||!c.state?.active||now-c.last>=15000)continue;
  const identity=c.reactionKey||String(c.id);total.add(identity);connections++;
  let room=rooms.get(c.room);if(!room){room={players:new Set(),connections:0};rooms.set(c.room,room);}room.players.add(identity);room.connections++;
 }
 return[{scope:'total',room:'',players:total.size,connections},...[...rooms].map(([room,r])=>({scope:'room',room,players:r.players.size,connections:r.connections}))];
}
