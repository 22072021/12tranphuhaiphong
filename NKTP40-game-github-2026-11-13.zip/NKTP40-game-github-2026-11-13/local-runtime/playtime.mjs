import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
const DAY=86400000,OFFSET=7*3600000,STALE=15000;
// One row per anonymous browser identity per Vietnam day; no names, IPs or motion data.
export function createPlaytime({directory=process.env.NKTP40_DATA||path.resolve('.data'),clock=Date.now}={}){
 fs.mkdirSync(directory,{recursive:true,mode:0o700});
 const db=new DatabaseSync(path.join(directory,'playtime.sqlite'));
 db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS playtime_daily(player TEXT NOT NULL,day TEXT NOT NULL,milliseconds INTEGER NOT NULL,PRIMARY KEY(player,day)); CREATE TABLE IF NOT EXISTS tracking_meta(started_at INTEGER NOT NULL);');
 if(!db.prepare('SELECT started_at FROM tracking_meta').get())db.prepare('INSERT INTO tracking_meta VALUES(?)').run(clock());
 db.exec('CREATE TABLE IF NOT EXISTS online_history(sampled_at INTEGER NOT NULL,scope TEXT NOT NULL,room TEXT NOT NULL,players INTEGER NOT NULL,connections INTEGER NOT NULL,PRIMARY KEY(sampled_at,scope,room));');
 const onlineAdd=db.prepare('INSERT OR IGNORE INTO online_history VALUES(?,?,?,?,?)');
 function snapshot(rows,at=clock()){db.exec('BEGIN IMMEDIATE');try{for(const r of rows)onlineAdd.run(at,r.scope,r.room,r.players,r.connections);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}}
 const add=db.prepare('INSERT INTO playtime_daily VALUES(?,?,?) ON CONFLICT(player,day) DO UPDATE SET milliseconds=milliseconds+excluded.milliseconds');
 const sessions=new Map(),pending=new Map();
 function interval(player,start,end){while(start<end){const stop=Math.min(end,(Math.floor((start+OFFSET)/DAY)+1)*DAY-OFFSET),day=new Date(start+OFFSET).toISOString().slice(0,10),key=player+'|'+day;const row=pending.get(key)||{player,day,ms:0};row.ms+=stop-start;pending.set(key,row);start=stop;}}
 function settle(player,now){const s=sessions.get(player);if(!s)return;let end=s.cursor;for(const last of s.tabs.values())end=Math.max(end,Math.min(now,last+STALE));interval(player,s.cursor,end);s.cursor=end;for(const [tab,last]of s.tabs)if(now>=last+STALE)s.tabs.delete(tab);if(!s.tabs.size)sessions.delete(player);}
 function update(player,tab,active,now=clock()){let s=sessions.get(player);if(!active||!s||![...s.tabs.values()].some(last=>now<=last+STALE)){settle(player,now);s=sessions.get(player);}if(active){if(!s){s={cursor:now,tabs:new Map()};sessions.set(player,s);const day=new Date(now+OFFSET).toISOString().slice(0,10);pending.set(player+'|'+day,pending.get(player+'|'+day)||{player,day,ms:0});}s.tabs.set(tab,now);}else if(s){s.tabs.delete(tab);if(!s.tabs.size)sessions.delete(player);}}
 function flush(){const now=clock();for(const p of sessions.keys())settle(p,now);if(!pending.size)return;db.exec('BEGIN IMMEDIATE');try{for(const r of pending.values())add.run(r.player,r.day,r.ms);db.exec('COMMIT');pending.clear();}catch(e){db.exec('ROLLBACK');throw e;}}
 return{update,flush,snapshot,close(){flush();db.close();}};
}
