const env={NKTP40_ADMIN_CODE:process.env.NKTP40_ADMIN_CODE};
import {bicycleTravelTarget} from '../public/bicycle-travel-target.js';
import {buildBicycleCatalog} from './bicycle-homes.mjs';
import {createWardrobe} from './wardrobe.mjs';
import {ONLINE_GIFT} from '../public/online-gift-plan.js';
import {createFoodService} from './food-service.mjs';
import {profileDetailsError} from '../public/profile-limits.js';
import {createGuestbook} from './guestbook.mjs';
import {FLAG_CEREMONY} from '../public/flag-ceremony-plan.js';
import {CLIENT_RELEASE} from '../public/multiplayer-client-release.js';
import {authorizeInlineScripts,securityHeaders,isPublic,publicHosts,ownOrigin,sameOrigin,clientIP,rateLimiter,createAdminSessions} from './security.mjs';

import {createIdentityService} from './player-identity.mjs';
import {COHORT_ROOMS_ENABLED} from '../public/multiplayer-config.js';
import {attachMultiplayer} from './multiplayer.mjs';


import http from 'node:http';
import {gzipSync} from 'node:zlib';
const compressed=new Map();
import{modelRevision,rewriteModule,moduleVersion,moduleSnapshot,versionedAsset}from'./model-revision.mjs';
import fs from 'node:fs';
import path from 'node:path';
import {createReadStream} from 'node:fs';


const root=path.resolve(process.env.NKTP40_ROOT||process.cwd(),'public');
const port=Number(process.env.PORT||8780);
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.glb':'model/gltf-binary','.mp4':'video/mp4','.m4a':'audio/mp4','.mp3':'audio/mpeg','.ogg':'audio/ogg','.woff2':'font/woff2','.ico':'image/x-icon','.pdf':'application/pdf','.zip':'application/zip','.md':'text/plain; charset=utf-8'};
process.umask(0o077);
const identities=createIdentityService(),adminSessions=createAdminSessions({directory:process.env.NKTP40_DATA||path.resolve('.data'),password:env.NKTP40_ADMIN_CODE}),rate=rateLimiter();
const guestbook=createGuestbook({identities,isAdmin:req=>adminSessions.authenticated(req)});
const authenticatedPlayer=req=>{const id=(req.headers.cookie||'').match(/(?:^|;\s*)nktp40-player=([a-f0-9]{64})(?:;|$)/)?.[1];if(!id||identities.isSuspended(req)||!identities.authorizePresence(req,req.headers['x-nktp-admin-token']))return null;const p=identities.roleIdentity(req);return p&&(p.isAdmin||!profileDetailsError(p,p.role))?{id,isAdmin:!!p.isAdmin,role:p.role}:null;};
const foodService=createFoodService({sameOrigin,presence:id=>multiplayer.presence(id),identity:authenticatedPlayer});
const wardrobe=createWardrobe({sameOrigin,identity:authenticatedPlayer});
const adminRoutes=new Set(['/api/admin-announcements','/api/teacher-verifications','/api/admin-guestbook']);
const server=http.createServer(async(req,res)=>{try{
 securityHeaders(req,res);
 const host=(req.headers.host||'').split(':')[0];
 if(!publicHosts.has(host)&&!['127.0.0.1','localhost','['].includes(host)){res.writeHead(421);return res.end('Host rejected');}
 if(isPublic(req)&&req.headers['x-forwarded-proto']!=='https'){res.writeHead(308,{Location:'https://'+host+(req.url.startsWith('/')&&!req.url.startsWith('//')?req.url:'/'),'Cache-Control':'no-store'});return res.end();}
 const url=new URL(req.url,'http://localhost'),pathname=decodeURIComponent(url.pathname);
 if(req.url.startsWith('/api/')&&!rate('http:'+clientIP(req),6000,60000)){res.writeHead(429,{'Retry-After':'60'});return res.end('Too many requests');}
 // Never accept platform identity/admin headers from the public network.
 for(const key of Object.keys(req.headers))if(key.startsWith('oai-'))delete req.headers[key];
 delete req.headers['x-nktp40-admin-code'];
 if(await adminSessions.handle(req,res,url))return;
 if(adminRoutes.has(pathname)){
  if(!adminSessions.authenticated(req)){res.writeHead(401,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({error:'admin_session_required'}));}
  if(!['GET','HEAD'].includes(req.method)&&!sameOrigin(req)){res.writeHead(403);return res.end('Origin rejected');}
  // Private adapter to existing generated handlers, never returned to client.
  req.headers['x-nktp40-admin-code']=env.NKTP40_ADMIN_CODE;
 }
 if(pathname==='/api/player-profile'&&!rate('profile:'+((req.headers.cookie||'').match(/nktp40-player=([a-f0-9]{64})/)?.[1]||clientIP(req)),120,60000)){res.writeHead(429,{'Retry-After':'60'});return res.end('{}');}
 if(identities.isSuspended(req)&&!pathname.startsWith('/api/')){res.writeHead(403,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});return res.end('<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>Tài khoản tạm khóa</title><main style="font:18px/1.6 system-ui;max-width:560px;margin:20vh auto;padding:24px"><h1>Tài khoản tạm khóa</h1><p>Tài khoản đang tạm khóa để xác minh danh tính.</p></main>');}
 const visitorHost=(req.headers.host||'').split(':')[0]==='12tranphu.mango.pro.vn';
 if(visitorHost&&pathname.startsWith('/api/')&&!['/api/model-revision','/api/player-profile','/api/teacher-verification','/api/flag-ceremony-clock','/api/guestbook','/api/food','/api/wardrobe'].includes(pathname)){res.writeHead(403,{'Cache-Control':'no-store'});return res.end('Visitor only');}
 if(visitorHost&&(pathname.endsWith('.html')&&pathname!=='/index.html'||!path.extname(pathname)&&!['/','/health','/api/model-revision','/api/player-profile','/api/teacher-verification','/api/flag-ceremony-clock','/api/guestbook','/api/food','/api/wardrobe'].includes(pathname))){res.writeHead(302,{Location:'/','Cache-Control':'no-store'});return res.end();}
 if(pathname==='/api/admin-announcements'){
  res.setHeader('Content-Type','application/json; charset=utf-8');res.setHeader('Cache-Control','no-store');
  if(req.method!=='POST'){res.writeHead(405);return res.end(JSON.stringify({error:'Chỉ hỗ trợ gửi thông báo.'}));}
  if(req.headers['x-nktp40-admin-code']!==env.NKTP40_ADMIN_CODE){res.writeHead(401);return res.end(JSON.stringify({error:'Mã quản trị chưa đúng.'}));}
  if(req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host){res.writeHead(403);return res.end(JSON.stringify({error:'Yêu cầu không hợp lệ.'}));}
  let body='';for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>4096){res.writeHead(413);return res.end(JSON.stringify({error:'Thông báo quá dài.'}));}}
  try{const input=JSON.parse(body),message=multiplayer.publishAnnouncement(input.text);return res.end(JSON.stringify({ok:true,message}));}catch(e){res.writeHead(400);return res.end(JSON.stringify({error:e.message}));}
 }
 if(await foodService.handle(req,res,url))return;
 if(await wardrobe.handle(req,res,url))return;
 if(await guestbook.handle(req,res,url))return;
 if(await identities.handleVerification(req,res,url))return;
 if(await identities.handle(req,res,url))return;
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');
 if(pathname==='/downloads/nktp40-map-kit.zip'){res.writeHead(403,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'});return res.end('Bộ tải được cấp qua link riêng có mật khẩu.');}
 if((pathname.startsWith('/sdk/')||pathname.startsWith('/vendor/')))res.setHeader('Access-Control-Allow-Origin','*');
 if(pathname==='/health'){res.setHeader('Content-Type','application/json');return res.end(JSON.stringify({ok:true,security:'20261107.1',storage:'sqlite',site:'standalone-export',model:modelRevision().revision,clientUpdates:multiplayer.clientUpdates}));}
 if(pathname==='/api/flag-ceremony-clock'){if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);return res.end();}res.setHeader('Content-Type','application/json');res.setHeader('Cache-Control','no-store, max-age=0');return res.end(JSON.stringify({serverNow:Date.now(),eventId:FLAG_CEREMONY.id}));}
 if(pathname==='/api/model-revision'){res.setHeader('Content-Type','application/json');res.setHeader('Cache-Control','public, max-age=10, s-maxage=15, stale-while-revalidate=30');const manifest=modelRevision(),tag='"'+manifest.revision+'"';res.setHeader('ETag',tag);if(req.headers['if-none-match']===tag){res.writeHead(304);return res.end();}return res.end(JSON.stringify(manifest));}
 if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);return res.end();}
 let rel=pathname==='/'?'index.html':pathname.slice(1);if(!path.extname(rel))rel+='.html';
 const file=path.resolve(root,rel);if(!file.startsWith(root+path.sep)){res.writeHead(403);return res.end();}
 let stat;try{if(!fs.realpathSync(file).startsWith(fs.realpathSync(root)+path.sep)){res.writeHead(403);return res.end();}stat=fs.statSync(file);if(!stat.isFile())throw Error();}catch{res.writeHead(404);return res.end('Not found');}
 if(file.endsWith('.html')||(file.endsWith('.js')&&!file.includes('/vendor/'))){const snap=file.endsWith('.js')?moduleSnapshot(file,url.searchParams.get('__rev')):null;const revision=snap?.revision||modelRevision().revision;let body=snap?.body||fs.readFileSync(file,'utf8');if(file.endsWith('.html'))body=body.replace(/(<script[^>]+src=["'])([^"']+\.js)(?:\?[^"']*)?(["'])/g,(_,a,b,c)=>a+b+'?__rev='+moduleVersion(path.resolve(path.dirname(file),b))+c);if(file.endsWith('.html'))body=body.replace(/(<link[^>]+href=["'])([^"']+\.css)(?:\?[^"']*)?(["'])/g,(_,a,b,c)=>a+b+'?__asset='+moduleVersion(path.resolve(path.dirname(file),b))+c);if(file.endsWith('.html'))body=body.replace(/(<img\b[^>]*\bsrc=["'])(assets\/[^"'?#]+)(["'])/g,(_,a,b,c)=>a+b+'?__asset='+moduleVersion(path.resolve(path.dirname(file),b))+c);if(file.endsWith('.html'))authorizeInlineScripts(res,body);let bytes=Buffer.from(body);res.setHeader('Content-Type',types[path.extname(file)]);res.setHeader('Cache-Control',snap&&url.searchParams.get('__rev')===revision?'public, max-age=31536000, immutable':'no-cache');const tag='"'+revision+'-'+bytes.length+'"';res.setHeader('ETag',tag);res.setHeader('Vary','Accept-Encoding');if(req.headers['if-none-match']===tag){res.writeHead(304);return res.end();}if(/gzip/.test(req.headers['accept-encoding']||'')){const key=file+tag;let zip=compressed.get(key);if(!zip){zip=gzipSync(bytes);compressed.set(key,zip);if(compressed.size>1000)compressed.delete(compressed.keys().next().value);}bytes=zip;res.setHeader('Content-Encoding','gzip');}res.setHeader('Content-Length',bytes.length);res.writeHead(200);return req.method==='HEAD'?res.end():res.end(bytes);}
 const assetVersion=url.searchParams.get('__asset'),asset=assetVersion?versionedAsset(file,assetVersion):null;
 if(asset){res.setHeader('Cache-Control','public, max-age=31536000, immutable');res.setHeader('ETag','"'+assetVersion+'"');res.setHeader('Content-Type',types[path.extname(file).toLowerCase()]||'application/octet-stream');if(req.headers['if-none-match']==='"'+assetVersion+'"'){res.writeHead(304);return res.end();}let bytes=asset;if(/\.(js|css|json|svg|bin|glb|gltf)$/.test(file)&&/gzip/.test(req.headers['accept-encoding']||'')){const key=file+'@'+assetVersion;let zip=compressed.get(key);if(!zip){zip=gzipSync(asset);compressed.set(key,zip);if(compressed.size>1000)compressed.delete(compressed.keys().next().value);}bytes=zip;res.setHeader('Vary','Accept-Encoding');res.setHeader('Content-Encoding','gzip');}res.setHeader('Content-Length',bytes.length);return req.method==='HEAD'?res.end():res.end(bytes);}

 const etag=`"${stat.size.toString(16)}-${Math.trunc(stat.mtimeMs).toString(16)}"`;res.setHeader('ETag',etag);res.setHeader('Cache-Control',/\/audio\/(?:nang-thien-thanh|mau-cua-noi-nho)-[a-f0-9]{12}\.m4a$/.test(file)?'public, max-age=31536000, immutable':file.includes('/vendor/')?'public, max-age=604800':(/\.(html|js|json|css)$/.test(file)||file.includes('/assets/')||file.includes('/textures/'))?'no-cache':'public, max-age=3600');res.setHeader('Content-Type',types[path.extname(file).toLowerCase()]||'application/octet-stream');res.setHeader('Accept-Ranges','bytes');
 if(req.headers['if-none-match']===etag){res.writeHead(304);return res.end();}
 if(!req.headers.range&&/\.(js|css|json|svg|bin|glb|gltf)$/.test(file)&&/gzip/.test(req.headers['accept-encoding']||'')){const key=file+etag;let zip=compressed.get(key);if(!zip){zip=gzipSync(fs.readFileSync(file));compressed.set(key,zip);if(compressed.size>1000)compressed.delete(compressed.keys().next().value);}res.setHeader('Vary','Accept-Encoding');res.setHeader('Content-Encoding','gzip');res.setHeader('Content-Length',zip.length);res.writeHead(200);return req.method==='HEAD'?res.end():res.end(zip);}
 const range=req.headers.range?.match(/^bytes=(\d+)-(\d*)$/);let start=0,end=stat.size-1,status=200;if(range){start=Number(range[1]);end=range[2]?Math.min(Number(range[2]),end):end;if(start>end){res.writeHead(416);return res.end();}status=206;res.setHeader('Content-Range',`bytes ${start}-${end}/${stat.size}`);}
 res.setHeader('Content-Length',end-start+1);res.writeHead(status);if(req.method==='HEAD')return res.end();createReadStream(file,{start,end}).on('error',()=>res.destroy()).pipe(res);
 }catch(error){console.error(new Date().toISOString(),error.message);if(!res.headersSent)res.writeHead(500);res.end('Server error');}});
server.headersTimeout=15000;server.requestTimeout=20000;server.keepAliveTimeout=5000;server.maxHeadersCount=80;
const multiplayer=attachMultiplayer(server,{bicycleTravelAllowed:(r,id)=>bicycleTravelTarget(JSON.parse(fs.readFileSync(path.join(root,'model-data.json'),'utf8')),id,r),bicycleCatalog:buildBicycleCatalog(JSON.parse(fs.readFileSync(path.join(root,'model-data.json'),'utf8'))),wardrobeState:user=>wardrobe.visit(user),foodIdentity:id=>foodService.activeFood(id),requiredClientRelease:CLIENT_RELEASE,isSuspended:identities.isSuspended,banAccount:identities.banAccount,chatMuteUntil:identities.chatMuteUntil,adminIdentity:identities.adminIdentity,roleIdentity:identities.roleIdentity,authorizePresence:identities.authorizePresence,cohortRooms:process.env.NKTP40_COHORT_ROOMS===undefined?COHORT_ROOMS_ENABLED:process.env.NKTP40_COHORT_ROOMS==='1'});
// One server-side deadline; balances and event receipts commit atomically, once per account.
const giftDelay=ONLINE_GIFT.at-Date.now();
const giftTimer=giftDelay>=-5000?setTimeout(()=>{try{const result=foodService.grantOnlineGift(ONLINE_GIFT,multiplayer.onlineAccounts());console.log('Online gift',ONLINE_GIFT.id,JSON.stringify(result));}catch(e){console.error('Online gift failed',e.message);}},Math.max(0,giftDelay)):null;
giftTimer?.unref();
server.listen(port,process.env.HOST||'127.0.0.1',()=>console.log(`NKTP40 Mac mini listening at http://127.0.0.1:${port}`));

// Flush aggregate statistics on planned restarts; abnormal power loss remains bounded by checkpoints.
let shuttingDown=false;for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>{if(shuttingDown)return;shuttingDown=true;clearTimeout(giftTimer);multiplayer.close();foodService.close();wardrobe.close();identities.close();server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),1500).unref();});
