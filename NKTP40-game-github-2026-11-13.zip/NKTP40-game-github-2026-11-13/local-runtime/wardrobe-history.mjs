import {DatabaseSync} from 'node:sqlite';import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
// Legacy playtime records used midnight Vietnam days, not06h. This is a one-off goodwill backfill, not a reconstruction of exact login times.
export function legacyJeansCandidates(directory){
 const playFile=path.join(directory,'playtime.sqlite'),identityFile=path.join(directory,'nktp40.sqlite');if(!fs.existsSync(playFile)||!fs.existsSync(identityFile))return null;
 const play=new DatabaseSync(playFile,{readOnly:true}),identity=new DatabaseSync(identityFile,{readOnly:true});try{
 const days=play.prepare('SELECT player,day FROM playtime_daily ORDER BY player,day').all(),qualified=new Map();let previous=null,chain=0;
 for(const r of days){chain=previous?.player===r.player&&Date.parse(r.day)-Date.parse(previous.day)===86400000?chain+1:1;if(chain>=3&&!qualified.has(r.player))qualified.set(r.player,r.day);previous=r;}
 const students=identity.prepare("SELECT id FROM player_role WHERE role='student'").all();return students.flatMap(({id})=>{const lastDay=qualified.get(createHash('sha256').update(id).digest('hex'));return lastDay?[{id,lastDay}]:[];});
 }finally{play.close();identity.close();}
}
export function backfillLegacyJeans(db,directory,now){
 db.exec('CREATE TABLE IF NOT EXISTS wardrobe_migration(name TEXT PRIMARY KEY,applied_at INTEGER NOT NULL,awarded INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS legacy_jeans_awards(account TEXT PRIMARY KEY,last_day TEXT NOT NULL);');
 const name='legacy-midnight-days-20261111';if(db.prepare('SELECT 1 FROM wardrobe_migration WHERE name=?').get(name))return;
 const candidates=legacyJeansCandidates(directory);if(!candidates)return;
 db.exec('BEGIN IMMEDIATE');try{let awarded=0;for(const {id,lastDay}of candidates){const old=db.prepare('SELECT unlocked_at FROM student_wardrobe WHERE account=?').get(id);if(!old?.unlocked_at)awarded++;db.prepare("INSERT INTO student_wardrobe(account,last_day,streak,unlocked_at,pants) VALUES(?,'',0,?,'cloth') ON CONFLICT(account) DO UPDATE SET unlocked_at=COALESCE(student_wardrobe.unlocked_at,excluded.unlocked_at)").run(id,now);db.prepare('INSERT OR IGNORE INTO legacy_jeans_awards VALUES(?,?)').run(id,lastDay);}db.prepare('INSERT INTO wardrobe_migration VALUES(?,?,?)').run(name,now,awarded);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
}
