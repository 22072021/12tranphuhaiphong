# 12 Trần Phú – Bản đồ và trò chơi

Bản xuất mã nguồn ngày **13/11/2026**, dùng để đưa lên một repository GitHub mới. Chia sẻ **phi thương mại** theo LICENSE.md.

## Bao gồm

- Toàn bộ bản đồ và các tòa nhà, sân trường, ngõ ngoại ngữ, cửa hàng, nội thất, vật dụng và mô hình xe.
- Nhân vật học sinh/giáo viên, đồng phục, áo dài, quần bò; NPC, thoại, tư thế và animation.
- Đi lại, va chạm, cầu thang, cửa, ngồi ghế/bậc thềm/mái, leo rào, xe đạp/chở người/trả xe/di chuyển nhanh/bộ đệm250ms.
- Quán net/chọn game; ăn uống/ví tiền/quà sự kiện; đứng phạt/bảng vàng; hiệu ứng cặp đôi học sinh; chữ chào mừng trên bảng và chụp hình.
- Máy chủ WebSocket, hồ sơ nhân vật, duyệt giáo viên, thông báo admin, chat/cấm chat/ban, lưu bút/reaction, thống kê và các module sự kiện. Các cơ chế chạy với dữ liệu MỚI của bản cài riêng.

## Không bao gồm

Ảnh/video khảo sát và ảnh tham chiếu gốc; hồ sơ góc máy/vị trí ảnh và dữ liệu duyệt; toàn bộ cơ sở dữ liệu người dùng, tài khoản, chat, lưu bút, bảng điểm, thống kê và lịch sử thực tế; mật khẩu, cookie, token, khóa và cấu hình máy chủ/Cloudflare; lịch sử Git, bản sao lưu, node_modules và công cụ cấp link tải riêng.

Giữ các bản texture tối ưu dùng trực tiếp khi render, không giữ ảnh khảo sát gốc. Riêng bảng cổng dùng ảnh đã xử lý sẵn; bảng huân chương A1 dùng phần vẽ chữ bằng canvas, bỏ thao tác tải ảnh tên bảng gốc. Các thay đổi đóng gói chỉ nằm trong bản xuất, không sửa website đang hoạt động.

## Chạy trên máy tính

Cần Node.js **24 trở lên** và npm. Mở terminal tại thư mục có package.json:

~~~sh
npm install
npm start
~~~

Mở **http://127.0.0.1:8780**. Máy chủ tạo kho SQLite mới trong .data/. Không có dữ liệu người dùng sẵn. Đây là game có backend; **GitHub Pages không chạy được đầy đủ** các chức năng online/SQLite/WebSocket. Có thể dùng GitHub để lưu/chia sẻ mã, sau đó chạy trên máy hoặc máy chủ Node riêng.

Có thể sao chép .env.example thành .env và tự đặt NKTP40_ADMIN_CODE. Nếu chưa đặt, lần chạy đầu tự tạo mật khẩu riêng tại .data/local-admin-password. Không đưa .env hoặc .data lên GitHub.

## Tài khoản admin của bản cài riêng

1. Chạy game và tạo nhân vật trên bản cài riêng, sau đó dừng máy chủ.
2. Chạy npm run admin để xem danh sách tài khoản của bản cài.
3. Chạy npm run admin -- 1 (thay1 bằng số tài khoản muốn cấp quyền).
4. Chạy lại npm start. Đăng nhập/mở khóa bằng mật khẩu riêng của bản cài. Trang /teacher-verifications.html dùng để duyệt giáo viên; /announcements.html gửi thông báo. Đăng nhập quản trị bằng mật khẩu riêng của bản cài. Giao diện chat của tài khoản admin có thao tác cấm chat/ban.

## Đưa lên GitHub

Giải nén ZIP; tải **nội dung bên trong** thư mục này lên repository mới (README.md, package.json, public/, local-runtime/, scripts/…), không chỉ tải mỗi ZIP. Có thể dùng GitHub Desktop hoặc Git. Không có file đơn lẻ trên100MB và không cần Git LFS cho gói hiện tại. Chạy npm run check trước khi chia sẻ.

## Tùy chỉnh / tích hợp

- public/model-data.json: dữ liệu hình học/bố trí cuối cùng cần dựng bản đồ; đây không phải ảnh/tư liệu gốc khảo sát.
- public/building-geometry.js, public/buildings/, public/site-features.js, public/furniture/: dựng mô hình.
- public/student/, public/characters/, public/visitor-avatar.js: nhân vật/animation.
- public/model-view.js, public/walk-physics.js: vòng lặp cảnh, điều khiển và tương tác.
- local-runtime/server.mjs, multiplayer.mjs và các service: cơ chế online/lưu dữ liệu.
- Các mốc sự kiện2026 trong module chào cờ/quà/xếp chữ/thông báo đóng cửa là cấu hình lịch sử được giữ để tham khảo; đổi lịch/nội dung trước khi mở bản cài mới. Thông báo đóng cửa chỉ là thông báo, không phải mã tự xóa dữ liệu của bản cài.
- Email liên hệ đã thay bằng admin@example.invalid trong bản xuất; thay bằng địa chỉ của người vận hành.

Các module dùng Three.js với đơn vị mét, trục Y đứng; tái dùng game nên giữ hệ tọa độ chung. Khi tích hợp engine khác cần chuyển mô hình và tự nối lại tương tác/mạng. Xem THIRD_PARTY_NOTICES.md trước khi tái sử dụng tài sản.
