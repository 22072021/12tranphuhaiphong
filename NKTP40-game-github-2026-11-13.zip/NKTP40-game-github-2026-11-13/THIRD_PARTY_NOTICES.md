# Tài sản và thư viện bên thứ ba

- Three.js và các module đi kèm: public/vendor/THREE-LICENSE.txt.
- ws: giấy phép MIT tại third_party/ws-LICENSE.txt và trong gói npm.
- Font: public/assets/fonts/*OFL.txt.
- Cây và mô hình xe máy, dụng cụ thể thao: SOURCE.txt/SOURCES.txt trong thư mục tài sản tương ứng.
- Bản ghi âm: public/audio/SOURCES.txt. Hai bài nhạc kỷ niệm giữ tên tác giả/người trình bày trong public/background-music.js; không mặc định cấp quyền sử dụng thương mại hoặc cấp lại bản quyền các bản ghi.
- Ảnh màn hình game: public/textures/cafe-games/SOURCES.txt; quyền trò chơi/hình ảnh thuộc chủ sở hữu tương ứng, không do giấy phép mã nguồn chuyển giao.
- Logo trường, bảng hiệu, ảnh chân dung và hình dùng làm texture giữ quyền của chủ sở hữu tương ứng.

Chỉ giữ các texture/mô hình/âm thanh phục vụ trò chơi và ghi công nguồn. Không kèm ảnh khảo sát toàn cảnh, video gốc, hồ sơ đối chiếu hay kho tài liệu dùng phục dựng. Trước khi tái phân phối tài sản bên thứ ba cho mục đích khác, cần tự kiểm tra phạm vi quyền tương ứng.
