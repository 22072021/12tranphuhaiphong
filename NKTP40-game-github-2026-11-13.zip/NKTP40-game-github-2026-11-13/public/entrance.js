import {createMainGate} from './main-gate.js';
import {auxiliaryGatePlan,subtractGateIntervals,createAuxiliaryGate} from './entrance-side-gates.js';
import {createGateSign} from './gate-sign.js?v=222.0';
import {createStairDoor} from './interactive-door.js?v=222.0';
import {createStreetShops} from './street-context.js?v=222.0';
import * as THREE from './vendor/three.module.js';
import {makeOpeningWall} from './wall-openings.js?v=222.0';
import {smoothArc} from './curved-surfaces.js?v=28.0';
import {ENTRANCE} from './entrance-layout.js?v=34.0';
export {ENTRANCE};
import {geometryKit} from './geometry-kit.js?v=222.0';
// Approximate entrance alignment: street side between K01 and the north end of K09.
// Roofs/trees obscure the satellite threshold. These are not surveyed boundary coordinates.
export function entranceBlocks(x,z,padding=.45){const q=ENTRANCE,dx=x-q.x,dz=z-q.z,a=-q.guard.rotation*Math.PI/180,c=Math.cos(a),s=Math.sin(a),gx=dx-q.guard.x,gz=dz-q.guard.z;return (Math.abs(dx)<.35+padding&&dz>=q.fence.from&&dz<=-q.opening/2)||(Math.abs(c*gx-s*gz)<q.guard.width/2+padding&&Math.abs(s*gx+c*gz)<q.guard.length/2+padding);}
export function createEntrance({gateAngle=0,fenceFrom=ENTRANCE.fence.from}={}){
 const root=new THREE.Group();root.name='entrance';root.position.set(ENTRANCE.x,0,ENTRANCE.z);
 const wall='#e3ca8c',edge='#eadbb3',panel='#c4a16a',green='#205244',brick='#9a5746';
 function part(id){const g=new THREE.Group();g.name=id;g.userData.id=id;root.add(g);return [g,geometryKit(g)];}
 function text(k,words,x,y,z,w,h,ry,color='#e9e4d0',ink='#305d75'){const m=k.solid(new THREE.PlaneGeometry(w,h),color,'entrance-sign');m.position.set(x,y,z);m.rotation.y=ry;m.userData.signText=words;m.userData.textColor=ink;if(words==='TRƯỜNG TRẦN PHÚ')m.userData.signLines=['TRƯỜNG','TRẦN PHÚ'];}
 const [gate,k]=part('GATE'),{box,beam}=k;gate.add(createMainGate({gateAngle,width:ENTRANCE.opening}));const v=(x,y,z)=>new THREE.Vector3(x,y,z);
 for(const s of [-1,1]){
  const z=s*2.65;box(.9,4.104,.9,0,2.052,z,'#efe3bf');
  for(const [y,w] of [[3.6,.95],[3.69,1.05],[3.77,.98]])box(w,.1026,w,0,y*1.14,z,'#eee1ba');
  for(const y of [.45,1.17,2.13,2.78]){const w=.67,h=.6612,r=.065,shape=new THREE.Shape();shape.moveTo(-w/2+r,-h/2);shape.lineTo(w/2-r,-h/2);shape.quadraticCurveTo(w/2-r,-h/2+r,w/2,-h/2+r);shape.lineTo(w/2,h/2-r);shape.quadraticCurveTo(w/2-r,h/2-r,w/2-r,h/2);shape.lineTo(-w/2+r,h/2);shape.quadraticCurveTo(-w/2+r,h/2-r,-w/2,h/2-r);shape.lineTo(-w/2,-h/2+r);shape.quadraticCurveTo(-w/2+r,-h/2+r,-w/2+r,-h/2);const plaque=k.solid(new THREE.ExtrudeGeometry(shape,{depth:.028,bevelEnabled:false}),'#dbbb80','gate-pier-shaped-panel');plaque.rotation.y=-Math.PI/2;plaque.position.set(-.453,y*1.14,z);}
  for(const y of [1.66,3.27]){const m=k.solid(new THREE.CylinderGeometry(.14,.14,.06,24),'#e8c786','roundel');m.rotation.z=Math.PI/2;m.position.set(-.49,y*1.14,z);}
 }
 // New owner-supplied red sign reference, date unverified.
 gate.add(createGateSign());
 // Solid side wall beside the first fence panel.
 box(.3,2.95,3.4,0,1.475,-4.7,wall);for(const y of [2.98,3.05])box(.42,.07,3.5,0,y,-4.7,edge);k.finish();
 const [fence,f]=part('FENCE');const lo=Math.min(fenceFrom,ENTRANCE.fence.from),hi=ENTRANCE.fence.to;
 const bays=Math.max(9,Math.round((hi-lo)/3.2)),span=(hi-lo)/bays;
 // P04: recessed red brick panels between cream masonry piers, with opaque steel above.
 const auxiliaryGates=auxiliaryGatePlan(lo,hi,bays);
 for(const [a,b]of subtractGateIntervals(lo,hi,auxiliaryGates))f.box(.25,.90,b-a,0,.45,(a+b)/2,wall);
 for(const spec of auxiliaryGates)fence.add(createAuxiliaryGate(spec));
 for(let j=0;j<bays;j++){
  const center=lo+(j+.5)*span;for(const [a,b]of subtractGateIntervals(center-(span-.27)/2,center+(span-.27)/2,auxiliaryGates,.025)){const z=(a+b)/2,width=b-a;
  f.box(.025,.69,width,-.14,.43,z,brick);f.box(.025,.69,width,.14,.43,z,brick);
  for(let y=.12;y<.79;y+=.09)for(const x of [-.157,.157])f.box(.008,.009,width,x,y,z,'#784333');
  f.box(.33,.11,width,0,.90,z,edge);

  for(let dz=-width/2+.09;dz<width/2;dz+=.18){f.box(.035,1.94,.028,-.035,1.94,z+dz,green);const sp=f.solid(new THREE.ConeGeometry(.035,.18,4),green,'fence-spear');sp.position.set(-.035,3.0,z+dz);}
  for(const y of [1.02,1.22,2.52,2.80])f.box(.075,.045,width,-.025,y,z,green);
  for(let dz=-width/2+.22;dz<width/2;dz+=.35){const ring=f.solid(new THREE.TorusGeometry(.075,.012,6,20),green,'fence-ring-band');ring.rotation.y=Math.PI/2;ring.position.set(-.05,1.82,z+dz);}
  // Continuous pointed fan motif and curled feet, rather than circular arches.
  const motif=(scale,dy)=>{const pts=[];for(let i=0;i<=32;i++){const t=i/32,u=(t-.5)*.82*scale,y=2.83+dy+.57*scale*Math.pow(1-Math.abs(2*t-1),.55);pts.push(v(-.045,y,z+u));}smoothArc(f,pts,.017,green,'pointed-fan');};
  const motifScale=Math.min(1,width/1.20);motif(motifScale,0);motif(.73*motifScale,0);for(const d of [-.22,0,.22])f.beam(v(-.045,2.83,z+d),v(-.045,3.27-Math.abs(d)*.65,z+d*.6),.025,green);
  for(const side of [-1,1]){const pts=Array.from({length:30},(_,i)=>{const t=i/29*Math.PI*1.65,r=.12*(1-i/40);return v(-.045,2.88+r*Math.sin(t),z+side*(.42+r*Math.cos(t)));});smoothArc(f,pts,.014,green,'fan-scroll');}
 }
 }
 for(let j=0;j<=bays;j++){
  const z=lo+j*span;if(auxiliaryGates.some(q=>Math.abs(z-q.z)<q.width/2+.24))continue;f.box(.34,.96,.27,0,.48,z,wall);
  for(const x of [-.12,.12])for(const dz of [-.12,.12])f.box(.045,2.43,.045,x,2.08,z+dz,green);
  for(const y of [1.0,1.7,2.5,3.24])f.box(.28,.04,.28,0,y,z,green);
  for(const y of [3.31,3.73])f.box(.43,.055,.43,0,y,z,green);
  for(const x of [-.185,.185])for(const dz of [-.185,.185])f.box(.038,.40,.038,x,3.52,z+dz,green);
  for(const x of [-.19,.19])for(const sign of [-1,1])f.beam(v(x,3.34,z-sign*.17),v(x,3.70,z+sign*.17),.025,green);
  for(const dz of [-.19,.19])for(const sign of [-1,1])f.beam(v(-sign*.17,3.34,z+dz),v(sign*.17,3.70,z+dz),.025,green);
 }
 fence.userData.evidence={photos:['P03','P04'],opaquePanel:false,solidGateWing:3.4,bays};f.finish();
 const join=geometryKit(root),qg=ENTRANCE.guard,joinFront=qg.z-qg.length/2,joinRear=qg.z+qg.length/2;join.box(.25,2.7,joinFront-2.9,0,1.35,(joinFront+2.9)/2,wall);join.box(4.42,2.7,.24,2.1,1.35,joinRear,wall);join.finish();root.add(createStreetShops());

 const [guard,g]=part('GUARD');const q=ENTRANCE.guard;guard.position.set(q.x,0,q.z);guard.rotation.y=-q.rotation*Math.PI/180;
 const height=2.7;
 // The street wall stays on the fence line; the door faces the gate at -Z.
 g.box(.22,height,q.length,-q.width/2+.11,height/2,0,wall);
 g.box(q.width,height,.22,0,height/2,q.length/2-.11,wall);
 makeOpeningWall(guard,{side:1,wallX:q.width/2,faceV:0,from:-q.length/2,to:q.length/2,height,color:wall,openings:[{u:0,y:1.55,width:1.4,height:1.15,kind:'window'}]});
 const gateFace=new THREE.Group();gateFace.name='guard-gate-facade';gateFace.rotation.y=Math.PI/2;guard.add(gateFace);const guardDoorU=(q.width/2+(-.85+1.4/2))/2;
 makeOpeningWall(gateFace,{side:1,wallX:q.length/2,faceV:0,from:-q.width/2,to:q.width/2,height,color:wall,openings:[{u:guardDoorU,y:1.05,width:.9,height:2.1,kind:'door'},{u:-.85,y:1.55,width:1.4,height:1.15,kind:'window'}]});
 const front=geometryKit(gateFace),face=q.length/2;
 // Recessed door, jambs and a leaf attached to its hinge, opening inward.
 for(const u of [guardDoorU-.45,guardDoorU+.45])front.box(.16,2.1,.055,face-.10,1.05,u,green);
 front.box(.16,.07,.91,face-.10,2.1,guardDoorU,green);front.box(.24,.055,.91,face-.10,.0275,guardDoorU,'#8d8776');
 gateFace.add(createStairDoor({side:1,wallX:face,u:guardDoorU,y:1.05,v:-.10,width:.9,height:2.06,color:green,single:true,glazed:true}));
 for(const y of [.24,1.8])front.cylinder(.018,.12,face-.10,y,guardDoorU-.41,'#504b3e');
 front.box(.32,.09,1.08,face+.04,2.25,guardDoorU,edge);
 function barredWindow(kit,x,y,z,width,h){for(const u of [-width/2,width/2])kit.box(.13,h+.09,.045,x-.07,y,z+u,green);for(let u=-width/2+.12;u<width/2;u+=.15)kit.box(.025,h,.025,x-.035,y,z+u,'#d7dccf');for(const yy of [y-h/2,y+h/2])kit.box(.14,.055,width+.09,x-.06,yy,z,green);kit.box(.24,.07,width+.2,x+.015,y+h/2+.12,z,panel);}
 barredWindow(front,face,1.55,-.85,1.4,1.15);
 // R50: two opaque wooden shutters folded outward, with an open barred aperture.
 for(const sign of [-1,1]){const center=-.85+sign*1.04;front.box(.045,1.10,.66,face+.035,1.55,center,'#80998a');for(const edge of [-1,1]){front.box(.06,1.10,.035,face+.06,1.55,center+edge*.31,green);front.box(.06,.045,.66,face+.06,1.55+edge*.52,center,green);}front.box(.055,.045,.66,face+.06,1.55,center,green);}front.box(.035,.05,1.4,face-.035,1.55,-.85,'#d7dccf');barredWindow(g,q.width/2,1.55,0,1.4,1.15);
 for(const u of [-.35,.35]){g.box(.055,1.04,.64,q.width/2-.075,1.55,u,'#476b60');for(const d of [-.32,.32])g.box(.085,1.10,.035,q.width/2-.025,1.55,u+d,green);g.box(.08,.035,.64,q.width/2-.02,1.55,u,green);}
 g.box(.10,1.15,.045,q.width/2-.015,1.55,0,green);
 text(front,'BẢO VỆ',face+.02,2.48,guardDoorU,.48,.18,Math.PI/2,'#f2eee2','#a76161');front.finish();
 for(const z of [-.8,.8]){g.box(.10,.20,.44,-q.width/2-.025,2.33,z,'#3b493e');g.box(.16,.045,.54,-q.width/2-.06,2.46,z,edge);}
 g.box(q.width,.08,q.length,0,.04,0,'#9c998c');g.box(q.width+.4,.14,q.length+.4,0,height+.07,0,edge);g.box(q.width+.25,.09,q.length+.25,0,height+.185,0,panel);g.finish();
 guard.userData.doorFacing={x:0,z:-1};guard.userData.doorCenterU=guardDoorU;guard.userData.estimatedDimensions={width:q.width,length:q.length,height};
 root.userData.basis=ENTRANCE.uncertainty;return root;
}
