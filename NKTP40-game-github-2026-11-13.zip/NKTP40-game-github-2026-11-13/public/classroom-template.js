import {addClassroomWelcome} from './classroom-welcome.js';
import {addBoardStats,BOARD_STATS_LABELS} from './board-stats.js';
import {registerTeacherChair} from './teacher-chair-seat.js';
import {lazyFloor} from './interior-streaming.js';
import {applyA2ClassroomFloor} from './a2-classroom-floor.js?v=214.0';
import {applyCorridorTiles} from './corridor-tiles.js?v=222.0';
import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
import {emitStudentDesk,STUDENT_DESK} from './student-desk.js?v=69.0';
import {disposeObject} from './building-cache.js?v=46.0';
import {subtractFloorRect} from './building-bases.js?v=223.0';
// One evidence-based furniture/finish definition; room envelopes retain their own openings.
export const CLASSROOM_TEMPLATE={id:'school-classroom-v69',revision:69,windowLayers:['outer-timber','inner-iron'],windowGlazed:false,deskWidth:1.30,deskDepth:.48,deskHeight:.74,benchHeight:.43,rowPitch:1.08,aisle:.76,tileSize:.30,sources:['R17','R18','R60','R65','R89','R90','R91','R92','R108','R109']};
export function classroomLayout(s,settings={}){
 const p={...CLASSROOM_TEMPLATE,...settings},width=s.xmax-s.xmin,depth=s.zmax-s.zmin,cx=(s.xmin+s.xmax)/2,frontSide=s.side??-1,end=(s.buildingId==='B1'||s.buildingId==='B2')&&Number.isFinite(s.boardEnd)?s.boardEnd:s.buildingId==='A2'&&Number.isFinite(s.doorU)?(s.doorU<(s.zmin+s.zmax)/2?-1:1):-frontSide,boardZ=end>0?s.zmax-.08:s.zmin+.08;
 const banks=2,tablesPerBank=2,rows=s.rows??5,pairGap=.06,tableW=Math.min(p.deskWidth,(width-.84-p.aisle-2*pairGap)/4),bankWidth=2*tableW+pairGap,first=boardZ-end*2.05,rowPitch=Math.min(p.rowPitch,(depth-2.05-.45-.52)/Math.max(1,rows-1));
 if(tableW<1.0||rowPitch<.78)throw new Error('Room too small for the confirmed forty-seat classroom');
 const sideClearance=p.tileSize/4,aisle=width-2*bankWidth-2*sideClearance;
 const desks=[];for(let row=0;row<rows;row++)for(let bank=0;bank<banks;bank++)for(let table=0;table<tablesPerBank;table++){const bankCenter=cx+(bank?1:-1)*(width/2-sideClearance-bankWidth/2);desks.push({row,bank,table,x:bankCenter+(table-.5)*(tableW+pairGap),z:first-end*row*rowPitch,seatZ:first-end*(row*rowPitch+.52)});}
 const teacher={x:s.buildingId==='B1'&&s.roomIndex===3&&s.teacherDesk?s.teacherDesk.x:cx-frontSide*(width/2-.75),z:boardZ-end*1.10,supportHeight:.18,width:1.2,depth:.6};
 const podiumMin=frontSide===1?s.xmin+.03:s.xmin+.82,podiumMax=frontSide===1?s.xmax-.82:s.xmax-.03;
 const podium={height:.18,main:{xmin:podiumMin,xmax:podiumMax,z:boardZ-end*.49,depth:1.0},extension:{xmin:Math.max(podiumMin,teacher.x-.72),xmax:Math.min(podiumMax,teacher.x+.72),z:teacher.z,depth:.84}};
 return{...p,width,depth,cx,frontSide,doorSide:frontSide===-end?'left-from-board':'right-from-board',teacherSide:'right-from-board',boardEnd:end,boardZ,rows,banks,tablesPerBank,tableW,pairGap,rowPitch,desks,teacherDesk:teacher,podium,capacity:rows*8,sideClearance,aisle};
}

function floorShader(material,tile){material.onBeforeCompile=sh=>{
 sh.vertexShader='varying vec2 vClassroomTile;\n'+sh.vertexShader;sh.vertexShader=sh.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
 vec4 q=vec4(position,1.0);
 #ifdef USE_INSTANCING
 q=instanceMatrix*q;
 #endif
 vClassroomTile=q.xz/${tile.toFixed(3)};`);
 sh.fragmentShader='varying vec2 vClassroomTile;\n'+sh.fragmentShader;sh.fragmentShader=sh.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
 vec2 p=fract(vClassroomTile)-0.5;float r=length(p),a=atan(p.y,p.x),aa=max(length(fwidth(vClassroomTile)),.002);
 float flower=.22+.075*cos(a*8.0);vec3 cream=vec3(.72,.64,.45),rose=vec3(.47,.30,.23),sage=vec3(.42,.45,.33);
 vec3 tileColor=mix(cream,rose,1.0-smoothstep(flower-aa,flower+aa,r));
 tileColor=mix(tileColor,cream,1.0-smoothstep(flower-.035-aa,flower-.035+aa,r));
 float ring=1.0-smoothstep(.015,.015+aa,abs(r-.405));tileColor=mix(tileColor,sage,ring*.72);
 float core=1.0-smoothstep(.065-aa,.065+aa,r);tileColor=mix(tileColor,rose,core);
 float edge=smoothstep(.488-aa,.498,max(abs(p.x),abs(p.y)));tileColor=mix(tileColor,vec3(.37,.35,.29),edge*.55);
 diffuseColor.rgb=tileColor;`);
 };material.customProgramCacheKey=()=>`classroom-flower-floor-v63-${tile}`;material.userData.classroomFlowerFloor=true;}
function textPanel(group,cache,text,x,y,z,width,height,end){
 const key=text;let mat=cache.get(key);if(!mat){if(typeof document==='undefined')mat=new THREE.MeshBasicMaterial({color:'#f5ebd5'});else{const c=document.createElement('canvas');c.width=768;c.height=192;const ctx=c.getContext('2d'),stats=text.includes('Sĩ số:');ctx.clearRect(0,0,768,192);if(!stats){ctx.fillStyle='#f5edd7';ctx.fillRect(0,0,768,192);}ctx.fillStyle=stats?'#f6f3e8':'#a72b33';ctx.font=stats?'60px Arial':'bold 90px Arial';ctx.textAlign=stats?'left':'center';ctx.textBaseline='middle';if(stats)text.split('\n').forEach((line,i)=>ctx.fillText(line,30,52+i*83,700));else ctx.fillText(text,384,100,730);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;mat=new THREE.MeshBasicMaterial({map:t,transparent:stats,depthWrite:!stats});}cache.set(key,mat);}

 const mesh=new THREE.Mesh(new THREE.PlaneGeometry(width,height),mat);mesh.position.set(x,y,z);mesh.rotation.y=end>0?Math.PI:0;mesh.userData.walkRole='none';mesh.name='classroom-wall-lettering';group.add(mesh);
}
export function createClassroomInteriors(specs,settings={}){
 if(typeof document==='undefined'||!globalThis.NKTP_LAZY_INTERIORS)return buildClassroomInteriors(specs,settings);
 const root=new THREE.Group();root.name='shared-classroom-interiors';root.userData={template:CLASSROOM_TEMPLATE.id,roomSpecs:specs,settings,lazy:true};const floors=new Map();for(const spec of specs){const key=spec.level||0;if(!floors.has(key))floors.set(key,[]);floors.get(key).push(spec);}for(const spec of specs){const a=[spec];const slot=new THREE.Group();slot.name='classroom-floor-stream-slot';root.add(slot);lazyFloor(slot,a,()=>buildClassroomInteriors(a,settings));}return root;
}
function buildClassroomInteriors(specs,settings={}){
 const root=new THREE.Group();root.name='shared-classroom-interiors';root.userData={template:CLASSROOM_TEMPLATE.id,templateRevision:69,roomSpecs:specs,settings};const k=geometryKit(root),labels=new Map(),wood='#b08a52',steel='#79827c',floorColor='#c8ad79',white='#f4f3eb';
 for(const s of specs){const p=classroomLayout(s,settings),level=s.level??0,ch=s.clearHeight??3.5,end=p.boardEnd,bz=p.boardZ,depth=p.depth,cx=p.cx;
  const box=(w,h,d,x,y,z,c)=>k.box(w,h,d,x,y+level,z,c);
  const anchor=new THREE.Group();anchor.name='furnished-classroom';anchor.position.y=level;anchor.userData={...p,desks:p.desks,studentDesk:STUDENT_DESK,teacherPlatform:true,portraitAboveBoard:true,boardStats:{labels:BOARD_STATS_LABELS,corner:'top-right-facing-board'},teacherDesk:p.teacherDesk,doorU:s.doorU,seatsPerDesk:2,estimatedInterior:true,sharedTemplate:CLASSROOM_TEMPLATE.id,buildingId:s.buildingId,roomIndex:s.roomIndex,floor:s.floor};anchor.userData.seatLanes=[];for(let row=0;row<p.rows;row++)for(let bank=0;bank<2;bank++){const ds=p.desks.filter(d=>d.row===row&&d.bank===bank);anchor.userData.seatLanes.push({xmin:Math.min(...ds.map(d=>d.x-p.tableW/2)),xmax:Math.max(...ds.map(d=>d.x+p.tableW/2)),z:ds[0].seatZ,height:.43,end});}root.add(anchor);
  box(p.width,.014,depth,cx,-.007,(s.zmin+s.zmax)/2,floorColor);
  if(s.divider)box(p.width,.0+ch,.12,cx,ch/2,s.zmax+.12,'#e8dfc4');
  // A single upward floor surface avoids coplanar tile overlays. Ceiling remains above head height.
  box(p.width,.025,depth,cx,ch-.0125,(s.zmin+s.zmax)/2,white);
  const pm=p.podium.main,pe=p.podium.extension,rect=part=>({x0:part.xmin,x1:part.xmax,z0:part.z-part.depth/2,z1:part.z+part.depth/2});
  for(const r of [rect(pm),...subtractFloorRect(rect(pe),rect(pm))])box(r.x1-r.x0,p.podium.height,r.z1-r.z0,(r.x0+r.x1)/2,p.podium.height/2,(r.z0+r.z1)/2,'#b3ada0');
  // Yellow teaching-wall finish, behind the board and clear of existing masonry.
  const teachingWall=new THREE.Mesh(new THREE.PlaneGeometry(p.width,ch-.03),new THREE.MeshStandardMaterial({color:'#dec17a',roughness:1}));
  teachingWall.name='classroom-yellow-teaching-wall';teachingWall.position.set(cx,level+(ch-.03)/2,bz+end*.04);teachingWall.rotation.y=end>0?Math.PI:0;teachingWall.receiveShadow=true;teachingWall.userData={walkRole:'none',teachingWall:true,buildingId:s.buildingId,floor:s.floor};root.add(teachingWall);
  const boardW=Math.min(4.1,p.width-.65);box(boardW,1.32,.055,cx,1.95,bz,'#315b50');
  for(const y of [1.27,2.63])box(boardW+.12,.045,.09,cx,y,bz-end*.012,'#d8dbd0');for(const x of [cx-boardW/2-.035,cx+boardW/2+.035])box(.05,1.40,.09,x,1.95,bz-end*.012,'#d8dbd0');box(boardW,.045,.16,cx,1.24,bz-end*.075,'#8f9690');
  textPanel(root,labels,'DẠY TỐT',cx+end*boardW*.33,level+2.94,bz-end*.055,1.12,.26,end);textPanel(root,labels,'HỌC TỐT',cx-end*boardW*.33,level+2.94,bz-end*.055,1.12,.26,end);
  addBoardStats(root,labels,{width:boardW,x:cx,y:level+1.95,z:bz,end});
  addClassroomWelcome(root,{spec:s,width:boardW,x:cx,y:level+1.95,z:bz,end});
  // The same real, credited portrait is reused in every classroom; no generated face.
  let portraitMaterial=labels.get('ho-chi-minh-portrait');if(!portraitMaterial){portraitMaterial=new THREE.MeshBasicMaterial({color:'#ffffff'});if(typeof document!=='undefined'){const tx=new THREE.TextureLoader().load(new URL('./assets/runtime/portrait-small.jpg',import.meta.url).href);tx.colorSpace=THREE.SRGBColorSpace;portraitMaterial.map=tx;}labels.set('ho-chi-minh-portrait',portraitMaterial);}
  const portrait=new THREE.Mesh(new THREE.PlaneGeometry(.36,.48),portraitMaterial);portrait.position.set(cx,level+3.12,bz-end*.075);portrait.rotation.y=end>0?Math.PI:0;portrait.name='classroom-ho-chi-minh-portrait';portrait.userData={walkRole:'none',portraitOf:'Ho Chi Minh',imageSrc:'assets/runtime/portrait-small.jpg'};root.add(portrait);
  box(.41,.53,.045,cx,3.12,bz-end*.035,'#b7a06e');
  // Rolled screen and ceiling projector; one centered clock on the rear wall.
  k.withCollision('none',()=>{box(1.72,.08,.13,cx,2.73,bz-end*.10,'#d8dbd0');box(.35,.10,.25,cx,ch-.40,(s.zmin+s.zmax)/2,'#d8dbd0');box(.035,.24,.035,cx,ch-.22,(s.zmin+s.zmax)/2,'#79827c');box(.08,.065,.035,cx,ch-.40,(s.zmin+s.zmax)/2+end*.14,'#394845');
   const rear=end>0?s.zmin+.18:s.zmax-.18;
   const clock=new THREE.Mesh(new THREE.CircleGeometry(.16,24),new THREE.MeshBasicMaterial({color:'#f1eddd'}));clock.position.set(cx,level+2.65,rear+end*.04);clock.rotation.y=end>0?0:Math.PI;clock.userData.walkRole='none';clock.name='classroom-rear-clock';root.add(clock);box(.015,.11,.012,cx,2.70,rear+end*.055,'#394845');box(.09,.015,.012,cx+.04,2.65,rear+end*.055,'#394845');
  });
  const t=p.teacherDesk;
  k.withCollision('furniture',()=>{box(1.2,.065,.6,t.x,t.supportHeight+.775,t.z,wood);
   // Enclosed face toward the pupils plus both side panels; rear knee-space stays open.
   box(1.16,.64,.035,t.x,t.supportHeight+.43,t.z-end*.275,wood);
   for(const a of [-1,1]){box(.035,.64,.56,t.x+a*.565,t.supportHeight+.43,t.z,wood);for(const dz of [-.24,.24])box(.045,.75,.045,t.x+a*.535,t.supportHeight+.375,t.z+dz,steel);}
   const cz=t.z+end*.60;registerTeacherChair(root,{x:t.x,z:cz,level:level+t.supportHeight,end:-end});box(.43,.045,.42,t.x,t.supportHeight+.43,cz,wood);box(.43,.40,.035,t.x,t.supportHeight+.70,cz+end*.18,wood);
   for(const a of [-1,1])for(const v of [-1,1])box(.032,.41,.032,t.x+a*.175,t.supportHeight+.205,cz+v*.16,steel);
   for(const a of [-1,1])box(.032,.50,.032,t.x+a*.175,t.supportHeight+.60,cz+end*.16,steel);
   for(const d of p.desks)emitStudentDesk(k,{width:p.tableW,x:d.x,z:d.z,seatZ:d.seatZ,end,level},{wood,steel});
  });
  // 6 suspended fluorescent fixtures; emissive tubes use no per-room point lights.
  k.withCollision('none',()=>{for(const a of [-1,1])for(const f of [.22,.50,.78]){const x=cx+a*p.width*.23,z=s.zmin+depth*f;box(1.20,.09,.16,x,ch-.34,z,'#aeb3b0');for(const dx of [-.44,.44])box(.016,.24,.016,x+dx,ch-.17,z,steel);box(1.13,.035,.085,x,ch-.398,z,'#faffef');}
   // Four wall-mounted fans per room: stand-off bracket, motor, cage and three curved blades.
   for(const a of [-1,1])for(const f of [.28,.73]){
    const x=cx+a*(p.width/2-.31),z=s.zmin+depth*f,y=Math.min(ch-.38,2.84)+level;
    k.box(.035,.18,.14,cx+a*(p.width/2-.035),y-.22,z,steel);k.beam(new THREE.Vector3(cx+a*(p.width/2-.05),y-.24,z),new THREE.Vector3(x,y-.05,z),.035,steel);
    const fan=new THREE.Group();fan.name='classroom-wall-fan';fan.position.set(x,y,z);fan.rotation.y=-a*Math.PI/2;fan.userData.walkRole='none';root.add(fan);
    const fm=new THREE.MeshStandardMaterial({color:'#697875',roughness:.65});const part=(geo,xx,yy,zz)=>{const m=new THREE.Mesh(geo,fm);m.position.set(xx,yy,zz);m.userData.walkRole='none';fan.add(m);return m;};
    const motor=part(new THREE.CylinderGeometry(.075,.075,.12,16),0,0,-.045);motor.rotation.x=Math.PI/2;
    for(const zz of [-.07,.06])part(new THREE.TorusGeometry(.245,.012,6,32),0,0,zz);
    for(const rr of [.10,.17,.215])part(new THREE.TorusGeometry(rr,.004,4,32),0,0,.065);
    for(let j=0;j<12;j++){const an=j*Math.PI/6,m=part(new THREE.BoxGeometry(.004,.48,.004),0,0,.07);m.rotation.z=an;}
    for(let j=0;j<3;j++){const sh=new THREE.Shape();sh.moveTo(0,.035);sh.quadraticCurveTo(.15,.04,.12,.205);sh.quadraticCurveTo(-.01,.25,-.035,.10);sh.closePath();const m=part(new THREE.ShapeGeometry(sh),0,0,.015);m.rotation.z=j*2*Math.PI/3;m.material.side=THREE.DoubleSide;}
    part(new THREE.SphereGeometry(.045,12,8),0,0,.08);
   }
  });
 }
 k.finish();batchFixtures(root);root.traverse(o=>{if(o.material?.color?.getHexString()==='c8ad79'){if(specs.every(s=>s.buildingId==='A1'))applyCorridorTiles(o.material,{floorPattern:'a1-star'});else if(specs.every(s=>s.buildingId==='A2'||s.buildingId==='B1'||s.buildingId==='B2'))applyA2ClassroomFloor(o.material);else floorShader(o.material,settings.tileSize??CLASSROOM_TEMPLATE.tileSize);}if(o.material?.color?.getHexString()==='f4f3eb'){o.material.emissive.set('#efefeb');o.material.emissiveIntensity=.55;}if(o.material?.color?.getHexString()==='faffef'){o.material.emissive.set('#faffef');o.material.emissiveIntensity=.6;}});return root;
}
function batchFixtures(root){
 const fans=root.children.filter(o=>o.name==='classroom-wall-fan');if(fans.length){const pos=[],norm=[];for(const m of fans[0].children){m.updateMatrix();const geo=(m.geometry.index?m.geometry.toNonIndexed():m.geometry.clone()).applyMatrix4(m.matrix);pos.push(...geo.attributes.position.array);norm.push(...geo.attributes.normal.array);geo.dispose();}const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setAttribute('normal',new THREE.Float32BufferAttribute(norm,3));const material=fans[0].children[0].material,batch=new THREE.InstancedMesh(geo,material,fans.length);batch.name='classroom-wall-fan-batch';batch.userData={walkRole:'none',fansPerRoom:4};for(const [i,fan]of fans.entries()){fan.updateMatrix();batch.setMatrixAt(i,fan.matrix);for(const m of fan.children){m.geometry.dispose();if(m.material!==material)m.material.dispose();}root.remove(fan);}batch.instanceMatrix.needsUpdate=true;batch.computeBoundingBox();batch.computeBoundingSphere();root.add(batch);}
 const groups=new Map();for(const o of [...root.children])if(['classroom-wall-fan','classroom-rear-clock','classroom-wall-lettering','classroom-ho-chi-minh-portrait'].includes(o.name)){const key=o.name+(o.material.map?.uuid||o.material.color.getHexString());if(!groups.has(key))groups.set(key,[]);groups.get(key).push(o);}
 for(const list of groups.values()){const first=list[0],batch=new THREE.InstancedMesh(first.geometry,first.material,list.length);batch.name=first.name+'-batch';batch.userData={...first.userData,walkRole:'none'};for(const [i,o]of list.entries()){o.updateMatrix();batch.setMatrixAt(i,o.matrix);root.remove(o);if(o.geometry!==first.geometry)o.geometry.dispose();if(o.material!==first.material)o.material.dispose();}batch.instanceMatrix.needsUpdate=true;batch.computeBoundingBox();batch.computeBoundingSphere();root.add(batch);}
}
export function replaceClassroomInteriors(building,settings={}){const old=building.children.find(c=>c.name==='shared-classroom-interiors');if(!old)return false;const next=createClassroomInteriors(old.userData.roomSpecs,{...old.userData.settings,...settings});next.position.copy(old.position);building.remove(old);building.add(next);disposeObject(old);return next;}
// Choose dividers in masonry gaps, keeping all facade door/window cutouts unchanged.
export function classroomWingRooms(from,to,openings){
 const doors=openings.filter(o=>o.kind==='door'&&o.u>from+.1&&o.u<to-.1).sort((a,b)=>a.u-b.u);if(!doors.length)return[];
 const count=Math.min(doors.length,Math.max(1,Math.round((to-from)/8))),bounds=[from];
 for(let i=1;i<count;i++){const target=from+(to-from)*i/count,candidates=[target,...openings.flatMap(o=>[o.u-o.width/2-.14,o.u+o.width/2+.14])].filter(z=>z>bounds.at(-1)+5.2&&z<to-5.2&&!openings.some(o=>Math.abs(z-o.u)<o.width/2+.08)&&doors.some(d=>d.u>bounds.at(-1)&&d.u<z)&&doors.some(d=>d.u>z));if(candidates.length)bounds.push(candidates.sort((x,y)=>Math.abs(x-target)-Math.abs(y-target))[0]);}
 bounds.push(to);return bounds.slice(0,-1).map((lo,i)=>({zmin:lo,zmax:bounds[i+1],doorU:doors.filter(d=>d.u>lo&&d.u<bounds[i+1]).at(-1)?.u})).filter(r=>Number.isFinite(r.doorU));
}
export function classroomVisitPoint(building,floor=1){const root=building.getObjectByName('shared-classroom-interiors'),s=root?.userData.roomSpecs.find(s=>s.floor===floor);if(!s)return null;const p=classroomLayout(s),point=new THREE.Vector3(p.cx,(s.level??0)+root.position.y,p.boardZ-p.boardEnd*1.50);building.localToWorld(point);const target=building.localToWorld(new THREE.Vector3(p.cx,(s.level??0)+root.position.y+1.5,p.boardZ));return{x:point.x,z:point.z,feet:point.y,yaw:Math.atan2(-(target.x-point.x),-(target.z-point.z))};}
