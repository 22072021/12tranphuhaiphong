import * as T from './vendor/three.module.js';
// Same two-bone reach method as cafe-gaming-pose; solve against actual scaled joints.
export function reachFoodHand(root,joints,side,target){
 const shoulder=joints[side+'Shoulder'],elbow=joints[side+'Elbow'];root.updateMatrixWorld(true);
 const origin=shoulder.getWorldPosition(new T.Vector3()),scale=shoulder.getWorldScale(new T.Vector3()).y,a=.235*scale,b=.214*scale,delta=target.clone().sub(origin),d=T.MathUtils.clamp(delta.length(),.02,a+b-.002),dir=delta.normalize();
 const along=(a*a-b*b+d*d)/(2*d),height=Math.sqrt(Math.max(0,a*a-along*along));
 let bend=new T.Vector3(0,-1,0).addScaledVector(dir,dir.y);if(bend.lengthSq()<.001)bend.set(side==='left'?1:-1,0,0);bend.normalize();
 const joint=origin.clone().addScaledVector(dir,along).addScaledVector(bend,height);
 function aim(bone,point){const from=bone.getWorldPosition(new T.Vector3()),q=new T.Quaternion().setFromUnitVectors(new T.Vector3(0,-1,0),point.clone().sub(from).normalize());bone.quaternion.copy(bone.parent.getWorldQuaternion(new T.Quaternion()).invert().multiply(q));root.updateMatrixWorld(true);}
 aim(shoulder,joint);aim(elbow,origin.clone().addScaledVector(dir,d));
 const hand=elbow.getObjectByName(side+'-hand');if(hand){hand.quaternion.copy(hand.parent.getWorldQuaternion(new T.Quaternion()).invert().multiply(root.getWorldQuaternion(new T.Quaternion())));root.updateMatrixWorld(true);}return hand;
}
export function applyFoodEatingPose(visitor,meal){
 const root=visitor.root,j=visitor.renderJoints,tableMeal=['fish','crab','pan'].includes(meal.id);
 j.torso.rotation.x=tableMeal?.14:0;j.head.rotation.x=tableMeal?.42:meal.id==='tea'?.08:.18;root.updateMatrixWorld(true);
 const mouth=j.head.localToWorld(new T.Vector3(0,.101,.123)),yaw=root.getWorldQuaternion(new T.Quaternion()),offset=(x,y,z)=>new T.Vector3(x,y,z).applyQuaternion(yaw);
 if(tableMeal){
  const p=j.torso.localToWorld(new T.Vector3(0,-.17,.34));const table=meal.tables?.slice().sort((a,b)=>a.distanceToPoint(root.position)-b.distanceToPoint(root.position))[0];
  if(table){p.x=T.MathUtils.clamp(p.x,table.min.x+.13,table.max.x-.13);p.z=T.MathUtils.clamp(p.z,table.min.z+.13,table.max.z-.13);p.y=table.max.y+.014;}
  meal.prop.position.copy(p);meal.prop.quaternion.copy(yaw);
  reachFoodHand(root,j,'left',p.clone().add(offset(.105,.06,0)));
  const hand=reachFoodHand(root,j,'right',mouth.clone().add(offset(-.055,-.055,.10)));
  if(hand&&meal.utensil){hand.getWorldPosition(meal.utensil.position);meal.utensil.position.add(offset(0,-.025,.025));const toward=mouth.clone().add(offset(0,-.012,.025)).sub(meal.utensil.position).normalize();meal.utensil.quaternion.setFromUnitVectors(new T.Vector3(0,0,1),toward);}
 }else if(meal.id==='bread'){
  // Grip the lower third; aim the loaf's upper end towards the mouth.
  const grip=mouth.clone().add(offset(.075,-.205,.09));
  reachFoodHand(root,j,'left',grip);
  const hand=j.leftElbow.getObjectByName('left-hand');
  const palm=hand?hand.getWorldPosition(new T.Vector3()):grip;
  const tip=mouth.clone().add(offset(0,-.035,.055));
  const direction=tip.clone().sub(palm).normalize();
  const localDirection=direction.clone().applyQuaternion(yaw.clone().invert());
  meal.prop.quaternion.copy(yaw).multiply(new T.Quaternion().setFromUnitVectors(new T.Vector3(0,0,-1),localDirection));
  const holdPoint=new T.Vector3(0,.055,.065).applyQuaternion(meal.prop.quaternion);
  meal.prop.position.copy(palm).add(offset(0,0,.025)).sub(holdPoint);
  reachFoodHand(root,j,'right',palm.clone().addScaledVector(direction,.075).add(offset(-.065,0,.025)));
 }else{
  const tea=meal.id==='tea';
  // Upper arms hang downward; left elbow stays beside ribs, right slightly relaxed outward.
  function carryArm(side){const shoulder=j[side+'Shoulder'],elbow=j[side+'Elbow'];shoulder.rotation.set(-.08,side==='left'?-.40:.75,side==='left'?.025:-.10);elbow.rotation.set(side==='left'?-2.12:-2.45,0,0);root.updateMatrixWorld(true);const hand=elbow.getObjectByName(side+'-hand');if(hand){hand.quaternion.copy(hand.parent.getWorldQuaternion(new T.Quaternion()).invert().multiply(yaw));root.updateMatrixWorld(true);}return hand;}
  const hand=carryArm(tea?'right':'left');
  if(tea){const thigh=j.pelvis.localToWorld(new T.Vector3(.12,.12,.22));reachFoodHand(root,j,'left',thigh);}else carryArm('right');
  if(hand){hand.getWorldPosition(meal.prop.position);meal.prop.position.add(offset(0,tea?-.035:0,tea?.057:.050));meal.prop.quaternion.copy(yaw);if(tea)meal.prop.rotateX(.15);if(meal.id==='bread')meal.prop.rotateX(Math.PI/2);}

 }
 root.updateMatrixWorld(true);
}
