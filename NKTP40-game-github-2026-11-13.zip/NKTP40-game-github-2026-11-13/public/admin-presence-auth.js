import {unlockAdminProfile} from './admin-profile-unlock.js';
import {refreshAlleyAdminAccess} from './alley-admin-access.js';
let pending=null;
// A stale socket challenge or an expired server session must not discard the world.
// Recheck the current credential first: the challenge can predate the unlock dialog.
export function recoverAdminPresence(){
 if(pending)return pending;
 pending=(async()=>{
  const response=await fetch('/api/player-profile',{credentials:'same-origin',cache:'no-store',headers:window.nktpAdminToken?{'X-NKTP-Admin-Token':window.nktpAdminToken}:{}});
  if(!response.ok)throw new Error('Chưa kiểm tra được phiên admin.');
  const data=await response.json();
  if(data.requiresAdminVerification)await unlockAdminProfile();
  else if(!data.isAdmin)throw new Error('Phiên này không phải tài khoản admin.');
  await refreshAlleyAdminAccess();
 })().finally(()=>{pending=null;});
 return pending;
}
