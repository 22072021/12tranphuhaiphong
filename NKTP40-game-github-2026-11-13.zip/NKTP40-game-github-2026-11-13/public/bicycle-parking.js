import {bicycleParkingPlacements} from './bicycle-parking-plan.js';
import * as T from './vendor/three.module.js';
import {createBicycle} from './furniture/bicycle.js';
import {CAMPUS_REAR} from './campus-limits.js';
const palette=['#242b30','#365e8c','#853c3f','#46715d','#d8ceb1','#bc939f','#809f91','#576978'];
// Bake each detailed prototype by material, then instance entire rows.
function bake(mini){
 const root=createBicycle({mini,lowDetail:true});root.updateMatrixWorld(true);const buckets=new Map();
 root.traverse(o=>{if(!o.isMesh)return;const key=o.material.color.getHexString();if(!buckets.has(key))buckets.set(key,{material:o.material,positions:[],normals:[]});const b=buckets.get(key),geometry=(o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone());geometry.applyMatrix4(o.matrixWorld);b.positions.push(...geometry.attributes.position.array);b.normals.push(...geometry.attributes.normal.array);geometry.dispose();});
 const parts=[];for(const [key,b]of buckets){const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(b.positions,3));geometry.setAttribute('normal',new T.Float32BufferAttribute(b.normals,3));geometry.computeBoundingBox();parts.push({key,geometry,material:b.material.clone()});}
 root.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});return parts;
}
export function createBicycleParking(layout){
 const g=new T.Group();g.name='classroom-rear-bicycle-parking';const placements=bicycleParkingPlacements(layout);
 const matrix=new T.Matrix4();
 for(const mini of [false,true]){const parts=bake(mini),defaultPaint=new T.Color(mini?'#d8ceb1':'#22272a').getHexString();for(let c=0;c<palette.length;c++){
  const points=placements.filter(p=>p.mini===mini&&p.color===c);if(!points.length)continue;
  for(const part of parts){const material=part.material.clone();if(part.key===defaultPaint)material.color.set(palette[c]);const mesh=new T.InstancedMesh(part.geometry,material,points.length);mesh.name='parked-bicycle-'+(mini?'mini':'MTB');mesh.userData.walkRole='none';mesh.userData.bikeIds=points.map(p=>p.id);points.forEach((p,i)=>{matrix.makeRotationY(p.rotation||0);matrix.setPosition(p.x,0,p.z);mesh.setMatrixAt(i,matrix);});mesh.castShadow=mesh.receiveShadow=true;mesh.computeBoundingBox();mesh.computeBoundingSphere();g.add(mesh);}
 }}
 const collision=new T.InstancedMesh(new T.BoxGeometry(1.90,1.15,.76),new T.MeshBasicMaterial(),placements.length);collision.name='parked-bicycle-barriers';collision.visible=false;collision.userData.walkRole='barrier';collision.userData.bikeIds=placements.map(p=>p.id);collision.userData.walkRoles=placements.map(()=> 'barrier');placements.forEach((p,i)=>{matrix.makeRotationY(p.rotation||0);matrix.setPosition(p.x,.575,p.z);collision.setMatrixAt(i,matrix);});g.add(collision);
 g.userData.parking={placements,count:placements.length,pitch:.90,colors:palette,wallClearance:.12,minimumWalkway:1.23,rearRows:{A1:3,B1:3},rowWalkway:1.6,centralCrossing:7.4};return g;
}
