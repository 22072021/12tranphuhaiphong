import * as THREE from './vendor/three.module.js';
// One pattern per building, reused on the facade and at corridor ends.
export function corridorGuardStyle(id){return id==='A1'?'masonry-horizontal-slot':id==='A2'||id==='B2'?'granito-geometric-iron':'masonry-solid-cap';}
export function drawCorridorGuard(k,{id,x=0,z=0,y=0,width,angle=0,wall='#dec17a',trim='#eee2bc'}){
 const c=Math.cos(angle),s=Math.sin(angle),style=corridorGuardStyle(id);
 const box=(u,yy,w,h,d,color)=>k.box(d,h,w,x+s*u,y+yy,z+c*u,color,0,angle,0);
 k.withCollision('barrier',()=>{
  if(id==='A1'){
   // P13: two interrupted rectangular openings, one at floor level and one below the cap.
   const low=.075,topSlotBottom=.575,topSlotTop=.705,capBottom=.735;
   box(0,(low+topSlotBottom)/2,width,topSlotBottom-low,.18,wall);
   box(0,(topSlotTop+capBottom)/2,width,capBottom-topSlotTop,.18,wall);
   const capShape=new THREE.Shape();capShape.moveTo(-.09,0);for(let i=0;i<=24;i++){const a=Math.PI-i*Math.PI/24;capShape.lineTo(.09*Math.cos(a),.09*Math.sin(a));}capShape.lineTo(-.09,0);const cap=new THREE.ExtrudeGeometry(capShape,{depth:width,bevelEnabled:false});cap.translate(0,0,-width/2);cap.rotateY(angle);cap.translate(x,y+capBottom,z);k.curved(cap,wall,'A1-rounded-balustrade-cap');
   const count=Math.max(1,Math.ceil(width/.82)),spacing=width/count,pier=Math.min(.12,spacing*.30);
   for(let j=0;j<=count;j++){const u=-width/2+j*spacing,ww=j===0||j===count?pier/2:pier,center=u+(j===0?pier/4:j===count?-pier/4:0);box(center,low/2,ww,low,.18,wall);box(center,(topSlotBottom+topSlotTop)/2,ww,topSlotTop-topSlotBottom,.18,wall);}
  }else if(id==='A2'||id==='B2'){
   // Low plaster parapet, slender geometric ironwork, and polished granito cap.
   box(0,.27,width,.54,.18,wall);box(0,.94,width,.12,.21,'#865f69');
   const count=Math.max(1,Math.round(width/.38)),pitch=width/count,iron='#c6ad69';
   for(let j=0;j<count;j++){const u=-width/2+(j+.5)*pitch,ww=pitch*.48,hh=.18;
    for(const sign of [-1,1]){box(u,.71+sign*hh/2,ww,.018,.035,iron);box(u+sign*ww/2,.71,.018,hh,.035,iron);}
    for(const sign of [-1,1])box(u,.71+sign*(hh/2+.085),.018,.17,.025,iron);box(u+pitch/2,.71,.018,.34,.025,iron);
   }
  }else if(id==='B1'){box(0,.44,width,.88,.18,wall);box(0,.94,width,.12,.24,trim);
  }else if(id==='B2'){
   box(0,.22*.9,width,.36*.9,.18,wall);box(0,.79*.9,width,.12*.9,.24,'#865f68');
   const count=Math.max(1,Math.round(width/.38));for(let j=0;j<count;j++){
    const u=-width/2+(j+.5)*width/count,a=width/count*.72,yy=.59*.9;
    for(const sign of [-1,1]){box(u,yy+sign*a*.45,a,.045*.9,.13,trim);box(u+sign*a/2,yy,.045,a*.9,.13,trim);}
    k.ring(a*.29,x+s*u,y+yy,z+c*u,trim,Math.PI/2+angle);
   }
  }else{box(0,.35*.9,width,.65*.9,.18,wall);box(0,.73*.9,width,.12*.9,.24,trim);}
 });return style;
}
