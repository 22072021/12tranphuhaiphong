import {FACADE_PROFILES} from './facade-profile.js';
// Ten points in one row on the courtyard side of the existing A1 flagpole.
export function punishmentPlan(layout){const a=layout?.buildings?.find(b=>b.id==='A1');if(!a)return[];const side=a.frontSide===1?1:-1,center=-side*(FACADE_PROFILES.A1.coreCentre-.5)*a.length,lx=side*(a.width/2-.04+3.9+1.05+2.2),theta=-(a.rotation||0)*Math.PI/180,c=Math.cos(theta),s=Math.sin(theta);return Array.from({length:10},(_,slot)=>{const lz=center+(slot-4.5)*1.05;return{slot,x:a.x+c*lx+s*lz,z:a.z-s*lx+c*lz,feet:.03,yaw:side*Math.PI/2+theta};});}
