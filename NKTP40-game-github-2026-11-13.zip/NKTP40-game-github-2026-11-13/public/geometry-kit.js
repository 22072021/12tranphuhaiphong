import * as THREE from './vendor/three.module.js';
import {surfaceMaterial} from './surface-material.js?v=222.0';

const unitBox=new THREE.BoxGeometry(1,1,1),circle=new THREE.TorusGeometry(1,.22,8,48),cylinderGeometry=new THREE.CylinderGeometry(.5,.5,1,12);
for(const g of [unitBox,circle,cylinderGeometry])g.userData.shared=true;
export function geometryKit(group,profile={}){
 const batches=new Map(),curves=new Map();
 const matrix=new THREE.Matrix4(),position=new THREE.Vector3(),scale=new THREE.Vector3(),rotation=new THREE.Quaternion();
 let walkRole='solid';
 function withCollision(role,fn){const previous=walkRole;walkRole=role;try{return fn();}finally{walkRole=previous;}}
 function instance(type,color,x,y,z,sx,sy,sz,rx=0,ry=0,rz=0){
  if([x,y,z,sx,sy,sz].some(v=>!Number.isFinite(v))||Math.min(sx,sy,sz)<=0)throw new Error('Invalid detail dimensions');
  const key=type+color;if(!batches.has(key))batches.set(key,{type,color,matrices:[],roles:[]});
  position.set(x,y,z);scale.set(sx,sy,sz);rotation.setFromEuler(new THREE.Euler(rx,ry,rz));matrix.compose(position,rotation,scale);batches.get(key).matrices.push(matrix.clone());batches.get(key).roles.push(walkRole);
 }
 const box=(w,h,l,x,y,z,color,rx=0,ry=0,rz=0)=>instance('box',color,x,y,z,w,h,l,rx,ry,rz);
 function cylinder(radius,height,x,y,z,color){instance('cylinder',color,x,y,z,radius*2,height,radius*2);}
 function ring(radius,x,y,z,color,ry=Math.PI/2){instance('ring',color,x,y,z,radius,radius,radius,0,ry,0);}
 function beam(a,b,width,color){const direction=new THREE.Vector3().subVectors(b,a),length=direction.length();rotation.setFromUnitVectors(new THREE.Vector3(0,1,0),direction.normalize());matrix.compose(a.clone().add(b).multiplyScalar(.5),rotation,new THREE.Vector3(width,length,width));const key='box'+color;if(!batches.has(key))batches.set(key,{type:'box',color,matrices:[],roles:[]});batches.get(key).matrices.push(matrix.clone());batches.get(key).roles.push(walkRole);}
 function solid(geometry,color,name){const mesh=new THREE.Mesh(geometry,surfaceMaterial(color,{...profile,whiteUnderside:/roof|slab/.test(name)}));mesh.material.side=THREE.DoubleSide;mesh.castShadow=true;mesh.receiveShadow=true;mesh.name=name;mesh.userData.walkRole=walkRole;group.add(mesh);return mesh;}
 function finish(){let instances=0;for(const batch of batches.values()){const mesh=new THREE.InstancedMesh(batch.type==='box'?unitBox:batch.type==='cylinder'?cylinderGeometry:circle,surfaceMaterial(batch.color,profile),batch.matrices.length);batch.matrices.forEach((m,i)=>mesh.setMatrixAt(i,m));mesh.instanceMatrix.needsUpdate=true;mesh.computeBoundingBox();mesh.computeBoundingSphere();mesh.castShadow=true;mesh.receiveShadow=true;mesh.name='detail-'+batch.type;mesh.userData.walkRoles=batch.roles;group.add(mesh);instances+=mesh.count;}group.userData.instanceCount=instances;group.userData.batchCount=batches.size;}
 function curved(geometry,color,name){const data=geometry.index?geometry.toNonIndexed():geometry;if(!curves.has(color))curves.set(color,[]);curves.get(color).push({geometry:data,name,walkRole});}
 const finishDetails=finish;
 function finishAll(){finishDetails();for(const [color,parts] of curves){const p=[],n=[];for(const part of parts){p.push(...part.geometry.attributes.position.array);n.push(...part.geometry.attributes.normal.array);}const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(p,3));geo.setAttribute('normal',new THREE.Float32BufferAttribute(n,3));const mesh=solid(geo,color,'continuous-curves');mesh.userData.profiles=parts.map(p=>p.name);mesh.userData.walkParts=parts.map(part=>{part.geometry.computeBoundingBox();return{bounds:part.geometry.boundingBox.clone(),walkRole:part.walkRole};});}}
 return {box,ring,beam,cylinder,solid,curved,withCollision,finish:finishAll};
}

export function gableRoof(kit,width,length,height,color,rise,name='pitched-roof'){
 const alongZ=width<=length,half=(alongZ?width:length)/2+.22,depth=(alongZ?length:width)/2+.22,vertices=[];
 const a=[-half,height,-depth],b=[half,height,-depth],c=[0,height+rise,-depth],d=[-half,height,depth],e=[half,height,depth],f=[0,height+rise,depth];
 for(const points of [[a,c,f],[a,f,d],[b,e,f],[b,f,c],[a,b,c],[d,f,e]])for(const p of points)vertices.push(...p);
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.computeVertexNormals();const roof=kit.solid(geo,color,name);if(!alongZ)roof.rotation.y=Math.PI/2;const ribs=geometryKit(roof),ribColor='#'+new THREE.Color(color).lerp(new THREE.Color('#ffffff'),.12).getHexString();for(let z=-depth+.12;z<=depth-.12;z+=.4)for(const side of [-1,1])ribs.beam(new THREE.Vector3(side*half,height+.025,z),new THREE.Vector3(0,height+rise+.025,z),.025,ribColor);ribs.finish();return roof;
}

export function hippedRoof(kit,width,length,height,color,rise){
 const alongZ=width<=length,w=(alongZ?width:length)/2-.28,l=(alongZ?length:width)/2-.28,ridge=Math.max(.2,l-w),a=[-w,height,-l],b=[w,height,-l],c=[w,height,l],d=[-w,height,l],e=[0,height+rise,-ridge],f=[0,height+rise,ridge],vertices=[];
 for(const face of [[a,b,e],[b,c,f],[b,f,e],[c,d,f],[d,a,e],[d,e,f]])for(const p of face)vertices.push(...p);
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.computeVertexNormals();const mesh=kit.solid(geo,color,'hipped-roof');if(!alongZ)mesh.rotation.y=Math.PI/2;return mesh;
}
