import {createAlleyTeacherGroup} from './alley-teacher-npcs.js';
import {createPanBreadStall} from './pan-bread-stall.js';
import {createAsphaltMaterial} from './street-surfaces.js';
import {createAlleyGameCafe,GAME_CAFE,GAME_CAFE_2} from './alley-game-cafe.js';
import {createSignCanvas} from './sign-canvas.js';
import {createThanhDungBookstore,BOOKSTORE} from './thanh-dung-bookstore.js';
import * as T from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js';
import {LANGUAGE_ALLEY as A} from './foreign-language-alley-layout.js';

// Context facades are reconstructed estimates; the two entrance signs follow supplied photos.
export function createForeignLanguageAlley(){
 const root=new T.Group();root.name='foreign-language-centre-alley';root.position.set(A.startX,0,A.entryZ);root.userData={id:A.id,reference:'Owner Street View June 2017 + entrance banner photograph',houseCount:80,streetDistance:84,depth:A.depth,gateLocked:true,estimated:true};
 root.add(createAlleyTeacherGroup());
 const bread=createPanBreadStall();bread.position.set(0,.035,A.width/2);root.add(bread);
 const crabNoodles=createPanBreadStall({crabNoodles:true});crabNoodles.position.set(6.8,.035,A.width/2);root.add(crabNoodles);
 const kit=geometryKit(root),{box,beam}=kit,wall=['#b8b4a5','#c3bca9','#aeb3aa','#c7bca5','#b3afa6','#c4c5b6'];
 // Road and sidewalk are provided continuously by the existing street-surfaces module.
 const lane=new T.Mesh(new T.BoxGeometry(A.depth,.18,A.width),createAsphaltMaterial());lane.name='foreign-language-alley-asphalt';lane.position.set(A.depth/2,-.055,0);lane.receiveShadow=true;lane.userData.walkRole='solid';root.add(lane);
 function dwelling(x,side,index,street=false,span=4.2){
  const h=[8.7,11.5,6.1,9.2,12.2,7.8][(index+(side>0?2:0))%6],depth=street?5.3:4.5+(index%3)*.35,color=wall[(index+(side>0?3:0))%wall.length];
  const center=street?new T.Vector3(2.65,h/2,x):new T.Vector3(x,h/2,side*(A.width/2+depth/2));
  // A row is closed; windows are external context only, not accessible rooms.
  box(street?depth:span,h,street?span:depth,center.x,center.y,center.z,color);
  box(street?depth+.2:span+.08,.17,street?span+.08:depth+.2,center.x,h+.08,center.z,'#888a80');
  const point=(u,y,out=0)=>street?new T.Vector3(-.045-out,y,x+u):new T.Vector3(x+u,y,side*(A.width/2-out));
  const detail=(w,h,y,u,color,out=.035,d=.045)=>{const p=point(u,y,out);box(street?d:w,h,street?w:d,p.x,p.y,p.z,color);};
  kit.withCollision('none',()=>{
   const roller=street||index%4===0;
   detail(span*(roller?.74:.60),2.45,1.25,0,roller?'#7c8078':['#496557','#695e4d','#69746e'][index%3]);
   if(roller){for(let y=.22;y<2.5;y+=.13)detail(span*.74,.018,y,0,'#a0a297',.067,.018);}
   else{for(let u=-span*.28;u<span*.29;u+=.15)detail(.018,2.1,1.38,u,'#acafa1',.075,.018);detail(span*.61,.04,.38,0,'#a5a89a',.08);detail(span*.61,.04,2.45,0,'#a5a89a',.08);detail(.04,2.3,1.25,0,'#a5a89a',.08);}
   if(index%5===2){detail(span*.77,.12,2.9,0,'#738b84',.46,.93);}
   for(let floor=1;floor<Math.floor(h/2.85);floor++){
    const level=floor*2.85;detail(span-.12,.16,level,0,'#d1cbb9',.08,.18);
    for(const u of[-span*.23,span*.23]){
     detail(span*.30,1.35,level+.99,u,'#475e5c',.055);
     for(const yy of[level+.30,level+1.68])detail(span*.34,.045,yy,u,'#d0cec2',.08);
     for(const uu of[u-span*.16,u,u+span*.16])detail(.035,1.39,level+.99,uu,'#b7bbae',.09);
     detail(span*.32,.035,level+.99,u,'#b7bbae',.09);
    }
    if(index%3!==1){detail(span*.80,.10,level-.02,0,'#b3b0a0',.27,.54);detail(span*.80,.04,level+.85,0,'#525f59',.53);for(let u=-span*.37;u<span*.4;u+=.26)detail(.025,.85,level+.42,u,'#65716b',.53);}
    if((index+floor)%4===0){detail(.64,.47,level+.85,span*.38,'#d5d4c4',.24,.3);detail(.44,.28,level+.85,span*.38,'#9a9e95',.41);}
   }
  });
 }
 for(let side of[-1,1])for(let i=0;i<A.housesPerSide;i++){if(side===1&&i>=GAME_CAFE_2.firstBay&&i<GAME_CAFE_2.firstBay+GAME_CAFE_2.bays)continue;if(side===-1&&i>=GAME_CAFE.firstBay&&i<GAME_CAFE.firstBay+GAME_CAFE.bays)continue;if(side===1&&i>=BOOKSTORE.firstBay&&i<BOOKSTORE.firstBay+BOOKSTORE.bays)continue;dwelling((i+.5)*A.houseUnit,side,i);}const bookstore=createThanhDungBookstore();bookstore.position.set((BOOKSTORE.firstBay+BOOKSTORE.bays/2)*A.houseUnit,0,A.width/2);root.add(bookstore);
 const gameCafe=createAlleyGameCafe();gameCafe.position.set((GAME_CAFE.firstBay+GAME_CAFE.bays/2)*A.houseUnit,0,-A.width/2);gameCafe.rotation.y=Math.PI;root.add(gameCafe);
 const gameCafe2=createAlleyGameCafe({variant:2});gameCafe2.position.set((GAME_CAFE_2.firstBay+GAME_CAFE_2.bays/2)*A.houseUnit,0,A.width/2);root.add(gameCafe2);
 // Thirteen new street blocks continue the existing seven blocks to the mouth.
 const far=-59.4-A.entryZ,near=A.width/2+4.2,span=(far-near)/13;
 for(let i=0;i<13;i++)dwelling(far-(i+.5)*span,1,i+7,true,span);
 // Two flanking shops frame the entrance, as opposed to an empty cut in a wall.
 for(const side of[-1,1]){const z=side*(A.width/2+2.1);box(5.3,10.8,4.2,2.65,5.4,z,side<0?'#b7afa2':'#d0c4a3');kit.withCollision('none',()=>{box(.07,2.7,3.1,-.04,1.45,z,'#77796f');for(let y=.2;y<2.8;y+=.15)box(.026,.018,3.1,-.09,y,z,'#a3a397');for(let y=4.5;y<10.5;y+=2.9){box(.065,1.5,2.9,-.06,y,z,'#49605e');for(const dz of[-1.45,0,1.45])box(.04,1.55,.05,-.11,y,z+dz,'#ccc9b7');for(const dy of[-.75,.75])box(.04,.05,2.95,-.11,y+dy,z,'#ccc9b7');}});}
 function sign(name,w,h,x,y,z,paint){const c=createSignCanvas(w,h,paint);const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;tex.anisotropy=4;const m=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshBasicMaterial({map:tex,side:T.FrontSide}));m.name=name;m.position.set(x,y,z);m.rotation.y=-Math.PI/2;m.userData.walkRole='none';root.add(m);return m;}
 const text=(c,t,x,y,size,color,width)=>{c.fillStyle=color;c.font=`700 ${size}px Arial, sans-serif`;c.textAlign='center';c.fillText(t,x,y,width);};
 // Roadside original sign. Clear passage remains under it.
 box(.12,4.65,.12,-6.7,2.325,-4.15,'#9baba9');box(.12,4.65,.12,-6.7,2.325,4.15,'#9baba9');box(.14,1.62,8.6,-6.7,4.40,0,'#d5d2bf');
 sign('language-centre-original-2017-sign',8.5,1.52,-6.781,4.40,0,(c,w,h)=>{c.fillStyle='#e2e3d8';c.fillRect(0,0,w,h);c.strokeStyle='#687976';c.lineWidth=9;c.strokeRect(5,5,w-10,h-10);text(c,'UBND THÀNH PHỐ HẢI PHÒNG',235,51,32,'#264c6b',420);c.strokeStyle='#597b91';c.lineWidth=7;c.beginPath();c.arc(228,181,83,0,Math.PI*2);c.stroke();text(c,'HP',228,204,76,'#b49d42',150);text(c,'TRƯỜNG ĐẠI HỌC HẢI PHÒNG',1220,87,62,'#2c4864',1540);text(c,'TRUNG TÂM NGOẠI NGỮ HẢI PHÒNG',1210,198,78,'#aa4941',1550);text(c,'Hải Phòng Foreign Language Center',1210,277,65,'#25746a',1500);c.fillStyle='#294d91';c.fillRect(12,h-68,w-24,55);text(c,'ĐC: SỐ 10 TRẦN PHÚ        ĐT: 031.836302        FAX: 031.827935',w/2,h-27,41,'#f4f2d9',w-70);});
 box(.1,.78,A.width+.05,.9,3.65,0,'#a34d3b');
 sign('neighbourhood-red-banner',A.width,.75,.843,3.65,0,(c,w,h)=>{c.fillStyle='#ac4634';c.fillRect(0,0,w,h);text(c,'TOÀN DÂN ĐOÀN KẾT',w/2,h*.40,92,'#e9cf71',w*.89);text(c,'XÂY DỰNG TỔ DÂN PHỐ VĂN HÓA',w/2,h*.81,83,'#e9cf71',w*.94);});
 sign('alley-address-49',.60,.40,-.15,2.13,A.width/2+.19,(c,w,h)=>{c.fillStyle='#253c82';c.fillRect(0,0,w,h);c.strokeStyle='white';c.lineWidth=25;c.strokeRect(20,20,w-40,h-40);text(c,'NGÕ 49',w/2,h*.43,360,'white',w*.86);text(c,'TRẦN PHÚ',w/2,h*.85,300,'white',w*.86);});
 // Recognisable mouth businesses from the 2017 frame, without speculative interiors.
 sign('thai-yam-shop',3.9,.95,-.12,3.13,4.2,(c,w,h)=>{c.fillStyle='#d5ca86';c.fillRect(0,0,w,h);text(c,'THAI YAM',w/2,h*.60,220,'#282f28',w*.9);text(c,'ẨM THỰC THÁI LAN',w/2,h*.91,65,'#444c31',w*.9);});
 sign('haitrans-shop',3.9,.72,-.12,3.13,-4.2,(c,w,h)=>{c.fillStyle='#ae3437';c.fillRect(0,0,w,h);text(c,'CÔNG TY DỊCH THUẬT HẢI PHÒNG',w/2,h*.44,95,'#f4ead6',w*.95);text(c,'HAIPHONG TRANSLATION COMPANY',w/2,h*.82,65,'#f4ead6',w*.94);});
 // Framed landscape pictures beside the gallery entrance; shared palette, no photo downloads.
 for(let i=0;i<3;i++){const y=.65+i*.80;box(.09,.73,.91,-.16,y,2.85,'#b9a15d');sign('gallery-picture-'+i,.83,.65,-.212,y,2.85,(c,w,h)=>{c.fillStyle='#afcbd0';c.fillRect(0,0,w,h);c.fillStyle='#667c49';c.beginPath();c.moveTo(0,h*.7);c.lineTo(w*.32,h*.3);c.lineTo(w*.68,h*.65);c.lineTo(w,h*.4);c.lineTo(w,h);c.lineTo(0,h);c.fill();c.fillStyle='#a8c3ba';c.fillRect(0,h*.78,w,h*.22);});}
 // End gate: solid closed panels, never registered as an interactive door.
 const end=A.depth;box(.34,3.6,.40,end,1.8,-A.width/2,'#c3b898');box(.34,3.6,.40,end,1.8,A.width/2,'#c3b898');box(.18,3,A.width-.4,end,1.5,0,'#365b50');
 kit.withCollision('none',()=>{for(let z=-A.width/2+.3;z<A.width/2-.2;z+=.14)box(.045,1,.025,end-.115,2.35,z,'#9cac93');box(.04,2.9,.045,end-.13,1.45,0,'#9baf9b');for(const z of[-.12,.12])box(.06,.25,.035,end-.16,1.35,z,'#b9b99a');});
 box(.22,.60,A.width,end,3.30,0,'#dad3bf');
 sign('locked-centre-gate-sign',A.width-.6,.50,end-.65,3.30,0,(c,w,h)=>{c.fillStyle='#f1ecda';c.fillRect(0,0,w,h);text(c,'TRUNG TÂM NGOẠI NGỮ',w/2,h*.46,137,'#273d70',w*.95);text(c,'HẢI PHÒNG',w/2,h*.89,115,'#273d70',w*.95);});
 kit.finish();return root;
}
