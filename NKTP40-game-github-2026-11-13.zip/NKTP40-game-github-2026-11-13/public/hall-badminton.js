import {createHallSportsGame} from './hall-sports-game.js';
import * as T from './vendor/three.module.js';
export function createHallBadminton({bodyMin,bodyMax,halfLength,side=-1}){
 const root=new T.Group();root.name='hall-two-badminton-courts';
 const width=6.10,length=13.40,line=.04,courtX=side<0?bodyMin+8.0:bodyMax-8.0,centres=[-3.65,3.65],white=new T.MeshBasicMaterial({color:'#ebe7d8'}),steel=new T.MeshStandardMaterial({color:'#254f49',roughness:.7});
 let current=root;const mark=(x,z,dx,dz)=>{const m=new T.Mesh(new T.PlaneGeometry(dx,dz),white);m.rotation.x=-Math.PI/2;m.position.set(x,.009,z);m.userData.walkRole='none';current.add(m);};
 for(const [index,centreZ]of centres.entries()){
  const court=new T.Group();court.name='badminton-court-'+(index+1);court.position.z=centreZ;root.add(court);const x=courtX;current=court;root.add(createHallSportsGame({kind:'badminton',x:courtX,z:centreZ,index:index+1}));
  for(const z of [-width/2,width/2,-2.59,2.59])mark(x,z,length,line);
  for(const dx of [-length/2,length/2,-5.94,5.94,-1.98,1.98])mark(x+dx,0,line,width);
  for(const sign of [-1,1])mark(x+sign*(length/2+1.98)/2,0,(length/2-1.98),line);
  for(const z of [-width/2-.10,width/2+.10]){const post=new T.Mesh(new T.CylinderGeometry(.035,.035,1.55,12),steel);post.position.set(x,.775,z);post.userData.walkRole='barrier';court.add(post);}
  const positions=[];for(let z=-width/2;z<=width/2+.001;z+=.10)positions.push(x,.79,z,x,1.55,z);for(let y=.79;y<=1.55+.001;y+=.08)positions.push(x,y,-width/2,x,y,width/2);
  const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(positions,3));const net=new T.LineSegments(geo,new T.LineBasicMaterial({color:'#797568',transparent:true,opacity:.65}));net.userData.walkRole='none';court.add(net);
  const tape=new T.Mesh(new T.BoxGeometry(.025,.04,width+.20),white);tape.position.set(x,1.55,0);tape.userData.walkRole='none';court.add(tape);
  const block=new T.Mesh(new T.BoxGeometry(.08,1.55,width+.20),new T.MeshBasicMaterial({visible:false}));block.position.set(x,.775,0);block.userData.walkRole='barrier';court.add(block);
 }
 const tableX=side<0?bodyMax-6.0:bodyMin+6.0;
 for(const [i,z]of [-3.1,3.1].entries()){root.add(createTableTennis(tableX,z));root.add(createHallSportsGame({kind:'table',x:tableX,z,index:i+1}));}
 root.userData={tableTennis:2,courtX,courts:2,length,width,lineWidth:line,centres,netHeight:1.55,sideClearance:halfLength-3.65-width/2};return root;
}

function createTableTennis(x,z){
 const g=new T.Group();g.name='hall-table-tennis';g.position.set(x,0,z);g.userData.dimensions={length:2.74,width:1.525,height:.76};
 const blue=new T.MeshStandardMaterial({color:'#245b87',roughness:.7}),white=new T.MeshBasicMaterial({color:'#f2f0e7'}),steel=new T.MeshStandardMaterial({color:'#404b4d',metalness:.5,roughness:.6});
 const box=(w,h,d,x,y,z,mat)=>{const m=new T.Mesh(new T.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);m.userData.walkSupport=false;g.add(m);return m;};
 box(2.74,.045,1.525,0,.7375,0,blue);for(const a of [-1,1]){box(2.74,.006,.02,0,.763,a*.7525,white);box(.02,.006,1.525,a*1.36,.763,0,white);}box(2.74,.006,.003,0,.763,0,white);
 for(const a of [-1,1])for(const b of [-1,1])box(.045,.70,.045,a*.99,.35,b*.55,steel);
 for(const b of [-1,1])box(2.06,.045,.045,0,.30,b*.55,steel);
 for(const b of [-1,1])box(.025,.22,.025,0,.85,b*.83,steel);
 const points=[];for(let z=-.82;z<=.82;z+=.04)points.push(0,.76,z,0,.9125,z);for(let y=.76;y<=.913;y+=.03)points.push(0,y,-.82,0,y,.82);const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(points,3));const net=new T.LineSegments(geo,new T.LineBasicMaterial({color:'#e0dfd4',transparent:true,opacity:.8}));net.userData.walkRole='none';g.add(net);box(.015,.015,1.66,0,.9125,0,white);return g;
}
