import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';

// Continuous hipped tile roof, with a ridge near the building and a long front slope.
// Length, pitch and tile module remain estimates from P18/P24/P43/P66.
export function createPorchRoof({side,wallX,u=0,width,depth=2.9,eave=3.10,rise=.58,color='#365d9b',hipLength=null,postPositions=null,backV=null}){
 const g=new THREE.Group();g.name='detailed-ground-floor-porch';const k=geometryKit(g),half=width/2,back=backV??-.28,front=depth,hip=hipLength??Math.min(1.25,width*.10),ridgeV=backV===null?.24:back+.24;
 const point=(t,y,v)=>new THREE.Vector3(side*(wallX+v),y,u+t);
 const a=point(-half,eave,back),b=point(-half,eave,front),c=point(half,eave,front),d=point(half,eave,back),e=point(-half+hip,eave+rise,ridgeV),f=point(half-hip,eave+rise,ridgeV);
 const faces=[[a,b,e],[b,c,f],[b,f,e],[c,d,f],[d,a,e],[d,e,f]],vertices=[];
 for(const face of faces)for(const p of face)vertices.push(...p.toArray());
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.computeVertexNormals();const sheet=k.solid(geo,color,'continuous-hipped-porch-tile-roof');sheet.userData={eave,rise,width,depth,back,ridgeV};
 // Fine roof joints follow the actual slope, not floating horizontal stripes.
 const tint=new THREE.Color(color),seam='#'+tint.clone().lerp(new THREE.Color('#d4d8df'),.24).getHexString(),course='#'+tint.clone().lerp(new THREE.Color('#9a9fa8'),.12).getHexString();
 const roofY=(t,v)=>eave+rise*Math.max(0,Math.min((v-back)/(ridgeV-back),(front-v)/(front-ridgeV),(t+half)/hip,(half-t)/hip));
 for(let v=back+.14;v<front;v+=.22){const path=[];for(let j=0;j<=48;j++){const t=-half+j*width/48;path.push(point(t,roofY(t,v)+.012,v));}for(let j=1;j<path.length;j++)k.beam(path[j-1],path[j],.015,course);}
 for(let t=-half+.12;t<half;t+=.18){const path=[];for(let j=0;j<=16;j++){const v=back+(front-back)*j/16;path.push(point(t,roofY(t,v)+.015,v));}for(let j=1;j<path.length;j++)k.beam(path[j-1],path[j],.014,seam);}
 for(const [p,q] of [[a,e],[b,e],[c,f],[d,f],[e,f]])k.beam(p.clone().add(new THREE.Vector3(0,.025,0)),q.clone().add(new THREE.Vector3(0,.025,0)),.055,seam);
 // Fascia, shaded soffit, front bearing beam and cross beams.
 const trim='#eee2bc',wall='#dec17a',beamY=eave-.16,beamH=.28;
 k.box(depth-back,.10,width,side*(wallX+(front+back)/2),eave-.10,u,trim);
 k.box(.25,beamH,width,side*(wallX+front-.10),beamY,u,wall);
 for(const sign of [-1,1])k.box(depth-back,beamH,.22,side*(wallX+(front+back)/2),beamY,u+sign*(half-.10),wall);
 const posts=postPositions?.length??6,postV=front-.37,columnTop=eave-.29;
 for(let j=0;j<posts;j++){
  const t=postPositions?postPositions[j]:-half+.50+j*(width-1)/(posts-1),x=side*(wallX+postV),z=u+t;
  k.box(.29,columnTop,.29,x,columnTop/2,z,wall);
  k.box(.40,.16,.40,x,.08,z,'#a9a69a');k.box(.38,.14,.38,x,columnTop-.07,z,trim);
  k.box(depth-back-.24,.15,.20,side*(wallX+(front+back)/2),eave-.29,z,trim);
 }
 g.userData={width,depth,eave,rise,posts,hip,ridgeWidth:width-2*hip,estimated:true};k.finish();return g;
}
