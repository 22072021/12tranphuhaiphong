import * as T from './vendor/three.module.js';
import {classroomStairPlan} from './stair-design.js';
export function roofLadderPlan(b){
 if(!['A1','A2'].includes(b.id))return null;
 const p=classroomStairPlan(b),turn=p.landings.filter(a=>!p.levels.includes(a.y)).sort((a,b)=>b.y-a.y)[0];
 // Owner's red line: rear-left wall corner on the highest half-storey landing.
 const side=b.frontSide||-1,x=-side*(b.width/2-.62),z=p.center-p.span/2+.09,bottom=turn.y,half=b.width/2+.045,roofY=x=>b.height+.18+.38*(1-Math.abs(x)/half),top=roofY(x)+.18;
 return{x,z,bottom,top,hole:{x0:x-.40,x1:x+.40,z0:z-.04,z1:z+.81},foot:{x,y:bottom,z:z+.45},exit:{x:x+side*.95,y:roofY(x+side*.95),z:z+.45},exitSide:side};
}
// Clip roof triangles into four independent exterior regions. No bounding box spans the hatch.
export function cutRoofHatch(g,b){const p=roofLadderPlan(b);if(!p)return;const h=p.hole,add=[],zero=new T.Matrix4().makeScale(0,0,0);
 // A2 uses the analytic sloping support below. Roof sheets and their 25mm
 // decorative ribs must not also become tall box obstacles above that surface.
 // Keep the approved A1 collision behaviour unchanged.
 if(b.id==='A2')g.traverse(o=>{let skin=false;for(let a=o;a;a=a.parent)if(a.name==='pitched-roof')skin=true;if(skin&&o.isMesh){o.userData.walkRole='none';if(o.isInstancedMesh)o.userData.walkRoles=Array(o.count).fill('none');}});


 const planes=[['x',h.x0,-1],['x',h.x1,1],['z',h.z0,-1],['z',h.z1,1]];
 function process(mesh,matrix){
  let roofSkin=false;for(let o=mesh;o;o=o.parent)if(o.name==='pitched-roof')roofSkin=true;
  const geo=mesh.geometry.index?mesh.geometry.toNonIndexed():mesh.geometry,pos=geo.attributes.position,uv=geo.attributes.uv,regions=[[],[],[],[]];let changed=false;
  const emit=(r,poly)=>{for(let j=1;j<poly.length-1;j++)regions[r].push(poly[0],poly[j],poly[j+1]);};
  const clipVertices=(poly,axis,value,sign)=>{const out=[];for(let i=0;i<poly.length;i++){const a=poly[i],c=poly[(i+1)%poly.length],da=sign*(a.p[axis]-value),dc=sign*(c.p[axis]-value);if(da>=-1e-8)out.push(a);if((da>0)!==(dc>0)&&Math.abs(da-dc)>1e-9){const t=da/(da-dc);out.push({p:a.p.clone().lerp(c.p,t),uv:a.uv.clone().lerp(c.uv,t)});}}return out;};
  for(let i=0;i<pos.count;i+=3){let poly=[0,1,2].map(j=>({p:new T.Vector3().fromBufferAttribute(pos,i+j).applyMatrix4(matrix),uv:uv?new T.Vector2().fromBufferAttribute(uv,i+j):new T.Vector2()}));if(Math.min(...poly.map(v=>v.p.y))<b.height-.45){emit(0,poly);continue;}for(let r=0;r<4&&poly.length;r++){const [axis,value,sign]=planes[r];emit(r,clipVertices(poly,axis,value,sign));poly=clipVertices(poly,axis,value,-sign);}if(poly.length)changed=true;}
  if(!changed)return false;
  for(const values of regions)if(values.length){const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(values.flatMap(v=>v.p.toArray()),3));if(uv)geometry.setAttribute('uv',new T.Float32BufferAttribute(values.flatMap(v=>v.uv.toArray()),2));geometry.computeVertexNormals();const part=new T.Mesh(geometry,mesh.material);part.name='roof-hatch-cut-piece';part.castShadow=part.receiveShadow=true;part.userData.walkRole=mesh.userData.walkRole;part.userData.walkSupport=mesh.geometry.type==='BoxGeometry';if(roofSkin)part.userData.walkRole='none';add.push(part);}return true;
 }
 g.updateMatrixWorld(true);const inverse=g.matrixWorld.clone().invert();g.traverse(o=>{if(!o.isMesh)return;if(o.isInstancedMesh){for(let i=0;i<o.count;i++){const m=new T.Matrix4();o.getMatrixAt(i,m);m.premultiply(o.matrixWorld).premultiply(inverse);const box=o.geometry.boundingBox||(o.geometry.computeBoundingBox(),o.geometry.boundingBox);const bounds=box.clone().applyMatrix4(m);if(bounds.min.y<b.height-.45||bounds.max.x<h.x0||bounds.min.x>h.x1||bounds.max.z<h.z0||bounds.min.z>h.z1)continue;if(process(o,m)){o.setMatrixAt(i,zero);(o.userData.walkRoles||=[])[i]='none';}}o.instanceMatrix.needsUpdate=true;}else{const m=inverse.clone().multiply(o.matrixWorld),bounds=new T.Box3().setFromObject(o);if(bounds.min.y<b.height-.45+g.position.y)return;if(process(o,m)){o.geometry=new T.BufferGeometry();o.geometry.setAttribute('position',new T.Float32BufferAttribute([],3));o.userData.walkRole='none';delete o.userData.walkParts;}}});for(const m of add)g.add(m);
}
export function addRoofLadder(g,b){const p=roofLadderPlan(b);if(!p)return;const group=new T.Group();group.name=b.id+'-R64-roof-ladder';g.add(group);const iron=new T.MeshStandardMaterial({color:'#51463c',roughness:.92});const count=Math.ceil((p.top-p.bottom)/.28);for(let i=0;i<=count;i++){const y=p.bottom+.25+i*(p.top-p.bottom-.25)/count,points=[[-.23,0,0],[-.23,0,.11],[-.19,0,.20],[.19,0,.20],[.23,0,.11],[.23,0,0]].map(a=>new T.Vector3(p.x+a[0],y,p.z+a[2])),m=new T.Mesh(new T.TubeGeometry(new T.CatmullRomCurve3(points),24,.011,8,false),iron);m.name='R64-independent-U-rung';m.userData.walkRole='none';group.add(m);}
 const stone=new T.MeshStandardMaterial({color:'#d3c9ae',roughness:1}),h=p.hole,half=b.width/2+.045;
 const roofY=x=>b.height+.18+.38*(1-Math.abs(x)/half);
 // Ten-centimetre curb follows the pitched roof; no platform or iron cage.
 for(const [x0,x1,z0,z1] of [[h.x0-.1,h.x0,h.z0-.1,h.z1+.1],[h.x1,h.x1+.1,h.z0-.1,h.z1+.1],[h.x0,h.x1,h.z0-.1,h.z0],[h.x0,h.x1,h.z1,h.z1+.1]]){
  const v=[];for(const lift of [-.02,.10])for(const [x,z] of [[x0,z0],[x1,z0],[x1,z1],[x0,z1]])v.push([x,roofY(x)+lift,z]);
  const points=[];for(const face of [[0,2,1],[0,3,2],[4,5,6],[4,6,7],[0,1,5],[0,5,4],[1,2,6],[1,6,5],[2,3,7],[2,7,6],[3,0,4],[3,4,7]])for(const i of face)points.push(...v[i]);
  const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(points,3));geo.computeVertexNormals();const curb=new T.Mesh(geo,stone);curb.name='roof-hatch-10cm-curb';curb.userData.walkRole='none';curb.castShadow=curb.receiveShadow=true;group.add(curb);
 }
 group.userData.walkRoofSurface={half,length:b.length,eave:b.height+.18,rise:.38,hole:h};
 group.userData.walkLadder={...p,rungCount:count+1};g.userData.roofLadder={reference:'R64',...p};
}
