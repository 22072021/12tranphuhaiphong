import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';

// A door leaf rotates around the left/right jamb, in local façade coordinates.
export function hingedLeafPose(hingeU,faceV,direction,width,angle){
 const half=width/2;
 return {u:hingeU+direction*half*Math.cos(angle),v:faceV+half*Math.sin(angle),rotation:-direction*angle};
}
// Split a thin wall into masonry rectangles around the union of all openings.
export function makeOpeningWall(parent,{side,wallX,faceV,from,to,height,color,openings,profile}){
 const group=new THREE.Group();group.name='opening-wall';parent.add(group);const kit=geometryKit(group,profile),wallDepth=.22;
 const holes=openings.filter(o=>o.u+o.width/2>from&&o.u-o.width/2<to&&o.y+o.height/2>0&&o.y-o.height/2<height).map(o=>({left:Math.max(from,o.u-o.width/2),right:Math.min(to,o.u+o.width/2),bottom:Math.max(0,o.y-o.height/2),top:Math.min(height,o.y+o.height/2),kind:o.kind}));
 const boundaries=[from,to,...holes.flatMap(o=>[o.left,o.right])].sort((a,b)=>a-b).filter((n,i,a)=>!i||n-a[i-1]>1e-6);
 for(let i=0;i<boundaries.length-1;i++){
  const left=boundaries[i],right=boundaries[i+1],middle=(left+right)/2;if(right-left<1e-5)continue;
  const spans=holes.filter(o=>o.left<middle&&o.right>middle).map(o=>[o.bottom,o.top]).sort((a,b)=>a[0]-b[0]);let y=0;
  const wall=(bottom,top)=>{if(top-bottom>1e-5)kit.box(wallDepth,top-bottom,right-left,side*(wallX+faceV-wallDepth/2),(top+bottom)/2,middle,color);};
  for(const [bottom,top] of spans){wall(y,bottom);y=Math.max(y,top);}wall(y,height);
 }
 // Paint the actual ventilation dividers white; retain the clear openings.
 kit.withCollision('none',()=>{for(const o of holes.filter(o=>o.kind==='vent')){const x=side*(wallX+faceV+.002),u=(o.left+o.right)/2;for(const y of [o.bottom-.012,o.top+.012])kit.box(.008,.024,o.right-o.left+.024,x,y,u,'#f1f0e8');for(const z of [o.left-.012,o.right+.012])kit.box(.008,o.top-o.bottom,.024,x,(o.bottom+o.top)/2,z,'#f1f0e8');}});
 kit.finish();group.userData.apertures=holes;group.userData.surface=side*(wallX+faceV);return group;
}
