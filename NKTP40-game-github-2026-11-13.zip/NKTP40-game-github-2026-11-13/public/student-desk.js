// User reference: timber top/shelf and a backed timber bench on independent steel frames.
// Both assemblies feed the shared material batches; no rail connects desk to bench.
export const STUDENT_DESK={id:'timber-steel-detached-bench-v66',deskHeight:.74,deskDepth:.48,seatHeight:.43,seatDepth:.24,backTop:.86,separateBench:true};
export function studentDeskParts({width,x=0,z=0,seatZ=-.52,end=1}){
 const parts=[],add=(assembly,part,w,h,d,px,py,pz,material)=>parts.push({assembly,part,w,h,d,x:px,y:py,z:pz,material});
 const desk=(...a)=>add('desk',...a),bench=(...a)=>add('bench',...a),legX=width/2-.085;
 desk('top',width,.045,.48,x,.7175,z,'wood');
 desk('shelf',width-.12,.025,.36,x,.635,z,'wood');
 for(const a of [-1,1]){const px=x+a*legX;
  for(const b of [-1,1]){desk('leg',.032,.68,.032,px,.35,z+b*.18,'steel');desk('foot-cap',.043,.016,.045,px,.008,z+b*.18,'rubber');}
  desk('side-top-rail',.032,.032,.42,px,.675,z,'steel');
  desk('side-foot-rail',.032,.032,.40,px,.032,z,'steel');
  desk('shelf-side',.032,.032,.38,px,.61,z,'steel');
 }
 for(const b of [-1,1])desk('shelf-cross-rail',width-.12,.032,.032,x,.61,z+b*.16,'steel');
 desk('shelf-divider',.025,.065,.025,x,.675,z-end*.18,'steel');
 bench('seat',width,.04,.24,x,.41,seatZ,'wood');
 bench('backrest',width,.27,.032,x,.725,seatZ-end*.09,'wood');
 for(const a of [-1,1]){const px=x+a*legX;
  for(const b of [-1,1]){bench('leg',.032,.38,.032,px,.20,seatZ+b*.085,'steel');bench('foot-cap',.043,.016,.045,px,.008,seatZ+b*.085,'rubber');}
  bench('seat-side-rail',.032,.032,.22,px,.375,seatZ,'steel');
  bench('back-post',.032,.46,.032,px,.60,seatZ-end*.085,'steel');
  bench('foot-rail',.032,.032,.27,px,.032,seatZ,'steel');
 }
 bench('cross-brace',width-.12,.032,.032,x,.20,seatZ,'steel');
 return parts;
}
export function emitStudentDesk(kit,options,{wood='#b08a52',steel='#79827c',rubber='#303735'}={}){
 for(const p of studentDeskParts(options))kit.box(p.w,p.h,p.d,p.x,p.y+(options.level??0),p.z,{wood,steel,rubber}[p.material]);
}
