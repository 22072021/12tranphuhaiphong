import * as T from './vendor/three.module.js';
import {createOldCampusTree} from './old-campus-tree.js';
export const R16_TREE_POSITIONS=[{x:-46,z:19},{x:-46,z:29},{x:-46,z:39}];
// R16 shows upright courtyard trees with branching trunks, rather than the leaning R01 specimen.
export function createR16CourtyardTrees(){
 const group=new T.Group();group.name='R16-three-courtyard-trees';
 for(const [index,p]of R16_TREE_POSITIONS.entries()){
  const tree=createOldCampusTree(p);tree.name='R16-courtyard-tree-'+(index+1);const bark=tree.getObjectByName('R01-root-flare').material;
  for(const o of [...tree.children])if(['old-tree-branch','R01-root-flare','R01-crown-clusters'].includes(o.name))tree.remove(o);
  function branch(a,b,r0,r1){const A=new T.Vector3(...a),B=new T.Vector3(...b),v=B.clone().sub(A),m=new T.Mesh(new T.CylinderGeometry(r1,r0,v.length(),9),bark);m.name='R16-trunk-branch';m.position.copy(A.add(B).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());m.castShadow=m.receiveShadow=true;tree.add(m);}
  const fork=[.12,3.1,-.08];branch([0,.14,0],fork,.35,.24);const roots=new T.Mesh(new T.SphereGeometry(1,12,8),bark);roots.scale.set(.48,.28,.45);roots.position.y=.25;roots.name='R16-root-flare';tree.add(roots);
  const tips=[];for(let i=0;i<6;i++){const a=i*Math.PI/3+index*.41,tip=[Math.cos(a)*(1.8+i%2*.6),6.5+(i%3)*.5,Math.sin(a)*(1.8+i%2*.6)];branch(fork,tip,.16,.055);for(let j=0;j<3;j++){const q=[tip[0]+Math.cos(a+j-1)*1.1,tip[1]+.8+j*.2,tip[2]+Math.sin(a+j-1)*1.1];branch(tip,q,.055,.014);tips.push(q);}}
  for(let c=0;c<3;c++){const foliage=new T.InstancedMesh(new T.IcosahedronGeometry(1,1),new T.MeshStandardMaterial({color:['#486b3d','#64824a','#395d36'][c],roughness:1}),tips.length),m=new T.Matrix4();tips.forEach((q,i)=>{m.makeScale(.9+(i%3)*.16,.62+(i%2)*.19,.85+(i%4)*.12);m.setPosition(q[0]+Math.cos(i*2.4+c)*.55,q[1]+Math.sin(i+c)*.4,q[2]+Math.sin(i*2.4+c)*.55);foliage.setMatrixAt(i,m);});foliage.name='R16-leaf-clusters';foliage.castShadow=true;foliage.userData.walkRole='none';tree.add(foliage);}
  tree.userData.reference='R16';tree.userData.markedPosition=index+1;group.add(tree);
 }
 return group;
}
