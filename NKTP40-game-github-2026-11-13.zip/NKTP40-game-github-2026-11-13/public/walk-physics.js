import {FOOD_CATALOG} from './food-catalog.js';
import {insideLanguageAlley,isLanguageAlleyRestricted} from './foreign-language-alley-layout.js';
import {insideStreetWalkLimit} from './exterior-street-layout.js';
import {CAMPUS_GROUND_BOUNDS as GROUND_LIMITS,rearLimit,insideCampusGround} from './campus-limits.js';
import {createDoorController} from './door-controller.js?v=239.0';
import {administrationPlan} from './admin-design.js?v=56.0';
import * as THREE from './vendor/three.module.js';
import {groundHeight} from './raised-platform.js?v=223.0';
import {buildingBaseProfile} from './building-bases.js?v=247.0';
import {classroomStairPlan} from './stair-design.js?v=228.0';

const CELL=3,EPS=.035;
export const WALKER={radius:.216,height:1.512,eye:1.422,maxStep:.52,speed:8.4};
const matrix=new THREE.Matrix4(),instance=new THREE.Matrix4();
function boxCollider(bounds,m,canSupport=true){
 const size=bounds.getSize(new THREE.Vector3()),center=bounds.getCenter(new THREE.Vector3()).applyMatrix4(m),e=m.elements;
 const sx=Math.hypot(e[0],e[1],e[2]),sy=Math.hypot(e[4],e[5],e[6]),sz=Math.hypot(e[8],e[9],e[10]);
 const yawOnly=Math.abs(e[1])+Math.abs(e[4])+Math.abs(e[6])+Math.abs(e[9])<1e-5&&e[5]>0;
 let hx,hy,hz,c=1,s=0;
 if(yawOnly){hx=size.x*sx/2;hy=size.y*sy/2;hz=size.z*sz/2;c=e[0]/sx;s=e[2]/sx;}
 else{const a=bounds.clone().applyMatrix4(m),v=a.getSize(new THREE.Vector3());a.getCenter(center);hx=v.x/2;hy=v.y/2;hz=v.z/2;}
 const ax=Math.abs(c)*hx+Math.abs(s)*hz,az=Math.abs(s)*hx+Math.abs(c)*hz;
 return{x:center.x,y:center.y,z:center.z,hx,hz,c,s,minY:center.y-hy,maxY:center.y+hy,minX:center.x-ax,maxX:center.x+ax,minZ:center.z-az,maxZ:center.z+az,support:yawOnly&&canSupport,oblique:!yawOnly,axes:[[e[0]/sx,e[1]/sx,e[2]/sx],[e[4]/sy,e[5]/sy,e[6]/sy],[e[8]/sz,e[9]/sz,e[10]/sz]],half:[size.x*sx/2,size.y*sy/2,size.z*sz/2]};
}
function overlaps(a,x,z,radius){const dx=x-a.x,dz=z-a.z,u=a.c*dx+a.s*dz,v=-a.s*dx+a.c*dz,qx=Math.max(Math.abs(u)-a.hx,0),qz=Math.max(Math.abs(v)-a.hz,0);return qx*qx+qz*qz<radius*radius-1e-8;}
function capsuleHitsOblique(a,x,z,feet,radius,height){
 const dx=x-a.x,dy=feet+radius-a.y,dz=z-a.z,length=height-2*radius,p=a.axes.map(v=>v[0]*dx+v[1]*dy+v[2]*dz),d=a.axes.map(v=>v[1]*length),breaks=[0,1];
 for(let k=0;k<3;k++)if(Math.abs(d[k])>1e-9)for(const sign of [-1,1]){const t=(sign*a.half[k]-p[k])/d[k];if(t>0&&t<1)breaks.push(t);}breaks.sort((x,y)=>x-y);
 const distance=t=>p.reduce((sum,v,k)=>sum+Math.max(Math.abs(v+d[k]*t)-a.half[k],0)**2,0);let best=Math.min(distance(0),distance(1));
 for(let j=0;j<breaks.length-1;j++){const lo=breaks[j],hi=breaks[j+1],mid=(lo+hi)/2;let A=0,B=0;for(let k=0;k<3;k++){const q=p[k]+d[k]*mid;if(Math.abs(q)>a.half[k]){const offset=p[k]-Math.sign(q)*a.half[k];A+=d[k]*d[k];B+=d[k]*offset;}}const t=A?Math.max(lo,Math.min(hi,-B/A)):mid;best=Math.min(best,distance(t));}
 return best<radius*radius-1e-8;
}
export function createCollisionWorld(roots,{canAccessLanguageAlley=()=>false}={}){
 const grid=new Map(),doors=[],ramps=[],helices=[],seats=[],ladders=[],fenceClimbs=[],porches=[],roofSurfaces=[],roofs=[],slideRails=[],dynamicSources=[];let dynamic=[];let bikeUnavailable=()=>false;let count=0;const chunks=new Map();
 function chunkRecord(o){for(let p=o;p;p=p.parent)if(p.userData.streamingChunk){if(!chunks.has(p))chunks.set(p,{colliders:new Set(),lanes:new Set()});return chunks.get(p);}return null;}
 function addSeat(lane,o){const value={...lane,matrix:o.matrixWorld.clone(),inverse:o.matrixWorld.clone().invert()};for(let parent=o;parent;parent=parent.parent){if(FOOD_CATALOG.some(f=>f.station===parent.name)){value.foodStation=parent.name;break;}}seats.push(value);chunkRecord(o)?.lanes.add(value);}
 function add(a,o){chunkRecord(o)?.colliders.add(a);count++;for(let x=Math.floor(a.minX/CELL);x<=Math.floor(a.maxX/CELL);x++)for(let z=Math.floor(a.minZ/CELL);z<=Math.floor(a.maxZ/CELL);z++){const key=x+','+z;if(!grid.has(key))grid.set(key,[]);grid.get(key).push(a);}}
 function readMesh(o,emit){
  let owner=o;while(owner&&!owner.userData.id)owner=owner.parent;const push=a=>{a.owner=owner?.userData.id||null;for(let p=o;p;p=p.parent)if(p.userData.rideBikeId){a.bikeId=p.userData.rideBikeId;break;}emit(a);};
  o.geometry.computeBoundingBox();
  if(o.isInstancedMesh){for(let i=0;i<o.count;i++){if(o.userData.walkRoles?.[i]==='none')continue;o.getMatrixAt(i,instance);matrix.multiplyMatrices(o.matrixWorld,instance);const collider=boxCollider(o.geometry.boundingBox,matrix,o.name!=='detail-ring'&&!['furniture','barrier'].includes(o.userData.walkRoles?.[i]));collider.bikeId=o.userData.bikeIds?.[i];push(collider);}}
  else if(o.userData.walkParts){for(const p of o.userData.walkParts)if(p.walkRole!=='none')push(boxCollider(p.bounds,o.matrixWorld,p.bounds.max.y-p.bounds.min.y<.25));}
  else push(boxCollider(o.geometry.boundingBox,o.matrixWorld,o.userData.walkSupport!==false&&(o.geometry.type==='BoxGeometry'||o.userData.walkSupport===true)));
 }
 function collect(root){root.updateWorldMatrix(true,true);root.traverse(o=>{
  if(o.userData.walkPorch)porches.push({spec:o.userData.walkPorch,matrix:o.matrixWorld.clone(),inverse:o.matrixWorld.clone().invert()});
  if(o.userData.walkFenceClimb)fenceClimbs.push(o.userData.walkFenceClimb);
  if(o.userData.walkRoofSurface)roofSurfaces.push({spec:o.userData.walkRoofSurface,matrix:o.matrixWorld.clone(),inverse:o.matrixWorld.clone().invert()});if(o.userData.walkRoof)roofs.push({spec:o.userData.walkRoof,inverse:o.matrixWorld.clone().invert()});if(o.userData.walkLadder)ladders.push({spec:o.userData.walkLadder,matrix:o.matrixWorld.clone(),inverse:o.matrixWorld.clone().invert()});if(o.userData.walkSlideRails)for(const flight of o.userData.walkSlideRails)for(const side of [Math.sign(o.userData.stairCenter-flight.from.z)])slideRails.push({flight,side,matrix:o.matrixWorld.clone(),inverse:o.matrixWorld.clone().invert()});if(o.userData.walkHelix)helices.push({spec:o.userData.walkHelix,matrix:o.matrixWorld.clone(),inverse:o.matrixWorld.clone().invert()});if(o.userData.seatLanes)for(const lane of o.userData.seatLanes)addSeat(lane,o);if(o.userData.walkRamp)ramps.push({spec:o.userData.walkRamp,matrix:o.matrixWorld.clone(),inverse:o.matrixWorld.clone().invert()});if(o.userData.door)doors.push(o);if(!o.isMesh||o.userData.signText||o.userData.walkRole==='none')return;
  let p=o,dynamicDoor=false;while(p){if(p.userData.walkIgnore)return;if(p.userData.door||p.userData.movingAperture)dynamicDoor=true;p=p.parent;}
  if(dynamicDoor)dynamicSources.push(o);else readMesh(o,a=>add(a,o));
 });}
 for(const root of roots)collect(root);
 function syncInteriorChunks(added=[],removed=[]){for(const root of removed){const record=chunks.get(root);if(!record)continue;const keys=new Set();for(const a of record.colliders)for(let x=Math.floor(a.minX/CELL);x<=Math.floor(a.maxX/CELL);x++)for(let z=Math.floor(a.minZ/CELL);z<=Math.floor(a.maxZ/CELL);z++)keys.add(x+','+z);for(const key of keys){const keep=grid.get(key).filter(a=>!record.colliders.has(a));if(keep.length)grid.set(key,keep);else grid.delete(key);}count-=record.colliders.size;for(let i=seats.length-1;i>=0;i--)if(record.lanes.has(seats[i]))seats.splice(i,1);chunks.delete(root);}for(const root of added)collect(root);}
 function refreshDoors(){dynamic=[];for(const door of doors)door.updateWorldMatrix(true,true);for(const o of dynamicSources)readMesh(o,a=>dynamic.push(a));}
 refreshDoors();
 function near(x,z,r=WALKER.radius){const set=new Set();for(let a=Math.floor((x-r)/CELL);a<=Math.floor((x+r)/CELL);a++)for(let b=Math.floor((z-r)/CELL);b<=Math.floor((z+r)/CELL);b++)for(const v of grid.get(a+','+b)||[])set.add(v);for(const v of dynamic)if(v.maxX>x-r&&v.minX<x+r&&v.maxZ>z-r&&v.minZ<z+r)set.add(v);for(const v of set)if(bikeUnavailable(v.bikeId))set.delete(v);return set;}
 function blocked(x,z,feet,radius=WALKER.radius,height=WALKER.height){if(isLanguageAlleyRestricted(x,z,radius)&&!canAccessLanguageAlley())return true;if(!insideLanguageAlley(x,z,radius)&&(!insideStreetWalkLimit(x,z,radius)||!insideCampusGround(x,z,radius)||x-radius<GROUND_LIMITS.xmin||x+radius>Math.min(rearLimit(z-radius),rearLimit(z+radius))||z-radius<GROUND_LIMITS.zmin||z+radius>GROUND_LIMITS.zmax))return true;for(const a of near(x,z,radius))if(!bikeUnavailable(a.bikeId)&&a.maxY>feet+EPS&&a.minY<feet+height-.015&&overlaps(a,x,z,radius)&&(!a.oblique||capsuleHitsOblique(a,x,z,feet,radius,height)))return true;return false;}
 function porchHeight(p,u,v){return p.eave+p.rise*Math.max(0,Math.min((v-p.back)/(p.ridgeV-p.back),(p.depth-v)/(p.depth-p.ridgeV),(u+p.width/2)/p.hip,(p.width/2-u)/p.hip));}
 function porchRoute(x,z,feet,dx,dz){
  for(const roof of porches){const p=roof.spec,q=new THREE.Vector3(x,feet,z).applyMatrix4(roof.inverse),v=p.side*q.x-p.wallX,u=q.z-p.u,delta=new THREE.Vector3(dx,0,dz).transformDirection(roof.inverse),out=p.side*delta.x;
   for(const sign of [-1,1]){const lane=sign*p.portalOffset;if(Math.abs(u-lane)>.42)continue;const outside=v>.65,targetV=outside?-.55:1.05,sourceV=outside?1.05:-.55,level=outside?porchHeight(p,lane,sourceV):p.floor;
    if(Math.abs(v-sourceV)>.45||Math.abs(q.y-level)>.35||out*(outside?-1:1)<=.001)continue;
    const target=new THREE.Vector3(p.side*(p.wallX+targetV),outside?p.floor:porchHeight(p,lane,targetV),p.u+lane).applyMatrix4(roof.matrix);
    if(blocked(target.x,target.z,target.y))continue;
    return{from:new THREE.Vector3(x,feet,z),to:target,crest:new THREE.Vector3(q.x,Math.max(p.floor+1.12,q.y+.45),q.z).applyMatrix4(roof.matrix).y};
   }
  }return null;
 }
 function supportAt(x,z,maxY,radius=WALKER.radius){let y=-.1;for(const roof of porches){const p=roof.spec,q=new THREE.Vector3(x,0,z).applyMatrix4(roof.inverse),u=q.z-p.u,v=p.side*q.x-p.wallX;if(Math.abs(u)<=p.width/2&&v>=p.back&&v<=p.depth){const level=new THREE.Vector3(q.x,porchHeight(p,u,v),q.z).applyMatrix4(roof.matrix).y;if(level<=maxY+1e-5)y=Math.max(y,level);}}const terrain=groundHeight(x,z);if(terrain<=maxY+1e-5)y=Math.max(y,terrain);for(const a of near(x,z,radius))if(a.support&&a.maxY<=maxY+1e-5&&a.maxY>y&&overlaps(a,x,z,radius))y=a.maxY;for(const r of roofSurfaces){const p=new THREE.Vector3(x,0,z).applyMatrix4(r.inverse),q=r.spec,h=q.hole;if(Math.abs(p.x)>q.half||Math.abs(p.z)>q.length/2||p.x>h.x0&&p.x<h.x1&&p.z>h.z0&&p.z<h.z1)continue;const level=new THREE.Vector3(p.x,q.eave+q.rise*(1-Math.abs(p.x)/q.half),p.z).applyMatrix4(r.matrix).y;if(level<=maxY+1e-5)y=Math.max(y,level);}for(const r of ramps){const p=new THREE.Vector3(x,0,z).applyMatrix4(r.inverse),q=r.spec;if(p.x<q.x0||p.x>q.x1||p.z<q.z0||p.z>q.z1)continue;const h=q.height*(q.x1-p.x)/(q.x1-q.x0),level=new THREE.Vector3(p.x,h,p.z).applyMatrix4(r.matrix).y;if(level<=maxY+1e-5)y=Math.max(y,level);}for(const r of helices){const p=new THREE.Vector3(x,0,z).applyMatrix4(r.inverse),q=r.spec,rad=Math.hypot(p.x,p.z);if(rad<q.inner||rad>q.outer)continue;let a=q.dir*(Math.atan2(p.z,p.x)-q.start);a=((a%(2*Math.PI))+2*Math.PI)%(2*Math.PI);for(let t=a;t<=q.total+1e-5;t+=2*Math.PI){const h=q.height*Math.min(q.count,Math.max(1,Math.ceil(t/q.total*q.count)))/q.count,level=new THREE.Vector3(p.x,h,p.z).applyMatrix4(r.matrix).y;if(level<=maxY+1e-5)y=Math.max(y,level);}}return y;}
 const {nearestDoor,interact,updateDoors,lockedPassageExit}=createDoorController(doors,{refreshDoors,blocked});
 // A roof exit is an explicit ladder/stair route, never a free fall over an eave.
 // Local coordinates retain protection when buildings are moved or rotated.
 function roofMoveAllowed(x,z,feet,nx,nz,nextSupport){
  // Porch eaves deliberately allow a misstep and gravity-driven fall.
  for(const roof of roofs){const p=roof.spec,q=new THREE.Vector3(x,feet,z).applyMatrix4(roof.inverse);
   if(q.y<p.minimumY||Math.abs(q.x)>p.width/2+.35||Math.abs(q.z)>p.length/2+.35)continue;
   const n=new THREE.Vector3(nx,feet,nz).applyMatrix4(roof.inverse),lx=p.width/2-WALKER.radius-.04,lz=p.length/2-WALKER.radius-.04;
   const overflow=v=>Math.max(0,Math.abs(v.x)-lx,Math.abs(v.z)-lz),before=overflow(q),after=overflow(n);
   if(after>1e-5&&after>=before-1e-5||nextSupport<feet-WALKER.maxStep)return false;
  }return true;
 }
 function surfaceOwner(x,z,feet){for(const a of near(x,z))if(a.owner&&a.support&&Math.abs(a.maxY-feet)<.055&&overlaps(a,x,z,WALKER.radius))return a.owner;return null;}
 function sweepCamera(from,to,radius=.18){
  const list=new Set();for(let x=Math.floor((Math.min(from.x,to.x)-radius)/CELL);x<=Math.floor((Math.max(from.x,to.x)+radius)/CELL);x++)for(let z=Math.floor((Math.min(from.z,to.z)-radius)/CELL);z<=Math.floor((Math.max(from.z,to.z)+radius)/CELL);z++)for(const a of grid.get(x+','+z)||[])list.add(a);for(const a of dynamic)list.add(a);
  const dx=to.x-from.x,dy=to.y-from.y,dz=to.z-from.z;let fraction=1;
  for(const a of list){if(a.maxY+radius<Math.min(from.y,to.y)||a.minY-radius>Math.max(from.y,to.y))continue;let lo=0,hi=fraction,hit=true;
   for(let k=0;k<3;k++){const v=a.axes[k],p=v[0]*(from.x-a.x)+v[1]*(from.y-a.y)+v[2]*(from.z-a.z),d=v[0]*dx+v[1]*dy+v[2]*dz,h=a.half[k]+radius;
    if(Math.abs(d)<1e-9){if(Math.abs(p)>h){hit=false;break;}}else{let t0=(-h-p)/d,t1=(h-p)/d;if(t0>t1)[t0,t1]=[t1,t0];lo=Math.max(lo,t0);hi=Math.min(hi,t1);if(lo>hi){hit=false;break;}}
   }if(hit&&lo>=0&&lo<=fraction)fraction=Math.max(0,lo-.015/Math.max(.01,Math.hypot(dx,dy,dz)));
  }
  return new THREE.Vector3(from.x+dx*fraction,from.y+dy*fraction,from.z+dz*fraction);
 }
 return{setBikeUnavailable(fn){bikeUnavailable=fn||(()=>false);},porchRoute,syncInteriorChunks,seats,ladders,fenceClimbs,slideRails,roofMoveAllowed,blocked,supportAt,near,nearestDoor,interact,refreshDoors,updateDoors,lockedPassageExit,surfaceOwner,sweepCamera,stats:{staticColliders:count,doorCount:doors.length,cells:grid.size}};
}

export function createWalker(world,start){
 const state={x:start.x,z:start.z,feet:start.feet??world.supportAt(start.x,start.z,WALKER.maxStep),velocity:0,blocked:false};
 let activePorch=null,porchCooldown=0;let activeFence=null,fenceCooldown=0;let activeClimb=null;let seatApproach=null;let activeSeat=null,seatCooldown=0,activeSlide=null,slideCooldown=0;
 function nearestLadder(){if(activeFence||activeClimb||activeSeat||activeSlide)return null;for(const p of world.fenceClimbs||[])for(const side of [-1,1]){if(fenceCooldown>0)continue;const x=p.x+side*p.distance;if(Math.hypot(state.x-x,state.z-p.z)<.36&&Math.abs(state.feet-(side<0?.0755:.035))<.25)return{fence:p,side};}let best=null,min=.85;for(const ladder of world.ladders||[]){const q=new THREE.Vector3(state.x,state.feet,state.z).applyMatrix4(ladder.inverse),p=ladder.spec;for(const [end,target]of [['bottom',p.foot],['top',p.exit]]){const d=Math.hypot(q.x-target.x,q.z-target.z);if(d<min&&Math.abs(q.y-target.y)<.30){const from=new THREE.Vector3(state.x,state.feet+.85,state.z),to=new THREE.Vector3(target.x,target.y+.85,target.z).applyMatrix4(ladder.matrix);if(world.sweepCamera(from,to,.08).distanceTo(to)>.025)continue;min=d;best={ladder,end};}}}return best;}
 function climb(){const choice=nearestLadder();if(!choice)return false;if(choice.fence){const p=choice.fence,side=choice.side,endX=p.x-side*.80,feet=world.supportAt(endX,p.z,.55);if(world.blocked(endX,p.z,feet))return false;activeFence={spec:p,side,elapsed:0,start:{x:state.x,z:state.z,feet:state.feet},landing:{x:endX,z:p.z,feet}};state.climbing=true;state.climbFrame=null;state.seated=false;state.velocity=0;return true;}const {ladder,end}=choice,p=ladder.spec;const top={x:p.foot.x,y:p.top-.85,z:p.foot.z},current=new THREE.Vector3(state.x,state.feet,state.z).applyMatrix4(ladder.inverse),path=end==='bottom'?[current,p.foot,top,p.exit]:[current,p.exit,top,p.foot];activeClimb={ladder,path,index:0,t:0,speed:end==='bottom'?1.5:.75};state.climbing=true;state.climbPhase=0;state.seated=false;state.velocity=0;return true;}
 function nearestSeat(){if(activeFence||activeClimb||activeSeat||activeSlide||seatCooldown>0)return null;let best=null,min=.86;for(const seat of world.seats||[]){const q=new THREE.Vector3(state.x,state.feet,state.z).applyMatrix4(seat.inverse);if(Math.abs(q.y)>(seat.roof?.65:.32))continue;const x=seat.centered?0:THREE.MathUtils.clamp(q.x,seat.xmin+.22,seat.xmax-.22),distance=Math.hypot(q.x-x,q.z-seat.z);if(distance<min){const point=new THREE.Vector3(x,0,seat.z+(seat.centered?0:seat.end*.06)).applyMatrix4(seat.matrix);let clear=true;for(const height of (seat.rearEntry?[1.3]:[.95,1.3])){const from=new THREE.Vector3(state.x,state.feet+height,state.z),to=new THREE.Vector3(point.x,point.y+height,point.z);if(world.sweepCamera&&world.sweepCamera(from,to,.06).distanceToSquared(to)>.0001){clear=false;break;}}if(clear){min=distance;best={seat,point};}}}return best;}
 function sit(){const choice=nearestSeat();if(!choice)return false;seatApproach={x:state.x,z:state.z,feet:state.feet};const {seat,point}=choice,forward=new THREE.Vector3(0,0,seat.end).transformDirection(seat.matrix);activeSeat=seat;if(seat.omnidirectional){forward.set(state.x-point.x,0,state.z-point.z);if(forward.lengthSq()<1e-8)forward.set(0,0,1);forward.normalize();}state.x=point.x;state.z=point.z;state.feet=point.y;state.seated=true;state.stoneBench=seat.kind==='stone'?new THREE.Vector3(0,0,0).applyMatrix4(seat.matrix).toArray().map(v=>Math.round(v*100)/100):null;state.seatStation=seat.foodStation||null;state.gameStation=seat.gameStation||null;state.seatKind=seat.kind;state.seatSize=seat.size;state.seatHeight=seat.height;state.seatYaw=Math.atan2(forward.x,forward.z);state.velocity=0;return true;}
 function stand(preferred){
  if(!activeSeat||activeSlide)return false;
  const seat=activeSeat,q=new THREE.Vector3(state.x,state.feet,state.z).applyMatrix4(seat.inverse),candidates=[],add=(x,z)=>candidates.push(new THREE.Vector3(x,0,z).applyMatrix4(seat.matrix));
  if(preferred?.lengthSq()>.000001){const d=preferred.clone().normalize().transformDirection(seat.inverse);for(const distance of [.58,.72,.90,1.08])add(q.x+d.x*distance,q.z+d.z*distance);}
  for(const distance of [.60,.75,.90,1.08])for(const offset of [0,-.24,.24])add(q.x+offset,seat.z+seat.end*distance);
  for(const side of [-1,1])for(const distance of [.38,.55,.72])add((side<0?seat.xmin:seat.xmax)+side*distance,seat.z);
  if(seatApproach&&Math.hypot(state.x-seatApproach.x,state.z-seatApproach.z)<1.35)candidates.push(new THREE.Vector3(seatApproach.x,seatApproach.feet,seatApproach.z));
  for(const exit of candidates){const feet=world.supportAt(exit.x,exit.z,state.feet+(seat.roof?seat.height+.20:.20));if(Math.abs(feet-state.feet)>(seat.roof?seat.height+.30:.30)||world.blocked(exit.x,exit.z,feet))continue;let clear=true;
   for(const h of [Math.max(.62,(seat.height||.4)+.14),.95,1.3]){const from=new THREE.Vector3(state.x,state.feet+h,state.z),to=new THREE.Vector3(exit.x,feet+h,exit.z);if(world.sweepCamera&&world.sweepCamera(from,to,.08).distanceToSquared(to)>.0001){clear=false;break;}}if(!clear)continue;
   state.x=exit.x;state.z=exit.z;state.feet=feet;state.seated=false;state.stoneBench=null;state.seatStation=null;state.gameStation=null;state.playingGame=false;state.seatKind=null;state.velocity=0;state.blocked=false;activeSeat=null;seatApproach=null;seatCooldown=.65;return true;
  }
  state.blocked=true;return false;
 }
 function canStand(x,z){const support=world.supportAt(x,z,state.feet+WALKER.maxStep),feet=Math.max(state.feet,support);if(!world.roofMoveAllowed(state.x,state.z,state.feet,x,z,support))return null;return!world.blocked(x,z,feet)?feet:null;}
 function step(dx,dz,dt){
  if(!activeFence&&!activeClimb){const exit=world.lockedPassageExit?.(state.x,state.z,state.feet);if(exit){state.x=exit.x;state.z=exit.z;state.blocked=false;}}
  porchCooldown=Math.max(0,porchCooldown-dt);
  if(activePorch){const a=activePorch;a.time=Math.min(1,a.time+dt/1.15);const t=a.time,s=t*t*(3-2*t);state.x=THREE.MathUtils.lerp(a.from.x,a.to.x,s);state.z=THREE.MathUtils.lerp(a.from.z,a.to.z,s);state.feet=THREE.MathUtils.lerp(a.from.y,a.to.y,s)+Math.sin(Math.PI*t)*(a.crest-(a.from.y+a.to.y)/2);state.velocity=0;state.blocked=false;if(t===1){state.feet=a.to.y;activePorch=null;porchCooldown=.5;}return state;}
  if(!activeSeat&&!activeClimb&&!activeFence&&!activeSlide&&porchCooldown===0&&Math.hypot(dx,dz)>.001){const route=world.porchRoute?.(state.x,state.z,state.feet,dx,dz);if(route){activePorch={...route,time:0};return state;}}
  fenceCooldown=Math.max(0,fenceCooldown-dt);
  if(activeFence){const a=activeFence;a.elapsed+=Math.min(dt,.1);if(a.elapsed>=12.3){Object.assign(state,a.landing,{climbing:false,fenceClimb:null,climbFrame:null,velocity:0,blocked:false});activeFence=null;fenceCooldown=.8;return state;}const yaw=a.side<0?Math.PI/2:-Math.PI/2,matrix=new THREE.Matrix4().makeRotationY(yaw);matrix.setPosition(a.spec.x,a.side<0?.0755:.035,a.spec.z);state.fenceClimb={time:Math.max(0,a.elapsed-.3),height:a.spec.height,yaw,matrix,approach:Math.min(1,a.elapsed/.3),start:a.start};state.climbing=true;state.velocity=0;return state;}
  if(activeClimb){const a=activeClimb,p=a.ladder.spec;if(a.index>=a.path.length-1){state.climbing=false;activeClimb=null;state.velocity=0;return state;}const from=a.path[a.index],to=a.path[a.index+1],length=Math.hypot(to.x-from.x,to.y-from.y,to.z-from.z);a.t=Math.min(1,a.t+dt/Math.max(a.index===(a.speed===1.5?2:1)?1.35:0,length/a.speed,.18));const local=new THREE.Vector3().lerpVectors(new THREE.Vector3(from.x,from.y,from.z),new THREE.Vector3(to.x,to.y,to.z),a.t),point=local.clone().applyMatrix4(a.ladder.matrix),facing=new THREE.Vector3(0,0,-1).transformDirection(a.ladder.matrix);state.x=point.x;state.z=point.z;state.feet=point.y;state.climbYaw=Math.atan2(facing.x,facing.z);state.climbPhase=(local.y-p.bottom)/.56*Math.PI*2;state.climbVertical=Math.abs(to.y-from.y)>.4;state.climbFrame={spec:p,matrix:a.ladder.matrix,rungs:p.rungCount,height:local.y,stage:a.index===(a.speed===1.5?1:2)?'vertical':a.index===(a.speed===1.5?2:1)?'exit':'approach',progress:a.speed===1.5?a.t:1-a.t};state.velocity=0;if(a.t===1){a.index++;a.t=0;}return state;}
  state.blocked=false;seatCooldown=Math.max(0,seatCooldown-dt);slideCooldown=Math.max(0,slideCooldown-dt);
  if(activeSlide){const {rail}=activeSlide,f=rail.flight;activeSlide.t=Math.max(0,activeSlide.t-dt*1.65/Math.abs(f.to.x-f.from.x));const t=activeSlide.t,x=f.from.x+(f.to.x-f.from.x)*t,y=f.from.y+(f.to.y-f.from.y)*t,z=f.from.z+rail.side*(f.width/2-.26)*Math.min(1,t/.15),pt=new THREE.Vector3(x,y,z).applyMatrix4(rail.matrix),railPoint=new THREE.Vector3(x,y,f.from.z+rail.side*f.width/2).applyMatrix4(rail.matrix);state.slideOffsetX=railPoint.x-pt.x;state.slideOffsetZ=railPoint.z-pt.z;state.x=pt.x;state.z=pt.z;state.feet=pt.y;state.seated=true;state.sliding=true;state.seatHeight=.92;state.velocity=0;if(t===0){const supported=world.supportAt(state.x,state.z,state.feet+WALKER.maxStep);if(!world.blocked(state.x,state.z,supported))state.feet=supported;activeSlide=null;state.seated=false;state.sliding=false;state.slideOffsetX=0;state.slideOffsetZ=0;slideCooldown=1.5;}return state;}
  if(!state.bicycling&&!activeSeat&&slideCooldown===0&&Math.hypot(dx,dz)>.00001)for(const rail of world.slideRails||[]){const f=rail.flight,q=new THREE.Vector3(state.x,state.feet,state.z).applyMatrix4(rail.inverse),delta=new THREE.Vector3(dx,0,dz).transformDirection(rail.inverse),t=(q.x-f.from.x)/(f.to.x-f.from.x),height=f.from.y+(f.to.y-f.from.y)*t,dist=rail.side*(q.z-f.from.z);if(t>.12&&t<.96&&Math.abs(q.y-height)<.38&&dist>f.width/2-.38&&dist<f.width/2-.18&&delta.x*(f.to.x-f.from.x)<-.25){const d=new THREE.Vector3(0,0,-rail.side).transformDirection(rail.matrix);state.seatYaw=Math.atan2(d.x,d.z);activeSlide={rail,t};state.seated=true;state.sliding=true;state.seatHeight=.92;return state;}}

  // Stone benches face away from a tree bed; dismount forwards instead of requiring
  // a sideways exit through neighbouring benches or their legs.
  if((activeSeat?.kind==='stone'||activeSeat?.kind==='step')&&Math.hypot(dx,dz)>.00001){
   const local=new THREE.Vector3(state.x,state.feet,state.z).applyMatrix4(activeSeat.inverse),delta=new THREE.Vector3(dx,0,dz).transformDirection(activeSeat.inverse),atEdge=local.x+delta.x*Math.hypot(dx,dz)*.5<activeSeat.xmin||local.x+delta.x*Math.hypot(dx,dz)*.5>activeSeat.xmax;
   if(Math.abs(delta.z)>.25||atEdge){
    stand(new THREE.Vector3(dx,0,dz));state.velocity=0;return state;
   }
  }
  if(activeSeat?.centered){if(Math.hypot(dx,dz)>.00001)stand(new THREE.Vector3(dx,0,dz));state.velocity=0;return state;}
  if(activeSeat){const local=new THREE.Vector3(state.x,state.feet,state.z).applyMatrix4(activeSeat.inverse),delta=new THREE.Vector3(dx,0,dz).transformDirection(activeSeat.inverse),length=Math.hypot(dx,dz),motion=length?delta.x*length*.5:0;
   const nx=local.x+motion,edge=nx<activeSeat.xmin?activeSeat.xmin:nx>activeSeat.xmax?activeSeat.xmax:null;
   if(edge!==null){stand(new THREE.Vector3(dx,0,dz));}
   else{const q=new THREE.Vector3(nx,0,activeSeat.z+activeSeat.end*.06).applyMatrix4(activeSeat.matrix);state.x=q.x;state.z=q.z;}
   state.velocity=0;return state;
  }

  const parts=Math.max(1,Math.ceil(Math.hypot(dx,dz)/.055)),sx=dx/parts,sz=dz/parts;
  for(let j=0;j<parts;j++){
   const together=canStand(state.x+sx,state.z+sz);
   if(together!==null){state.x+=sx;state.z+=sz;state.feet=together;}
   else{state.blocked=true;const xx=canStand(state.x+sx,state.z);if(xx!==null){state.x+=sx;state.feet=xx;}const zz=canStand(state.x,state.z+sz);if(zz!==null){state.z+=sz;state.feet=zz;}}
  }
  const support=world.supportAt(state.x,state.z,state.feet+WALKER.maxStep);
  if(support>=state.feet-WALKER.maxStep&&!world.blocked(state.x,state.z,support)){state.feet=support;state.velocity=0;}
  else{state.velocity=Math.max(-12,state.velocity-9.81*dt);state.feet=Math.max(support,state.feet+state.velocity*dt);if(state.feet<=support+.001)state.velocity=0;}
  return state;
 }
 function restoreFoodSeat(location){const seat=(world.seats||[]).find(s=>{if(s.foodStation!==location.seatStation)return false;const p=new THREE.Vector3(location.x,location.feet,location.z).applyMatrix4(s.inverse);return Math.abs(p.y)<.15&&Math.abs(p.z-s.z)<.2&&p.x>=s.xmin-.1&&p.x<=s.xmax+.1;});if(!seat)return false;const previous={x:state.x,z:state.z,feet:state.feet};activeSeat=null;seatCooldown=0;state.seated=false;Object.assign(state,location);if(!sit()){Object.assign(state,previous);return false;}return true;}
 return{restoreFoodSeat,state,step,nearestLadder,climb,nearestSeat,sit,stand,updateDoors:dt=>world.updateDoors(dt,state.x,state.z,state.feet),interact:()=>climb()||world.interact(state.x,state.z,state.feet)};
}
export function walkingEntry(b,world){
 if(b.id==='A1'){
  const plan=classroomStairPlan(b),flight=plan.flights[0],q=buildingBaseProfile(b),angle=b.rotation*Math.PI/180,c=Math.cos(angle),s=Math.sin(angle),lx=flight.from.x+q.side*.45,u=flight.from.z,x=b.x+c*lx-s*u,z=b.z+s*lx+c*u;
  const feet=world.supportAt(x,z,groundHeight(x,z)+q.height+.10);
  if(!world.blocked(x,z,feet))return{x,z,feet,yaw:Math.atan2(q.side*c,q.side*s)};
  return null;
 }
 const q=buildingBaseProfile(b);let a=q.accesses[0];if(b.kind==='heritage')a=q.accesses[1];if(b.kind==='hall')a=q.accesses.at(-2);if(b.kind==='admin')a=q.accesses[1];if(!a)return null;
 let u=b.kind==='admin'?administrationPlan(b).stairU:a.u;if(b.kind==='classroom'){const p=classroomStairPlan(b);if(p.width<.60)return null;u=p.entryU;}
 const lx=q.side*(b.width/2+a.front+a.steps*a.tread+1),angle=b.rotation*Math.PI/180,c=Math.cos(angle),s=Math.sin(angle),x=b.x+c*lx-s*u,z=b.z+s*lx+c*u;
 for(const offset of [0,.25,-.25,.5,-.5,1,-1,2,-2]){const xx=x-s*offset,zz=z+c*offset,feet=world.supportAt(xx,zz,groundHeight(xx,zz)+WALKER.maxStep);if(!world.blocked(xx,zz,feet))return{x:xx,z:zz,feet,yaw:Math.atan2(q.side*c,q.side*s)};}
 return null;
}
