import * as T from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js';
import {ENTRANCE} from './entrance-layout.js';
import {LEFT_STREET_HOUSES} from './exterior-street-layout.js';
// Read from June 2017 Street View, from the school fence outwards.
// Upper storeys obscured by trees/wires remain estimates; do not treat as surveyed dimensions.
export const FRONTAGE_2017=[
 {label:'QUEEN',sub:'DESIGNER',color:'#c3b9a4',board:'#222724',ink:'#eee8d7',type:'shutter',floors:3,roof:8.7,setback:.10,upper:'balcony'},
 {label:'HỒNG HẢI',sub:'THIẾT BỊ ĐIỆN • ĐIỆN LẠNH',color:'#c7cdca',board:'#224f87',ink:'#ece7d8',type:'glass',floors:3,roof:9.3,setback:.22,upper:'paired'},
 {label:'Apple',sub:'ĐIỆN THOẠI',color:'#aeb5b4',board:'#262b2a',ink:'#e7e4d8',type:'glass',floors:3,roof:9.05,setback:.05,upper:'wide'},
 {label:'CHANH',sub:'PHỤ KIỆN ĐIỆN THOẠI',color:'#c7c3b1',board:'#292d28',ink:'#e4dfcd',type:'glass',floors:3,roof:8.8,setback:.14,upper:'paired'},
 {label:'CK',sub:'FASHION',color:'#c4b4a1',board:'#252627',ink:'#cbbd7d',type:'shutter',floors:3,roof:9.65,setback:.04,upper:'arched'},
 {label:'IN ẤN • THIẾT KẾ',sub:'DỊCH VỤ VĂN PHÒNG',color:'#c4c7bf',board:'#326294',ink:'#f0e5d5',type:'open',floors:3,roof:9.15,setback:.20,upper:'paired'},
 {label:'Guu',sub:'BBQ & HOT POT',color:'#515956',board:'#272c2b',ink:'#e9e5da',type:'shutter',floors:4,roof:11.8,setback:.02,upper:'terrace'}
];
function sign(g,p,x,y,w){
 if(typeof document==='undefined')return;
 const c=document.createElement('canvas');c.width=1024;c.height=256;const a=c.getContext('2d');a.fillStyle=p.board;a.fillRect(0,0,1024,256);a.textAlign='center';a.fillStyle=p.ink;a.font=`${p.label==='Guu'?'italic':'bold'} 88px Arial`;a.fillText(p.label,512,119,940);a.font='bold 31px Arial';a.fillText(p.sub,512,199,950);
 const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;const m=new T.Mesh(new T.PlaneGeometry(w,1.05),new T.MeshBasicMaterial({map:tex,toneMapped:false}));m.rotation.y=-Math.PI/2;m.position.set(x,y,0);m.name='streetview-2017-shop-sign';m.userData.walkRole='decorative';g.add(m);
}
export function createFrontageLeftHouses(){
 const root=new T.Group();root.name='seven-left-frontage-houses';root.userData={estimated:true,ownerRequested:true,count:7,referenceDate:'2017-06',sourcePanoramas:['Xmt9Dhgqkr6Tiq4TdMGB_A','cfU5xKkH1iQt6P_R06nMGQ','GwSZjkxkYwbErFYCwzPKzQ']};
 for(const [i,b]of LEFT_STREET_HOUSES.entries()){
  const p=FRONTAGE_2017[i],g=new T.Group();g.name=b.id;g.position.set(ENTRANCE.x+2.65+p.setback,0,(b.from+b.to)/2);g.userData={floors:p.floors,contextOnly:true,upperStoreysEstimated:true,referenceDate:'2017-06',shop:p.label};root.add(g);
  const k=geometryKit(g),w=b.to-b.from,d=5.3,x=-d/2,h=p.roof;
  // Solid building envelope; the street face is recessed between grounded jambs.
  k.box(d-.26,h,w-.03,.13,h/2,0,p.color);
  for(const z of [-w/2+.11,w/2-.11])k.box(.40,h,.22,x+.08,h/2,z,p.color);
  k.box(d+.12,.18,w+.03,0,h+.09,0,'#777d76');
  k.box(.18,.34,w-.04,x,h+.26,0,p.color);
  const opening=w-.5;
  if(p.type==='shutter'){
   k.box(.06,2.75,opening,x-.005,1.43,0,i===0?'#a6a49a':'#a6a18e');
   for(let y=.12;y<2.8;y+=.095)k.box(.02,.012,opening,x-.045,y,0,'#70746e');
   k.box(.07,.10,opening,x-.03,.1,0,'#626960');
  }else{
   k.box(.04,2.7,opening,x,1.42,0,'#344345');
   for(const z of [-opening/2,0,opening/2])k.box(.09,2.7,.045,x-.05,1.42,z,'#b0b6b1');
   k.box(.09,.06,opening,x-.05,2.76,0,'#b0b6b1');k.box(.09,.07,opening,x-.05,.09,0,'#b0b6b1');
   k.box(.12,.55,opening-.2,x-.07,.5,0,'#6e7871');
   if(p.type==='open'){k.box(.34,.85,1.3,x-.15,.52,.6,'#b1ad92');k.box(.36,.07,1.4,x-.16,.98,.6,'#e0ddcc');}
  }
  k.box(.14,1.15,w-.14,x-.08,3.36,0,p.board);sign(g,p,x-.158,3.36,w-.22);
  k.box(.65,.10,w+.05,x-.2,4.02,0,p.board);
  for(let f=1;f<p.floors;f++){
   const low=4.12+(f-1)*2.65,wh=Math.min(1.75,h-low-.35),y=low+wh/2;
   if(wh<=.2)continue;
   k.box(.14,.13,w-.1,x,low-.12,0,'#d2d0c5');
   const wide=['wide','terrace','balcony'].includes(p.upper),ww=wide?w-.8:1.24;
   for(const z of wide?[0]:[-.95,.95]){
    k.box(.045,wh+.12,ww+.12,x-.025,y,z,'#d2d3c9');k.box(.05,wh,ww,x-.055,y,z,'#3c5053');
    k.box(.055,wh,.035,x-.09,y,z,'#a3ada9');k.box(.055,.035,ww,x-.09,y+.1,z,'#a3ada9');k.box(.26,.07,ww+.16,x-.12,low-.08,z,'#a4aaa1');
   }
   if(['balcony','terrace'].includes(p.upper)){
    k.box(.62,.13,w-.25,x-.22,low-.16,0,'#a1a69a');
    for(const yy of [low+.10,low+.88])k.box(.035,.035,w-.4,x-.50,yy,0,'#333e37');
    for(let z=-w/2+.25;z<w/2-.1;z+=.24)k.box(.025,.80,.025,x-.50,low+.49,z,'#39483d');
    // Recessed top terrace/plant ledge rather than another identical window row.
    if(f===p.floors-1)for(const z of [-1.25,-.6,.1,.8,1.4]){k.box(.22,.16,.35,x-.28,low+.03,z,'#956657');k.box(.18,.30,.27,x-.28,low+.25,z,'#657653');}
   }
   if(p.upper==='arched'){
    const pts=[];for(let j=0;j<=32;j++){const t=Math.PI*j/32;pts.push(new T.Vector3(x-.13,low+wh+.08+.4*Math.sin(t),1.5*Math.cos(t)));}for(let j=1;j<pts.length;j++)k.beam(pts[j-1],pts[j],.07,'#d2cbb9');
   }
  }
  k.finish();
 }return root;
}
