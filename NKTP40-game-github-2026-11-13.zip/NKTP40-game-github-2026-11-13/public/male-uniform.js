import * as THREE from './vendor/three.module.js';
import {softAvatarForm} from './avatar-shapes.js?v=236.0';
export function createMaleUniform(torso,mesh,shirt,stitch){const g=new THREE.Group();g.name='male-tran-phu-uniform';torso.add(g);
 for(const sign of [-1,1]){const shape=new THREE.Shape();[[sign*.018,.502],[sign*.054,.525],[sign*.112,.456],[sign*.105,.408],[sign*.029,.466]].forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();mesh(g,new THREE.ExtrudeGeometry(shape,{depth:.005,bevelEnabled:true,bevelSize:.002,bevelThickness:.001,bevelSegments:2}),shirt,0,0,.105);}
 // The pocket is on the wearer's left (+X), sewn onto the shirt surface.
 const shape=new THREE.Shape();shape.moveTo(.042,.355);shape.lineTo(.113,.355);shape.lineTo(.113,.283);shape.quadraticCurveTo(.078,.265,.042,.283);shape.closePath();const pocketGeo=new THREE.ExtrudeGeometry(shape,{depth:.002,bevelEnabled:false}),pos=pocketGeo.attributes.position;for(let i=0;i<pos.count;i++)pos.setZ(i,pos.getZ(i)+Math.sqrt(Math.max(0,1-(pos.getX(i)/.177)**2))*.11+.002);pocketGeo.computeVertexNormals();mesh(g,pocketGeo,shirt).name='male-left-chest-pocket';
 const seam=new THREE.CatmullRomCurve3([new THREE.Vector3(.043,.350,.117),new THREE.Vector3(.043,.285,.117),new THREE.Vector3(.078,.276,.117),new THREE.Vector3(.112,.285,.117),new THREE.Vector3(.112,.350,.117)]);for(const v of seam.points)v.z=Math.sqrt(Math.max(0,1-(v.x/.177)**2))*.11+.005;mesh(g,new THREE.TubeGeometry(seam,24,.0012,5,false),stitch);return g;
}
export function createMaleSleeve(arm,elbow,mesh,shirt){const top=new THREE.Group(),rolled=new THREE.Group();top.name='male-long-sleeve';rolled.name='male-rolled-cuff';arm.add(top);elbow.add(rolled);
 mesh(top,softAvatarForm([[-.284,.041,.041],[-.25,.044,.043],[-.17,.046,.045]],{rings:12}),shirt);
 mesh(rolled,softAvatarForm([[-.076,.041,.041],[-.060,.050,.048],[-.026,.050,.048],[.012,.042,.042]],{rings:14}),shirt);return{top,rolled};}
