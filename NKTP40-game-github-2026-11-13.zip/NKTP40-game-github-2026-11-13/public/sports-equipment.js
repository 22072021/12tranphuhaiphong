import * as T from './vendor/three.module.js';
import {GLTFLoader} from './vendor/SportsGLTFLoader.js';
let badminton;
export function createBadmintonShuttle(){
 const root=new T.Group();root.name='badminton-shuttle';if(typeof document==='undefined'){root.equipmentReady=Promise.resolve(root);return root;}
 badminton??=new GLTFLoader().loadAsync(new URL('./assets/sports/badminton-shuttle.glb',import.meta.url).href);
 root.equipmentReady=badminton.then(({scene})=>{const model=scene.clone(true);model.position.set(-.5135,0,-.2164);const upright=new T.Group();upright.rotation.x=Math.PI/2;upright.add(model);root.add(upright);root.scale.setScalar(1.5);return root;});return root;
}
// Separate Vietnamese foot shuttle: stacked rubber discs and four flexible feathers.
export function createFootShuttle(){
 const g=new T.Group();g.name='flying-shuttlecock';
 const rubber=new T.MeshStandardMaterial({color:'#ce6039',roughness:.88}),stem=new T.MeshStandardMaterial({color:'#ddc69b',roughness:.9});
 for(let i=0;i<5;i++){const disc=new T.Mesh(new T.CylinderGeometry(.032,.034,.009,24),rubber);disc.position.y=i*.009;g.add(disc);}
 const shaft=new T.Mesh(new T.CylinderGeometry(.007,.009,.14,8),stem);shaft.position.y=.10;g.add(shaft);
 const colors=['#e6b94b','#d45d3f','#e4b551','#b84b32'];
 for(let i=0;i<4;i++){
  const geom=new T.BufferGeometry(),pos=[],uv=[],idx=[];
  for(let k=0;k<=12;k++){const t=k/12,w=Math.pow(Math.sin(Math.PI*t),.65)*.023,y=.08+t*.19,bend=t*t*.033;pos.push(-w,y,bend,w,y,bend);uv.push(0,t,1,t);if(k<12){const a=k*2;idx.push(a,a+1,a+2,a+1,a+3,a+2);}}
  geom.setAttribute('position',new T.Float32BufferAttribute(pos,3));geom.setAttribute('uv',new T.Float32BufferAttribute(uv,2));geom.setIndex(idx);geom.computeVertexNormals();
  const f=new T.Mesh(geom,new T.MeshStandardMaterial({color:colors[i],roughness:.95,side:T.DoubleSide}));f.rotation.y=i*Math.PI/2;g.add(f);
  const curve=new T.QuadraticBezierCurve3(new T.Vector3(0,.08,0),new T.Vector3(0,.18,0),new T.Vector3(0,.27,.033));const rib=new T.Mesh(new T.TubeGeometry(curve,12,.0015,4,false),stem);rib.rotation.y=f.rotation.y;g.add(rib);
 }return g;
}
export function orientShuttle(root,velocity){if(velocity.lengthSq()<1e-8)return;root.quaternion.setFromUnitVectors(new T.Vector3(0,-1,0),velocity.clone().normalize());}
