import * as THREE from './vendor/three.module.js';
// R99/R106 show a tall cyan panel, pale medal and dark-blue school-name band.
// Fine inscription on the medal is unreadable in available frames.
export function createA1MedalSign({side,w,h,center,span}){
 const group=new THREE.Group(),width=span*.92,height=Math.min(width*2.08,h-(h/3+.55)-.25),top=h-.25;
 group.name='A1-medal-school-sign';group.position.set(side*(w+.23),top-height/2,center);group.rotation.y=side*Math.PI/2;group.userData={sources:['R99','R106','R112'],estimated:true,unreadableMedalDetails:true,walkRole:'none'};
 const material=new THREE.MeshBasicMaterial({color:'#b95961',side:THREE.DoubleSide});
 if(typeof document!=='undefined'){
  const canvas=document.createElement('canvas');canvas.width=768;canvas.height=1536;const c=canvas.getContext('2d');
  c.fillStyle='#bf5960';c.fillRect(0,0,768,1536);c.strokeStyle='#eee7cf';c.lineWidth=12;c.strokeRect(6,6,756,1524);
  c.fillStyle='#e2c6b8';c.fillRect(244,80,280,145);c.fillStyle='#a95560';c.fillRect(266,100,236,88);c.textAlign='center';c.fillStyle='#f5e8c8';c.font='bold 35px Arial';c.fillText('ANH HÙNG',384,136,220);c.fillText('LAO ĐỘNG',384,177,220);c.strokeStyle='#f3e1b8';c.lineWidth=9;c.strokeRect(263,97,242,94);
  c.fillStyle='#f4d8b8';c.fillRect(351,225,66,120);
  c.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2===0?245:100,x=384+Math.cos(a)*r,y=575+Math.sin(a)*r;if(i===0)c.moveTo(x,y);else c.lineTo(x,y);}c.closePath();c.fillStyle='#f2d7bd';c.fill();c.strokeStyle='#fff2d5';c.lineWidth=12;c.stroke();
  c.fillStyle='#eed7c2';c.beginPath();c.arc(384,575,67,0,Math.PI*2);c.fill();
  c.fillStyle='#1674ad';c.fillRect(6,980,756,550);c.textAlign='center';c.fillStyle='#fff';c.font='bold 56px Arial';c.fillText('TRƯỜNG THPT CHUYÊN',384,1075,700);c.font='bold 98px Arial';c.fillText('TRẦN PHÚ',384,1210,700);c.font='bold 50px Arial';c.fillText('HẢI PHÒNG',384,1335,650);
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=8;material.map=texture;material.color.set('#ffffff');
  // Use the photographed nameplate itself so Vietnamese accents retain their original shapes.
 }
 const sign=new THREE.Mesh(new THREE.PlaneGeometry(width,height),material);sign.name='A1-medal-panel';sign.userData.walkRole='none';group.add(sign);
 if(typeof document!=='undefined')for(const [direction,lines] of [[-1,['DÙ','KHÓ','KHĂN','ĐẾN','ĐÂU','VẪN','THI','ĐUA','DẠY','TỐT,','HỌC','TỐT','HỒ CHÍ MINH']],[1,['HIỀN','TÀI','LÀ','NGUYÊN','KHÍ','CỦA','QUỐC','GIA','THÂN NHÂN TRUNG']]]){const c=document.createElement('canvas');c.width=256;c.height=1536;const t=c.getContext('2d');t.fillStyle='#176293';t.fillRect(0,0,256,1536);t.strokeStyle='#d9c566';t.lineWidth=5;t.strokeRect(7,7,242,1522);t.textAlign='center';t.fillStyle='#eee184';const total=lines.length;lines.forEach((line,i)=>{t.font=i===total-1?'bold 19px Arial':'bold 48px Arial';t.fillText(line,128,80+i*(1280/total),224);});t.fillStyle='#eee8c8';t.font='60px serif';t.fillText('❀',128,1445);const tx=new THREE.CanvasTexture(c);tx.colorSpace=THREE.SRGBColorSpace;const m=new THREE.Mesh(new THREE.PlaneGeometry(1.25,7.0),new THREE.MeshBasicMaterial({map:tx,side:THREE.DoubleSide}));m.name='A1-vertical-couplet';m.position.set(direction*6.2,-3.5,0);m.userData={walkRole:'none',source:'R112',textEstimated:direction<0};group.add(m);}
 return group;
}
