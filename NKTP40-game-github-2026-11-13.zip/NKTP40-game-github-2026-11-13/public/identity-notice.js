let notice;
export function showIdentityNotice(){
 if(!notice){
  notice=document.createElement('dialog');notice.className='identity-notice';notice.setAttribute('aria-labelledby','identityNoticeTitle');notice.setAttribute('aria-describedby','identityNoticeText');
  const title=document.createElement('h2');title.id='identityNoticeTitle';title.textContent='Lưu ý về danh tính';
  const text=document.createElement('p');text.id='identityNoticeText';text.textContent='Xin hãy sử dụng đúng danh tính của mình, không sử dụng danh tính người khác!';
  const confirm=document.createElement('button');confirm.type='button';confirm.textContent='Xác nhận';confirm.autofocus=true;confirm.onclick=()=>notice.close();
  notice.append(title,text,confirm);notice.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();}});notice.addEventListener('cancel',event=>event.preventDefault());document.body.append(notice);
 }
 if(!notice.open)notice.showModal();
}
