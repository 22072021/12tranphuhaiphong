import {createA1EntertainmentModule} from './a1-entertainment-module.js';
import * as T from './vendor/three.module.js';
import {mergeGeometries} from './vendor/BufferGeometryUtils.js';
import {createStudent} from './student/student.js';
// Rasterize a bold italic font once, then reuse four appearance × four pose prototypes.
export function tpcFormationPoints(){
 const canvas=document.createElement('canvas');canvas.width=640;canvas.height=256;const ctx=canvas.getContext('2d');ctx.font='italic 900 200px Arial';ctx.fillStyle='#fff';ctx.fillText('TPC',20,210);const pixels=ctx.getImageData(0,0,640,256).data;let x0=640,x1=0,y0=256,y1=0;for(let y=0;y<256;y++)for(let x=0;x<640;x++)if(pixels[(y*640+x)*4+3]>140){x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);}
 const points=[];for(let row=0;row<=20;row++)for(let col=0;col<=40;col++){const px=Math.round(x0+(x1-x0)*col/40),py=Math.round(y0+(y1-y0)*row/20);if(pixels[(py*640+px)*4+3]<=140)continue;const n=points.length,hash=((n+7)*1664525+1013904223)>>>0,pose=hash%10<5?0:1+((hash>>>8)%3);points.push({x:-42+row*.30,y:.035,z:39-col*.475,variant:2+(hash>>>16)%2,pose,line:'TPC'});}
 // Upright rounded monoline numbers, elongated to compensate for the A1 roof view.
 function numberPaths(char){
  const paths=[],path=new T.Path();
  const oval=(cx,cy,rx,ry)=>{const p=new T.Path();p.absellipse(cx,cy,rx,ry,0,Math.PI*2,false,0);paths.push(p);};
  if(char==='0')oval(.775,2,.72,1.98);
  if(char==='8'){oval(.775,1,.72,.98);oval(.775,3,.72,.98);}
  if(char==='9'){oval(.775,1.05,.72,1.03);path.moveTo(1.495,1.05);path.lineTo(1.495,2.95);path.bezierCurveTo(1.495,4,.7,4.2,.1,3.8);}
  if(char==='6'){oval(.775,2.95,.72,1.03);path.moveTo(.055,2.95);path.lineTo(.055,1.1);path.bezierCurveTo(.055,.05,.85,-.2,1.45,.2);}
  if(char==='2'){path.moveTo(.055,.85);path.bezierCurveTo(.055,-.25,1.495,-.25,1.495,.85);path.bezierCurveTo(1.495,1.8,.15,2.4,.055,3.8);path.quadraticCurveTo(.04,4,.25,4);path.lineTo(1.5,4);}
  if(char==='1'){path.moveTo(.15,.65);path.lineTo(.8,.02);path.lineTo(.8,4);}
  if(char==='-'){path.moveTo(.1,2);path.lineTo(1.45,2);}
  if(path.curves.length)paths.push(path);return paths;
 }
 const ribbonPaths=[];points.ribbonPaths=ribbonPaths;
 const datePoints=[];let cursor=0;for(const char of '1986-2026'){if(char==='-')cursor+=.3;for(const path of numberPaths(char)){const n=Math.max(1,Math.round(path.getLength()/.74));ribbonPaths.push({path,cursor,length:path.getLength()});for(let i=0;i<=n;i++){const q=path.getPointAt(i/n),tangent=path.getTangentAt(i/n),p={x:-34.55+q.y,y:.035,z:39.7-cursor-q.x,yaw:Math.atan2(tangent.x,tangent.y)};if(datePoints.some(a=>Math.hypot(a.x-p.x,a.z-p.z)<.44))continue;datePoints.push(p);}}cursor+=2.2;if(char==='-')cursor+=.3;}
 for(const p of datePoints){const hash=((points.length+7)*1664525+1013904223)>>>0;points.push({...p,variant:(hash>>>16)%2,pose:4,line:'1986 - 2026'});}return points;
}
// Solve limbs toward grounded crossed ankles; knees open sideways, never a squat.
export function poseCrossLegged(student,holdRibbon=false){
 const j=student.joints,root=student.root;j.pelvis.position.y=.145;root.updateMatrixWorld(true);
 const localPoint=bone=>root.worldToLocal(bone.getWorldPosition(new T.Vector3()));
 function aim(bone,child,target){root.updateMatrixWorld(true);const world=root.localToWorld(target.clone());bone.parent.worldToLocal(world);const direction=world.sub(bone.position).normalize();bone.quaternion.setFromUnitVectors(child.position.clone().normalize(),direction);root.updateMatrixWorld(true);}
 function solve(first,middle,last,end,pole){
  const start=localPoint(first),l1=middle.position.length(),l2=last.position.length(),axis=end.clone().sub(start),distance=axis.length();axis.normalize();
  const along=(l1*l1-l2*l2+distance*distance)/(2*distance),height=Math.sqrt(Math.max(0,l1*l1-along*along));
  const bend=pole.clone().sub(start);bend.addScaledVector(axis,-bend.dot(axis)).normalize();
  const joint=start.clone().addScaledVector(axis,along).addScaledVector(bend,height);
  aim(first,middle,joint);aim(middle,last,end);return joint;
 }
 for(const [side,sign]of [['left',1],['right',-1]]){
  const knee=solve(j[side+'Hip'],j[side+'Knee'],j[side+'Ankle'],new T.Vector3(-sign*.10,.115,.29+sign*.025),new T.Vector3(sign*.8,.08,.08));
  // Keep shoes approximately horizontal instead of folded under the body.
  j[side+'Ankle'].quaternion.copy(j[side+'Ankle'].parent.getWorldQuaternion(new T.Quaternion()).invert());
  const hand=j[side+'Elbow'].children.find(o=>o.isBone);
  if(hand)solve(j[side+'Shoulder'],j[side+'Elbow'],hand,holdRibbon?new T.Vector3(sign*.20,.32,.24):knee.clone().add(new T.Vector3(-sign*.025,.09,.015)),holdRibbon?new T.Vector3(sign*.15,.20,.02):new T.Vector3(sign*.4,.32,.4));
 }
 root.updateMatrixWorld(true);
}
function createNumberRibbons(paths){
 const positions=[],indices=[];
 for(const {path,cursor,length}of paths){const segments=Math.max(8,Math.ceil(length/.06)),base=positions.length/3;for(let i=0;i<=segments;i++){
  const t=i/segments,q=path.getPointAt(t),tangent=path.getTangentAt(t),yaw=Math.atan2(tangent.x,tangent.y),nx=Math.sin(yaw),nz=Math.cos(yaw);
  // A broad sky-blue strip held just ahead of the lap, with a small static drape.
  const x=-34.55+q.y+nx*.223,z=39.7-cursor-q.x+nz*.223,y=.333-.025*Math.pow(Math.sin(Math.PI*t*length/.74),2);
  for(const side of [-1,1])positions.push(x+nx*side*.14,y+side*.008*Math.sin(t*length*3),z+nz*side*.14);
  if(i<segments){const a=base+i*2;indices.push(a,a+1,a+2,a+1,a+3,a+2);}
 }
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setIndex(indices);g.computeVertexNormals();
 const material=new T.MeshStandardMaterial({color:'#57bce9',roughness:.85,metalness:0,side:T.DoubleSide});
 const mesh=new T.Mesh(g,material);mesh.name='admin-anniversary-sky-blue-silk';mesh.userData.walkIgnore=true;mesh.userData.walkRole='none';mesh.userData.ownedMaterial=true;return mesh;
}
function createFormation(){
 const root=new T.Group();root.name='admin-only-TPC-students';root.userData.walkIgnore=true;
 const points=tpcFormationPoints(),matrix=new T.Matrix4(),rotation=new T.Quaternion();
 for(let variant=0;variant<4;variant++)for(let pose=0;pose<5;pose++){
  const people=points.filter(p=>p.variant===variant&&p.pose===pose);if(!people.length)continue;const student=createStudent({gender:variant%2?'female':'male',season:variant<2?'summer':'winter',scale:.93});student.update(0,'idle');
  for(const [side,sign,raised]of [['left',1,pose===1||pose===3],['right',-1,pose===2||pose===3]])if(raised){student.joints[side+'Shoulder'].rotation.set(-.12,0,sign*2.65);student.joints[side+'Elbow'].rotation.x=-.18;}
  if(pose===4)poseCrossLegged(student,true);
  student.root.updateMatrixWorld(true);const batches=new Map();
  student.root.traverse(o=>{if(!o.isMesh||!o.visible)return;let parent=o;while(parent!==student.root){if(!parent.visible)return;parent=parent.parent;}let geometry=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone();const pos=geometry.attributes.position,v=new T.Vector3();if(o.isSkinnedMesh)o.skeleton.update();for(let i=0;i<pos.count;i++){const source=o.geometry.index?o.geometry.index.getX(i):i;o.getVertexPosition(source,v);v.applyMatrix4(o.matrixWorld);pos.setXYZ(i,v.x,v.y,v.z);}geometry.deleteAttribute('skinIndex');geometry.deleteAttribute('skinWeight');geometry.computeVertexNormals();if(!batches.has(o.material))batches.set(o.material,[]);batches.get(o.material).push(geometry);});
  for(const [material,list]of batches){const geometry=mergeGeometries(list);if(!geometry)throw Error('TPC prototype geometry mismatch');list.forEach(g=>g.dispose());const mesh=new T.InstancedMesh(geometry,material,people.length);mesh.name='TPC-'+variant+'-pose-'+pose;mesh.userData.walkRole='none';mesh.userData.pose=pose;mesh.castShadow=false;mesh.receiveShadow=true;people.forEach((p,i)=>{rotation.setFromAxisAngle(new T.Vector3(0,1,0),p.yaw??Math.atan2(30-p.x,33.65-p.z));matrix.compose(new T.Vector3(p.x,p.y,p.z),rotation,new T.Vector3(1,1,1));mesh.setMatrixAt(i,matrix);});mesh.computeBoundingSphere();root.add(mesh);}
 }
 root.add(createNumberRibbons(points.ribbonPaths));
 root.userData.count=points.length;root.userData.points=points;return root;
}
export function createTPCDisplay(scene){
 let enabled=false,formation=null;const entertainment=createA1EntertainmentModule();
 function restore(){entertainment.restore();if(formation){scene.remove(formation);formation.traverse(o=>{if(o.isMesh){o.geometry.dispose();if(o.userData.ownedMaterial)o.material.dispose();}});formation=null;}}
 return{restore,enforce(){if(enabled)entertainment.hide();},get targets(){return entertainment.targets;},setEnabled(value){value=value===true;if(enabled===value)return false;enabled=value;return true;},bind(models,campus){restore();entertainment.bind([models,campus]);if(!enabled)return;entertainment.hide();formation=createFormation();scene.add(formation);},dispose:restore};
}
// Compatibility for isolated preview/tests; live scheduling is handled by tpc-event.js.
export const createAdminTPCDemo=createTPCDisplay;
