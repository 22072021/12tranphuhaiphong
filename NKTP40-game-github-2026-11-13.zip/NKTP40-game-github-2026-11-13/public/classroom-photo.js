import * as T from './vendor/three.module.js';
import {classroomLayout} from './classroom-template.js';
const roomIndexes=new WeakMap();
export function findPhotoRoom(models,state){
 if(!state)return null;let index=roomIndexes.get(models);const children=models.children;
 const attached=g=>{while(g&&g!==models)g=g.parent;return g===models;};
 if(!index||children.length!==index.children.length||children.some((g,i)=>g!==index.children[i])||index.roots.some(g=>!attached(g))){const roots=[];const collect=g=>{if(g.name==='shared-classroom-interiors'||g.userData.photoRoomSpecs){roots.push(g);return;}for(const c of g.children)collect(c);};collect(models);index={children:[...children],roots};roomIndexes.set(models,index);}
 const world=new T.Vector3(state.x,state.feet,state.z);
 for(const root of index.roots){root.updateWorldMatrix(true,false);const p=root.worldToLocal(world.clone());for(const s of root.userData.roomSpecs||root.userData.photoRoomSpecs||[]){if(p.x>s.xmin+.02&&p.x<s.xmax-.02&&p.z>s.zmin+.02&&p.z<s.zmax-.02&&p.y>=(s.level||0)-.12&&p.y<(s.level||0)+.75)return{root,spec:s};}}return null;
}
export function classroomPhotoFrame({root,spec:s},aspect=1.6){
 root.updateWorldMatrix(true,false);const p=s.boardEndOverride?{cx:(s.xmin+s.xmax)/2,boardEnd:s.boardEndOverride}:classroomLayout(s),end=p.boardEnd,level=s.level||0,ch=s.clearHeight||3.5,rear=end>0?s.zmin:s.zmax;
 const camera=new T.PerspectiveCamera(68,aspect,.08,300),target=new T.Vector3(p.cx,level+1.1,(s.zmin+s.zmax)/2);const corners=[];
 for(const x of [s.xmin,s.xmax])for(const y of [level+.02,level+ch-.1])for(const z of [s.zmin,s.zmax])corners.push(root.localToWorld(new T.Vector3(x,y,z)));
 for(let distance=1;distance<80;distance+=.25){camera.position.copy(root.localToWorld(new T.Vector3(p.cx,level+ch*.85,rear-end*distance)));camera.lookAt(root.localToWorld(target.clone()));camera.updateMatrixWorld();if(corners.every(v=>{const q=v.clone().project(camera);return Math.abs(q.x)<.94&&Math.abs(q.y)<.94&&q.z<1;}))break;}
 // Cut away only the rear wall and surroundings for this render, never fade them.
 const planes=[new T.Plane(new T.Vector3(0,0,end),-end*(rear+end*.045)),new T.Plane(new T.Vector3(1,0,0),-s.xmin+.45),new T.Plane(new T.Vector3(-1,0,0),s.xmax+.45),new T.Plane(new T.Vector3(0,0,-end),end*(end>0?s.zmax+.14:s.zmin-.14)),new T.Plane(new T.Vector3(0,1,0),-level+.08),new T.Plane(new T.Vector3(0,-1,0),level+ch+.10)].map(v=>v.applyMatrix4(root.matrixWorld));
 // Find an inscribed crop in this room's projected rear opening, not a fixed pixel box.
 const fullW=1600,fullH=1000,project=(x,y,z)=>{const v=root.localToWorld(new T.Vector3(x,y,z)).project(camera);return{x:(v.x+1)*fullW/2,y:(1-v.y)*fullH/2};};
 const back=rear+end*.06,front=end>0?s.zmax:s.zmin;
 const opening=[project(s.xmin,level,back),project(s.xmax,level,back),project(s.xmin,level+ch,back),project(s.xmax,level+ch,back)];
 const left=opening.filter(q=>q.x<fullW/2),right=opening.filter(q=>q.x>=fullW/2);
 const topBack=Math.max(...opening.filter(q=>q.y<fullH/2).map(q=>q.y));
 const frontTop=project(p.cx,level+ch,front).y;
 const x0=Math.ceil(Math.max(0,...left.map(q=>q.x))+3),x1=Math.floor(Math.min(fullW,...right.map(q=>q.x))-3);
 const y0=Math.ceil(Math.max(0,topBack+(frontTop-topBack)*.48)),y1=Math.floor(Math.min(fullH,...opening.filter(q=>q.y>=fullH/2).map(q=>q.y))-3);
 const crop={x:x0,y:y0,width:Math.max(1,x1-x0),height:Math.max(1,y1-y0)};
 camera.setViewOffset(fullW,fullH,crop.x,crop.y,crop.width,crop.height);camera.updateMatrixWorld();
 return{camera,planes,renderPlanes:[planes[0],planes[4],planes[5]],crop,width:1600,height:Math.round(1600*crop.height/crop.width)};
}
export function createClassroomPhotoButton(container,onClick){const b=document.createElement('button');b.id='classroomCaptureBtn';b.hidden=true;b.type='button';b.title='Chụp toàn cảnh lớp học';b.setAttribute('aria-label',b.title);b.style.cssText='position:absolute;z-index:9;top:max(12px,env(safe-area-inset-top));left:50%;transform:translateX(-50%);width:52px;height:44px;padding:8px;border:1px solid #ffffffaa;border-radius:12px;color:white;background:#243d3380;touch-action:manipulation';b.innerHTML='<svg width="32" height="26" viewBox="0 0 32 26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" aria-hidden="true"><path d="M7 8h5l2-3h5l2 3h4v14H7Z"/><circle cx="16" cy="15" r="4"/><path d="M1 9V3h7M24 3h7v6M1 17v6h4M27 23h4v-6"/></svg>';b.onclick=onClick;container.append(b);return b;}

// Clip only the occupied building. Global clipping would erase the world seen through windows.
export function clipClassroomBuilding(room,models,planes){
 let building=room.root;while(building.parent&&building.parent!==models)building=building.parent;
 const originals=[],copies=new Map();
 const copy=original=>{if(!copies.has(original)){const m=original.clone();m.onBeforeCompile=original.onBeforeCompile;m.customProgramCacheKey=original.customProgramCacheKey;m.clippingPlanes=planes;m.clipShadows=false;copies.set(original,m);}return copies.get(original);};
 building.traverse(o=>{if(!o.isMesh||!o.material)return;originals.push([o,o.material]);o.material=Array.isArray(o.material)?o.material.map(copy):copy(o.material);});
 return()=>{for(const [o,material]of originals)o.material=material;for(const m of copies.values())m.dispose();};
}
