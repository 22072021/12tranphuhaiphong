let logoReady,fontReady;
function loadFooterFont(){return fontReady??=(async()=>{try{const face=new FontFace('Be Vietnam Pro',`url(${new URL('./assets/fonts/BeVietnamPro-Medium.ttf',import.meta.url).href})`,{weight:'500'});await face.load();document.fonts.add(face);}catch{ /* Arial remains a readable offline fallback. */ }})();}

function loadLogo(){return logoReady??=new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=()=>{logoReady=null;reject(Error('Chưa tải được logo, vui lòng thử lại.'));};image.src=new URL('./assets/branding/12-tran-phu-title.png',import.meta.url).href;});}
// Composite only labels that the player can currently see, never hidden profiles or HUD controls.
export async function captureVisitorPhoto(source,container,{type='image/png',quality=.92,blob=false,frameAspect=null,labelSize=1,labelOpacity=1}={}){
 const output=document.createElement('canvas'),box=source.getBoundingClientRect(),scale=source.width/box.width,scaleY=frameAspect?source.height/box.height:scale;
 const portrait=source.height>source.width;
 const footer=Math.round((portrait?Math.min(box.height*.15,box.width*.30):Math.max(64,Math.min(108,(frameAspect?box.width/frameAspect:box.height)*.12)))*scale);
 const sceneHeight=portrait?source.height-footer:source.height;
 output.width=source.width;output.height=portrait?source.height:source.height+footer;const ctx=output.getContext('2d');
 ctx.drawImage(source,0,0);ctx.save();ctx.beginPath();ctx.rect(0,0,source.width,sceneHeight);ctx.clip();
 for(const label of container.querySelectorAll('.player-label')){
  if(label.hidden||!label.checkVisibility())continue;
  for(const line of label.children){
   if(line.hidden||line.classList.contains('player-chat-bubble')||!line.checkVisibility())continue;
   const text=line.querySelector('span')||line;if(!text.textContent)continue;
   const range=document.createRange();range.selectNodeContents(text);const rect=range.getBoundingClientRect(),style=getComputedStyle(text),clip=line.getBoundingClientRect();
   ctx.save();if(style.overflow==='hidden'||getComputedStyle(line).overflow==='hidden'){ctx.beginPath();ctx.rect((clip.left-box.left)*scale,(clip.top-box.top)*scaleY,clip.width*scale,clip.height*scaleY);ctx.clip();}
   const fontSize=labelSize===1?parseFloat(style.fontSize)*scale:Math.min(20,parseFloat(style.fontSize)*scale*labelSize);
   ctx.globalAlpha=labelOpacity;ctx.font=`${style.fontWeight} ${fontSize}px ${style.fontFamily}`;ctx.textBaseline='middle';ctx.textAlign=labelSize===1?'left':'center';
   const x=(rect.left-box.left+(labelSize===1?0:rect.width/2))*scale,y=(rect.top-box.top+rect.height/2)*scaleY;
   ctx.fillStyle='#111';for(const dx of [-1,0,1])for(const dy of [-1,0,1])if(dx||dy)ctx.fillText(text.textContent,x+dx*(labelSize===1?scale:Math.min(scale,1.2)),y+dy*(labelSize===1?scale:Math.min(scale,1.2)));
   ctx.fillStyle=style.color;ctx.fillText(text.textContent,x,y);ctx.restore();
  }
 }
 ctx.restore();const [logo]=await Promise.all([loadLogo(),loadFooterFont()]);ctx.fillStyle='#65ADE5';ctx.fillRect(0,sceneHeight,output.width,footer);
 drawPhotoFooter(ctx,logo,output.width,sceneHeight,footer,{portrait});
 if(blob)return new Promise((resolve,reject)=>output.toBlob(value=>value?resolve(value):reject(Error('Chưa tạo được ảnh.')),type,quality));
 return output.toDataURL(type,quality);
}

export const ANNIVERSARY_TEXT='Sản phẩm chào mừng 40 năm thành lập trường PTTH Năng Khiếu Trần Phú - THPT Chuyên Trần Phú 1986-2026';
export function drawPhotoFooter(ctx,logo,width,top,height,{portrait=width<800}={}){
 ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';

 const pad=width*.035,logoArea=width*.29,gap=width*.035,textX=pad+logoArea+gap,textWidth=width-pad-textX;
 const ratio=logo.naturalWidth/logo.naturalHeight,w=Math.min(logoArea,height*.80*ratio),h=w/ratio;
 ctx.drawImage(logo,pad+(logoArea-w)/2,top+(height-h)/2,w,h);
 const lines=portrait?['Sản phẩm chào mừng 40 năm','thành lập trường PTTH Năng Khiếu','Trần Phú - THPT Chuyên Trần Phú','1986-2026']:['Sản phẩm chào mừng 40 năm thành lập trường','PTTH Năng Khiếu Trần Phú - THPT Chuyên Trần Phú','1986-2026'];
 let size=height*.215;ctx.font=`500 ${size}px "Be Vietnam Pro", Arial, sans-serif`;
 while(lines.some(line=>ctx.measureText(line).width>textWidth)||lines.length*size*1.27>height*.83){size*=.96;ctx.font=`500 ${size}px "Be Vietnam Pro", Arial, sans-serif`;}
 ctx.save();ctx.fillStyle='#123d53';ctx.textAlign='center';ctx.textBaseline='middle';
 const lineHeight=size*1.27,start=top+height/2-(lines.length-1)*lineHeight/2;
 lines.forEach((line,i)=>ctx.fillText(line,textX+textWidth/2,start+i*lineHeight));ctx.restore();
 return{logo:{x:pad+(logoArea-w)/2,y:top+(height-h)/2,width:w,height:h},text:{x:textX,width:textWidth,size,lines,lineHeight,start}};
}
