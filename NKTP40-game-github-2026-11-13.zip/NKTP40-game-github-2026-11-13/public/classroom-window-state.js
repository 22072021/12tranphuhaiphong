// Seeded initial state: per-room quotas, stable across rebuilds and page reloads.
const hash=s=>{let h=2166136261;for(const c of s)h=Math.imul(h^c.charCodeAt(0),16777619);return h>>>0;};
export function initializeClassroomWindows(root,b){
 const rooms=root.getObjectByName('shared-classroom-interiors')?.userData.roomSpecs;if(!rooms)return[];const windows=[];root.traverse(o=>{if(o.userData.operableWindow)windows.push(o);});const report=[];
 for(const room of rooms){const seed=b.id+':'+room.floor+':'+room.roomIndex,list=windows.filter(o=>Math.floor(o.position.y/(b.height/b.floors))+1===room.floor&&o.position.z>=room.zmin&&o.position.z<=room.zmax).sort((a,c)=>hash(seed+':'+a.position.x+':'+a.position.z)-hash(seed+':'+c.position.x+':'+c.position.z));
  if(!list.length)continue;const lo=Math.ceil(list.length*.30),hi=Math.max(lo,Math.floor(list.length*.50)),closed=lo+hash(seed+':quota')%(hi-lo+1);
  for(const [i,w]of list.entries()){w.userData.setInitialOpen(i>=closed);w.userData.initialClosed=i<closed;w.userData.classroomKey=seed;}
  report.push({room:seed,total:list.length,closed});
 }
 root.userData.initialWindowStates=report;return report;
}
