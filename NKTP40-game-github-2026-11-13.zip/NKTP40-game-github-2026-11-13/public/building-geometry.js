import {addStepSeats} from './step-seats.js';
import {cutRoofHatch,addRoofLadder} from './roof-ladder.js';
import {groundColumns} from './column-grounding.js?v=222.0';
import {drawClassicTimberLeaf} from './openings/classic-timber-leaf.js?v=245.0';
import {initializeClassroomWindows} from './classroom-window-state.js?v=216.0';
import {removeHorizontalOverlaps} from './surface-overlap.js?v=171.0';
import {connectColumnBeams} from './structural-frame.js?v=248.0';
import {drawCorridorGuard,corridorGuardStyle} from './corridor-guard.js?v=219.0';
import {createSchoolWindow} from './openings/school-window.js?v=222.0';
import {corridorPattern} from './corridor-tiles.js?v=222.0';
import {buildClassroom} from './buildings/classroom.js?v=242.0';
import {buildAdmin} from './buildings/admin.js?v=228.0';
import {buildHeritage} from './buildings/heritage.js?v=254.0';
import {buildHall} from './buildings/hall.js?v=247.0';
import {buildToilet} from './buildings/toilet.js?v=222.0';
import {buildLab} from './buildings/lab.js?v=222.0';
import {buildParking} from './buildings/parking.js?v=222.0';
import * as THREE from './vendor/three.module.js';
import {buildingBaseProfile,createBuildingBase} from './building-bases.js?v=253.0';
import {drawClassroomStairs} from './stair-design.js?v=244.0';
import {createStairDoor} from './interactive-door.js?v=245.0';
import {foundationElevation} from './raised-platform.js?v=223.0';
import {geometryKit,gableRoof} from './geometry-kit.js?v=222.0';

export function createBuildingGroup(b,selected=false){
 const g=new THREE.Group();g.position.set(b.x,foundationElevation(b),b.z);g.rotation.y=-b.rotation*Math.PI/180;g.userData.id=b.id;g.userData.features=[];g.userData.walkRoof={width:b.width,length:b.length,minimumY:buildingBaseProfile(b).height+b.height-.35};
 const kit=geometryKit(g,{height:b.height,storey:b.height/(b.floors||1),floorPattern:corridorPattern(b.id),floorOuterLimit:b.id==='A1'?{side:b.frontSide,limit:b.width/2-.29}:null,corridorEdges:b.id==='A1'?[b.frontSide*(b.width/2-.41),b.frontSide*(b.width/2-Math.min(2.25,b.width*.22)+.12)]:null,weatheringScale:b.kind==='admin'?.12:1}),{box,ring,beam}=kit,w=b.width/2,l=b.length/2,h=b.height;
 const floors=b.floors||Math.max(1,Math.round(h/3.5)),step=h/floors,side=b.frontSide===1?1:b.frontSide===-1?-1:b.kind==='admin'?1:-1;
 const wall=selected?'#ead894':b.kind==='admin'?'#f0ede3':'#dec17a',trim=b.kind==='admin'?'#f3efe5':'#eee2bc',green='#456c5c',brown='#665246',dark='#293f39',floor='#bb9271';
 const feature=name=>g.userData.features.push(name);
 const apertures=[],doorRecords=[];
 const record=(kind,u,y,width,height,v)=>{if(['classroom','lab','admin','heritage','hall','toilet'].includes(b.kind))apertures.push({kind,u,y,width:width+.08,height:height+.06,v});};
 // Facade coordinates: u along Z; v outward from the principal wall at +/-X.
 const fb=(u,y,v,width,height,depth,color,angle=0)=>box(depth,height,width,side*(w+v),y,u,color,0,-side*angle,0);
 function windowAt(u,y,v,width=1.6,height=1.5,color=green,shutters=true){
  if(b.kind==='classroom'&&Math.abs(u-(g.userData.coreCenter??0))>=(g.userData.coreSpan??0)/2){const roomWidth=width+.08,leafCount=width>1.7?4:2;width=(leafCount===4?2.32:1.16)*.8;record('window',u,y,width,height,v);apertures[apertures.length-1].roomWidth=roomWidth;g.add(createSchoolWindow({side,wallX:w+v,u,y,width,height,open:true,color,leafCount,flushFrame:b.id==='A2'||b.id==='B2'}));return;}width*=.8;record('window',u,y,width,height,v);const frame=b.kind==='heritage'? '#e5e8df':color;
  // Side jambs, sill and lintel surround an actual cut-out, with the sash inset.
  const windowFrameV=b.id==='A2'?v-.26:v;
  for(const a of [-1,1])fb(u+a*(width/2+.035),y,windowFrameV,width*.0+.07,height+.14,.03,frame);
  fb(u,y+height/2+.035,windowFrameV,width+.14,.07,.03,frame);fb(u,y-height/2-.035,windowFrameV,width+.14,.07,.0425,frame);
  fb(u,y,v-.04,width,height,.025,dark);fb(u,y,v+.015,.045,height,.055,frame);fb(u,y,v+.015,width,.045,.055,frame);
  // The room-facing sash has its own framing, not a blank reverse of the pane.
  const iv=v-.18;
  for(const a of [-1,1])fb(u+a*width/2,y,iv,.065,height+.10,.02,frame);
  for(const yy of [y-height/2,y+height/2])fb(u,yy,iv,width+.10,.065,.025,frame);
  fb(u,y,iv,.065,height,.07,frame);for(const yy of (b.kind==='admin'?[y-.30,y,y+.50]:[y-height*.25,y+height*.25]))fb(u,yy,iv,width,.045,.07,frame);if(b.kind==='admin')for(const t of [-.25,.25])fb(u+t*width,y,iv,.045,height,.07,frame);
  for(const a of [-1,1])fb(u+a*.09,y-.08,iv-.045,.035,.11,.035,'#b9b7a3');
  if(shutters)for(const a of [-1,1]){const leaf=new THREE.Group();leaf.position.set(side*(w+v+.025),y,u+a*width*.25);leaf.scale.x=side;g.add(leaf);const lk=geometryKit(leaf);drawClassicTimberLeaf(lk,{width:width*.46,height:height-.05,color});lk.finish();}
  if(shutters)for(const a of [-1,1]){const leafU=u+a*width*.25;fb(leafU,y,v+.025,width*.46,height-.05,.06,color);for(let j=0;j<18;j++)fb(leafU,y-height*.45+j*height*.05,v+.06,width*.38,.022,.045,dark);}
 }
 function doorAt(u,y,v,width,height,color,angle=0,interactive=false){
  record('door',u,y,width,height,v);const leafWidth=(width-.10)/2,hingeU=[u-width/2+.06,u+width/2-.06];
  const frameV=(b.id==='A2'||b.id==='B2')?v-.17:v;
  for(const a of [-1,1])fb(u+a*(width/2+.035),y,frameV,.07,height+.12,.035,color);
  fb(u,y+height/2+.035,frameV,width+.14,.07,.035,color);fb(u,y-height/2-.025,frameV,width+.14,.05,.05,'#a7a28d');
  const door=createStairDoor({side,wallX:w,u,y,v:(b.id==='A2'||b.id==='B2')?v-.155:v,width,height,color,grilled:b.id==='A2'&&interactive,decorated:(b.id==='A2'||b.id==='B2')&&!interactive,referenceLouver:['A1','B1'].includes(b.id),glazed:b.kind==='admin'||b.kind==='lab'});g.add(door);
  doorRecords.push({u,y,v,width,height,hinges:hingeU,openingAngle:angle,kind:'double-door'});
 }
 function vent(u,y,v,width=1.55){if(b.id==='A1'){for(const a of [-1,1])fb(u+a*width*.28,y,v,width*.38,.075,.08,dark);}else {for(let j=0;j<2;j++)fb(u,y+j*.14,v,width,.075,.08,dark);fb(u,y+.07,v+.06,.055,.26,.04,trim);fb(u,y-.08,v+.04,width+.10,.045,.08,trim);fb(u,y+.22,v+.04,width+.10,.045,.08,trim);}}
 function rail(u,y,v,width,color=trim,metal=false){
  const baseY=y,scale=metal?.8:.9,rfb=(u,yy,v,ww,hh,dd,c)=>kit.withCollision('barrier',()=>fb(u,baseY+(yy-baseY)*scale,v,ww,hh*scale,dd,c));
  if(metal){rfb(u,y+.94,v,width,.055,.055,'#373e39');for(let j=0;j<4;j++)rfb(u,y+.22+j*.18,v,width,.045,.045,'#373e39');const count=Math.max(2,Math.round(width/.8));for(let j=0;j<=count;j++)rfb(u-width/2+j*width/count,y+.48,v,.035,.9,.04,'#373e39');}
  else drawCorridorGuard(kit,{id:b.id,x:side*(w+v),z:u,y,width,wall,trim});

 }
 function plaque(text,u,y,v,width,height,color='#38617a'){
  const panel=kit.solid(new THREE.PlaneGeometry(width,height),color,'sign-panel');

  panel.position.set(side*(w+v),y,u);panel.rotation.y=side*Math.PI/2;panel.userData.signText=text;
 }
 function archOpening(u,y,v,width,height,rise){
  record('arched-door',u,y,width,height,v);const points=[],face=side*(w+v+.09),top=y+height/2;
  for(let j=0;j<20;j++){const a=j/20*Math.PI,b=(j+1)/20*Math.PI;points.push(face,top,u,face,top+rise*Math.sin(a),u+width/2*Math.cos(a),face,top+rise*Math.sin(b),u+width/2*Math.cos(b));}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(points,3));geo.computeVertexNormals();kit.withCollision('none',()=>kit.solid(geo,dark,'arched-portal'));
 }
 function flatRoof(parapet=.42){
  box(b.width+.05,.12,b.length+.05,0,h+.15,0,'#aaa98e');
  for(const s of [-1,1]){box(.18,parapet,b.length+.3,s*(w+.04),h+parapet/2,0,wall);box(b.width,.10,.3,0,h+parapet,s*(l+.05),trim);box(b.width,parapet,.16,0,h+parapet/2,s*l,wall);}
  feature('flat-parapet-roof');
 }
 function canopy(u,y,width,depth,color){fb(u,y,depth*.5,width,.14,depth,color);const count=b.kind==='hall'?4:6;for(let j=0;j<count;j++)fb(u-width/2+.35+j*(width-.70)/(count-1),y/2,depth-.2,.24,y,.24,trim);}
 function stairCore(span,screen=false,center=0){
  g.userData.stairPlan=drawClassroomStairs(kit,b);feature('connected-walkable-stair-flights');if(['A1','A2','B1','B2'].includes(b.id)){const anchor=new THREE.Group();anchor.name=b.id+'-slide-rails';anchor.userData.walkSlideRails=g.userData.stairPlan.flights;anchor.userData.stairCenter=g.userData.stairPlan.center;g.add(anchor);}
  if(screen){
   const cols=11,cell=span/cols;
   for(const face of [-1,1]){const bottom=face===side?step+.28:step*.54,top=b.id==='A1'?h-.12:h-.75,screenH=top-bottom,rows=Math.max(4,Math.round(screenH/cell)),x=face*(w+.06);
    for(let j=0;j<=cols;j++)box(.12,screenH,.045,x,bottom+screenH/2,center-span/2+j*cell,trim);
    for(let j=0;j<=rows;j++)box(.12,.045,span,x,bottom+j*screenH/rows,center,trim);
    for(let j=0;j<cols;j++)for(let k=0;k<rows;k++){const cy=bottom+(k+.5)*screenH/rows,cz=center-span/2+(j+.5)*cell;ring(Math.min(cell,screenH/rows)*.30,x,cy,cz,trim);for(const a of [-1,1]){box(.12,.045,cell*.19,x,cy,cz+a*cell*.405,trim);box(.12,screenH/rows*.19,.045,x,cy+a*screenH/rows*.405,cz,trim);}}
   }
   feature('circular-breeze-block-stair-screen');
  }
 }
 if(b.width<4||b.length<6||b.height<2.4){box(b.width,h,b.length,0,h/2,0,wall);flatRoof(.15);feature('simplified-small-mass');kit.finish();return g;}
 const builders={classroom:buildClassroom,admin:buildAdmin,heritage:buildHeritage,hall:buildHall,toilet:buildToilet,lab:buildLab,parking:buildParking};
 const ctx={b,g,kit,box,ring,beam,w,l,h,floors,step,side,wall,trim,green,brown,dark,floor,feature,apertures,doorRecords,record,fb,windowAt,doorAt,vent,rail,plaque,archOpening,flatRoof,canopy,stairCore};
 if(builders[b.kind])builders[b.kind](ctx);else{box(b.width,h,b.length,0,h/2,0,wall);gableRoof(kit,b.width,b.length,h,b.roof,1);}
 if(b.kind==='classroom'){
  initializeClassroomWindows(g,b);
  const corridor=Math.min(2.25,b.width*.22),ys=g.userData.stairPlan.levels.slice(1),guardHeight=b.id==='A1'?.775:b.id==='A2'||b.id==='B2'?.765:.711;
  for(const [floorIndex,y]of ys.entries())for(const end of [-1,1]){
   const x=side*(w-corridor/2),z=end*(l-.10),opening=b.id==='A1'&&floorIndex===0&&end===-1?1.35:0;
   const ranges=opening?[[-corridor/2,-opening/2],[opening/2,corridor/2]]:[[-corridor/2,corridor/2]];
   for(const [lo,hi]of ranges)drawCorridorGuard(kit,{id:b.id,x:x+(lo+hi)/2,z,y:(floorIndex+1)*step,width:hi-lo,angle:Math.PI/2,wall,trim});
  }
  g.userData.corridorEndGuards={floors:ys.length,ends:2,height:guardHeight,style:corridorGuardStyle(b.id),sharedWithFacade:true,datum:"storey grid, matching front parapet; excludes stair landing finish offset"};
  if(b.id==='A1')g.userData.hallLinkOpening={floor:2,end:-1,width:1.35};
 }
 g.userData.stairFinish='admin-red-yellow-stone';g.userData.doorLeaves=doorRecords;g.userData.apertures=apertures;kit.finish();
 connectColumnBeams(g,b,wall);removeHorizontalOverlaps(g);
 if(['A1','A2'].includes(b.id)){cutRoofHatch(g,b);addRoofLadder(g,b);}
 const base=buildingBaseProfile(b);for(const child of g.children)child.position.y+=base.height;g.add(createBuildingBase(b));g.userData.floorElevation=foundationElevation(b)+base.height;feature('raised-plinth-and-connected-entrance-steps');groundColumns(g);addStepSeats(g,b,base);return g;
}
