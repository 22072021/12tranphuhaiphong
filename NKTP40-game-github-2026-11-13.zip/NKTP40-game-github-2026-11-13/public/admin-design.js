export const ADMIN_STRUCTURE={columnWidth:.80,columnDepth:.72,floorSlab:.28,floorBeam:.44,roofSlab:.30,roofBeam:.52,porchColumn:.64,porchSlab:.32,roofCanopySlab:.32};
// Left/right are as seen while facing the courtyard facade.
export function administrationPlan(b){
 const side=b.frontSide===-1?-1:1,w=b.width/2,l=b.length/2,step=b.height/b.floors,corridor=2.0,bay=b.length/7;
 // Keep the four room bays and total footprint; redistribute only the side bays.
 // Clear openings between facade columns: hall : staircase = 1 : 2.
 const columnWidth=ADMIN_STRUCTURE.columnWidth,hallBay=(3*bay+columnWidth)/4,stairBay=2*hallBay-columnWidth;
 const u=t=>{const k=t*7,d=k<=1?k*hallBay:k<=5?hallBay+(k-1)*bay:k<=6?hallBay+4*bay+(k-5)*hallBay:2*hallBay+4*bay+(k-6)*stairBay;return side*(l-d);};
 const stairWidth=(stairBay-.65)/2,gap=.22,wellU=u(6.5/7),offset=(stairWidth+gap)/2,stairU=wellU-side*offset,laneU=wellU+side*offset,front=side*(w-corridor-.4),count=Math.ceil(step/2/.18),run=count*.30+Math.max(0,b.width-8.6)/2,rear=front-side*run;
 const flights=[],landings=[];for(let f=0;f<b.floors-1;f++){
  const mid=(f+.5)*step;
  flights.push({from:{x:front,z:stairU,y:f*step},to:{x:rear,z:stairU,y:mid},width:stairWidth,count});
  flights.push({from:{x:rear,z:laneU,y:mid},to:{x:front,z:laneU,y:(f+1)*step},width:stairWidth,count});
  // Continue the intermediate landing to the real rear facade. Keep the
  // V56: split extra building depth equally between the flight run and landing.
  // Keep the original riser count and floor levels.
  const backInner=-side*(w-.22),landingDepth=Math.abs(rear-backInner);
  landings.push({x:(rear+backInner)/2,z:wellU,y:mid,sx:landingDepth,sz:stairBay-.20});
 }

 return{structure:ADMIN_STRUCTURE,side,w,l,step,corridor,bay,hallBay,stairBay,columnWidth,u,stairWidth,stairU,front,rear,laneU,wellU,gap,run,count,flights,landings,edges:[0,1/7,2/7,4/7,5/7,6/7,1].map(u),floors:[['side-hall','door','long-window','long-window','door','side-hall'],['side-hall','door','long-window','long-window','door','side-hall'],['side-hall','door','door','door','window','side-hall']],estimated:true};
}
