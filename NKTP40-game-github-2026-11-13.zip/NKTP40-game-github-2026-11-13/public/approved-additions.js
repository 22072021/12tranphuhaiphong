import {createStairDoor} from './interactive-door.js?v=222.0';
import * as THREE from './vendor/three.module.js';
import {makeOpeningWall} from './wall-openings.js?v=222.0';
import {geometryKit,gableRoof} from './geometry-kit.js?v=222.0';
import {buildingBaseProfile,createBuildingBase} from './building-bases.js?v=223.0';
import {APPROVED_ADDITIONS} from './approved-additions-data.js?v=213.0';
import {containsPoint} from './layout-state.js?v=127.1';
export {APPROVED_ADDITIONS};
export function approvedAdditionBlocks(x,z,padding=.4){return APPROVED_ADDITIONS.some(b=>['context','water','connector'].includes(b.kind)?containsPoint(x,z,b,padding):false);}
export function createApprovedAdditions(){const root=new THREE.Group();root.name='approved-additions';
 for(const b of APPROVED_ADDITIONS){const g=new THREE.Group();g.name=b.id;g.position.set(b.x,0,b.z);g.rotation.y=-b.rotation*Math.PI/180;g.userData={...b};root.add(g);const k=geometryKit(g),{box,beam}=k;
 if(b.kind==='connector'){
  box(b.width,.12,b.length,0,-.06,0,'#aaa18e');
  // Continuous outer boundary ties into the parking rear wall line and LAB end.
  box(.22,b.height,b.length,-b.width/2+.11,b.height/2,0,'#dec17a');
  for(const z of [-b.length/2,b.length/2])box(b.width,b.height,.22,0,b.height/2,z,'#dec17a');
  const garageU=-b.length/2+2.4;
  const holes=[{u:garageU,y:1.25,width:3.25,height:2.50,kind:'door'},{u:-2,y:1.20,width:1.15,height:2.4,kind:'door'},{u:1.8,y:1.55,width:1.5,height:1.35,kind:'window'}];
  makeOpeningWall(g,{side:1,wallX:b.width/2,faceV:0,from:-b.length/2,to:b.length/2,height:b.height,color:'#dec17a',openings:holes});
  g.add(createStairDoor({side:1,wallX:b.width/2,u:-2,y:1.2,v:0,width:1.15,height:2.4,color:'#456c5c',glazed:true}));
  box(.06,1.35,1.50,b.width/2-.10,1.55,1.8,'#456c5c');
  gableRoof(k,b.width,b.length,b.height,'#a45446',.8,'connector-continuous-parking-roof');
  const blue=[];for(const sign of [-1,1]){const a=[0,b.height+.808,0],c=[sign*(b.width/2+.22),b.height+.008,0],d=[sign*(b.width/2+.22),b.height+.008,b.length/2+.22],e=[0,b.height+.808,b.length/2+.22];for(const v of [a,c,d,a,d,e])blue.push(...v);}const bg=new THREE.BufferGeometry();bg.setAttribute('position',new THREE.Float32BufferAttribute(blue,3));bg.computeVertexNormals();k.withCollision('none',()=>k.solid(bg,'#507da4','connector-blue-roof-section'));
  // Return wall reaches the LAB wall despite the small angle in the aerial fit.
  box(1.85,b.height,.24,b.width/2-.2,b.height/2,b.length/2,'#dec17a');
  box(.24,.16,3.45,b.width/2-.02,2.60,garageU,'#d5c99f');
  box(2.1,.10,3.25,b.width/2+1.0,-.05,garageU,'#aaa18e');
  g.userData.garage={u:garageU,width:3.25,height:2.50,open:true};
  g.userData.closedBoundary=true;g.userData.roofMatchesParking={eave:3.32,rise:.8};
 }else if(b.kind==='shed'){
  for(const x of [-b.width/2,b.width/2])for(const z of [-b.length/2,b.length/2])box(.14,b.height,.14,x,b.height/2,z,'#8e9689');
  box(b.width,.15,.14,0,b.height,-b.length/2,'#838c82');box(b.width,.15,.14,0,b.height,b.length/2,'#838c82');
  for(const [x,color] of [[-2,'#6388a1'],[2,'#955b57']]){const roof=gableRoof(k,4,b.length,b.height,color,.65,'D01-roof');roof.position.x=x;}
 }else if(b.kind==='context'){
  // P38: lower left wing, taller two-storey centre, low right wing with red pitched roof.
  const parts=b.parts||[{width:b.width*.33,height:5.25,roof:'flat',color:'#93958b'},{width:b.width*.30,height:6.3,roof:'flat',color:'#a5a499'},{width:b.width*.37,height:3.55,roof:'red',color:'#aaa58f'}];let edge=-b.width/2;
  for(const part of parts){const redRoof=part.roof==='red',width=part.width,cx=edge+width/2,h=part.height;edge+=width;
   box(width,h,b.length,cx,h/2,0,part.color);
   if(redRoof){const roof=gableRoof(k,width,b.length,h,'#92504b',.8,'P38-red-pitched-roof');roof.position.x=cx;}
   else box(width+.08,.14,b.length+.08,cx,h+.07,0,'#6c7067');
   const floors=redRoof?1:2;for(let f=0;f<floors;f++)for(const sign of [-1,1]){const x=cx+sign*width*.24,y=1.35+f*2.95,ww=redRoof?1.35:1.12,hh=redRoof?1.3:1.65;
    box(ww,hh,.06,x,y,b.length/2+.04,'#3f4741');for(const dy of [-hh/2-.05,hh/2+.05])box(ww+.18,.10,.16,x,y+dy,b.length/2+.08,'#b0ac9c');
    for(let j=0;j<5;j++)box(.018,hh,.025,x-ww/2+(j+1)*ww/6,y,b.length/2+.09,'#4c514a');
    for(const side of [-1,1]){const shutterX=x+side*(ww/2+.23);box(.42,hh,.045,shutterX,y,b.length/2+.08,redRoof?'#82785e':'#a0b3b2');for(let j=0;j<9;j++)box(.40,.018,.025,shutterX,y-hh/2+(j+.5)*hh/9,b.length/2+.11,'#778986');}
    box(ww+.35,.09,.38,x,y+hh/2+.18,b.length/2+.18,'#86857a');
   }
  }
  g.userData.source='P38';g.userData.facadeCoverageB1=4;g.userData.removedCentralMass=true;g.userData.redWingShift=7.245;g.userData.estimated=true;
 }else if(b.kind==='water'){
  const face=-b.width/2;
  // Closed contextual volume: no room or operable door behind the opaque steel gate.
  box(b.width,b.height,b.length,0,b.height/2,0,'#dec17a');box(b.width+.3,.16,b.length+.35,0,b.height+.08,0,'#9b9f8e');
  const doorX=face-.035,green='#285b49',steel='#48735c',width=2.25,height=2.4;
  box(.045,height,width,doorX,height/2,0,green);
  for(const z of [-width/2,0,width/2])box(.055,height,.045,doorX-.035,height/2,z,steel);
  for(const y of [.025,height-.025])box(.06,.05,width+.06,doorX-.035,y,0,steel);
  for(let z=-width/2+.10;z<width/2;z+=.15)box(.04,height-.08,.022,doorX-.065,height/2,z,steel);
  for(let row=0;row<3;row++)for(let z=-width/2+.08;z<width/2-.1;z+=.30){const z1=Math.min(z+.30,width/2-.06),y=.20+row*.72;beam(new THREE.Vector3(doorX-.085,y,z),new THREE.Vector3(doorX-.085,y+.62,z1),.018,steel);beam(new THREE.Vector3(doorX-.085,y+.62,z),new THREE.Vector3(doorX-.085,y,z1),.018,steel);}
  for(const z of [-.055,.055])box(.035,.19,.022,doorX-.11,1.12,z,'#809283');
  g.userData.waterEntrance={type:'opaque-green-accordion',locked:true,operable:false,interior:false};
  box(1.7,.16,b.length+.3,face-.6,2.85,0,'#b9b7a3');box(.10,.52,b.length+.2,face-1.45,3.0,0,'#386c9e');
  const panel=k.solid(new THREE.PlaneGeometry(b.length+.1,.47),'#386c9e','drinking-water-sign');panel.position.set(face-1.51,3.0,0);panel.rotation.y=-Math.PI/2;panel.userData.signText='PHÒNG NƯỚC UỐNG TINH KHIẾT';panel.userData.textColor='white';
 }else{
  for(const x of [-b.width/2,b.width/2])for(const z of [-b.length/2,0,b.length/2])box(.045,b.height,.045,x,b.height/2,z,'#5a6257');
  for(const x of [-b.width/2,0,b.width/2])box(.04,.045,b.length,x,b.height,0,'#626d5b');
  for(let z=-b.length/2;z<=b.length/2;z+=.5)box(b.width,.04,.035,0,b.height,z,'#626d5b');
  for(let i=0;i<14;i++){const x=Math.sin(i*2.1)*b.width*.40,z=-b.length/2+(i+.5)*b.length/14;box(.32,.05,.22,x,b.height+.06,z,'#668259',.08,i*.7,.1);}
 }
 k.finish();if(b.kind==='water'){const base=buildingBaseProfile(b);for(const child of g.children)child.position.y+=base.height;g.add(createBuildingBase(b));g.userData.floorElevation=base.height;}}return root;
}
