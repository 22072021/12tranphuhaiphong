import {importAsset,retryAsset,assetFailure} from './asset-retry.js';
import * as T from './vendor/three.module.js';
let source;
export function createHallPottedPine(){
 const g=new T.Group();g.name='hall-entrance-topiary';g.userData.walkRole='none';
 const profile=[[0,0],[.40,0],[.43,.08],[.50,.16],[.61,.48],[.65,.50],[.65,.56],[.57,.56],[.55,.49],[.41,.10],[0,.10]].map(([x,y])=>new T.Vector2(x,y));
 const pot=new T.Mesh(new T.LatheGeometry(profile,40),new T.MeshStandardMaterial({color:'#935b49',roughness:.85}));pot.name='grounded-terracotta-pot';g.add(pot);
 const soil=new T.Mesh(new T.CylinderGeometry(.565,.565,.04,32),new T.MeshStandardMaterial({color:'#514631',roughness:1}));soil.position.y=.48;g.add(soil);
 if(typeof document!=='undefined'){source??=importAsset(new URL('./vendor/GLTFLoader.js',import.meta.url).href).then(({GLTFLoader})=>retryAsset(()=>new GLTFLoader().loadAsync(new URL('./assets/hall-pine/pine-tree.bin',import.meta.url).href)));g.userData.textureReady=source.then(data=>{for(let p=g;p;p=p.parent)if(p.userData.disposed)return;const model=data.scene.clone(true),bounds=new T.Box3().setFromObject(model),size=bounds.getSize(new T.Vector3()),center=bounds.getCenter(new T.Vector3()),s=Math.min(2.7/size.y,1.7/Math.max(size.x,size.z));model.scale.multiplyScalar(s);model.position.set(-center.x*s,.48-bounds.min.y*s,-center.z*s);model.traverse(o=>{if(o.isMesh){o.geometry.userData.shared=true;for(const m of Array.isArray(o.material)?o.material:[o.material]){m.userData.shared=true;for(const t of Object.values(m))if(t?.isTexture)t.userData.shared=true;}o.castShadow=o.receiveShadow=true;o.userData.walkRole='none';}});g.add(model);g.updateMatrixWorld(true);window.dispatchEvent(new Event('nktp-texture-ready'));}).catch(e=>{source=null;assetFailure(g,e);});}
 return g;
}
