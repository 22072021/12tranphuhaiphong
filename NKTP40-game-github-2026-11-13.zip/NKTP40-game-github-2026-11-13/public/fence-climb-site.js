import * as T from './vendor/three.module.js';
import {FENCE_CLIMB,fenceClimbPoint} from './fence-climb-layout.js';
import {createCampusNPC} from './campus-npcs.js';
export function createFenceClimbSite(){
 const root=new T.Group();root.name='gate-fence-climb-interaction';root.userData.walkFenceClimb={...FENCE_CLIMB};
 const red=new T.MeshBasicMaterial({color:'#dc3030',transparent:true,opacity:.85,depthWrite:false});
 for(const side of [-1,1]){const p=fenceClimbPoint(side),dot=new T.Mesh(new T.CircleGeometry(.23,28),red);dot.name=side<0?'fence-climb-outside-dot':'fence-climb-inside-dot';dot.rotation.x=-Math.PI/2;dot.position.set(p.x,side<0?.0855:.045,p.z);dot.userData.walkRole='none';root.add(dot);}
 const guard=createCampusNPC({id:'fence-guard',name:'Chú bảo vệ',guardStyle:true,clothingPalette:{hair:'#191916'}});guard.position.set(FENCE_CLIMB.x-1.25,.0755,FENCE_CLIMB.z+1.25);guard.rotation.y=-Math.PI*.68;guard.userData.dialogue='Cấm trèo hàng rào ở chỗ này';guard.userData.reference='Same guard uniform as Khuyen; black hair, no moustache';root.add(guard);return root;
}
