// Compatibility entry point; all copies use one reusable window template.
export {ADMIN_WINDOW,createAdministrationWindow} from './openings/window-template.js?v=222.0';
