// Apply white paint only to downward structural faces; keep walls/floors intact.
const structural=new Set(['#dec17a','#eee2bc','#e4dfcd','#e5e8df','#b8c6a4','#e2dfd2','#bba47e','#adab91','#c9b8a0','#a9a69a','#9a5149','#96988e','#9b9f8e','#aaa98e','#f0ede3','#f3efe5','#d8d4bb']);
export function applyCeilingFinish(material,color,force=false){
 if(!force&&!structural.has(color.toLowerCase()))return material;
 const compile=material.onBeforeCompile.bind(material),cache=material.customProgramCacheKey.bind(material),previousKey=cache();
 material.onBeforeCompile=shader=>{compile(shader);shader.vertexShader='varying vec3 vCeilingNormal;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <beginnormal_vertex>',`#include <beginnormal_vertex>
 vec3 ceilingNormal=objectNormal;
 #ifdef USE_INSTANCING
  ceilingNormal=mat3(instanceMatrix)*ceilingNormal;
 #endif
 vCeilingNormal=normalize(mat3(modelMatrix)*ceilingNormal);`);
 shader.fragmentShader='varying vec3 vCeilingNormal;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>',`if((gl_FrontFacing ? 1.0 : -1.0)*normalize(vCeilingNormal).y < -0.72){diffuseColor.rgb=vec3(0.94,0.94,0.92);}
 #include <roughnessmap_fragment>`);shader.fragmentShader=shader.fragmentShader.replace('#include <emissivemap_fragment>',`#include <emissivemap_fragment>
 if((gl_FrontFacing ? 1.0 : -1.0)*normalize(vCeilingNormal).y < -0.72){totalEmissiveRadiance+=vec3(0.42,0.42,0.41);}`);};
 material.customProgramCacheKey=()=>previousKey+'-white-ceilings-v48';material.userData.ceilingFinish='white-downward-faces';return material;
}
