import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
// Connect actual column axes, rather than introducing a second arbitrary grid.
export function connectColumnBeams(group,b,color){
 // Heritage masonry arch piers are not columns: automatic lintels would cut across the arch.
 if(b.kind==='heritage'||b.kind==='hall'){group.userData.columnBeamConnections=[];return;}
 const columns=[],m=new THREE.Matrix4(),p=new THREE.Vector3(),q=new THREE.Quaternion(),s=new THREE.Vector3();
 for(const mesh of group.children)if(mesh.isInstancedMesh&&mesh.name==='detail-box')for(let i=0;i<mesh.count;i++){mesh.getMatrixAt(i,m);m.decompose(p,q,s);if(s.y<1.7||s.x<.15||s.z<.15||s.x>.85||s.z>.85||Math.abs(q.x)+Math.abs(q.y)+Math.abs(q.z)>.01)continue;columns.push({x:p.x,z:p.z,bottom:p.y-s.y/2,top:p.y+s.y/2,width:Math.min(s.x,s.z)});}
 const k=geometryKit(group,{height:b.height,storey:b.height/(b.floors||1)}),seen=new Set(),records=[];const step=b.height/(b.floors||1),core=group.userData.coreSpan,center=group.userData.coreCenter??0;
 for(const a of columns)for(const axis of ['x','z']){const other=axis==='x'?'z':'x';const targets=columns.filter(c=>c!==a&&Math.abs(c[other]-a[other])<.12&&c[axis]>a[axis]+.14).sort((c,d)=>c[axis]-d[axis]);const c=targets[0];if(!c)continue;
 const top=Math.min(a.top,c.top),bottom=Math.max(a.bottom,c.bottom),levels=[top];for(let f=1;f<=(b.floors||1);f++)if(f*step>bottom+1&&f*step<top-.2)levels.push(f*step);
 for(const y of levels){if(y> b.height+.7)continue;const key=[axis,a.x.toFixed(2),a.z.toFixed(2),c.x.toFixed(2),c.z.toFixed(2),y.toFixed(2)].join(':');if(seen.has(key))continue;seen.add(key);
 // Leave stair wells open; their perimeter beams already join the landing columns.
 if(core&&axis==='x'&&Math.abs(a.z-center)<core/2&&y<b.height-.1)continue;
 const depth=.22,width=Math.min(.28,a.width,c.width),length=c[axis]-a[axis]+Math.max(a.width,c.width);k.box(axis==='x'?length:width,depth,axis==='z'?length:width,(a.x+c.x)/2,y-depth/2,(a.z+c.z)/2,color);records.push({axis,y,from:[a.x,a.z],to:[c.x,c.z]});}
 }
 k.finish();group.userData.columnBeamConnections=records;
}
