import * as T from './vendor/three.module.js';
import {createResidentialBack} from './accordion-neighbours.js';
export const EXERCISE_BACKS=[
 {id:'yard-boundary-house-1',from:-36.75,to:-42.65,height:3.6,floors:1,color:'#a8a291',vents:true},
 {id:'yard-boundary-house-2',from:-42.65,to:-48.55,height:6.1,floors:2,color:'#959e9b'},
 {id:'yard-boundary-house-3',from:-48.55,to:-54.6,height:3.8,floors:1,color:'#b1a89a'}
];
export function createExerciseBoundaryBacks(){
 const root=new T.Group();root.name='exercise-boundary-residential-backs';
 for(const p of EXERCISE_BACKS){const g=createResidentialBack({...p,width:p.from-p.to});g.position.set(-14.82,0,(p.from+p.to)/2);g.rotation.y=Math.PI/2;root.add(g);}
 return root;
}
