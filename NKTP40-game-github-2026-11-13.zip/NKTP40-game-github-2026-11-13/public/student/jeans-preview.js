import * as T from '../vendor/three.module.js';
const textures=new Map(),states=new WeakMap();
function denimTexture(female){
 const key=female?'female':'male';if(textures.has(key))return textures.get(key);
 const c=document.createElement('canvas');c.width=512;c.height=512;const x=c.getContext('2d');
 x.fillStyle=female?'#6f98b6':'#254d73';x.fillRect(0,0,512,512);
 let seed=71;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
 for(let i=0;i<36000;i++){x.fillStyle=random()>.5?'rgba(225,237,240,.09)':'rgba(5,22,43,.09)';x.fillRect(random()*512,random()*512,1,2);}
 for(let side=0;side<2;side++){const ox=side*256;x.save();x.translate(ox,0);
 for(const cx of [65,191]){const g=x.createRadialGradient(cx,270,5,cx,270,170);g.addColorStop(0,female?'rgba(224,238,240,.27)':'rgba(147,187,207,.13)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,60,256,420);}
 x.strokeStyle=female?'#c4bba1':'#b39c72';x.lineWidth=1.4;x.setLineDash([3,2]);
 const line=(a,b,c,d)=>{x.beginPath();x.moveTo(a,b);x.lineTo(c,d);x.stroke();};
 line(10,19,246,19);line(10,33,246,33);line(12,481,244,481);line(16,487,240,487);line(12,35,15,485);line(244,35,241,485);line(126,130,123,485);line(130,130,133,485);
 if(side===0){x.beginPath();x.moveTo(20,38);x.quadraticCurveTo(25,91,82,95);x.stroke();x.beginPath();x.moveTo(236,38);x.quadraticCurveTo(231,91,174,95);x.stroke();line(132,35,132,122);x.fillStyle='#ccb27e';x.beginPath();x.arc(127,26,3,0,Math.PI*2);x.fill();}
 else for(const cx of [69,187]){x.fillStyle=female?'rgba(52,89,120,.14)':'rgba(10,28,50,.15)';x.beginPath();x.moveTo(cx-35,63);x.lineTo(cx+35,63);x.lineTo(cx+29,123);x.lineTo(cx,137);x.lineTo(cx-29,123);x.closePath();x.fill();x.stroke();line(cx-26,75,cx,93);line(cx,93,cx+26,75);}
 for(const px of [33,105,151,223]){line(px,17,px,39);line(px+4,17,px+4,39);}x.restore();}
 const texture=new T.CanvasTexture(c);texture.colorSpace=T.SRGBColorSpace;texture.userData.shared=true;textures.set(key,texture);return texture;
}
export function setJeansPreview(root,gender,enabled){
 const mesh=root.getObjectByName('continuous-trousers');if(!mesh)return;let state=states.get(mesh);
 if(!enabled){if(state){mesh.geometry=state.geometry;mesh.material=state.material;}return;}
 if(!state){state={geometry:mesh.geometry,material:mesh.material};const g=mesh.geometry.clone(),p=g.attributes.position,n=g.attributes.normal,uv=[];const female=gender==='female';
 for(let i=0;i<p.count;i++){const y=p.getY(i),xx=p.getX(i);if(y<.59){const center=Math.sign(xx)*.079,factor=female?1:1.09;p.setX(i,center+(xx-center)*factor);}const u=T.MathUtils.clamp((xx+.155)/.31,0,1),v=T.MathUtils.clamp((y-.088)/(.815-.088),0,1);uv.push((n.getZ(i)>=0?0:.5)+u*.5,v);}
 g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.computeVertexNormals();state.jeansGeometry=g;state.jeansMaterial=new T.MeshStandardMaterial({map:denimTexture(female),roughness:.95,metalness:0});states.set(mesh,state);}
 mesh.geometry=state.jeansGeometry;mesh.material=state.jeansMaterial;
}
export function disposeJeansPreview(root){const mesh=root.getObjectByName('continuous-trousers'),state=mesh&&states.get(mesh);if(!state)return;mesh.geometry=state.geometry;mesh.material=state.material;state.jeansGeometry.dispose();state.jeansMaterial.dispose();states.delete(mesh);}
