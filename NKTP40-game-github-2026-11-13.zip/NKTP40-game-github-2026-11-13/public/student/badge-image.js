export default new URL('../assets/student/badge.webp',import.meta.url).href;
