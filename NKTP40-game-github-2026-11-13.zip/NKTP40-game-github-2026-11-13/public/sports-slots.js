import * as T from './vendor/three.module.js';
export function createSportsSlots(root,state,positions,{kind,title,target=new T.Vector3()}){
 const slots=positions.map((position,index)=>{const marker=new T.Mesh(new T.CircleGeometry(.30,32),new T.MeshBasicMaterial({color:'#d84037',transparent:true,opacity:.9,side:T.DoubleSide,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1}));marker.rotation.x=-Math.PI/2;marker.position.copy(position);marker.position.y=kind==='shuttlecock'?.055:.022;marker.name='sports-join-red-dot';root.add(marker);
  const slot={root,marker,kind,title,index,targetLocal:target.clone(),localOccupied:false,remoteOccupied:false,rally:0,misses:0,swingUntil:0,get occupied(){return this.localOccupied||this.remoteOccupied;},get time(){return state.time||0;},join(){this.localOccupied=true;this.rally=0;this.misses=0;state.lastHitRound=undefined;},leave(){this.localOccupied=false;},hit(){this.swingUntil=this.time+.65;if(!this.localOccupied)return false;if(state.onPlayerHit)return state.onPlayerHit(this);if(state.target===this&&state.progress>.50&&state.lastHitRound!==state.round){this.rally++;state.lastHitRound=state.round;return true;}return false;}};return slot;
 });root.sportsGames=slots;root.sportsGame=slots[0];root.userData.sportsGame=true;return slots;
}
export function finishSportsPass(state){if(state.previousTarget?.localOccupied&&state.lastHitRound!==state.previousRound)state.previousTarget.misses++;}
// A missed local return ends the rally, without clearing accumulated counters.
export function sportsClock(state,time,duration){
 state.time=time;let pass=(time-(state.resetAt??0))/duration,n=Math.floor(pass),u=pass-n;
 if(state.clockRound!==undefined&&n!==state.clockRound&&state.previousTarget?.localOccupied&&state.lastHitRound!==state.previousRound){state.previousTarget.misses++;state.resetAt=time;state.previousTarget=null;state.lastHitRound=undefined;n=0;u=0;state.resetCount=(state.resetCount||0)+1;}
 state.clockRound=n;state.round=n;state.progress=u;return{n,u};
}
