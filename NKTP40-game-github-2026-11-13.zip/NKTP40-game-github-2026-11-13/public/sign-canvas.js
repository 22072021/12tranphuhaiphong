// Cap BOTH dimensions, not just width: narrow/tall signs must not allocate
// a 2048 x 16000+ canvas. Paint in existing logical coordinates unchanged.
export function createSignCanvas(width,height,paint){
 if(!Number.isFinite(width)||!Number.isFinite(height)||width<=0||height<=0)throw Error('Invalid sign size');
 const logicalWidth=2048,logicalHeight=Math.max(1,Math.round(logicalWidth*height/width));
 const longest=Math.min(2048,Math.max(128,Math.ceil(Math.max(width,height)*384)));
 const scale=longest/Math.max(logicalWidth,logicalHeight),canvas=document.createElement('canvas');
 canvas.width=Math.max(1,Math.round(logicalWidth*scale));canvas.height=Math.max(1,Math.round(logicalHeight*scale));
 const context=canvas.getContext('2d');context.scale(canvas.width/logicalWidth,canvas.height/logicalHeight);
 paint(context,logicalWidth,logicalHeight);return canvas;
}
