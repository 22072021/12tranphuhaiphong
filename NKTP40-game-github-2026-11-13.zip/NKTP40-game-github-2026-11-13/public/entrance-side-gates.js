import * as T from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js';
// Photo widths are estimated from adjacent fence bays. Local Z runs along frontage.
export function auxiliaryGatePlan(lo,hi,bays){const span=(hi-lo)/bays;return[
 {id:'tea-side-auxiliary-gate',z:hi-2.50,width:1.18,height:3.04,leaves:1,source:'gate-location.jpg'},
 {id:'noodle-side-double-gate',z:hi-7.5*span,width:span-.27,height:3.04,leaves:2,fenceBay:8,source:'double-gate-bay8.jpg'}
];}
export function subtractGateIntervals(from,to,gates,margin=0){let pieces=[[from,to]];for(const gate of gates){const lo=gate.z-gate.width/2-margin,hi=gate.z+gate.width/2+margin;pieces=pieces.flatMap(([a,b])=>hi<=a||lo>=b?[[a,b]]:[[a,Math.min(b,lo)],[Math.max(a,hi),b]].filter(([x,y])=>y-x>.001));}return pieces;}
export function createAuxiliaryGate(q){const root=new T.Group();root.name=q.id;root.position.z=q.z;root.userData={...q,closed:true,operable:false,estimated:true};const k=geometryKit(root),green='#2c5a43',rail='#386a50';
 for(const side of [-1,1]){k.box(.15,q.height+.06,.075,0,(q.height+.06)/2,side*q.width/2,green);for(const y of [.35,2.35])k.box(.13,.14,.06,-.05,y,side*q.width/2,rail);}
 // Fixed narrow ironwork joins each jamb to the neighbouring fence without a side gap.
 for(const side of [-1,1]){const z=side*(q.width/2+.10);for(const y of [1.02,1.22,2.54,2.92])k.box(.075,.045,.24,-.025,y,z,rail);for(const offset of [.06,.16])k.box(.045,2.94,.028,-.025,1.5,side*(q.width/2+offset),rail);k.box(.15,.90,.22,0,.45,z,'#e3ca8c');}
 const leafWidth=q.width/q.leaves;for(let i=0;i<q.leaves;i++){const leaf=new T.Group();leaf.name=q.id+'-leaf-'+(i+1);const z=-q.width/2+(i+.5)*leafWidth;leaf.position.z=z;root.add(leaf);const f=geometryKit(leaf),w=leafWidth-.022;
 // Opaque lower steel sheet, recessed field, tall vertical upper sheet and pickets.
 f.box(.045,.87,w-.09,.006,.535,0,green);f.box(.023,.70,w-.23,-.025,.53,0,rail);
 f.box(.035,1.42,w-.09,.006,1.81,0,green);
 for(const zz of [-w/2,w/2])f.box(.07,2.98,.045,-.025,1.52,zz,rail);
 for(const y of [.10,.98,1.12,2.54,2.92])f.box(.075,.04,w,-.035,y,0,rail);
 for(let zz=-w/2+.10;zz<w/2-.04;zz+=.13){f.box(.026,1.88,.022,-.025,2.08,zz,rail);const spear=f.solid(new T.ConeGeometry(.022,.09,4),rail,'aux-gate-spear');spear.position.set(-.025,3.065,zz);}
 if(q.leaves===2){for(const sign of [-1,1])f.beam(new T.Vector3(-.065,1.25,sign*w*.43),new T.Vector3(-.065,2.53,-sign*w*.43),.028,rail);}

 f.box(.035,.13,.03,-.075,1.15,i===0?w/2-.11:-w/2+.11,'#a3a68a');f.finish();}
 k.finish();return root;}
