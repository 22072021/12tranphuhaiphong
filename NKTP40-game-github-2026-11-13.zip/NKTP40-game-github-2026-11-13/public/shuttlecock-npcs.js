import {createFootShuttle,orientShuttle} from './sports-equipment.js';
import {applySportsMotion} from './sports-motion.js';
import * as T from './vendor/three.module.js';
import {importAsset,assetFailure} from './asset-retry.js';
import {registerNPC} from './npc-animation.js';
import {createSportsSlots,sportsClock} from './sports-slots.js';
export function createShuttlecockGroups(layout){
 const root=new T.Group();root.name='courtyard-shuttlecock-groups';root.userData.walkIgnore=true;
 for(const id of ['A2','B2']){const b=layout.buildings.find(b=>b.id===id);if(!b)continue;const a=b.rotation*Math.PI/180,c=Math.cos(a),s=Math.sin(a),x=(b.frontSide||-1)*(b.width/2+8),z=id==='A2'?9:-9,g=new T.Group();g.name='shuttlecock-group-'+id;g.position.set(b.x+c*x-s*z,0,b.z+s*x+c*z);g.userData={npc:true,walkIgnore:true,players:3,building:id,animationRadius:4};root.add(g);
  const location=i=>new T.Vector3(Math.sin(i*Math.PI/3)*2.4,0,Math.cos(i*Math.PI/3)*2.4),state={},slots=createSportsSlots(g,state,[1,3,5].map(location),{kind:'shuttlecock',title:'Đá cầu'});
  g.userData.textureReady=importAsset(new URL('./student/student.js',import.meta.url).href).then(async({createStudent,badgeReady})=>{await badgeReady;for(let p=g;p;p=p.parent)if(p.userData.disposed)return;const actors=[];for(let i=0;i<3;i++){const avatar=createStudent({gender:i===1?'female':'male',season:'summer',scale:.93});avatar.root.name='shuttlecock-player-'+(i+1);avatar.root.position.copy(location(i*2));avatar.root.rotation.y=Math.atan2(-avatar.root.position.x,-avatar.root.position.z);g.add(avatar.root);actors.push(avatar);}
   const shuttle=createFootShuttle();g.add(shuttle);
   let round=-1,from={p:location(0)},to={p:location(2)},queueIndex=0;const nodes=()=>actors.map((actor,i)=>({p:actor.root.position.clone(),npc:i})).concat(slots.filter(s=>s.occupied).map(slot=>({p:slot.marker.position.clone(),slot})));
   const tick=time=>{const oldReset=state.resetCount||0,{n,u}=sportsClock(state,time,1.8);if(round!==n||oldReset!==(state.resetCount||0)){const list=nodes();if(n===0){queueIndex=0;from=list[0];}else from=to.slot&&!to.slot.occupied?list[0]:to;queueIndex=(queueIndex+1)%list.length;to=list[queueIndex];if(to===from||to.p.distanceTo(from.p)<.1){queueIndex=(queueIndex+1)%list.length;to=list[queueIndex];}round=n;}if(to.slot&&!to.slot.occupied)to=nodes().find(v=>!v.slot&&v.p.distanceTo(from.p)>.1);state.target=to.slot||null;state.previousTarget=state.target;state.previousRound=n;
    actors.forEach((actor,i)=>{actor.update(time+i*.7,'idle');const k=i===from.npc?Math.max(0,1-u/.40):0;applySportsMotion(actor.joints,{kind:'shuttlecock',swing:k,anticipation:i===to.npc?T.MathUtils.smoothstep(u,.7,1):0});});const flight=T.MathUtils.clamp((u-.17)/.83,0,1),contact=p=>p.clone().add(p.clone().setY(0).normalize().multiplyScalar(-.35));shuttle.position.lerpVectors(contact(from.p),contact(to.p),flight);shuttle.position.y=.48+Math.sin(Math.PI*flight)*1.5;orientShuttle(shuttle,new T.Vector3(to.p.x-from.p.x,Math.PI*1.5*Math.cos(Math.PI*flight),to.p.z-from.p.z));g.userData.currentPass={toSlot:to.slot?to.slot.index:null,toNPC:to.npc===undefined?null:to.npc+1,progress:u};};tick(0);registerNPC(g,tick);g.userData.ready=true;
  }).catch(e=>assetFailure(g,e));slots.forEach(s=>s.textureReady=g.userData.textureReady);
 }return root;
}
