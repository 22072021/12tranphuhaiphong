import * as THREE from './vendor/three.module.js';
// Split coincident horizontal rectangles, retaining a single surface per patch.
export function removeHorizontalOverlaps(group){
 const accepted=[],m=new THREE.Matrix4(),p=new THREE.Vector3(),q=new THREE.Quaternion(),s=new THREE.Vector3(),zero=new THREE.Matrix4().makeScale(0,0,0);let fixed=0;
 [...group.children].forEach(mesh=>{if(!mesh.isInstancedMesh||mesh.name!=='detail-box'||mesh.parent!==group)return;const replacements=[];
 for(let i=0;i<mesh.count;i++){mesh.getMatrixAt(i,m);m.decompose(p,q,s);if(Math.abs(q.x)+Math.abs(q.y)+Math.abs(q.z)>.002||s.y>.30||s.y<.005||s.x<.10||s.z<.10)continue;
 const a={x0:p.x-s.x/2,x1:p.x+s.x/2,z0:p.z-s.z/2,z1:p.z+s.z/2,top:p.y+s.y/2};let parts=[a];
 for(const b of accepted){if(Math.abs(a.top-b.top)>.003)continue;parts=parts.flatMap(c=>{const x0=Math.max(c.x0,b.x0),x1=Math.min(c.x1,b.x1),z0=Math.max(c.z0,b.z0),z1=Math.min(c.z1,b.z1);if(x1-x0<.00001||z1-z0<.00001)return[c];return[{...c,x1:x0},{...c,x0:x1},{...c,x0,x1,z1:z0},{...c,x0,x1,z0:z1}].filter(r=>r.x1-r.x0>.00001&&r.z1-r.z0>.00001);});}
 if(parts.length!==1||Math.abs((parts[0].x1-parts[0].x0)-s.x)>.00001||Math.abs((parts[0].z1-parts[0].z0)-s.z)>.00001){mesh.setMatrixAt(i,zero);if(mesh.userData.walkRoles)mesh.userData.walkRoles[i]='none';for(const a of parts){const matrix=new THREE.Matrix4().compose(new THREE.Vector3((a.x0+a.x1)/2,p.y,(a.z0+a.z1)/2),q,new THREE.Vector3(a.x1-a.x0,s.y,a.z1-a.z0));replacements.push({matrix,role:'solid'});}fixed++;}accepted.push(...parts);
 }
 if(replacements.length){const extra=new THREE.InstancedMesh(mesh.geometry,mesh.material,replacements.length);extra.name='detail-box';extra.castShadow=mesh.castShadow;extra.receiveShadow=mesh.receiveShadow;extra.userData.walkRoles=replacements.map(r=>r.role);replacements.forEach((r,i)=>extra.setMatrixAt(i,r.matrix));extra.computeBoundingBox();extra.computeBoundingSphere();mesh.parent.add(extra);}mesh.instanceMatrix.needsUpdate=true;mesh.computeBoundingBox();mesh.computeBoundingSphere();
 });group.userData.overlappingSurfacesRemoved=fixed;
}
