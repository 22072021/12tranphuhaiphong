export {createCollisionWorld,createWalker,walkingEntry} from './walk-physics.js';
export {createNPCDialogue} from './npc-dialogue.js';
export {createCampusGround} from './campus-ground.js';
// Both visit and review use this same current geometry entrypoint.
export {createBuildingGroup} from './building-geometry.js';
export {createCampusFeatures,decorateSigns,campusFeatureKey} from './site-features.js';
export {buildingBaseProfile} from './building-bases.js';
export function watchModelRevision(onChange){
 // Visitor sessions keep their loaded world. Fetch metadata once only; no timer,
 // visibility recheck or cross-tab update can replace the active map.
 if(location.hostname==='12tranphu.mango.pro.vn'){
  let stopped=false,previous=null,pending=null;const badge=document.createElement('span');badge.id='live-model-version';badge.style.cssText='position:fixed;right:8px;bottom:3px;z-index:30;background:#f7f6efc9;color:#385747;padding:2px 5px;border-radius:4px;font:10px system-ui;pointer-events:none';document.body.append(badge);
  const show=next=>{badge.textContent=Number.isSafeInteger(next.version)?'Phiên bản '+next.version:'Phiên bản hiện tại';document.documentElement.dataset.modelRevision=next.revision;if(next.version)document.documentElement.dataset.releaseVersion=next.version;};
  const request=async()=>{const r=await fetch('/api/model-revision',{cache:'no-store'});if(!r.ok)throw Error('Không tải được bản đồ mới');return r.json();};
  const initial=request().then(next=>{if(!stopped){previous=next;show(next);}return next;}).catch(()=>{badge.textContent='Phiên bản hiện tại';return null;});
  const stop=()=>{stopped=true;badge.remove();};
  stop.refresh=()=>{if(pending)return pending;pending=(async()=>{await initial;if(stopped)return false;const next=await request();if(!previous)throw Error('Chưa xác định được phiên bản đang dùng. Vui lòng thử lại.');const changed=next.revision!==previous.revision;if(changed){badge.textContent='Đang cập nhật bản đồ…';await onChange(next,previous);}previous=next;show(next);return changed;})().finally(()=>{pending=null;});return pending;};
  return stop;
 }
 let previous=null,busy=false,stopped=false,timer;const fast=/review|editor|compare/.test(location.pathname),period=fast?10000:75000,key='nktp-model-manifest-v2';
 const badge=document.createElement('span');badge.id='live-model-version';badge.style.cssText='position:fixed;right:8px;bottom:3px;z-index:30;background:#f7f6efc9;color:#385747;padding:2px 5px;border-radius:4px;font:10px system-ui;pointer-events:none';document.body.append(badge);
 const channel=typeof BroadcastChannel!=='undefined'?new BroadcastChannel(key):null;
 const accept=async next=>{if(stopped)return;if(previous&&next.revision!==previous.revision){badge.textContent='Đang cập nhật mô hình…';await onChange(next,previous);}previous=next;badge.textContent='Mô hình · '+next.revision.slice(0,7);document.documentElement.dataset.modelRevision=next.revision;};
 const check=async()=>{if(busy||stopped||document.hidden)return;busy=true;try{let record;try{record=JSON.parse(localStorage.getItem(key));}catch{}if(record?.next&&Date.now()-record.at<period){await accept(record.next);return;}const r=await fetch('/api/model-revision',{cache:'default'});if(!r.ok)return;const next=await r.json();try{localStorage.setItem(key,JSON.stringify({at:Date.now(),next}));}catch{}channel?.postMessage(next);await accept(next);}catch{badge.textContent='Chưa kiểm tra được bản mới';}finally{busy=false;clearTimeout(timer);if(!stopped)timer=setTimeout(check,period*(.9+Math.random()*.2));}};
 if(channel)channel.onmessage=async e=>{if(!busy&&!stopped){busy=true;try{await accept(e.data);}finally{busy=false;}}};
 check();document.addEventListener('visibilitychange',check);return()=>{stopped=true;clearTimeout(timer);channel?.close();document.removeEventListener('visibilitychange',check);badge.remove();};
}
