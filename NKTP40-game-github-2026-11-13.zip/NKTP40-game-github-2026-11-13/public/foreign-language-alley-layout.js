import {ENTRANCE} from './entrance-layout.js';
// Owner's block counts, not a cadastral measurement. The existing frontage module is 4.2 m.
export const LANGUAGE_ALLEY={id:'NGO-49-TRAN-PHU',houseUnit:4.2,streetBlocks:20,housesPerSide:40,width:4.2,startX:ENTRANCE.x,noodleZ:-28.76111111111111,entryZ:-28.76111111111111-20*4.2,depth:40*4.2};
export const ALLEY_STREET_END=LANGUAGE_ALLEY.entryZ-8;
// Overlap the old street domain by more than a capsule diameter, avoiding an invisible seam.
export const GAME_CAFE={firstBay:11,bays:2,width:8.4,depth:8.4};
export const GAME_CAFE_2={firstBay:7,bays:2,width:8.4,depth:9.8};
export const ALLEY_VISIT_ROOMS=[{firstBay:17,bays:2,depth:4.8,side:1},{...GAME_CAFE,side:-1},{...GAME_CAFE_2,side:1}];
export function insideLanguageAlley(x,z,r=0){const a=LANGUAGE_ALLEY;const road=x-r>=ENTRANCE.x-12&&x+r<=ENTRANCE.x-.04&&z-r>=ALLEY_STREET_END&&z+r<=-32;const alley=x-r>=ENTRANCE.x-12&&x+r<=a.startX+a.depth-.14&&z-r>=a.entryZ-a.width/2&&z+r<=a.entryZ+a.width/2;const rooms=ALLEY_VISIT_ROOMS.some(room=>{const lo=a.startX+room.firstBay*a.houseUnit+.18,hi=a.startX+(room.firstBay+room.bays)*a.houseUnit-.18,edge=a.entryZ+room.side*a.width/2,back=edge+room.side*(room.depth-.18);return x-r>=lo&&x+r<=hi&&z-r>=Math.min(edge-room.side*.5,back)&&z+r<=Math.max(edge-room.side*.5,back);});return road||alley||rooms;}

// Historical frontier retained for layout references; the alley is now open to all players.
export const LANGUAGE_ALLEY_PUBLIC=true;
export const LANGUAGE_PUBLIC_FRONTIER=LANGUAGE_ALLEY.noodleZ-LANGUAGE_ALLEY.houseUnit;
export function isLanguageAlleyRestricted(x,z,r=0){return !LANGUAGE_ALLEY_PUBLIC&&insideLanguageAlley(x,z,0)&&z-r<LANGUAGE_PUBLIC_FRONTIER;}
