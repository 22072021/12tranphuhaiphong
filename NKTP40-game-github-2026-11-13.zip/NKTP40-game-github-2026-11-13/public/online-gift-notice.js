import * as T from './vendor/three.module.js';
import {gateNow} from './main-gate-schedule.js';
import {ONLINE_GIFT} from './online-gift-plan.js';

export function createOnlineGiftNotice(container,{now=gateNow,plan=ONLINE_GIFT}={}){
 const el=document.createElement('div');el.className='online-gift-notice';el.dataset.photoExclude='true';el.hidden=true;
 el.style.cssText='position:absolute;z-index:9;pointer-events:none;transform:translate(-50%,-100%);width:max-content;max-width:90%;text-align:center;color:white;font:650 clamp(13px,2vw,24px)/1.45 system-ui;text-shadow:0 2px 4px #163d32,0 0 8px #163d32';
 const title=document.createElement('div'),count=document.createElement('div');title.textContent='Admin khao cả nhà: Tặng 40k cho mỗi người đang online vào lúc 21:00';count.style.fontSize='85%';el.append(title,count);container.append(el);
 let a1=null,second=-1;const projected=new T.Vector3();
 return{bind(layout){a1=layout?.buildings.find(b=>b.id==='A1');},update(camera,state){const time=now();el.hidden=true;if(!a1||time>=plan.at||!state)return;const seconds=Math.ceil((plan.at-time)/1000);if(seconds!==second){second=seconds;count.textContent='Còn '+String(Math.floor(seconds/3600)).padStart(2,'0')+':'+String(Math.floor(seconds%3600/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');}projected.set(a1.x-20,7,a1.z).project(camera);if(projected.z< -1||projected.z>1||Math.abs(projected.x)>1.2||Math.abs(projected.y)>1.2)return;el.hidden=false;el.style.left=(projected.x+1)*container.clientWidth/2+'px';el.style.top=(1-projected.y)*container.clientHeight/2+'px';},dispose(){el.remove();}};
}
