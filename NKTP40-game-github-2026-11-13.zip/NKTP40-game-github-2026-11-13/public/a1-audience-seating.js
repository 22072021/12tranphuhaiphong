import * as T from './vendor/three.module.js';
import {createSquarePlasticStool,SQUARE_PLASTIC_STOOL,PLASTIC_STOOL_SCALE} from './furniture/plastic-square-stool.js';

// Approved near silhouette; spatial instancing and distant tessellation reduce mobile work.
export function createA1AudienceSeating(layout){
 const root=new T.Group();root.name='A1-480-audience-stools';
 const a=layout.buildings.find(b=>b.id==='A1');if(!a)return root;
 function baked(detail){const prototype=createSquarePlasticStool({detail});prototype.updateMatrixWorld(true);const positions=[],normals=[];prototype.traverse(o=>{if(!o.isMesh)return;const geo=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone();geo.applyMatrix4(o.matrixWorld);positions.push(...geo.attributes.position.array);normals.push(...geo.attributes.normal.array);geo.dispose();o.geometry.dispose();o.material.dispose();});const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(positions,3));geo.setAttribute('normal',new T.Float32BufferAttribute(normals,3));geo.computeBoundingSphere();return geo;}
 const geometry=baked('full'),distant=baked('distant'),chunks=new Map();
 const blockers=new T.InstancedMesh(new T.BoxGeometry(.44*PLASTIC_STOOL_SCALE,.396*PLASTIC_STOOL_SCALE,.44*PLASTIC_STOOL_SCALE),new T.MeshBasicMaterial({visible:false}),480);blockers.name='audience-stool-colliders';blockers.userData.walkRole='barrier';blockers.userData.walkRoles=Array(480).fill('barrier');root.add(blockers);
 const chairs=[],matrix=new T.Matrix4(),rotation=new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),Math.PI/2);
 for(let row=0;row<20;row++)for(let col=0;col<24;col++){
  // Leave the central pair slot empty along the entire seating block.
  const localPair=Math.floor(col/2),pair=localPair+(localPair>=6?1:0),color=pair%2?'blue':'red';
  const x=a.x-11.2-row*.92,z=a.z+(pair-6)*1.65+(col%2? .3:-.3),y=.025;
  const chunkKey=Math.floor(row/5)+','+Math.floor(col/6)+','+color;if(!chunks.has(chunkKey))chunks.set(chunkKey,{color,points:[]});chunks.get(chunkKey).points.push({x,y,z});
  matrix.makeTranslation(x,y+.198*PLASTIC_STOOL_SCALE,z);blockers.setMatrixAt(chairs.length,matrix);
  const seat=new T.Group();seat.name=`A1-audience-${row+1}-${col+1}`;seat.position.set(x,y,z);seat.rotation.y=Math.PI/2;
  seat.userData.seatLanes=[{kind:'plastic',centered:true,xmin:-.185*PLASTIC_STOOL_SCALE,xmax:.185*PLASTIC_STOOL_SCALE,z:0,end:1,height:.396*PLASTIC_STOOL_SCALE,size:.37*PLASTIC_STOOL_SCALE}];root.add(seat);
  chairs.push({row:row+1,column:col+1,pair:pair+1,color,x,y,z});
 }
 for(const [key,chunk]of chunks){const center=new T.Vector3();for(const p of chunk.points)center.add(new T.Vector3(p.x,p.y,p.z));center.divideScalar(chunk.points.length);const lod=new T.LOD();lod.name='audience-lod-'+key;lod.position.copy(center);for(const [geo,distance]of [[geometry,0],[distant,14]]){const mesh=new T.InstancedMesh(geo,new T.MeshStandardMaterial({color:SQUARE_PLASTIC_STOOL.colors[chunk.color],roughness:.46}),chunk.points.length);mesh.name='audience-stools-'+chunk.color;mesh.castShadow=mesh.receiveShadow=true;mesh.userData.walkRole='none';for(let i=0;i<chunk.points.length;i++){const p=chunk.points[i];matrix.compose(new T.Vector3(p.x-center.x,p.y-center.y,p.z-center.z),rotation,new T.Vector3(1,1,1));mesh.setMatrixAt(i,matrix);}mesh.computeBoundingSphere();lod.addLevel(mesh,distance,.12);}lod.levels[1].object.visible=false;root.add(lod);}
 root.userData={chairs,count:480,rows:20,columns:24,rowColumns:Array(20).fill(24),aisleClearance:1.05,rowPitch:.92,facing:'A1-stage',assetId:SQUARE_PLASTIC_STOOL.id};return root;
}
