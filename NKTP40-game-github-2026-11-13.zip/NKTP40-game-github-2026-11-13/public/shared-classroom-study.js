import * as THREE from './vendor/three.module.js';
import {createClassroomInteriors} from './classroom-template.js?v=223.0';
import {geometryKit} from './geometry-kit.js?v=222.0';
import {makeOpeningWall} from './wall-openings.js?v=222.0';
import {createSchoolWindow} from './openings/school-window.js?v=222.0';
import {createStairDoor} from './interactive-door.js?v=222.0';
// Same forty-seat furniture used in the campus; the room/floor of this photo is unknown.
export function createSharedClassroomStudy(){
 const g=new THREE.Group();g.name='shared-classroom-photo-study';g.userData.study=true;
 g.add(createClassroomInteriors([{xmin:-3.6,xmax:3.6,zmin:-4.2,zmax:4.2,doorU:3,level:.02,clearHeight:3.55,buildingId:'MẪU',roomIndex:0,floor:1,side:-1,teacherDesk:{x:2.82,z:3,supportHeight:.18}}]));
 const k=geometryKit(g);for(const z of [-4.32,4.32])k.box(7.5,3.75,.18,0,1.875,z,'#e7d7aa');k.finish();
 for(const side of [-1,1]){const holes=[{kind:'window',u:-2.3,y:1.8,width:1.70,height:1.65},{kind:'window',u:0,y:1.8,width:1.70,height:1.65},side===-1?{kind:'door',u:3,y:1.36,width:1.16,height:2.72}:{kind:'window',u:3,y:1.8,width:1.16,height:1.65}];makeOpeningWall(g,{side,wallX:3.8,faceV:0,from:-4.4,to:4.4,height:3.75,color:'#e7d7aa',openings:holes});for(const o of holes)g.add(o.kind==='window'?createSchoolWindow({side,wallX:3.8,u:o.u,y:o.y,width:o.width,height:o.height,open:true}):createStairDoor({side,wallX:3.8,u:o.u,y:o.y,width:o.width,height:o.height,color:'#346454',glazed:true}));}
 return g;
}
