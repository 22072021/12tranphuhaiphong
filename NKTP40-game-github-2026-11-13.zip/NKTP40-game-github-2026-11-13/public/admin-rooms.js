import {createAdministrationAuditorium} from './admin-auditorium.js?v=222.0';
import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
import {makeOpeningWall} from './wall-openings.js?v=222.0';
import {createStairDoor} from './interactive-door.js?v=222.0';
// Side openings and simple room finishes requested by the owner; dimensions are estimates.
export function createAdministrationRooms(b,p){
 const root=new THREE.Group();root.name='admin-room-interiors';const roomLo=Math.min(p.u(1/7),p.u(5/7)),roomHi=Math.max(p.u(1/7),p.u(5/7)),doorX=p.w-p.corridor-.90,doorW=1.45,doorH=2.75,windowX=-1.10,windowW=3.10,windowH=1.85;
 for(const wallU of [roomLo,roomHi]){
  const panel=new THREE.Group();panel.name=wallU===roomHi?'admin-room-left-side':'admin-room-right-side';panel.rotation.y=Math.PI/2;root.add(panel);const side=-Math.sign(wallU),wallX=Math.abs(wallU),holes=[];
  for(let f=0;f<b.floors;f++){holes.push({u:doorX,y:f*p.step+doorH/2,width:doorW,height:doorH,kind:'door'});holes.push({u:windowX,y:f*p.step+1.72,width:windowW,height:windowH,kind:'window'});}
  const shell=makeOpeningWall(panel,{side,wallX,faceV:0,from:-p.w+.22,to:p.w-p.corridor,height:b.height,color:'#f0ede3',openings:holes,profile:{height:b.height,storey:p.step,weatheringScale:.12}});shell.name='admin-side-opening-wall';
  const k=geometryKit(panel),wood='#665246',x=side*(wallX+.01);
  for(let f=0;f<b.floors;f++){
   const level=f*p.step,door=createStairDoor({side,wallX,u:doorX,y:level+doorH/2,v:0,width:doorW,height:doorH,color:wood,glazed:true});door.userData.role='admin-side-door';door.userData.floor=f+1;panel.add(door);
   for(const u of [doorX-doorW/2,doorX+doorW/2])k.box(.16,doorH+.06,.065,x,level+doorH/2,u,wood);k.box(.16,.07,doorW+.12,x,level+doorH,doorX,wood);k.box(.22,.020,doorW+.10,x,level+.010,doorX,'#aaa18e');
   const y=level+1.72;
   for(const u of [windowX-windowW/2,windowX+windowW/2])k.box(.15,windowH+.08,.065,x,y,u,wood);for(const yy of [y-windowH/2,y+windowH/2])k.box(.16,.07,windowW+.12,x,yy,windowX,wood);
   k.box(.025,windowH-.04,windowW-.04,side*(wallX-.045),y,windowX,'#3d5550');for(const t of [-.25,0,.25])k.box(.07,windowH,.045,x,y,windowX+t*windowW,wood);for(const yy of [y-.30,y+.45])k.box(.07,.045,windowW,x,yy,windowX,wood);
   const ix=side*(wallX-.17);for(const u of [windowX-windowW/2,windowX,windowX+windowW/2])k.box(.08,windowH+.08,.065,ix,y,u,wood);for(const yy of [y-windowH/2,y-.30,y+.45,y+windowH/2])k.box(.08,.055,windowW+.10,ix,yy,windowX,wood);for(const t of [-.25,.25])k.box(.08,windowH,.045,ix,y,windowX+t*windowW,wood);for(const a of [-1,1])k.box(.035,.11,.035,ix-side*.055,y-.08,windowX+a*.09,'#b9b7a3');
  }k.finish();panel.userData={wallU,doors:3,windows:3,doorX,windowX};
 }
 const xmin=-p.w+.25,xmax=p.w-p.corridor-.24,zmin=roomLo+.15,zmax=roomHi-.15,cx=(xmin+xmax)/2,cz=(zmin+zmax)/2;
 for(let f=0;f<b.floors;f++){
  const room=new THREE.Group();room.name='admin-room-floor-'+(f+1);room.userData={floor:f+1,oneLargeRoom:true,estimatedInterior:true};root.add(room);const k=geometryKit(room),y=f*p.step,ceilingSlab=f===b.floors-1?p.structure.roofSlab:p.structure.floorSlab;
  k.box(xmax-xmin,.018,zmax-zmin,cx,y+.009,cz,'#b8b1a0');
  // Tile joints lie below the walking tolerance and do not obstruct movement.
  for(let x=xmin+.6;x<xmax;x+=.6)k.box(.008,.002,zmax-zmin,x,y+.019,cz,'#979487');for(let z=zmin+.6;z<zmax;z+=.6)k.box(xmax-xmin,.002,.008,cx,y+.019,z,'#979487');
  k.box(xmax-xmin,.018,zmax-zmin,cx,y+p.step-ceilingSlab-.014,cz,'#e2dfd2');k.box(.055,.15,zmax-zmin,xmin+.025,y+.075,cz,'#8f8a7b');
  for(const x of [cx-(xmax-xmin)*.28,cx+(xmax-xmin)*.28])for(const z of [cz-3.6,cz,cz+3.6]){
   const light=new THREE.Mesh(new THREE.BoxGeometry(1.15,.045,.22),new THREE.MeshStandardMaterial({color:'#ebe5cc',emissive:'#e0d9bd',emissiveIntensity:.65,roughness:.7}));light.position.set(x,y+p.step-ceilingSlab-.05,z);light.name='admin-ceiling-light';light.userData.walkRole='none';room.add(light);
  }k.finish();
  if(f<b.floors){
   const words='Chưa bao giờ bị gọi vào đây nên không có chút tư liệu nào';
   const note=new THREE.Mesh(new THREE.PlaneGeometry(7.2,1.95),new THREE.MeshBasicMaterial({color:'#56453c',transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1}));
   note.name='admin-author-memory-floor-'+(f+1);note.position.set(-p.w+.228,y+2.30,cz);note.rotation.y=Math.PI/2;
   note.userData={signText:words,signLines:['Chưa bao giờ bị gọi vào đây','nên không có chút tư liệu nào'],signAuthor:'Tác giả',transparentSign:true,textColor:'#56453c',walkRole:'none',source:'owner-authored-memory',floor:f+1};room.add(note);
  }
 }
 root.add(createAdministrationAuditorium(p));
 root.userData={sideDoors:6,sideWindows:6,rooms:3,source:'owner-request',estimated:true};return root;
}
