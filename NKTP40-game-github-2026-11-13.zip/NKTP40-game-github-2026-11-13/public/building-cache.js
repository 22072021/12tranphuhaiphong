// Keep unchanged THREE groups and GPU resources when editing a different building.
export function disposeObject(root){const geometries=new Set(),materials=new Set(),textures=new Set();root.userData.disposed=true;root.traverse(o=>{if(o.isSkinnedMesh)o.skeleton?.dispose();if(o.isInstancedMesh)o.dispose();if(o.geometry)geometries.add(o.geometry);for(const m of Array.isArray(o.material)?o.material:[o.material])if(m){materials.add(m);for(const v of Object.values(m))if(v?.isTexture)textures.add(v);}});for(const t of textures)if(!t.userData?.shared)t.dispose();for(const g of geometries)if(!g.userData?.shared)g.dispose();for(const m of materials)if(!m.userData?.shared)m.dispose();}
export function geometryKey(b,selected=false){return JSON.stringify([selected,Object.keys(b).sort().filter(k=>!['x','z','rotation','note'].includes(k)).map(k=>[k,b[k]])]);}
export function createBuildingCache(container,{create,decorate=()=>{},dispose=disposeObject}){
 const records=new Map();
 function update(buildings,selected=null){const stats={created:[],removed:[],reused:[],moved:[]},wanted=new Set(buildings.map(b=>b.id));
  for(const [id,r]of records)if(!wanted.has(id)){container.remove(r.object);dispose(r.object);records.delete(id);stats.removed.push(id);}
  for(const b of buildings){const key=geometryKey(b,selected===b.id),transform=JSON.stringify([b.x,b.z,b.rotation]);let r=records.get(b.id);
   if(r?.key===key){stats.reused.push(b.id);if(r.transform!==transform){r.object.position.x=b.x;r.object.position.z=b.z;r.object.rotation.y=-b.rotation*Math.PI/180;r.object.updateMatrixWorld(true);r.transform=transform;stats.moved.push(b.id);}continue;}
   const object=create(b,selected===b.id);decorate(object,b);if(r){container.remove(r.object);dispose(r.object);}container.add(object);records.set(b.id,{key,transform,object});stats.created.push(b.id);
  }return stats;
 }
 return{invalidate(ids){for(const id of ids){const r=records.get(id);if(r)r.key=null;}},update,get:id=>records.get(id)?.object,dispose(){for(const r of records.values()){container.remove(r.object);dispose(r.object);}records.clear();}};
}
