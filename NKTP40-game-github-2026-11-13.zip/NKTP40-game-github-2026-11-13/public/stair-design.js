import {drawStoneStep,drawStoneLanding,STAIR_STONE,STUDENT_STAIR_STONE,AGED_A2_STONE} from './stair-stone.js?v=218.0';
import * as THREE from './vendor/three.module.js';
import {buildingBaseProfile} from './building-bases.js?v=247.0';
import {FACADE_PROFILES} from './facade-profile.js?v=217.0';

export const CLASSROOM_STAIR_TEMPLATE=Object.freeze({gap:.18,maxRise:.18,tread:.27,landingDepth:1.20,topology:'right-first-full-bay-switchback'});
export function classroomStairPlan(b){
 const q=buildingBaseProfile(b),w=b.width/2,step=b.height/b.floors,corridor=Math.min(2.25,b.width*.22),p=FACADE_PROFILES[b.id];
 const span=b.id==='B1'&&Number.isFinite(b.stairCoreWidth)?b.stairCoreWidth:p?b.length*p.coreSpan:Math.min(4,b.length*.13),center=p?-q.side*(p.coreCentre-.5)*b.length:0;
 const gap=CLASSROOM_STAIR_TEMPLATE.gap,width=(span-gap)/2,offset=(width+gap)/2,first=-q.side,front=q.side*(w-corridor-.85),levels=Array.from({length:b.floors+(b.id==='B1'?1:0)},(_,f)=>f*step+(f?(b.id==='B1'?(f===b.floors?.21:.02):.18):0));
 const flights=[],landings=[];const addLanding=(x,z,sx,sz,y)=>landings.push({x,z,sx,sz,y});
 for(const y of levels)addLanding(q.side*(w+(w-corridor-.85))/2,center,corridor+.85,span,y);
 for(let f=0;f<levels.length-1;f++){
  const half=(levels[f+1]-levels[f])/2,count=Math.ceil(half/CLASSROOM_STAIR_TEMPLATE.maxRise),initialRun=Math.min(count*CLASSROOM_STAIR_TEMPLATE.tread,b.width-corridor-2.5),initialLandingDepth=Math.abs(-q.side*(w+.04)-(front-q.side*initialRun)),run=initialRun+(['A2','B2'].includes(b.id)?initialLandingDepth*.20:0),rear=front-q.side*run,mid=levels[f]+half;
  flights.push({from:{x:front,z:center+first*offset,y:levels[f]},to:{x:rear,z:center+first*offset,y:mid},width,count,floor:f});
  flights.push({from:{x:rear,z:center-first*offset,y:mid},to:{x:front,z:center-first*offset,y:levels[f+1]},width,count,floor:f});
  // Extend the half-storey turn continuously to the rear wall/screen, rather
  // than leaving the fixed 1.20m slab floating inside the stair well.
  const rearBoundary=-q.side*(w+.04),landingDepth=Math.abs(rearBoundary-rear);
  addLanding((rear+rearBoundary)/2,center,landingDepth,span,mid);
 }
 const entryU=['A2','B2'].includes(b.id)?flights[0].from.z:b.id==='B1'?flights[0].from.z:b.id==='B2'?flights[0].from.z:flights[0]?.from.z??center;
 return{center,span,width,gap,first,front,entryU,levels,flights,landings,templateId:CLASSROOM_STAIR_TEMPLATE.topology,estimated:true};
}
export function drawStairUnderSlab(k,from,to,width,color='#c4b394'){
 const points=[];for(const z of [from.z-width/2,from.z+width/2])for(const [x,y] of [[from.x,from.y-.12],[to.x,to.y-.12],[to.x,to.y-.28],[from.x,from.y-.28]])points.push([x,y,z]);
 const v=[];for(const face of [[0,1,2],[0,2,3],[4,6,5],[4,7,6],[0,4,5],[0,5,1],[3,2,6],[3,6,7]])for(const i of face)v.push(...points[i]);
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(v,3));geo.computeVertexNormals();k.withCollision('none',()=>k.curved(geo,color,'stair-stringer'));
}
export function stairGuard(k,from,to,color='#66594d'){
 for(const h of [.46,.95])k.beam(new THREE.Vector3(from.x,from.y+h,from.z),new THREE.Vector3(to.x,to.y+h,to.z),.045,color);
 const count=Math.max(1,Math.ceil(Math.hypot(to.x-from.x,to.z-from.z)/.65));for(let j=0;j<=count;j++){const t=j/count;k.box(.04,.95,.04,from.x+(to.x-from.x)*t,from.y+(to.y-from.y)*t+.475,from.z+(to.z-from.z)*t,color);}
}
// Concrete A1 rail: a continuous rounded sweep with rounded ends and joints.
function concreteHandrail(k,points){
 const path=new THREE.CurvePath();for(let i=1;i<points.length;i++)path.add(new THREE.LineCurve3(points[i-1],points[i]));
 k.withCollision('none',()=>{k.curved(new THREE.TubeGeometry(path,Math.max(32,points.length*16),.085,12,false),'#c9bd9f','A1-continuous-concrete-handrail');for(const p of points){const sphere=new THREE.SphereGeometry(.085,12,8);sphere.translate(p.x,p.y,p.z);k.curved(sphere,'#c9bd9f','A1-concrete-handrail-rounded-joint');}});
}
function concretePanel(k,from,to,z){
 const shape=new THREE.Shape();shape.moveTo(from.x,from.y-.10);shape.lineTo(to.x,to.y-.10);shape.lineTo(to.x,to.y+.92);shape.lineTo(from.x,from.y+.92);shape.closePath();const geo=new THREE.ExtrudeGeometry(shape,{depth:.16,bevelEnabled:false});geo.translate(0,0,z-.08);k.withCollision('none',()=>k.curved(geo,'#c9bd9f','A1-solid-concrete-balustrade'));
}
function concreteGuard(k,from,to){
 concreteHandrail(k,[new THREE.Vector3(from.x,from.y+.95,from.z),new THREE.Vector3(to.x,to.y+.95,to.z)]);
 const len=Math.hypot(to.x-from.x,to.z-from.z);if(len>.001){const a=Math.atan2(to.x-from.x,to.z-from.z);k.withCollision('barrier',()=>k.box(.16,.91,len,(from.x+to.x)/2,(from.y+to.y)/2+.455,(from.z+to.z)/2,'#c9bd9f',0,a,0));}
}
function a2GranitoGuard(k,from,to){
 const stone='#b77d80',iron='#c6ad69',len=Math.hypot(to.x-from.x,to.z-from.z),n=Math.max(1,Math.ceil(len/.14));
 (k.a2Rails||=[]).push([from,to]);
 for(let j=0;j<=n;j++){const t=j/n,x=from.x+(to.x-from.x)*t,y=from.y+(to.y-from.y)*t,z=from.z+(to.z-from.z)*t,main=j===0||j===n;if(main){const key=[x,y,z].map(v=>v.toFixed(5)).join(',');const posts=k.a2Posts||=new Set();if(posts.has(key))continue;posts.add(key);}k.box(main?.18:.022,.87,main?.18:.022,x,y+.435,z,main?stone:iron);}
}
export function drawClassroomStairs(k,b){
 const p=classroomStairPlan(b),rail='#66594d',finish=['A1','A2','B1','B2'].includes(b.id)?STUDENT_STAIR_STONE:STAIR_STONE;
 // The plinth already has the finished ground floor; draw stone only on elevated landings.
 for(const a of p.landings)if(a.y>1e-5){if((['A2','B2'].includes(b.id)||b.id==='B1')&&p.levels.includes(a.y))k.box(a.sx,.16,a.sz,a.x,a.y-.08,a.z,'#bb9271');else drawStoneLanding(k,{x:a.x,y:a.y,z:a.z,width:a.sx,depth:a.sz,finish});}
 for(let f=1;f<p.levels.length;f++){
  const openings=[];const low=p.flights[0].from.z,high=p.flights[1].to.z;if(f<p.levels.length-1)openings.push([low-p.width/2,low+p.width/2]);
  openings.push([high-p.width/2,high+p.width/2]);openings.sort((a,b)=>a[0]-b[0]);
  let z=p.center-p.span/2;for(const [lo,hi]of [...openings,[p.center+p.span/2,p.center+p.span/2]]){if(lo-z>.05)((b.id==='A1'||b.id==='B1')?concreteGuard:['A2','B2'].includes(b.id)?a2GranitoGuard:stairGuard)(k,{x:p.front,y:p.levels[f],z},{x:p.front,y:p.levels[f],z:lo});z=Math.max(z,hi);}
 }
 for(const a of p.flights){const dx=a.to.x-a.from.x;
  for(let j=0;j<a.count;j++){const t=(j+.5)/a.count,y=a.from.y+(a.to.y-a.from.y)*(j+1)/a.count;drawStoneStep(k,{x:a.from.x+dx*t,y,z:a.from.z,width:a.width,depth:Math.abs(dx)/a.count+.006,finish});}
  // A rendered sloping stringer joins the undersides of the solid treads.
  drawStairUnderSlab(k,a.from,a.to,a.width);
  for(const side of [-1,1]){const z=a.from.z+side*a.width/2;if(['A2','B2'].includes(b.id)){if(side===-Math.sign(a.from.z-p.center))a2GranitoGuard(k,{...a.from,z},{...a.to,z});continue;}if((b.id==='A1'||b.id==='B1')){concretePanel(k,a.from,a.to,z);for(let n=0;n<a.count;n++){const t=(n+.5)/a.count,yy=a.from.y+(a.to.y-a.from.y)*t;k.withCollision('barrier',()=>k.box(Math.abs(dx)/a.count+.01,.94,.12,a.from.x+dx*t,yy+.41,z,'#c9bd9f'));}}if((b.id!=='A1'&&b.id!=='B1'))k.beam(new THREE.Vector3(a.from.x,a.from.y+.95,z),new THREE.Vector3(a.to.x,a.to.y+.95,z),.055,rail);for(let j=0;j<=a.count;j+=2){const t=j/a.count,y=a.from.y+(a.to.y-a.from.y)*t;k.box((b.id==='A1'||b.id==='B1')?.10:.04,.95,(b.id==='A1'||b.id==='B1')?.10:.04,a.from.x+dx*t,y+.475,z,(b.id==='A1'||b.id==='B1')?'#c9bd9f':rail);}}
 }
 if((b.id==='A1'||b.id==='B1'))for(const flight of p.flights)for(const sign of [-1,1]){const z=flight.from.z+sign*flight.width/2;concreteHandrail(k,[new THREE.Vector3(flight.from.x,flight.from.y+.95,z),new THREE.Vector3(flight.to.x,flight.to.y+.95,z)]);}
 // Rear wall/screen encloses the landing. Keep only the two side guards;
 // a transverse guard at the old slab edge would fence off the new floor.
 for(const a of p.landings.filter(a=>!['A2','B2'].includes(b.id)&&!p.levels.includes(a.y)))for(const sign of [-1,1])((b.id==='A1'||b.id==='B1')?concreteGuard:['A2','B2'].includes(b.id)?a2GranitoGuard:stairGuard)(k,{x:a.x-a.sx/2,y:a.y,z:a.z+sign*a.sz/2},{x:a.x+a.sx/2,y:a.y,z:a.z+sign*a.sz/2},rail);
 if(['A2','B2'].includes(b.id))for(let i=0;i<p.flights.length;i+=2){const a=p.flights[i],b=p.flights[i+1];const z0=a.to.z-Math.sign(a.to.z-p.center)*a.width/2,z1=b.from.z-Math.sign(b.from.z-p.center)*b.width/2;a2GranitoGuard(k,{x:a.to.x,y:a.to.y,z:z0},{x:a.to.x,y:a.to.y,z:z1});}
 if(['A2','B2'].includes(b.id))drawA2ContinuousCaps(k);
 return p;
}

// Shared endpoint topology gives every turn one mitered cap, no overlapping
// extended boxes or decorative balls. The path is open at stair entrances.
function drawA2ContinuousCaps(k){
 const segments=k.a2Rails||[],nodes=new Map(),edges=[];
 const key=p=>[p.x,p.y,p.z].map(v=>v.toFixed(5)).join(',');
 for(const [a,b] of segments){for(const p of [a,b])if(!nodes.has(key(p)))nodes.set(key(p),{p,edges:[]});const e={a:key(a),b:key(b),used:false};edges.push(e);nodes.get(e.a).edges.push(e);nodes.get(e.b).edges.push(e);}
 for(const seed of edges){if(seed.used)continue;let root=[seed.a,seed.b].find(v=>nodes.get(v).edges.length===1)||seed.a;
 // Find the open end of this connected component first.
 const seen=new Set(),queue=[root];while(queue.length){const v=queue.pop();if(seen.has(v))continue;seen.add(v);if(nodes.get(v).edges.length===1)root=v;for(const e of nodes.get(v).edges)queue.push(e.a===v?e.b:e.a);}
 const path=[];let at=root;while(true){path.push(nodes.get(at).p);const e=nodes.get(at).edges.find(e=>!e.used);if(!e)break;e.used=true;at=e.a===at?e.b:e.a;}
 const sides=path.map((p,i)=>{const prev=path[Math.max(0,i-1)],next=path[Math.min(path.length-1,i+1)],dir=(a,b)=>new THREE.Vector2(b.x-a.x,b.z-a.z).normalize(),a=i?dir(prev,p):dir(p,next),b=i<path.length-1?dir(p,next):a,n1=new THREE.Vector2(-a.y,a.x),n2=new THREE.Vector2(-b.y,b.x),m=n1.clone().add(n2).normalize(),d=.09/Math.max(.3,m.dot(n1));return [1,-1].map(sign=>({x:p.x+sign*m.x*d,z:p.z+sign*m.y*d,y:p.y}));});
 const verts=[],tri=(a,b,c)=>verts.push(...a,...b,...c),v=(i,side,top)=>{const p=sides[i][side];return[p.x,p.y+(top?1.05:.87),p.z];};
 for(let i=0;i<path.length-1;i++){for(const [a,b,c,d] of [[v(i,0,1),v(i+1,0,1),v(i+1,1,1),v(i,1,1)],[v(i,1,0),v(i+1,1,0),v(i+1,0,0),v(i,0,0)],[v(i,0,0),v(i+1,0,0),v(i+1,0,1),v(i,0,1)],[v(i,1,1),v(i+1,1,1),v(i+1,1,0),v(i,1,0)]]){tri(a,b,c);tri(a,c,d);}}
 for(const i of [0,path.length-1]){tri(v(i,0,0),v(i,0,1),v(i,1,1));tri(v(i,0,0),v(i,1,1),v(i,1,0));}
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));geo.computeVertexNormals();k.withCollision('none',()=>k.curved(geo,'#b77d80','A2-continuous-mitered-granito-cap'));
 }
 delete k.a2Rails;delete k.a2Posts;
}
