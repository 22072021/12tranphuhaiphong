// Reduce rendering resolution only after sustained load; recover gradually.
export function createAdaptiveQuality({initial=1.5,min=0.75,max=1.5,windowMs=4000,cooldownMs=8000}={}){
 let ratio=Math.min(max,Math.max(min,initial)),elapsed=0,frames=0,cooldown=0;
 return {sample(dt){if(!Number.isFinite(dt)||dt<=0||dt>1){elapsed=0;frames=0;return null;}elapsed+=dt;frames++;cooldown=Math.max(0,cooldown-dt*1000);if(elapsed*1000<windowMs)return null;const fps=frames/elapsed;elapsed=0;frames=0;if(cooldown>0)return null;let next=ratio;if(fps<27)next=Math.max(min,ratio-.15);else if(fps>53)next=Math.min(max,ratio+.10);next=Math.round(next*100)/100;if(next===ratio)return null;ratio=next;cooldown=cooldownMs;return ratio;},get ratio(){return ratio;},reset(){elapsed=0;frames=0;cooldown=0;}};
}
