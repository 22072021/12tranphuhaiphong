import * as T from './vendor/three.module.js';
export const BOARD_STATS_LABELS=['Lớp','Sĩ số:','Vắng:'];
let fontReady;
function loadFont(){return fontReady??=(async()=>{const font=new FontFace('School Chalk Handwriting',`url(${new URL('./assets/fonts/DancingScript.ttf',import.meta.url).href})`,{weight:'400'});await font.load();document.fonts.add(font);})();}
// Half the previous physical lettering height; the blank right-hand area remains writable.
export function addBoardStats(parent,cache,{width,height=1.32,x=0,y=0,z=0,end=-1}){
 if(typeof document==='undefined')return null;
 let material=cache.get('handwritten-board-stats');
 if(!material){const canvas=document.createElement('canvas');canvas.width=768;canvas.height=512;const ctx=canvas.getContext('2d'),texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;
  const draw=()=>{ctx.clearRect(0,0,768,512);ctx.fillStyle='#eeefdf';ctx.font='400 85px "School Chalk Handwriting", cursive';ctx.textBaseline='middle';BOARD_STATS_LABELS.forEach((line,i)=>ctx.fillText(line,24,90+i*137));texture.needsUpdate=true;window.dispatchEvent(new Event('nktp-texture-ready'));};
  loadFont().then(draw).catch(draw);material=new T.MeshBasicMaterial({map:texture,transparent:true,depthWrite:false});cache.set('handwritten-board-stats',material);
 }
 const blockWidth=Math.min(.50,width*.25),blockHeight=.32,margin=.025;
 const mesh=new T.Mesh(new T.PlaneGeometry(blockWidth,blockHeight),material);
 mesh.name='classroom-board-statistics';mesh.position.set(x-end*(width/2-margin-blockWidth/2),y+height/2-margin-blockHeight/2,z-end*.035);mesh.rotation.y=end>0?Math.PI:0;
 mesh.userData={walkRole:'none',labels:BOARD_STATS_LABELS,font:'Dancing Script',scaleOfPrevious:.5,corner:'top-right',writingSpace:true};parent.add(mesh);return mesh;
}
