import * as THREE from './vendor/three.module.js';
import {createGlassPane} from './openings/glass.js?v=49.0';
// Fixed stainless-steel clerestory: two columns, three rows of real glazing.
export function drawHallSideWindows(parent,{bodyMin,bodyWidth,bays,l,sideH,linkX}){
 const g=new THREE.Group();g.name='hall-inox-clerestory';parent.add(g);
 const material=new THREE.MeshStandardMaterial({color:'#bcc3c5',metalness:.78,roughness:.27});
 const frames=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),material,bays*2*7);frames.count=0;frames.name='hall-stainless-window-frames';frames.castShadow=true;frames.receiveShadow=true;g.add(frames);
 const add=(w,h,d,x,y,z)=>{const m=new THREE.Matrix4().makeScale(w,h,d);m.setPosition(x,y,z);frames.setMatrixAt(frames.count++,m);};
 const batches=[];const width=.96,bar=.027;
 for(const end of [-1,1])for(let j=0;j<bays;j++){
  const x=bodyMin+(j+.5)*bodyWidth/bays,overLink=false,height=overLink?.40:1.90,cy=overLink?sideH-.35:sideH-1.30,z=end*(l+.012);
  for(const s of [-1,1])add(bar,height,.045,x+s*(width-bar)/2,cy,z);
  add(bar,height-2*bar,.045,x,cy,z);
  for(let row=0;row<=3;row++)add(width-2*bar,bar,.045,x,cy-height/2+bar/2+row*(height-bar)/3,z);
  const chunk=(end===-1?0:2)+Math.floor(j/6);if(!batches[chunk]){batches[chunk]=new THREE.Group();batches[chunk].rotation.y=Math.PI/2;g.add(batches[chunk]);}
  const paneW=(width-3*bar)/2,paneH=(height-4*bar)/3;
  for(let row=0;row<3;row++)for(let col=0;col<2;col++)createGlassPane(batches[chunk],{x:-z,y:cy-height/2+bar+paneH/2+row*(paneH+bar),z:x-width/2+bar+paneW/2+col*(paneW+bar),width:paneW,height:paneH,depth:.008,name:'hall-side-six-pane-glazing'});
 }
 frames.instanceMatrix.needsUpdate=true;frames.computeBoundingBox();frames.computeBoundingSphere();g.userData={windows:2*bays,panesPerWindow:6,width,frameWidth:bar,finish:'stainless-steel',grid:[2,3]};return g;
}
