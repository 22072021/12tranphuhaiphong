// Ephemeral shared pairing rules; no profile data or persistent storage.
export function benchPairEffect(male,female){
 const year=value=>{let s=String(value??'');if(/^\d{2}$/.test(s))s=(Number(s)>=86?'19':'20')+s;return /^\d{4}$/.test(s)&&+s>=1986&&+s<=2026?+s:null;};
 const m=year(male?.year),f=year(female?.year);return m!==null&&f!==null&&f<m?'plane':'heart';
}
export function createBenchPairs({delay=15000,random=Math.random}={}){
 const pairs=new Map();let serial=0;
 return{update(players,now){players=players.filter(p=>p.role!=='teacher');const byId=new Map(players.map(p=>[p.id,p])),used=new Set();
  for(const[key,pair]of pairs){const a=byId.get(pair.ids[0]),b=byId.get(pair.ids[1]);if(!a?.seated||!b?.seated||a.bench!==b.bench||a.bench!==pair.bench||a.gender===b.gender||pair.genders!==a.gender+':'+b.gender){pairs.delete(key);continue;}used.add(a.id);used.add(b.id);}
  const benches=new Set(players.filter(p=>p.seated&&p.bench).map(p=>p.bench));for(const bench of benches){const free=players.filter(p=>p.seated&&p.bench===bench&&!used.has(p.id)),men=free.filter(p=>p.gender==='male'),women=free.filter(p=>p.gender==='female');for(let i=women.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[women[i],women[j]]=[women[j],women[i]];}for(let i=0;i<Math.min(men.length,women.length);i++){const a=men[i],b=women[i];pairs.set(++serial,{ids:[a.id,b.id],bench,genders:a.gender+':'+b.gender,since:now});}}
  return [...pairs.values()].map(p=>({...p,effect:benchPairEffect(byId.get(p.ids[0]),byId.get(p.ids[1])),readyAt:p.since+delay,active:now-p.since>=delay}));
 }};
}
