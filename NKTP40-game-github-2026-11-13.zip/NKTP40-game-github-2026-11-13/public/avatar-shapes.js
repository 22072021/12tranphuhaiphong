import * as THREE from './vendor/three.module.js';
// Smooth elliptical loft: one connected surface, rather than stacked capsules.
export function softAvatarForm(profile,{segments=32,rings=28,fold=0}={}){
 profile=profile.slice().sort((a,b)=>a[0]-b[0]);
 const curve=new THREE.CatmullRomCurve3(profile.map(([y,x,z])=>new THREE.Vector3(x,y,z)),false,'centripetal'),p=[],uv=[],index=[];
 for(let r=0;r<=rings;r++){const q=curve.getPoint(r/rings);for(let j=0;j<=segments;j++){const t=j/segments*Math.PI*2,pleat=1+fold*Math.cos(t*10);p.push(Math.sin(t)*q.x*pleat,q.y,Math.cos(t)*q.z*pleat);uv.push(j/segments,r/rings);}}
 for(let r=0;r<rings;r++)for(let j=0;j<segments;j++){const a=r*(segments+1)+j,b=a+segments+1;index.push(a,a+1,b,b,a+1,b+1);}
 // Seal the two ends to avoid gaps at wrists, collars and shoulders.
 for(const r of [0,rings]){const base=r*(segments+1),center=p.length/3;p.push(0,p[base*3+1],0);uv.push(.5,r/rings);for(let j=0;j<segments;j++)r===0?index.push(center,base+j+1,base+j):index.push(center,base+j,base+j+1);}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(index);g.computeVertexNormals();return g;
}
