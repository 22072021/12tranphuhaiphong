import {ENTRANCE} from './entrance-layout.js';
import * as T from './vendor/three.module.js';
export const NPC_LINES=Object.freeze({'npc-to':'uống gì nào?','npc-noodle':'Ăn bún hay bánh đa?','npc-khuyen':'Sao đi muộn thế.','notice-teacher':'Đứa nào sáng nay không nộp bài đứng vào đây, ngày mai họp phụ huynh khẩn cấp'});
export function noodleRearDialogue(npc,state){if(npc.name!=='npc-noodle'||state.x<=ENTRANCE.x)return false;const p=npc.worldToLocal(new T.Vector3(state.x,state.feet,state.z));return p.z<-.25;}
export function createNPCDialogue(container){
 const bubble=document.createElement('div'),line=document.createElement('div');bubble.className='npc-dialogue';bubble.setAttribute('role','status');bubble.hidden=true;
 Object.assign(bubble.style,{position:'absolute',zIndex:'8',pointerEvents:'none',width:'max-content',maxWidth:'230px',boxSizing:'border-box',overflowWrap:'normal',flexShrink:'0',padding:'10px 14px',borderRadius:'16px',background:'rgba(255,255,249,.92)',color:'#243f35',boxShadow:'0 3px 15px #0002',border:'1px solid #fff9',textAlign:'center',transform:'translate(-50%,-100%)',font:'16px/1.4 system-ui,sans-serif'});bubble.append(line);container.append(bubble);
 let previousRoot,npcs=[],gateSide=0,guardLine=null;const point=new T.Vector3(),from=new T.Vector3();
 function update(root,state,camera,world){
  if(root!==previousRoot){previousRoot=root;npcs=[];root?.traverse(o=>{if(o.userData.npc&&(o.userData.dialogue||NPC_LINES[o.name]))npcs.push(o);});}
  if(!state||!root?.visible){bubble.hidden=true;return;}
  const gate=root.getObjectByName('interactive-school-gate');if(gate){gate.getWorldPosition(point);const side=state.x<point.x-.65?-1:state.x>point.x+.65?1:0;if(side&&Math.abs(state.z-point.z)<7){if(gateSide&&side!==gateSide)guardLine=side>0?'Sao đi muộn thế.':'Đi đâu đấy?';gateSide=side;}}
  let selected=null,best=6.0;
  for(const npc of npcs){npc.getWorldPosition(point);const distance=Math.hypot(point.x-state.x,point.z-state.z);if(distance>=best||Math.abs(point.y-state.feet)>.6)continue;point.y+=1.15;from.set(state.x,state.feet+1.15,state.z);point.lerp(from,Math.min(1,.40/Math.max(distance,.01))); if(!noodleRearDialogue(npc,state)&&world?.sweepCamera&&world.sweepCamera(from,point,.03).distanceToSquared(point)>.0025)continue;selected=npc;best=distance;}
  if(!selected){bubble.hidden=true;return;}
  selected.getWorldPosition(point);point.y+=selected.name==='npc-khuyen'?1.85:1.65;point.project(camera);if(point.z<-1||point.z>1){bubble.hidden=true;return;}
  const w=container.clientWidth,h=container.clientHeight;line.textContent=selected.name==='npc-khuyen'?(guardLine||(gateSide<0?'Sao đi muộn thế.':'Đi đâu đấy?')):(noodleRearDialogue(selected,state)?'Ăn bát bao nhiêu cô làm cho':selected.userData.dialogue||NPC_LINES[selected.name]);bubble.hidden=false;bubble.style.left=((point.x+1)/2*w)+'px';bubble.style.top=((1-point.y)/2*h)+'px';
 }
 return{update,dispose(){bubble.remove();}};
}
