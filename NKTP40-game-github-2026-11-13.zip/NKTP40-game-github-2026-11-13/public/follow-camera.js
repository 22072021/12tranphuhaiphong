import * as THREE from './vendor/three.module.js';

export function createFollowCamera(camera){
 let distance=3.4,boom=distance,ready=false,lowerSpaceReduction=0;const pivot=new THREE.Vector3(),desired=new THREE.Vector3(),smooth=new THREE.Vector3(),focus=new THREE.Vector3(),feetPoint=new THREE.Vector3();
 return{setFraming(reduction=0){lowerSpaceReduction=THREE.MathUtils.clamp(reduction,0,.4);camera.updateProjectionMatrix();},reset(){ready=false;boom=distance;},zoom(delta){distance=THREE.MathUtils.clamp(distance+delta*.003,1.6,6);},update(dt,state,yaw,pitch,world,visualFeet=state.feet){
  pivot.set(state.x,visualFeet+(state.seated?1.15:.972),state.z);const elevation=THREE.MathUtils.clamp(.30-pitch,.10,1.12),ce=Math.cos(elevation);
  desired.copy(pivot).add(new THREE.Vector3(Math.sin(yaw)*ce,Math.sin(elevation),Math.cos(yaw)*ce).multiplyScalar(distance));
  let safe=desired.clone(),safeDistance=pivot.distanceTo(safe);const cramped=safeDistance<distance*.72;
  // Keep user yaw and lens stable in corridors: collision changes distance only.
  const portraitFov=THREE.MathUtils.radToDeg(2*Math.atan(Math.tan(THREE.MathUtils.degToRad(29))/Math.max(.65,camera.aspect))),targetFov=Math.min(82,Math.max(58,portraitFov));if(Math.abs(camera.fov-targetFov)>.01){camera.fov=targetFov;camera.updateProjectionMatrix();}
  boom=safeDistance<boom?safeDistance:THREE.MathUtils.lerp(boom,safeDistance,1-Math.exp(-5*dt));
  desired.subVectors(safe,pivot);if(desired.lengthSq()>.00001)desired.setLength(boom);desired.add(pivot);
  if(!ready||state.bicyclePassenger){smooth.copy(desired);focus.copy(pivot);ready=true;}else{smooth.lerp(desired,1-Math.exp(-9*dt));focus.lerp(pivot,1-Math.exp(-13*dt));}
  // Recheck the smoothed boom too, so orbiting around a corner cannot cut through it.
  camera.position.copy(smooth);camera.up.set(0,1,0);camera.lookAt(focus);
  if(pitch>.20){const t=THREE.MathUtils.smoothstep(pitch,.20,.60),upward=new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.min(pitch,Math.PI/2),yaw,0,'YXZ'));camera.quaternion.slerp(upward,t);}
  if(lowerSpaceReduction){
   // Shift framing only: retain yaw, lens, boom and obstruction handling.
   // Remove the previous frame's bias before measuring visible space below feet.
   camera.projectionMatrix.elements[9]=0;camera.updateMatrixWorld(true);
   feetPoint.set(state.x,visualFeet,state.z).project(camera);
   camera.projectionMatrix.elements[9]=THREE.MathUtils.clamp(lowerSpaceReduction*(feetPoint.y+1),0,.4);
   camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert();
  }
  return{distance:pivot.distanceTo(camera.position),opacity:THREE.MathUtils.clamp((pivot.distanceTo(camera.position)-.32)/.60,.10,1)};
 }};
}
