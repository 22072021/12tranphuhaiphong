import * as THREE from './vendor/three.module.js';
// White blouse, navy-edged collar, ribbon bow and sleeve piping from user photos.
export function createFemaleUniform(torso,mesh,shirt,navy){
 const g=new THREE.Group();g.name='female-tran-phu-uniform';torso.add(g);
 for(const sign of [-1,1]){
  const pts=[[0,.507],[sign*.063,.516],[sign*.120,.453],[sign*.075,.410],[sign*.020,.462]],shape=new THREE.Shape();pts.forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();const geo=new THREE.ExtrudeGeometry(shape,{depth:.006,bevelEnabled:true,bevelSize:.002,bevelThickness:.001,bevelSegments:2});mesh(g,geo,shirt,0,0,.103);
  const edge=new THREE.CatmullRomCurve3(pts.slice(1,4).map(([x,y])=>new THREE.Vector3(x,y,.112)));mesh(g,new THREE.TubeGeometry(edge,20,.0035,6,false),navy);
  const loop=new THREE.CatmullRomCurve3([new THREE.Vector3(0,.425,.119),new THREE.Vector3(sign*.040,.389,.132),new THREE.Vector3(sign*.044,.326,.135),new THREE.Vector3(sign*.017,.333,.135),new THREE.Vector3(0,.425,.119)]);mesh(g,new THREE.TubeGeometry(loop,32,.0055,8,false),navy);
  const ribbon=mesh(g,new THREE.BoxGeometry(.012,.17,.006),navy,sign*.010,.328,.125);ribbon.rotation.z=sign*.045;
 }
 mesh(g,new THREE.SphereGeometry(.011,12,10),navy,0,.424,.126);
 return g;
}
export function createSleevePiping(arm,mesh,navy){const curve=new THREE.CatmullRomCurve3(Array.from({length:33},(_,i)=>{const t=i/32*Math.PI*2;return new THREE.Vector3(Math.sin(t)*.044,-.184,Math.cos(t)*.044);}),true);const pipe=mesh(arm,new THREE.TubeGeometry(curve,32,.0028,6,true),navy);pipe.name='female-navy-sleeve-piping';return pipe;}
