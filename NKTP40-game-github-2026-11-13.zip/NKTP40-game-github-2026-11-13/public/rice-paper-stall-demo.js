import * as T from './vendor/three.module.js';
import {createCampusNPC} from './campus-npcs.js';
import {createSquarePlasticStool} from './furniture/plastic-square-stool.js';
export function createRicePaperStall(){
 const g=new T.Group();g.name='rice-paper-cart-demo';
 const mat=(color,extra={})=>new T.MeshStandardMaterial({color,roughness:.8,...extra}),blue=mat('#147aa7'),frame=mat('#354d51',{metalness:.5}),steel=mat('#afb9b7',{metalness:.65,roughness:.35}),red=mat('#c42d35'),cream=mat('#eee7cb');
 function mesh(geo,m,x,y,z,parent=g){const o=new T.Mesh(geo,m);o.position.set(x,y,z);parent.add(o);return o;}
 const box=(w,h,d,x,y,z,m,p=g)=>mesh(new T.BoxGeometry(w,h,d),m,x,y,z,p);
 function rod(a,b,r=.012,m=frame,parent=g){const d=new T.Vector3().subVectors(b,a),o=mesh(new T.CylinderGeometry(r,r,d.length(),8),m,0,0,0,parent);o.position.copy(a).add(b).multiplyScalar(.5);o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),d.normalize());return o;}
 function label(text,w,h,bg,lines=1){const c=document.createElement('canvas');c.width=1024;c.height=Math.round(1024*h/w);const ctx=c.getContext('2d');if(bg){ctx.fillStyle=bg;ctx.fillRect(0,0,c.width,c.height);}ctx.fillStyle='#f8f4dd';ctx.textAlign='center';ctx.textBaseline='middle';const rows=text.split('\n'),size=Math.min(125,c.height/(rows.length+ .5));ctx.font=`800 ${size}px Arial,sans-serif`;rows.forEach((r,i)=>ctx.fillText(r,c.width/2,c.height*(i+.5)/rows.length,c.width*.93));const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;t.anisotropy=4;return new T.MeshBasicMaterial({map:t,transparent:!bg,side:T.DoubleSide});}
 // Blue weathered cart with metal worktop and two spoked wheels.
 box(1.30,.69,.68,0,.60,0,blue);box(1.34,.035,.72,0,.965,0,steel);
 mesh(new T.PlaneGeometry(1.26,.62),label('BÁNH TRÁNG TRỘN\nKHÔ · NƯỚC\nBẮC SANH  SÀI GÒN',1.26,.62,'#147aa7'),0,.60,.347);
 for(const x of [-.56,.56]){const wheel=mesh(new T.TorusGeometry(.16,.025,8,32),mat('#524c42'),x,.18,.24);const hub=mesh(new T.CylinderGeometry(.035,.035,.07,12),steel,x,.18,.24);hub.rotation.x=Math.PI/2;for(let i=0;i<8;i++){const a=i*Math.PI/4;rod(new T.Vector3(x,.18,.24),new T.Vector3(x+Math.cos(a)*.143,.18+Math.sin(a)*.143,.24),.006,steel);} }
 // Four tall thin uprights support green/white striped pitched canvas.
 for(const x of [-.65,.65])for(const z of [-.33,.33])rod(new T.Vector3(x,.92,z),new T.Vector3(x,2.13,z));
 const roofWidth=1.93,roofDepth=1.18;for(let i=0;i<22;i++){const x=-roofWidth/2+(i+.5)*roofWidth/22,m=mat(i%2?'#d3d9c2':'#608e7a',{side:T.DoubleSide});for(const side of [-1,1]){const panel=box(roofWidth/22+.001,.012,roofDepth/2,x,2.17,side*roofDepth/4,m);panel.rotation.x=side*.13;}for(const side of [-1,1]){const flap=box(roofWidth/22+.001,.15,.012,x,2.055,side*roofDepth/2,m);flap.rotation.x=side*.2;}}
 for(const z of [-.34,.34])rod(new T.Vector3(-.74,2.13,z),new T.Vector3(.74,2.13,z));
 function basket(x,z,color,w=.35,d=.27){const b=new T.Group();b.position.set(x,.99,z);g.add(b);const m=mat(color);box(w,.012,d,0,0,0,m,b);for(const sign of [-1,1]){box(w,.018,.018,0,.115,sign*d/2,m,b);box(.018,.018,d,sign*w/2,.115,0,m,b);for(let i=0;i<12;i++)box(.007,.11,.009,-w/2+i*w/11,.057,sign*d/2,m,b);for(let i=0;i<8;i++)box(.009,.11,.007,sign*w/2,.057,-d/2+i*d/7,m,b);}return b;}
 basket(-.40,.12,'#d33134');basket(.03,.13,'#d58d9e');basket(-.37,-.18,'#68ac46',.29,.23);
 for(let i=0;i<35;i++){const strip=box(.035,.004,.008,-.46+(i%7)*.026,1.11+Math.floor(i/7)*.003,-.22+((i*3)%7)*.014,mat(i%3?'#e4d590':'#6e9c49'));strip.rotation.y=i*.8;}
 for(let i=0;i<25;i++){const food=mesh(new T.SphereGeometry(.012,6,4),mat('#a24429'),-.08+(i%6)*.035,1.08+Math.floor(i/6)*.01,.04+((i*3)%6)*.03);}
 const bucket=mesh(new T.CylinderGeometry(.145,.12,.28,24,1,true),cream,.43,1.105,.05);mesh(new T.CircleGeometry(.137,24),mat('#ede1a4'),.43,1.23,.05).rotation.x=-Math.PI/2;rod(new T.Vector3(.43,1.16,.05),new T.Vector3(.54,1.50,-.02),.012,cream);
 for(const [x,z]of [[-.04,-.20],[.16,-.23]]){mesh(new T.CylinderGeometry(.042,.045,.16,16),mat('#bc6634',{transparent:true,opacity:.8}),x,1.06,z);mesh(new T.CylinderGeometry(.048,.048,.017,16),red,x,1.15,z);}
 // Small glass display on a separate blue plastic table.
 const tx=-1.02;box(.55,.035,.55,tx,.53,.02,blue);for(const x of [tx-.22,tx+.22])for(const z of [-.2,.24])box(.035,.52,.035,x,.26,z,blue);
 const glass=mat('#cee9df',{transparent:true,opacity:.17,depthWrite:false,side:T.DoubleSide});for(const x of [tx-.23,tx+.23])for(const z of [-.18,.22])box(.018,.56,.018,x,.83,z,steel);for(const y of [.55,1.10])box(.50,.018,.43,tx,y,.02,steel);box(.46,.52,.007,tx,.83,.226,glass);for(const x of [tx-.23,tx+.23])box(.007,.52,.40,x,.83,.02,glass);
 mesh(new T.PlaneGeometry(.44,.26),label('BÁNH TRÁNG TRỘN\nSÀI GÒN',.44,.26,null),tx,.91,.232);box(.34,.09,.30,tx,.61,.02,mat('#dce0c2'));for(let i=0;i<8;i++)box(.04,.003,.27,tx-.14+i*.04,.69,.02,mat(i%2?'#e4dca3':'#c3c487'));
 const stool=createSquarePlasticStool({color:'#a93038',height:.34,size:.39});stool.position.set(-1.05,0,.85);delete stool.userData.seatLanes;g.add(stool);mesh(new T.CylinderGeometry(.20,.18,.36,28),red,-1.05,.53,.85);mesh(new T.CylinderGeometry(.215,.215,.025,28),red,-1.05,.72,.85);mesh(new T.PlaneGeometry(.30,.21),label('SÂM LẠNH',.30,.21,null),-1.05,.54,1.045);
 // Vendor kept in same established low-poly style, behind the worktop.
 const seller=createCampusNPC({id:'rice-paper',name:'Bác Sanh',female:true});seller.position.set(.08,0,-.65);seller.userData.dialogue='Ăn thử bánh tráng của bác đi ngon lắm!';g.add(seller);g.userData.textureReady=seller.userData.textureReady?.then(()=>{const torso=seller.getObjectByName('torso');if(!torso)return;box(.32,.36,.22,0,.14,.008,mat('#282c30'),torso);box(.16,.30,.012,0,.14,.124,mat('#3d537c'),torso);for(let i=0;i<14;i++){const flower=mesh(new T.CircleGeometry(.018,6),mat(['#c65296','#e3c24b','#7275a3'][i%3]),-.065+(i%3)*.06,.03+Math.floor(i/3)*.06,.133,torso);}for(const side of ['left','right']){seller.getObjectByName(side+'-shoulder').rotation.x=-.55;seller.getObjectByName(side+'-elbow').rotation.x=-.8;}});
 return g;
}
