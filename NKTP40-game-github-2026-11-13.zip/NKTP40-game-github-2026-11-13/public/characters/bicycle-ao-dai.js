import * as T from '../vendor/three.module.js';
const cached=new WeakMap();
// Fold the front panel around the right hip and lay it behind the saddle.
// Fixed lightweight cloth shape: no cloth simulation or extra network payload.
export function fitBicyclePanels(avatar){
 if(!avatar.root.userData.aoDai)return;
 for(const name of ['ao-dai-front-panel','ao-dai-back-panel']){
  const panel=avatar.root.getObjectByName(name);if(!panel)continue;const geometry=panel.geometry,pos=geometry.attributes.position;let cache=cached.get(geometry);
  if(cache?.version===pos.version)continue;
  if(!cache){const front=name.includes('front');for(let r=0;r<29;r++){
   const f=r/28,turn=T.MathUtils.smoothstep(f,0,.52),tail=T.MathUtils.smoothstep(f,.48,1),angle=front?Math.PI*turn:Math.PI;
   const half=front?T.MathUtils.lerp(1.48,.42,Math.sin(turn*Math.PI)):1.48;
   const rx=T.MathUtils.lerp(.151,.19,T.MathUtils.smoothstep(f,0,.22)),rz=front?T.MathUtils.lerp(.111,.155,turn)+tail*.21:.111+f*.14;
   const y=front?.015+Math.sin(turn*Math.PI)*.060-tail*.205:.015-f*.34;
   for(let c=0;c<17;c++){const u=c/16*2-1,a=angle+u*half,fold=Math.sin(u*Math.PI*3)*.004*f;pos.setXYZ(r*17+c,Math.sin(a)*rx,y+fold,Math.cos(a)*rz);}
  }geometry.computeVertexNormals();geometry.computeBoundingSphere();cache={positions:pos.array.slice(),normals:geometry.attributes.normal.array.slice()};cached.set(geometry,cache);
  }else{pos.array.set(cache.positions);geometry.attributes.normal.array.set(cache.normals);geometry.attributes.normal.needsUpdate=true;geometry.computeBoundingSphere();}
  pos.needsUpdate=true;cache.version=pos.version;
 }
}
