import * as T from '../vendor/three.module.js';
const fitted=new WeakMap();
export function fitSeatedPanels(a,prepare){
 const joints=a.renderJoints||a.joints,parts=[];
 for(const name of ['pelvis','torso','leftHip','rightHip','leftKnee','rightKnee','leftAnkle','rightAnkle']){const j=joints[name];for(const n of [...j.position.toArray(),...j.quaternion.toArray()])parts.push(Math.round(n*100000));}
 const signature=(a.root.getObjectByName('continuous-trousers')?.geometry.uuid||'')+parts.join(',');
 const frontPosition=a.root.getObjectByName('ao-dai-front-panel')?.geometry.attributes.position,last=fitted.get(a);if(last?.signature===signature&&last.version===frontPosition?.version)return false;
 prepare?.();
 const pants=a.root.getObjectByName('continuous-trousers'),torso=(a.renderJoints||a.joints).torso;
 a.root.updateMatrixWorld(true);pants.skeleton.update();
 const inv=new T.Matrix4().copy(torso.matrixWorld).invert(),v=new T.Vector3(),samples=[];
 for(let i=0;i<pants.geometry.attributes.position.count;i++){pants.getVertexPosition(i,v);v.applyMatrix4(pants.matrixWorld).applyMatrix4(inv);samples.push(v.clone());}
 const points=samples.map(q=>[q.z,q.y]).sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
 const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
 const half=pts=>{const h=[];for(const p of pts){while(h.length>1&&cross(h.at(-2),h.at(-1),p)<=0)h.pop();h.push(p);}return h;};
 const hull=[...half(points).slice(0,-1),...half([...points].reverse()).slice(0,-1)];
 function envelope(value,axis){let best=-Infinity;for(let i=0;i<hull.length;i++){const p=hull[i],q=hull[(i+1)%hull.length];if(value<Math.min(p[axis],q[axis])||value>Math.max(p[axis],q[axis]))continue;const t=(value-p[axis])/(q[axis]-p[axis]||1);best=Math.max(best,T.MathUtils.lerp(p[1-axis],q[1-axis],t));}return best;}
 // Follow the continuous outer silhouette from the lap to the hem.
 const top=hull.reduce((best,p,i)=>p[1]>hull[best][1]?i:best,0),bottom=hull.reduce((best,p,i)=>p[1]<hull[best][1]?i:best,0);
 const chain=dir=>{const out=[];for(let i=top,n=0;n<=hull.length;n++,i=(i+dir+hull.length)%hull.length){out.push(hull[i]);if(i===bottom)break;}return out;};
 const paths=[chain(1),chain(-1)],score=path=>path.reduce((s,p)=>s+p[0],0)/path.length;
 let outline=paths.sort((a,b)=>score(b)-score(a))[0].map(([z,y])=>new T.Vector3(0,y+.018,z+.025));
 // Do not extend past the original tunic hem.
 outline=outline.filter(p=>p.y>-.55);outline.push(new T.Vector3(0,-.55,Math.max(.11,envelope(-.55,1))+.025));
 for(let pass=0;pass<2;pass++){const next=[outline[0]];for(let i=0;i<outline.length-1;i++){next.push(outline[i].clone().lerp(outline[i+1],.25),outline[i].clone().lerp(outline[i+1],.75));}next.push(outline.at(-1));outline=next;}
 const length=[0];for(let i=1;i<outline.length;i++)length.push(length.at(-1)+outline[i].distanceTo(outline[i-1]));
 function contour(f){const d=f*length.at(-1);let i=1;while(i<length.length-1&&length[i]<d)i++;return outline[i-1].clone().lerp(outline[i],(d-length[i-1])/(length[i]-length[i-1]||1));}

 for(const name of ['ao-dai-front-panel','ao-dai-back-panel']){
 const panel=a.root.getObjectByName(name);if(!panel)continue;const pos=panel.geometry.attributes.position,front=name.includes('front');
 for(let row=0;row<29;row++){
  const f=row/28,point=front?contour(f):null,y=front?point.y:pos.getY(row*17),z=front?point.z:0;
  let width=.15,depth=.11,sideDepth=Infinity;
  for(const q of samples){if(Math.abs(q.y-y)<(front?.09:.085)){width=Math.max(width,Math.abs(q.x)+(front?0:.025));depth=Math.max(depth,-q.z+.025);sideDepth=Math.min(sideDepth,q.z);}}
  const blend=T.MathUtils.smoothstep(f,.1,.4),newWidth=T.MathUtils.lerp(1,Math.min(1,width/.20),blend);
  const frontWidth=T.MathUtils.lerp(.151,Math.max(.15,width)+.023,T.MathUtils.smoothstep(f,0,.20));
  const side=Number.isFinite(sideDepth)?sideDepth-.015:z-.13,wrap=T.MathUtils.smoothstep(f,.08,.28);
  for(let c=0;c<17;c++){const i=row*17+c;
   if(front){const u=c/16*2-1,edge=T.MathUtils.smoothstep(Math.abs(u),.75,1);pos.setXYZ(i,Math.sign(u)*Math.min(Math.abs(u)/.75,1)*frontWidth,y,z-(z-side)*edge*wrap);}
   else{const x=pos.getX(i),oldZ=pos.getZ(i),newDepth=T.MathUtils.lerp(Math.abs(oldZ),Math.min(Math.abs(oldZ),depth),blend);pos.setXYZ(i,x*newWidth,y,-newDepth);}
  }
 }
 pos.needsUpdate=true;panel.geometry.computeVertexNormals();panel.geometry.computeBoundingSphere();
 }
 fitted.set(a,{signature,version:frontPosition?.version});return true;
}