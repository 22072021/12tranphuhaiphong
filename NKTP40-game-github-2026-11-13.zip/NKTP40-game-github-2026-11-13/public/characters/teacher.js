import {createAoDaiAvatar} from './ao-dai-avatar.js';
import * as T from '../vendor/three.module.js';
import {createStudent} from '../student/student.js';
import {AO_DAI_COLORS} from './teacher-palette.js';
export {AO_DAI_COLORS};
export function createTeacher({gender='male',studentScale=.93,aoDaiColor=AO_DAI_COLORS[0].color}={}){
 if(gender==='female')return createAoDaiAvatar({gender,studentScale:studentScale*1.1,aoDaiColor,closedCollar:true});
 const female=gender==='female',avatar=createStudent({gender,season:'summer',scale:studentScale*1.10}),{root,joints}=avatar,torso=joints.torso;
 root.name=`teacher-${gender}`;
 const cloth=new T.MeshStandardMaterial({color:female?aoDaiColor:'#283348',roughness:.86,side:T.DoubleSide}),black=new T.MeshStandardMaterial({color:'#171a22',roughness:.65}),white=new T.MeshStandardMaterial({color:'#f5f1e7',roughness:.9,side:T.DoubleSide}),skin=new T.MeshStandardMaterial({color:'#F2C69D',roughness:.95}),tie=new T.MeshStandardMaterial({color:'#713747',roughness:.82,side:T.DoubleSide});
 const owned=[];function add(parent,g,m,name,x=0,y=0,z=0){const o=new T.Mesh(g,m);o.name=name;o.position.set(x,y,z);parent.add(o);owned.push(o);return o;}
 torso.children.find(o=>o.name==='torso-surface').visible=false;
 root.traverse(o=>{if(o.name==='original-badge-left-outer-sleeve'||(o.name.endsWith('-elbow-surface')||o.name.endsWith('-shoulder-surface')))o.visible=false;if(o.name.startsWith('continuous-sleeve')||o.name.startsWith('arm-skin-'))o.material=cloth;if(o.name.endsWith('ankle-surface'))o.material=black;});
 function shell(rings){const p=[],idx=[],n=12;for(const[y,w,d]of rings)for(let i=0;i<n;i++){const a=i/n*Math.PI*2;p.push(Math.sin(a)*w,y,Math.cos(a)*d);}for(let r=0;r<rings.length-1;r++)for(let i=0;i<n;i++){const a=r*n+i,b=r*n+(i+1)%n;idx.push(a,b,a+n,b,b+n,a+n);}const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setIndex(idx);g.computeVertexNormals();return g;}
 const shoulderY=joints.leftShoulder.position.y,neckY=joints.head.position.y;
 add(torso,shell([...(female?[]:[[-.035,.14,.096]]),[.07,.142,.10],[shoulderY-.08,.163,.10],[shoulderY,.181,.094],[shoulderY+.028,.15,.084],[neckY-.034,.054,.052]]),cloth,'teacher-fitted-body');
 // Overlap shoulder shells with torso and upper sleeves; neck reaches the jaw.
 for(const side of ['left','right']){const shoulder=joints[side+'Shoulder'];const cap=add(shoulder,new T.SphereGeometry(.069,10,8),cloth,'teacher-connected-shoulder',0,-.026,0);cap.scale.set(1,.95,.95);add(joints[side+'Elbow'],new T.SphereGeometry(.043,12,8),cloth,'teacher-covered-elbow',0,0,0);}
 const neckBottom=neckY-.05,neckTop=neckY+.026;
 add(torso,new T.CylinderGeometry(.045,.049,neckTop-neckBottom,10),skin,'teacher-neck',0,(neckBottom+neckTop)/2,0);
 function patch(points,z,material,name){const shape=new T.Shape();points.forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();return add(torso,new T.ShapeGeometry(shape),material,name,0,0,z);}
 if(female){
  // One skinned sleeve per arm: no separate upper/forearm shells or dark cuffs.
  const skeleton=root.getObjectByName('continuous-trousers').skeleton;
  root.updateMatrixWorld(true);
  root.traverse(o=>{if(o.name.startsWith('continuous-sleeve')||o.name.startsWith('arm-skin-')||o.name==='teacher-covered-elbow'||o.name==='teacher-connected-shoulder')o.visible=false;});
  for(const side of ['left','right']){
   const cap=add(joints[side+'Shoulder'],new T.SphereGeometry(.060,16,10),cloth,'ao-dai-rounded-shoulder',0,.028,0);cap.scale.y=.75;
   const shoulder=joints[side+'Shoulder'],elbow=joints[side+'Elbow'],top=root.worldToLocal(shoulder.getWorldPosition(new T.Vector3())),bend=root.worldToLocal(elbow.getWorldPosition(new T.Vector3())),end=elbow.localToWorld(new T.Vector3(0,-.209,0));root.worldToLocal(end);
   const p=[],indices=[],weights=[],idx=[],segments=24,n=16;
   for(let r=0;r<=segments;r++){const f=r/segments,y=T.MathUtils.lerp(top.y+.028,end.y,f),radius=T.MathUtils.lerp(.059,.039,f),e=T.MathUtils.smoothstep(top.y-y,top.y-bend.y-.075,top.y-bend.y+.075);
    for(let i=0;i<n;i++){const a=i/n*Math.PI*2;p.push(top.x+Math.sin(a)*radius,y,top.z+Math.cos(a)*radius);indices.push(skeleton.bones.indexOf(shoulder),skeleton.bones.indexOf(elbow),0,0);weights.push(1-e,e,0,0);if(r<segments){const k=r*n+i,b=r*n+(i+1)%n;idx.push(k,b,k+n,b,b+n,k+n);}}
   }
   const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('skinIndex',new T.Uint16BufferAttribute(indices,4));g.setAttribute('skinWeight',new T.Float32BufferAttribute(weights,4));g.setIndex(idx);g.computeVertexNormals();const sleeve=new T.SkinnedMesh(g,cloth);sleeve.name='ao-dai-seamless-sleeve-'+side;root.add(sleeve);sleeve.bind(skeleton);sleeve.frustumCulled=false;owned.push(sleeve);
   // Closed court shoe with a slim heel; sole remains on the original foot plane.
   const ankle=joints[side+'Ankle'];for(const o of ankle.children)if(o.isMesh)o.visible=false;
   const shoe=add(ankle,new T.SphereGeometry(1,16,10),black,'teacher-court-shoe',0,-.042,.048);shoe.scale.set(.050,.040,.097);
   add(ankle,new T.BoxGeometry(.032,.065,.035),black,'teacher-high-heel',0,-.052,-.026);
   const sole=add(ankle,new T.SphereGeometry(1,12,8),black,'teacher-shoe-toe-sole',0,-.075,.087);sole.scale.set(.047,.010,.058);
  }
  // Two continuous, curved fabric panels. Deform around the actual posed trousers
  // rather than letting rigid flat sheets cut through the moving knees.
  const panels=[],rows=24,cols=20;
  for(const sign of [-1,1]){
   const g=new T.PlaneGeometry(1,1,cols,rows),panel=add(torso,g,cloth,sign>0?'ao-dai-front-panel':'ao-dai-back-panel');panels.push({panel,sign});
  }
  const pants=root.getObjectByName('continuous-trousers'),v=new T.Vector3();
  avatar.updateGarment=(time=0)=>{
   root.updateMatrixWorld(true);pants.skeleton.update();const samples=[],a=pants.geometry.attributes.position,inv=new T.Matrix4().copy(torso.matrixWorld).invert();
   for(let i=0;i<a.count;i++){pants.getVertexPosition(i,v);v.applyMatrix4(pants.matrixWorld).applyMatrix4(inv);samples.push([v.x,v.y,v.z]);}
   for(const {panel,sign} of panels){const pos=panel.geometry.attributes.position;
    const rings=[];for(let r=0;r<=rows;r++){
     const f=r/rows,y=.07-f*.73;let extent=.17,depth=.125;
     for(const [x,py,z]of samples)if(Math.abs(py-y)<.065){extent=Math.max(extent,Math.abs(x)+.047);depth=Math.max(depth,sign*z+.057);}
     const blend=T.MathUtils.smoothstep(f,0,.08);rings.push({f,y,width:T.MathUtils.lerp(.142,Math.max(.17+f*.045,extent),blend),depth:T.MathUtils.lerp(.10,depth,blend)});}
    // A smooth envelope keeps the fabric outside the knees without hard horizontal folds.
    for(let pass=0;pass<5;pass++)for(let r=1;r<rows;r++){rings[r].depth=Math.max(rings[r].depth,(rings[r-1].depth+rings[r+1].depth)/2);rings[r].width=Math.max(rings[r].width,(rings[r-1].width+rings[r+1].width)/2);}
    for(let r=0;r<=rows;r++){const {f,y,width,depth}=rings[r],sway=Math.sin(time*3.4-f*2.2)*.009*f*f;
     for(let c=0;c<=cols;c++){const u=c/cols*2-1,theta=u*(Math.PI/2-.09*T.MathUtils.smoothstep(f,.18,.30)),round=Math.cos(theta),z=sign*(depth*Math.pow(Math.max(0,round),T.MathUtils.lerp(1,.40,T.MathUtils.smoothstep(f,0,.2)))+.006*f*Math.sin(u*7+time*2)*round);pos.setXYZ(r*(cols+1)+c,Math.sin(theta)*width+sway,y,z);}
    }pos.needsUpdate=true;panel.geometry.computeVertexNormals();panel.geometry.computeBoundingSphere();
   }
  };
  avatar.updateGarment();
  add(torso,new T.CylinderGeometry(.053,.058,.035,12,1,true),cloth,'ao-dai-standing-collar',0,neckY-.035,0);
  root.getObjectByName('continuous-trousers').material=white;
 }else{
  root.getObjectByName('continuous-trousers').material=cloth;
  patch([[-.057,neckY-.029],[.057,neckY-.029],[.068,shoulderY-.014],[0,.15],[-.068,shoulderY-.014]],.105,white,'white-shirt-insert');
  for(const sign of [-1,1]){patch([[sign*.055,neckY-.028],[sign*.12,shoulderY+.003],[sign*.082,shoulderY-.052],[sign*.101,shoulderY-.064],[sign*.015,.17]],.111,cloth,'suit-notched-lapel');patch([[0,neckY-.025],[sign*.049,neckY-.035],[sign*.036,neckY-.077]],.115,white,'shirt-collar');}
  patch([[0,neckY-.050],[.017,neckY-.073],[.010,neckY-.091],[-.010,neckY-.091],[-.017,neckY-.073]],.12,tie,'tie-knot');
  patch([[-.009,neckY-.088],[.009,neckY-.088],[.023,.17],[0,.142],[-.023,.17]],.12,tie,'necktie');
  for(const y of [.085,.035])add(torso,new T.SphereGeometry(.006,6,4),black,'suit-button',.018,y,.104);
  for(const x of [-.092,.092])add(torso,new T.BoxGeometry(.054,.007,.005),cloth,'suit-pocket',x,.085,.101);
 }
 root.userData.teacher=true;root.userData.relativeStudentHeight=1.10;
 const baseUpdate=avatar.update;
 return{...avatar,update(time,mode){baseUpdate(time,mode);avatar.updateGarment?.(time);},setAoDaiColor(color){if(female&&AO_DAI_COLORS.some(c=>c.color===color))cloth.color.set(color);},dispose(){owned.forEach(o=>o.geometry.dispose());for(const m of [cloth,black,white,skin,tie])m.dispose();avatar.dispose();}};
}
