import * as T from '../vendor/three.module.js';
import {createStudent} from '../student/student.js';
import {AO_DAI_COLORS,teacherColor} from '../characters/teacher-palette.js';
export {AO_DAI_COLORS};
export function createAoDaiAvatar({gender='female',studentScale=.93,aoDaiColor='#f5f4f0',closedCollar=false}={}){
 const female=gender==='female',avatar=createStudent({gender,season:'summer',scale:studentScale}),{root,joints}=avatar,torso=joints.torso;
 root.name=closedCollar?'teacher-female':'student-female-ao-dai';
 const cloth=new T.MeshStandardMaterial({color:female?(closedCollar?teacherColor(aoDaiColor):'#f5f4f0'):'#283348',roughness:.86,side:T.DoubleSide}),black=new T.MeshStandardMaterial({color:'#171a22',roughness:.65}),white=new T.MeshStandardMaterial({color:'#f5f1e7',roughness:.9,side:T.DoubleSide}),skin=new T.MeshStandardMaterial({color:'#F2C69D',roughness:.95}),tie=new T.MeshStandardMaterial({color:'#713747',roughness:.82,side:T.DoubleSide});
 const owned=[];function add(parent,g,m,name,x=0,y=0,z=0){const o=new T.Mesh(g,m);o.name=name;o.position.set(x,y,z);parent.add(o);owned.push(o);return o;}
 torso.children.find(o=>o.name==='torso-surface').visible=false;
 root.traverse(o=>{if(o.name==='original-badge-left-outer-sleeve'||(o.name.endsWith('-elbow-surface')||o.name.endsWith('-shoulder-surface')))o.visible=false;if(o.name.startsWith('continuous-sleeve')||o.name.startsWith('arm-skin-'))o.material=cloth;if(o.name.endsWith('ankle-surface'))o.material=black;});
 function shell(rings){
  const curve=new T.CatmullRomCurve3(rings.map(([y,w,d])=>new T.Vector3(w,y,d)),false,'centripetal'),p=[],idx=[],n=24,rows=36;
  for(let r=0;r<=rows;r++){const v=curve.getPoint(r/rows);for(let i=0;i<n;i++){const angle=i/n*Math.PI*2;const front=Math.max(0,Math.cos(angle)),bust=.012*Math.exp(-Math.pow((v.y-(shoulderY-.080))/.060,2))*front*front;p.push(Math.sin(angle)*v.x,v.y,Math.cos(angle)*v.z+bust);}}
  for(let r=0;r<rows;r++)for(let i=0;i<n;i++){const a=r*n+i,b=r*n+(i+1)%n;idx.push(a,b,a+n,b,b+n,a+n);}const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setIndex(idx);g.computeVertexNormals();return g;
 }
 // Establish a neutral bind pose before constructing the replacement sleeves.
 for(const side of ['left','right']){joints[side+'Shoulder'].position.y-=.032;joints[side+'Shoulder'].rotation.set(0,0,0);joints[side+'Elbow'].rotation.set(0,0,0);}
 root.updateMatrixWorld(true);const restSkeleton=root.getObjectByName('continuous-trousers').skeleton;restSkeleton.calculateInverses();root.traverse(o=>{if(o.isSkinnedMesh)o.bind(restSkeleton);});
 const shoulderY=joints.leftShoulder.position.y,neckY=joints.head.position.y;
 add(torso,shell([...(female?[[.015,.151,.111]]:[[-.035,.14,.096]]),[.045,.143,.101],[shoulderY-.095,.158,.102],[shoulderY-.018,.164,.096],[shoulderY+.015,.128,.082],[neckY-.034,.054,.052]]),cloth,'teacher-fitted-body');
 // Overlap shoulder shells with torso and upper sleeves; neck reaches the jaw.
 for(const side of ['left','right']){const shoulder=joints[side+'Shoulder'];const cap=add(shoulder,new T.SphereGeometry(.069,10,8),cloth,'teacher-connected-shoulder',0,-.026,0);cap.scale.set(1,.95,.95);add(joints[side+'Elbow'],new T.SphereGeometry(.043,12,8),cloth,'teacher-covered-elbow',0,0,0);}
 const neckBottom=neckY-.05,neckTop=neckY+.026;
 add(torso,new T.CylinderGeometry(.045,.049,neckTop-neckBottom,10),skin,'teacher-neck',0,(neckBottom+neckTop)/2,0);
 function patch(points,z,material,name){const shape=new T.Shape();points.forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();return add(torso,new T.ShapeGeometry(shape),material,name,0,0,z);}
 if(female){
  // One skinned sleeve per arm: no separate upper/forearm shells or dark cuffs.
  const skeleton=root.getObjectByName('continuous-trousers').skeleton;
  root.updateMatrixWorld(true);
  root.traverse(o=>{if(o.name.startsWith('continuous-sleeve')||o.name.startsWith('arm-skin-')||o.name==='teacher-covered-elbow'||o.name==='teacher-connected-shoulder')o.visible=false;});
  for(const side of ['left','right']){

   const shoulder=joints[side+'Shoulder'],elbow=joints[side+'Elbow'],top=root.worldToLocal(shoulder.getWorldPosition(new T.Vector3())),bend=root.worldToLocal(elbow.getWorldPosition(new T.Vector3())),end=root.getObjectByName(side+'-hand').localToWorld(new T.Vector3(0,.010,0));root.worldToLocal(end);
   const p=[],indices=[],weights=[],idx=[],segments=40,n=24;
   for(let r=0;r<=segments;r++){const f=r/segments,y=f<.12?top.y+.008-(.053-Math.sqrt(Math.max(0,.053*.053-Math.pow(Math.sin(f/.12*Math.PI/2)*.053,2)))):T.MathUtils.lerp(top.y-.045,end.y,(f-.12)/.88),radius=T.MathUtils.lerp(.053,.031,f)+Math.sin(f*Math.PI)*.002,e=T.MathUtils.smoothstep(top.y-y,top.y-bend.y-.075,top.y-bend.y+.075);
    for(let i=0;i<n;i++){const a=i/n*Math.PI*2;const capBlend=1-T.MathUtils.smoothstep(f,0,.14),capRadius=Math.sin(Math.min(1,f/.12)*Math.PI/2);
     p.push(top.x-Math.sign(top.x)*.022*capBlend+Math.sin(a)*radius*capRadius,y,top.z+Math.cos(a)*radius*capRadius);indices.push(skeleton.bones.indexOf(shoulder),skeleton.bones.indexOf(elbow),skeleton.bones.indexOf(torso),0);const torsoW=capBlend*.65;weights.push((1-e)*(1-torsoW),e*(1-torsoW),torsoW,0);if(r<segments){const k=r*n+i,b=r*n+(i+1)%n;idx.push(k,b,k+n,b,b+n,k+n);}}
   }
   const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('skinIndex',new T.Uint16BufferAttribute(indices,4));g.setAttribute('skinWeight',new T.Float32BufferAttribute(weights,4));g.setIndex(idx);g.computeVertexNormals();const sleeve=new T.SkinnedMesh(g,cloth);sleeve.name='ao-dai-seamless-sleeve-'+side;root.add(sleeve);sleeve.bind(skeleton);sleeve.frustumCulled=false;owned.push(sleeve);
   // Closed court shoe with a slim heel; sole remains on the original foot plane.
   const ankle=joints[side+'Ankle'];for(const o of ankle.children)if(o.isMesh)o.visible=false;
   {
   // A shallow shoe cup has a real opening around the visible instep.
   const foot=add(ankle,new T.SphereGeometry(1,14,8),skin,'visible-instep',0,-.032,.036);foot.scale.set(.039,.027,.075);
   const sp=[],si=[],n=32,rings=[[ -.071,.047,.092,.046],[-.048,.050,.096,.047],[-.027,.048,.090,.045],[-.025,.034,.060,.021]];
   for(const [y,w,d,z]of rings)for(let i=0;i<n;i++){const a=i/n*Math.PI*2;sp.push(Math.sin(a)*w,y,Math.cos(a)*d+z);}
   for(let r=0;r<rings.length-1;r++)for(let i=0;i<n;i++){const a=r*n+i,b=r*n+(i+1)%n;si.push(a,b,a+n,b,b+n,a+n);}
   const shoeG=new T.BufferGeometry();shoeG.setAttribute('position',new T.Float32BufferAttribute(sp,3));shoeG.setIndex(si);shoeG.computeVertexNormals();
   add(ankle,shoeG,black,'ballet-shoe-open-rim');
   const sole=add(ankle,new T.SphereGeometry(1,16,8),black,'ballet-flat-sole',0,-.074,.046);sole.scale.set(.048,.009,.093);
   }
  }
  // Two continuous, curved fabric panels. Deform around the actual posed trousers
  // rather than letting rigid flat sheets cut through the moving knees.
  const panels=[],rows=28,cols=16;
  for(const sign of [-1,1]){
   const g=new T.PlaneGeometry(1,1,cols,rows),panel=add(torso,g,cloth,sign>0?'ao-dai-front-panel':'ao-dai-back-panel');panels.push({panel,sign});
  }
  const pants=root.getObjectByName('continuous-trousers'),v=new T.Vector3();
  // Taper only the concealed upper trousers; leave the visible legs and cuffs intact.
  root.updateMatrixWorld(true);const toTorso=new T.Matrix4().copy(torso.matrixWorld).invert().multiply(pants.matrixWorld),toPants=toTorso.clone().invert(),pa=pants.geometry.attributes.position;
  for(let i=0;i<pa.count;i++){v.fromBufferAttribute(pa,i).applyMatrix4(toTorso);const taper=T.MathUtils.smoothstep(v.y,-.28,-.07);v.x*=1-.26*taper;v.z*=1-.22*taper;v.applyMatrix4(toPants);pa.setXYZ(i,v.x,v.y,v.z);}pa.needsUpdate=true;pants.geometry.computeVertexNormals();
  avatar.updateGarment=(time=0)=>{
   root.updateMatrixWorld(true);pants.skeleton.update();const samples=[],a=pants.geometry.attributes.position,inv=new T.Matrix4().copy(torso.matrixWorld).invert();
   for(let i=0;i<a.count;i++){pants.getVertexPosition(i,v);v.applyMatrix4(pants.matrixWorld).applyMatrix4(inv);samples.push([v.x,v.y,v.z]);}
   for(const {panel,sign} of panels){const pos=panel.geometry.attributes.position;
    let fullDepth=.125,fullWidth=.175;for(const [x,y,z] of samples)if(y<.02&&y>-.69){fullDepth=Math.max(fullDepth,sign*z+.045);fullWidth=Math.max(fullWidth,Math.abs(x)+.036);}const rings=[];for(let r=0;r<=rows;r++){
     const f=r/rows,y=.015-f*.565;let extent=.17,depth=.125;
     extent=fullWidth;depth=fullDepth;
     const blend=T.MathUtils.smoothstep(f,0,.35);rings.push({f,y,width:T.MathUtils.lerp(.151,Math.max(.17+f*.045,extent),blend),depth:T.MathUtils.lerp(.111,depth,T.MathUtils.smoothstep(f,0,.60))});}
    // A smooth envelope keeps the fabric outside the knees without hard horizontal folds.
    for(let pass=0;pass<5;pass++)for(let r=1;r<rows;r++){rings[r].depth=Math.max(rings[r].depth,(rings[r-1].depth+rings[r+1].depth)/2);rings[r].width=Math.max(rings[r].width,(rings[r-1].width+rings[r+1].width)/2);}
    for(let r=0;r<=rows;r++){const {f,y,width,depth}=rings[r],sway=Math.sin(time*3.0-f*2.2)*.008*f*f;
     for(let c=0;c<=cols;c++){const u=c/cols*2-1,theta=u*(Math.PI/2-.27*T.MathUtils.smoothstep(f,.06,.28)),round=Math.cos(theta),z=sign*(depth*Math.pow(Math.max(0,round),1)+.003*f*Math.sin(u*7+time*2)*round);pos.setXYZ(r*(cols+1)+c,Math.sin(theta)*width+sway,y,z);}
    }pos.needsUpdate=true;panel.geometry.computeVertexNormals();panel.geometry.computeBoundingSphere();
   }
  };
  avatar.updateGarment();
  // Low standing band, with the centered V opening from the supplied close-up.
  const cp=[],ci=[],n=64,base=neckY-.057;
  for(let layer=0;layer<2;layer++)for(let row=0;row<2;row++)for(let i=0;i<=n;i++){
   const angle=-Math.PI+i/n*Math.PI*2,notch=closedCollar?0:Math.max(0,1-Math.abs(angle)/.30),top=neckY-.007-notch*.047;
   const w=.060-layer*.004,d=.054-layer*.004;
   cp.push(Math.sin(angle)*w,row?top:base,Math.cos(angle)*d);
  }
  for(let layer=0;layer<2;layer++)for(let i=0;i<n;i++){const a=layer*2*(n+1)+i,b=a+1;ci.push(a,b,a+n+1,b,b+n+1,a+n+1);}
  for(let i=0;i<n;i++){const a=n+1+i,b=a+1,c=a+2*(n+1);ci.push(a,c,b,b,c,c+1);}
  const cg=new T.BufferGeometry();cg.setAttribute('position',new T.Float32BufferAttribute(cp,3));cg.setIndex(ci);cg.computeVertexNormals();add(torso,cg,cloth,'low-standing-v-notch-collar');
  root.getObjectByName('continuous-trousers').material=white;
 }else{
  root.getObjectByName('continuous-trousers').material=cloth;
  patch([[-.057,neckY-.029],[.057,neckY-.029],[.068,shoulderY-.014],[0,.15],[-.068,shoulderY-.014]],.105,white,'white-shirt-insert');
  for(const sign of [-1,1]){patch([[sign*.055,neckY-.028],[sign*.12,shoulderY+.003],[sign*.082,shoulderY-.052],[sign*.101,shoulderY-.064],[sign*.015,.17]],.111,cloth,'suit-notched-lapel');patch([[0,neckY-.025],[sign*.049,neckY-.035],[sign*.036,neckY-.077]],.115,white,'shirt-collar');}
  patch([[0,neckY-.050],[.017,neckY-.073],[.010,neckY-.091],[-.010,neckY-.091],[-.017,neckY-.073]],.12,tie,'tie-knot');
  patch([[-.009,neckY-.088],[.009,neckY-.088],[.023,.17],[0,.142],[-.023,.17]],.12,tie,'necktie');
  for(const y of [.085,.035])add(torso,new T.SphereGeometry(.006,6,4),black,'suit-button',.018,y,.104);
  for(const x of [-.092,.092])add(torso,new T.BoxGeometry(.054,.007,.005),cloth,'suit-pocket',x,.085,.101);
 }
 root.userData.teacher=closedCollar;root.userData.aoDai=true;root.userData.relativeStudentHeight=closedCollar?1.1:1.0;
 const baseUpdate=avatar.update;
 return{...avatar,update(time,mode){baseUpdate(time,mode);if(mode==='walk'){for(const side of ['left','right']){joints[side+'Hip'].rotation.x*=.48;joints[side+'Knee'].rotation.x*=.48;const phase=time*6.5+(side==='left'?0:Math.PI);joints[side+'Shoulder'].rotation.x=Math.sin(phase)*.12;joints[side+'Shoulder'].rotation.z=(side==='left'?1:-1)*.045;joints[side+'Elbow'].rotation.x=-.10-Math.max(0,Math.sin(phase))*.07;}}avatar.updateGarment?.(time);},setAoDaiColor(color){if(female&&closedCollar&&AO_DAI_COLORS.some(c=>c.color===color))cloth.color.set(color);},dispose(){owned.forEach(o=>{o.geometry.dispose();if(o.isLine)o.material.dispose();});for(const m of [cloth,black,white,skin,tie])m.dispose();avatar.dispose();}};
}
