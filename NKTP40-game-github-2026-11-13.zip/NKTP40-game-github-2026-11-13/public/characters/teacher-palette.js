export const AO_DAI_COLORS=[{name:'Hồng phấn',color:'#d6a1b2'},{name:'Tím nhạt',color:'#ada0c8'},{name:'Xanh ngọc',color:'#79b4aa'},{name:'Xanh da trời nhạt',color:'#91b5cf'},{name:'Đỏ đô',color:'#82334b'}];
export const teacherColor=value=>AO_DAI_COLORS.some(c=>c.color===value)?value:AO_DAI_COLORS[0].color;
