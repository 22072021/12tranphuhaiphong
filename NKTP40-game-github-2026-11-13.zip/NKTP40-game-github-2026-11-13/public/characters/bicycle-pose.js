import {fitBicyclePanels} from './bicycle-ao-dai.js';
import * as T from '../vendor/three.module.js';
const v=new T.Vector3(),axis=new T.Vector3(),bend=new T.Vector3(),joint=new T.Vector3(),goal=new T.Vector3(),start=new T.Vector3(),local=new T.Vector3(),rotation=new T.Quaternion(),forwardRotation=new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),Math.PI/2);
function aim(bone,child,point){local.copy(point);bone.parent.worldToLocal(local);local.sub(bone.position).normalize();v.copy(child.position).normalize();bone.quaternion.setFromUnitVectors(v,local);bone.updateWorldMatrix(false,true);}
function solve(first,middle,last,end,pole){
 first.getWorldPosition(start);const scale=first.getWorldScale(v).y,L1=middle.position.length()*scale,L2=last.position.length()*scale;
 axis.copy(end).sub(start);const distance=T.MathUtils.clamp(axis.length(),Math.abs(L1-L2)+.001,L1+L2-.001);axis.normalize();goal.copy(start).addScaledVector(axis,distance);const along=(L1*L1-L2*L2+distance*distance)/(2*distance),height=Math.sqrt(Math.max(0,L1*L1-along*along));bend.copy(pole).sub(start).addScaledVector(axis,-bend.copy(pole).sub(start).dot(axis)).normalize();joint.copy(start).addScaledVector(axis,along).addScaledVector(bend,height);aim(first,middle,joint);aim(middle,last,goal);
}
const end=new T.Vector3(),pole=new T.Vector3(),pedal=new T.Vector3(),floor=new T.Vector3(),desired=new T.Quaternion();
export function poseBicycleRider(avatar,vehicle,{stop=0,rear=false}={}){
 const j=avatar.joints,root=avatar.root,S=.86;avatar.update(0,'idle');const scale=root.scale.y;
 const hip=rear?.735:T.MathUtils.lerp(.835,.68,stop),x=rear?-.54*S:T.MathUtils.lerp(-.25*S+.03,-.25*S+.19,stop);
 root.position.set(x,hip-.79*scale,rear?0:-.018*stop);root.rotation.set(0,Math.PI/2,0);j.torso.rotation.x=rear?.12:T.MathUtils.lerp(.50,.25,stop);j.head.rotation.x=rear?-.06:T.MathUtils.lerp(-.22,-.06,stop);root.updateWorldMatrix(true,true);root.updateMatrixWorld(true);
 desired.copy(vehicle.rig.getWorldQuaternion(rotation)).multiply(forwardRotation);
 for(const [i,side]of ['left','right'].entries()){
  const sign=i?1:-1;
  if(rear){end.set(-.55*S,.33*S+.09*scale,sign*.20);vehicle.rig.localToWorld(end);}else{vehicle.bike.bikeMotion.pedals[i].getWorldPosition(pedal);end.copy(pedal);end.y+=.09*scale;const front=new T.Vector3(.038*scale,0,0).applyQuaternion(vehicle.rig.getWorldQuaternion(rotation));end.sub(front);if(!i){floor.set(.06,.09*scale,sign*.23);vehicle.rig.localToWorld(floor);end.lerp(floor,stop);}}
  pole.set(x+.32,.52,sign*.25);vehicle.rig.localToWorld(pole);solve(j[side+'Hip'],j[side+'Knee'],j[side+'Ankle'],end,pole);j[side+'Ankle'].quaternion.copy(j[side+'Ankle'].parent.getWorldQuaternion(rotation)).invert().multiply(desired);root.updateMatrixWorld(true);
  if(rear)end.set(-.18,.93,sign*.12);else end.set((vehicle.mini?.28:.38)*S,.99*S+.025,sign*.25*S);vehicle.rig.localToWorld(end);pole.set(x+.04,1.02,sign*.45);vehicle.rig.localToWorld(pole);const hand=root.getObjectByName(side+'-hand');solve(j[side+'Shoulder'],j[side+'Elbow'],hand,end,pole);
 }
 fitBicyclePanels(avatar);root.updateMatrixWorld(true);
}
