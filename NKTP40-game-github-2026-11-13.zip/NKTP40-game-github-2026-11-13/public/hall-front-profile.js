// R114: front projection proportions from the supplied elevation; dimensions estimated.
export function hallFrontProfile(b){
 const l=b.length/2,level=b.hallLevel??(b.height*.46+.8),half=3.10;
 // Align the finished plaster face (not the projecting ribs) to the top tread seam.
 const terraceEdge=3.10,wallThickness=.20,forwardShift=terraceEdge-wallThickness/2-1.35;
 const cornerStart=l-1.30,cornerWidth=1.30;
 const face=u=>1.35+forwardShift-cornerWidth*Math.max(0,Math.min(1,(Math.abs(u)-cornerStart)/cornerWidth));
 const roof=()=>b.height;
 const canopy=u=>1.48+forwardShift+1.40*Math.sqrt(Math.max(0,1-(u/half)**2));
 return {level,half,face,roof,canopy,forwardShift,terraceEdge,wallThickness,soffit:level-.18,signTop:level+.62,
  ribs:[-2.63,-1.34,0,1.34,2.63],windows:[-3.35,-1.98,1.98,3.35],
  windowWidth:1.04,windowBottom:level+.68,windowTop:b.height-.35,
  outerU:l-.22,outerV:terraceEdge-.21,outerTop:b.height-.42};
}
