import {showIdentityNotice} from './identity-notice.js';
// Load the character editor independently of the 3D module graph.
import {installPlayerMenu} from './player-profile.js';
const visitorOnly=true;
let visitorEntry=null;
if(visitorOnly){
 document.body.classList.add('visitor-only');
 const welcomeScroll=document.getElementById('welcomeScroll'),welcomeButton=document.getElementById('welcomeContinue');
 let welcomeRead=false;
 const welcomeText=document.getElementById('welcomeText');
 const sizeWelcome=()=>{if(!welcomeText)return;const height=welcomeText.getBoundingClientRect().height;if(height>0)welcomeScroll.style.height=Math.max(48,Math.ceil(height)-28)+'px';};
 const checkWelcome=(event)=>{
  if(welcomeScroll.clientHeight<=0)return;
  if(event?.type==='scroll'&&welcomeScroll.scrollTop>0&&welcomeScroll.scrollHeight-welcomeScroll.clientHeight-welcomeScroll.scrollTop<=3)welcomeRead=true;
  welcomeButton.disabled=!welcomeRead;
  welcomeButton.textContent=welcomeRead?'Tiếp tục':'Cuộn xuống để đọc tiếp';
 };
 welcomeScroll.addEventListener('scroll',checkWelcome,{passive:true});
 const welcomeResize=new ResizeObserver(()=>{sizeWelcome();checkWelcome();});welcomeResize.observe(welcomeText);welcomeResize.observe(welcomeScroll);
 const welcomeChanges=new MutationObserver(()=>{sizeWelcome();checkWelcome();});welcomeChanges.observe(welcomeScroll,{childList:true,subtree:true,characterData:true});
 document.fonts.ready.then(()=>{sizeWelcome();checkWelcome();});requestAnimationFrame(()=>{sizeWelcome();checkWelcome();});
 welcomeButton.onclick=()=>{if(!welcomeRead)return;welcomeResize.disconnect();welcomeChanges.disconnect();document.getElementById('entryPanel').classList.remove('welcome-step');document.getElementById('welcomeContent').hidden=true;showIdentityNotice();};
 const isEditable=target=>target instanceof Element&&target.closest('input,textarea,select,[contenteditable="true"]');
 for(const type of ['contextmenu','selectstart'])document.addEventListener(type,event=>{if(!isEditable(event.target))event.preventDefault();});
 for(const [id,key,fallback] of [['avatarStyle','nktp40-avatar','male'],['avatarSeason','nktp40-season','summer']]){
  const select=document.getElementById(id);try{const saved=localStorage.getItem(key);if([...select.options].some(o=>o.value===saved))select.value=saved;else select.value=fallback;}catch{select.value=fallback;}
  select.addEventListener('change',()=>{try{localStorage.setItem(key,select.value);}catch{}});
 }
 visitorEntry=installPlayerMenu({setProfile(){}},{onboarding:true,waitForMap:true});
 document.querySelector('script[src^="app.js"]')?.addEventListener('error',()=>visitorEntry.mapFailed());
}else{
 const menu=document.getElementById('playerMenu');menu.hidden=true;document.getElementById('playerMenuMount')?.replaceWith(menu);
 document.getElementById('entryOverlay')?.remove();document.body.classList.remove('entry-pending');
}
export {visitorEntry};
