import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
export const GATE_SIGN=Object.freeze({width:6.1,height:1.21,centerY:5.295,background:'#eeede9',border:'#777c79',ink:'#143e86',school:'TRƯỜNG TRUNG HỌC PHỔ THÔNG CHUYÊN',name:'TRẦN PHÚ',municipality:'UBND TP HẢI PHÒNG',authority:'SỞ GIÁO DỤC & ĐÀO TẠO',phone:'0313836604',logoLettering:'TRƯỜNG T.H.P.T CHUYÊN TRẦN PHÚ',backMotto:'TIÊN HỌC LỄ - HẬU HỌC VĂN',reference:'gate-user-white/reference.png',captureDate:null});
// Keep the supplied board's main lettering; replace only the owner-corrected
// authority/logo panel and telephone field. The logo uses the unmodified upload.
export const GATE_SIGN_LOGO=new URL('./assets/runtime/school-logo.png',import.meta.url).href;
export const GATE_SIGN_TEXTURE=new URL('./assets/runtime/school-sign.webp',import.meta.url).href;
// The exported game uses the final baked sign; original reconstruction photos are excluded.
export async function correctedSignCanvas(){const image=new Image();image.src=GATE_SIGN_TEXTURE;await image.decode();const c=document.createElement('canvas');c.width=image.naturalWidth;c.height=image.naturalHeight;c.getContext('2d').drawImage(image,0,0);return c;}
export function createGateSign(){
 const q=GATE_SIGN,g=new THREE.Group();g.name='gate-white-school-sign';g.userData={source:q.reference,captureDate:null,estimatedDimensions:true};const k=geometryKit(g);
 k.box(.18,q.height,q.width,0,q.centerY,0,q.background);
 for(const y of [q.centerY-q.height/2,q.centerY+q.height/2])k.box(.22,.055,q.width+.06,-.015,y,0,q.border);
 for(const z of [-q.width/2,q.width/2])k.box(.22,q.height+.06,.055,-.015,q.centerY,z,q.border);
 for(const z of [-2.6,2.6])k.box(.44,.32,.44,0,4.53,z,'#e9e7db');

 const colors=['#9837bd','#ee78bc','#f08222','#f391cb','#d82724','#f3cf22','#a3d965','#189968','#f88821'];
 for(let i=0;i<colors.length;i++){const z=-2.82+i*5.64/8,staffTop=6.75+(i===4?.16:0);k.cylinder(.009,staffTop-5.89,0,(staffTop+5.89)/2,z,'#a5aaa8');const tip=k.solid(new THREE.ConeGeometry(.028,.12,8),'#cdd2ce','flag-spear');tip.position.set(0,staffTop+.06,z);tip.userData.walkRole='none';const points=[],n=12;for(let j=0;j<n;j++){const t=j/n,u=(j+1)/n,vertex=(f,edge)=>[.03+Math.sin(f*Math.PI*2)*(.10*edge),staffTop-.04-f*.91,z+edge*(.08+.18*Math.sin(f*Math.PI))];for(const a of [[vertex(t,0),vertex(t,1),vertex(u,1)],[vertex(t,0),vertex(u,1),vertex(u,0)]])for(const v of a)points.push(...v);}const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(points,3));geo.computeVertexNormals();const flag=k.solid(geo,colors[i],'entrance-colour-flag');flag.userData.walkRole='none';}
 k.finish();const face=new THREE.Mesh(new THREE.PlaneGeometry(q.width-.055,q.height-.055),new THREE.MeshBasicMaterial({color:'white',toneMapped:false}));face.rotation.y=-Math.PI/2;face.position.set(-.115,q.centerY,0);face.name='gate-school-sign-face';face.userData={gateSign:true,walkRole:'none',reference:q.reference};g.add(face);const back=face.clone();back.geometry=new THREE.PlaneGeometry(q.width-.055,q.height-.055);back.material=face.material.clone();back.rotation.y=Math.PI/2;back.position.x=.115;back.name='gate-school-sign-back';back.userData={gateSign:true,signSide:'back',walkRole:'none',reference:'Cuvwo4GrbLU@06:54'};g.add(back);return g;
}
export function paintGateSign(mesh){
 if(typeof document==='undefined')return;
 if(mesh.userData.painted)return mesh.userData.textureReady;
 mesh.userData.painted=true;
 if(mesh.userData.signSide!=='back'){
  mesh.userData.textureState='loading';mesh.userData.textureReady=new THREE.TextureLoader().loadAsync(GATE_SIGN_TEXTURE).then(texture=>{
   texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=8;mesh.material.map=texture;mesh.material.needsUpdate=true;mesh.userData.textureState='ready';
  }).catch(error=>{mesh.userData.textureState='error';console.error('Không tải được ảnh bảng hiệu gốc',error);});return mesh.userData.textureReady;
 }
 const c=document.createElement('canvas');c.width=32;c.height=32;const t=c.getContext('2d');t.fillStyle='#ffffff';t.fillRect(0,0,32,32);
 const texture=new THREE.CanvasTexture(c);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=8;mesh.material.map=texture;mesh.material.needsUpdate=true;
}
