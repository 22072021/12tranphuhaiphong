import * as T from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js';
import {ACCORDION_HOUSE as H} from './accordion-house.js';

// Owner-authorized contextual backs, deliberately not claimed as surveyed houses.
export function accordionNeighbourPlan(){return[
 {id:'context-left-outer',xmin:-42.8,xmax:H.xmin-4.6,height:3.55,floors:1,color:'#9c9d95',vents:true},
 {id:'context-left-inner',xmin:H.xmin-4.6,xmax:H.xmin,height:6.05,floors:2,color:'#b1a99b'},
 {id:'context-right',xmin:H.xmax,xmax:H.xmax+6,height:5.7,floors:2,color:'#929b9c'}
];}
export function createResidentialBack(p){
  const g=new T.Group();g.name=p.id;
  const k=geometryKit(g),w=p.width??(p.xmax-p.xmin),depth=p.vents?3.1:4.2,h=p.height,step=h/p.floors;
  k.box(w,h,.2,0,h/2,-depth,p.color);
  for(const side of [-1,1])k.box(.2,h,depth,side*(w/2-.1),h/2,-depth/2,p.color);
  k.box(w,.16,depth,0,.08,-depth/2,'#92948f');
  k.box(w+.16,.2,depth+.2,0,h+.1,-depth/2,'#777c76');
  k.box(w+.16,.075,.3,0,h+.23,.015,'#b9b9ab');
  for(let f=0;f<p.floors;f++){
   const bottom=f*step,openH=p.vents?.48:1.05,openW=p.vents?.62:.86,cy=bottom+(p.vents?2.6:1.95),lo=cy-openH/2,hi=cy+openH/2;
   k.box(w,lo-bottom,.22,0,(lo+bottom)/2,0,p.color);
   k.box(w,bottom+step-hi,.22,0,(hi+bottom+step)/2,0,p.color);
   const centres=[-w*.26,w*.26];let cursor=-w/2;
   for(const x of centres){
    const left=x-openW/2,right=x+openW/2;
    k.box(left-cursor,openH,.22,(left+cursor)/2,cy,0,p.color);cursor=right;
    k.box(openW,openH,.035,x,cy,-.045,p.vents?'#424b45':'#596c6d');
    k.withCollision('none',()=>{
     for(const dx of [-openW/2,openW/2])k.box(.045,openH+.07,.065,x+dx,cy,.045,'#c3c6bd');
     for(const y of [lo,hi])k.box(openW+.06,.045,.065,x,y,.045,'#c3c6bd');
     if(p.vents){for(let i=1;i<4;i++)k.box(openW,.025,.07,x,lo+i*openH/4,.065,'#b7bbb0');}
     else{ k.box(.034,openH,.045,x,cy,.05,'#bfc3b9');k.box(openW,.034,.045,x,cy,.05,'#bfc3b9');
      for(const dx of [-.21,.21])k.box(.012,openH,.02,x+dx,cy,.085,'#455449');
     }
     k.box(openW+.16,.055,.28,x,hi+.12,.07,'#b1b4a9');
     k.box(openW+.12,.06,.13,x,lo-.035,.07,'#babdb2');
    });
   }
   k.box(w/2-cursor,openH,.22,(w/2+cursor)/2,cy,0,p.color);
   if(f)k.box(w,.10,.25,0,bottom,.01,'#b6b6a9');
  }
  k.finish();g.userData={accessible:false,ownerAuthorizedContext:true,historicalAccuracy:'illustrative-only',floors:p.floors};
 return g;
}
export function createAccordionNeighbours(){
 const root=new T.Group();root.name='accordion-neighbour-backs';
 for(const p of accordionNeighbourPlan()){const g=createResidentialBack(p);g.position.set((p.xmin+p.xmax)/2,0,H.frontZ-.02);root.add(g);}
 return root;
}
