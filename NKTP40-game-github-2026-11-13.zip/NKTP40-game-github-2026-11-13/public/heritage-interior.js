import {addClassroomWelcome} from './classroom-welcome.js';
import {addBoardStats} from './board-stats.js';
import {registerTeacherChair} from './teacher-chair-seat.js';
import {emitStudentDesk,STUDENT_DESK} from './student-desk.js?v=69.0';
import {heritageWindow} from './heritage-window.js?v=231.0';
import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
import {makeOpeningWall} from './wall-openings.js?v=222.0';
import {createStairDoor} from './interactive-door.js?v=222.0';
import {createGlassPane} from './openings/glass.js?v=49.0';
export function createHeritageInterior(b,{rearSetback,mainDepth}){
 const g=new THREE.Group();g.name='heritage-through-corridors-and-team-rooms';const statsMaterials=new Map();const k=geometryKit(g),w=b.width/2,l=b.length/2,step=b.height/2,side=b.frontSide||-1,xmin=-w+.2,xmax=w-rearSetback-.2,split=(xmin+xmax)/2,white='#e5e8df',wall='#dec17a';
 for(let f=0;f<2;f++){const y=f*step;
  k.box(mainDepth-.4,.03,b.length-.4,side*rearSetback/2,y+.025,0,'#b3ada0');
  k.box(mainDepth-.4,.07,b.length-.4,side*rearSetback/2,y+step-.16,0,'#f4f3eb');
  // Square stone joints are visual only; the finished slab is the sole floor.
  k.withCollision('none',()=>{for(let x=xmin;x<xmax;x+=.6)k.box(.007,.002,b.length-.4,x,y+.041,0,'#88877c');for(let z=-l+.2;z<l;z+=.6)k.box(mainDepth-.4,.002,.007,side*rearSetback/2,y+.041,z,'#88877c');});
  for(const sign of [-1,1]){const face=new THREE.Group();face.rotation.y=Math.PI/2;g.add(face);const openings=[];
   for(let r=0;r<2;r++){const lo=r?split:xmin,hi=r?xmax:split,c=(lo+hi)/2,door=c+sign*(hi-lo)*.22,win=c-sign*(hi-lo)*.23;openings.push({u:door,y:y+1.15,width:1.15,height:2.3,kind:'door'},{u:win,y:y+1.6,width:.95,height:1.35,kind:'window'});face.add(createStairDoor({side:-sign,wallX:1.05,u:door,y:y+1.15,v:0,width:1.15,height:2.3,color:white,glazed:true,single:false,swingDirection:-1,heritagePanels:true}));const sash=heritageWindow({width:.95,height:1.35,shutters:false});sash.position.set(-sign*1.05,y+1.6,win);face.add(sash);
    // Modest team-classroom furniture, not the 40-seat standard template.
    const z0=sign*(1.25+(l-1.4)/2),cx=c;
    const photoRoot=new THREE.Group();photoRoot.position.set(r?lo:hi,y+.04,z0);photoRoot.rotation.y=r?-Math.PI/2:Math.PI/2;photoRoot.userData.photoRoomSpecs=[{xmin:-(l-1.4)/2,xmax:(l-1.4)/2,zmin:-(hi-lo)+.15,zmax:-.15,level:0,clearHeight:step-.22,buildingId:b.id,floor:f+1,roomIndex:(sign===-1?0:2)+r,boardEndOverride:1}];g.add(photoRoot);
    const boardWidth=Math.min(4.1,l-1.4-.65),boardHeight=boardWidth*1.32/4.1,boardX=r?lo+.12:hi-.12;
    k.box(.06,boardHeight,boardWidth,boardX,y+1.8,z0,'#315b50');
    k.withCollision('none',()=>{for(const dy of [-1,1])k.box(.09,.045,boardWidth+.12,boardX,y+1.8+dy*(boardHeight/2+.025),z0,'#d8dbd0');for(const dz of [-1,1])k.box(.09,boardHeight+.10,.05,boardX,y+1.8,z0+dz*(boardWidth/2+.035),'#d8dbd0');});
    const statsFace=new THREE.Group();statsFace.position.set(r?lo+.12:hi-.12,y+1.8,z0);statsFace.rotation.y=r?Math.PI/2:-Math.PI/2;g.add(statsFace);statsFace.userData.boardDimensions={width:boardWidth,height:boardHeight,aspect:4.1/1.32};addBoardStats(statsFace,statsMaterials,{width:boardWidth,height:boardHeight});addClassroomWelcome(statsFace,{spec:photoRoot.userData.photoRoomSpecs[0],width:boardWidth,height:boardHeight});
    const furniture=new THREE.Group();furniture.name='heritage-classroom-furniture';furniture.position.set(r?lo:hi,y+.04,z0);furniture.rotation.y=r?-Math.PI/2:Math.PI/2;g.add(furniture);const fk=geometryKit(furniture),wood='#b08a52',steel='#79827c',seatLanes=[];
    fk.withCollision('furniture',()=>{for(let row=0;row<3;row++){const dz=-(1.5+row*(hi-lo-2.0)/3);for(const bank of [-1,1]){const xx=bank*1.10,seatZ=dz-.60;emitStudentDesk(fk,{width:1.40,x:xx,z:dz,seatZ,end:1},{wood,steel});seatLanes.push({xmin:xx-.70,xmax:xx+.70,z:seatZ,height:.43,end:1});}}
     const tx=1.65,tz=-.85,cz=-.38;fk.box(1.05,.065,.60,tx,.775,tz,wood);fk.box(1.01,.64,.035,tx,.43,tz-.275,wood);for(const edge of [-1,1]){fk.box(.035,.64,.56,tx+edge*.49,.43,tz,wood);for(const zz of [-.24,.24])fk.box(.035,.75,.035,tx+edge*.46,.375,tz+zz,steel);}
     registerTeacherChair(furniture,{x:tx,z:cz,end:-1});fk.box(.43,.045,.42,tx,.43,cz,wood);fk.box(.43,.40,.035,tx,.70,cz+.18,wood);for(const edge of [-1,1])for(const zz of [-.16,.16])fk.box(.032,.41,.032,tx+edge*.175,.205,cz+zz,steel);for(const edge of [-1,1])fk.box(.032,.50,.032,tx+edge*.175,.60,cz+.16,steel);
    });fk.finish();furniture.userData={studentDesk:STUDENT_DESK,rows:3,banks:2,deskCount:6,teachingWall:r?lo:hi,teachingWallHasDoor:false,teacherChair:true,teacherDeskPosition:[1.65,.775,-.85],teacherChairPosition:[1.65,.43,-.38],teacherDeskBesideBoard:true,seatLanes};

   }
   const masonry=new THREE.Group();masonry.position.y=y;face.add(masonry);makeOpeningWall(masonry,{side:-sign,wallX:1.05,faceV:0,from:xmin,to:xmax,height:step,color:wall,openings:openings.map(o=>({...o,y:o.y-y})),profile:{height:b.height,storey:step}});
  }
  for(const sign of [-1,1])k.box(.14,step-.22,l-1.2,split,y+(step-.22)/2,sign*(l+1.2)/2,wall);
  k.withCollision('none',()=>{for(let x=xmin+.3;x<xmax;x+=.6)k.box(.015,.016,b.length-.4,x,y+step-.205,0,'#c6c6bd');for(let z=-l+.2;z<l;z+=.6)k.box(mainDepth-.4,.016,.015,side*rearSetback/2,y+step-.205,z,'#c6c6bd');});
  for(const x of [xmin+2,xmax-2])k.cylinder(.14,.07,x,y+step-.24,0,'#e5e8df');
 }
 k.finish();g.userData.rooms=8;g.userData.corridors={floors:2,width:2.1,through:true,staggeredDoors:true,source:['P51','P52','P53','P54']};return g;
}
