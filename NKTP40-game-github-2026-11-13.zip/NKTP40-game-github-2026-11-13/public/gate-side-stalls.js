import {createRicePaperStall} from './rice-paper-stall-demo.js';
import {createStickyRiceStall} from './sticky-rice-demo.js';
import {createNoodleStudents} from './noodle-student-npcs.js';
import {createCampusNPC} from './campus-npcs.js';
import * as T from './vendor/three.module.js';
import {createSquarePlasticStool} from './furniture/plastic-square-stool.js';
import {ENTRANCE} from './entrance-layout.js';
import {campusBoundaryPlan} from './campus-boundary.js';
function tea(withNPC=true){const s=new T.Group();
function box(w,h,d,x,y,z,color){const m=new T.Mesh(new T.BoxGeometry(w,h,d),new T.MeshStandardMaterial({color,roughness:.85}));m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;s.add(m);return m;}
function cylinder(rad,h,x,y,z,color){const m=new T.Mesh(new T.CylinderGeometry(rad,rad,h,24),new T.MeshStandardMaterial({color,roughness:.5}));m.position.set(x,y,z);m.castShadow=true;s.add(m);return m;}
// Table against the brick panel. Open space under its thin metal legs.
box(2.05,.055,.64,-.35,.75,-1.67,'#dce1d9');for(const x of [-1.29,.59])for(const z of [-1.92,-1.42])box(.035,.72,.035,x,.36,z,'#747c75');
box(.64,.025,.38,-.92,.80,-1.65,'#315eae');for(const z of [-1.84,-1.46])box(.64,.045,.015,-.92,.82,z,'#426ac1');
function bottle(x,z,color,i){const points=[[.062,0],[.071,.04],[.067,.22],[.044,.29],[.025,.31],[.025,.38]].map(([x,y])=>new T.Vector2(x,y));const m=new T.Mesh(new T.LatheGeometry(points,12),new T.MeshStandardMaterial({color,roughness:.30,transparent:true,opacity:.85}));m.position.set(x,.79,z);s.add(m);cylinder(.027,.026,x,1.18,z,i%3?'#e4dc8d':'#f3eee0');cylinder(.069,.10,x,.94,z,['#dacc77','#bce1af','#f2df9a'][i%3]);}
for(let row=0;row<3;row++)for(let col=0;col<6;col++)bottle(-.4+col*.145,-1.88+row*.14,['#668638','#b58f39','#497f4e','#b3a149'][(row+col)%4],row+col);
for(let i=0;i<5;i++)cylinder(.04,.10,-1.15+i*.10,.86,-1.62,'#c5d7d5');
for(let i=0;i<5;i++)cylinder(.055,.14,.14+i*.13,.86,-1.4,'#a6c2ca');
for(let i=0;i<4;i++)box(.22,.045,.17,.20,.82+i*.047,-1.75,['#e7bc59','#f4d769','#d58f42','#dcc182'][i]);
for(let i=0;i<3;i++)box(.23,.065,.16,-1.14,.88+i*.067,-1.88,'#c1b38c');
function panel(shape,color,x,y,z,ry=0){const geo=new T.ExtrudeGeometry(shape,{depth:.022,bevelEnabled:true,bevelSegments:3,bevelSize:.007,bevelThickness:.007,curveSegments:20});const m=new T.Mesh(geo,new T.MeshStandardMaterial({color,roughness:.32}));m.position.set(x,y,z);m.rotation.y=ry;m.castShadow=true;s.add(m);return m;}
function stool(x,z,color='#155db5',height=.36,size=.37){const model=createSquarePlasticStool({color,height,size});model.position.set(x,0,z);s.add(model);return model;}
for(const [i,[x,z]]of [[.95,-1],[1.5,-.35],[.95,.35],[.25,.65],[-.50,.65],[-1.25,.65],[1.70,.65],[1.70,-1.10]].entries()){const chair=stool(x,z,i%2?'#c32127':'#155db5');for(const lane of chair.userData.seatLanes)lane.omnidirectional=true;}
const sx=-1.53,sz=-1.80,plastic='#617bd1';const sellerSeat=stool(sx,sz,plastic,.44/.765,.40/.765);delete sellerSeat.userData.seatLanes;sellerSeat.userData.npcReserved=true;
const back=new T.Shape();back.moveTo(-.18,0);back.lineTo(-.225,.38);back.bezierCurveTo(-.24,.54,.24,.54,.225,.38);back.lineTo(.18,0);back.closePath();
for(const sign of [-1,1]){const hole=new T.Path();hole.moveTo(sign*.065,.08);hole.lineTo(sign*.09,.41);hole.quadraticCurveTo(sign*.17,.45,sign*.18,.36);hole.lineTo(sign*.145,.09);hole.closePath();back.holes.push(hole);}for(const xx of [-.033,0,.033]){const hole=new T.Path();hole.moveTo(xx-.008,.17);hole.lineTo(xx-.011,.43);hole.quadraticCurveTo(xx,.46,xx+.011,.43);hole.lineTo(xx+.008,.17);hole.closePath();back.holes.push(hole);}const backMesh=panel(back,plastic,sx,.43,sz-.19);backMesh.rotation.x=-.10;backMesh.name='seller-chair-back';

if(withNPC){const seller=createCampusNPC({id:'to',name:'Bác Tô',seated:true});seller.position.set(sx,0,sz);s.add(seller);}return s;}

export function createGateSideStalls(layout){const root=new T.Group();root.name='gate-side-stalls';const plan=campusBoundaryPlan(layout),lo=Math.min(plan.fenceFrom,ENTRANCE.fence.from),hi=ENTRANCE.fence.to,count=Math.max(9,Math.round((hi-lo)/3.2)),span=(hi-lo)/count;
function place(g,bay){g.position.set(ENTRANCE.x-2.25,.078,ENTRANCE.z+hi-(bay-.5)*span);g.rotation.y=-Math.PI/2;g.userData.fenceBay=bay;root.add(g);}
const rice=createStickyRiceStall();rice.name='sticky-rice-stall';rice.position.set(ENTRANCE.x-2.8,.078,ENTRANCE.z+4.8);rice.rotation.y=Math.PI;rice.userData.placementReference='right of gate from street, sidewalk; facing parallel to frontage, perpendicular to gate traffic';root.add(rice);
const drinks=tea();drinks.name='bac-to-tea-stall';place(drinks,1);drinks.position.z=ENTRANCE.z+hi-2.15;
const sanh=createRicePaperStall();sanh.name='bac-sanh-rice-paper-stall';sanh.position.copy(drinks.position).add(new T.Vector3(-1.3,0,-4.3));sanh.rotation.y=drinks.rotation.y;sanh.userData.placementReference='wearer-right of Bac To (-local X), closer to sidewalk kerb';root.add(sanh);
const noodle=new T.Group();noodle.name='fish-noodle-stall';place(noodle,9);
function box(w,h,d,x,y,z,color){const m=new T.Mesh(new T.BoxGeometry(w,h,d),new T.MeshStandardMaterial({color,roughness:.8}));m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;noodle.add(m);return m;}
box(1.8,.06,.65,0,.75,-.4,'#c6c6b8');for(const x of [-.78,.78])for(const z of [-.65,-.15])box(.045,.73,.045,x,.365,z,'#667365');const bench=new T.Group();bench.name='noodle-customer-bench';bench.position.z=.35;noodle.add(bench);const top=box(1.9,.055,.32,0,.43,0,'#886b4b');bench.add(top);for(const x of [-.8,.8]){const leg=box(.12,.42,.25,x,.21,0,'#645843');bench.add(leg);}bench.userData.seatLanes=[{kind:'stone',xmin:-.75,xmax:.75,z:0,end:-1,height:.4575,size:.32}];bench.traverse(o=>{if(o.isMesh)o.userData.walkSupport=false;});
// Photo-confirmed wheeled display/cart with open lower shelf and bowls.
box(1.8,.045,.65,0,.20,-.4,'#697462');for(const x of [-.78,.78]){const wheel=new T.Mesh(new T.TorusGeometry(.10,.025,8,20),new T.MeshStandardMaterial({color:'#343a32'}));wheel.rotation.y=Math.PI/2;wheel.position.set(x,.11,-.4);noodle.add(wheel);}for(let i=0;i<4;i++){const bowl=new T.Mesh(new T.SphereGeometry(.09,16,8,0,Math.PI*2,0,Math.PI/2),new T.MeshStandardMaterial({color:'#eeeade',side:T.DoubleSide}));bowl.rotation.x=Math.PI;bowl.position.set(-.58+i*.35,.86,-.4);noodle.add(bowl);}for(const x of [-.55,.15,.58])box(.20,.24,.27,x,.34,-.4,'#b6c4ad');
const tableX=2.05,tableZ=-.2;const table=box(.8,.045,.65,tableX,.46,tableZ,'#5b8db3');table.userData.walkSupport=false;for(const x of [tableX-.33,tableX+.33])for(const z of [tableZ-.25,tableZ+.25]){const leg=box(.04,.44,.04,x,.22,z,'#5b8db3');leg.userData.walkSupport=false;}
for(const [x,z]of [[tableX,tableZ+.70],[tableX+.70,tableZ],[tableX,tableZ-.70],[tableX-.70,tableZ]]){const st=createSquarePlasticStool({color:'#973d42',height:.31,size:.31});st.position.set(x,0,z);st.rotation.y=Math.atan2(tableX-x,tableZ-z);st.userData.faces='plastic-table';st.traverse(o=>{if(o.isMesh)o.userData.walkSupport=false;});noodle.add(st);}

const chairSource=tea(false);for(const item of [...chairSource.children])if(item.name==='square-plastic-stool'&&item.position.x< -1.25||item.name==='seller-chair-back'){item.position.x+=1.1;noodle.add(item);} // Seller chair backed to fence.
noodle.add(createNoodleStudents());
const seller=createCampusNPC({id:'noodle',name:'Cô bán bún cá',female:true,seated:true});seller.position.set(-.43,0,-1.80);noodle.add(seller);
const stove=new T.Mesh(new T.CylinderGeometry(.25,.28,.44,24),new T.MeshStandardMaterial({color:'#635747',roughness:1}));stove.position.set(-1.13,.22,-1.25);noodle.add(stove);box(.20,.15,.06,-1.13,.18,-.98,'#28251f');
const pot=new T.Mesh(new T.CylinderGeometry(.32,.29,.42,32),new T.MeshStandardMaterial({color:'#aeb6b4',metalness:.75,roughness:.35}));pot.position.set(-1.13,.67,-1.25);noodle.add(pot);const lid=new T.Mesh(new T.CylinderGeometry(.33,.33,.025,32),pot.material);lid.position.set(-1.13,.89,-1.25);noodle.add(lid);box(.12,.035,.055,-1.13,.925,-1.25,'#444a46');for(const sign of [-1,1])box(.12,.035,.06,-1.13+sign*.34,.76,-1.25,'#727b77');root.userData={basis:'owner new gate photo: tea beside auxiliary door; noodle photo cart, bay9 provisional',baySpan:span};return root;}
