import {loginAdmin,adminFetch} from './admin-session.js';
const form=document.querySelector('form'),code=document.getElementById('code'),text=document.getElementById('text'),result=document.getElementById('result'),button=form.querySelector('button');
text.oninput=()=>document.getElementById('count').textContent=Array.from(text.value).length;
form.onsubmit=async event=>{event.preventDefault();button.disabled=true;result.textContent='Đang gửi…';result.dataset.error='false';try{if(code.value){await loginAdmin(code.value);code.value='';}const response=await adminFetch('/api/admin-announcements',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:text.value.trim()})});const data=await response.json();if(!response.ok)throw Error(data.error||'Chưa gửi được thông báo.');result.textContent='Đã gửi thông báo đến tất cả người chơi:\n'+data.message.text;text.value='';text.oninput();}catch(error){result.dataset.error='true';result.textContent=error.message;}finally{button.disabled=false;}};

button.disabled=false;
