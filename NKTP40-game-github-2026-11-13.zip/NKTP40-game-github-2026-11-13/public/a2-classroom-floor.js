import {finishFloorFaces} from './floor-face-finish.js?v=214.0';
import * as THREE from './vendor/three.module.js';
let texture;
export function applyA2ClassroomFloor(material){
 if(typeof document==='undefined')return;
 if(!texture){texture=new THREE.TextureLoader().load(new URL('./textures/a2-classroom-floral-user.webp',import.meta.url).href);texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=2;}
 material.onBeforeCompile=shader=>{shader.uniforms.a2FloralTile={value:texture};shader.vertexShader='varying vec2 vA2Floral;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
 vec4 floralPosition=vec4(position,1.0);
 #ifdef USE_INSTANCING
 floralPosition=instanceMatrix*floralPosition;
 #endif
 vA2Floral=floralPosition.xz/.60;`);shader.fragmentShader='uniform sampler2D a2FloralTile;\nvarying vec2 vA2Floral;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>\n vec3 agedTile=texture2D(a2FloralTile,vA2Floral).rgb*.40;
 agedTile+=(texture2D(a2FloralTile,vA2Floral+vec2(.006,0.)).rgb+texture2D(a2FloralTile,vA2Floral-vec2(.006,0.)).rgb+texture2D(a2FloralTile,vA2Floral+vec2(0.,.006)).rgb+texture2D(a2FloralTile,vA2Floral-vec2(0.,.006)).rgb)*.15;
 float tileLuma=dot(agedTile,vec3(.299,.587,.114));
 agedTile=mix(vec3(tileLuma),agedTile,.68);
 diffuseColor.rgb=mix(agedTile,vec3(.52,.43,.29),.22);`);};material.customProgramCacheKey=()=> 'a2-classroom-user-floral-aged-194';material.userData.floorReference='a2-classroom-floral-user.webp';finishFloorFaces(material);material.needsUpdate=true;
}
