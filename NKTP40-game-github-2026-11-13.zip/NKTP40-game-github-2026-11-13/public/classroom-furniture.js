import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
// Reusable school desks, benches, teacher platform and board. Layout remains estimated.
export function furnishClassroom({xmin,xmax,zmin,zmax,doorU,level=0,side=1,rows=4,teacherDesk}){
 const g=new THREE.Group();g.name='furnished-classroom';g.position.y=level;const k=geometryKit(g),wood='#a57b4d',metal='#60746a',width=xmax-xmin,depth=zmax-zmin,boardEnd=doorU>(zmin+zmax)/2?1:-1,boardZ=boardEnd>0?zmax-.18:zmin+.18,cx=(xmin+xmax)/2,platformZ=boardZ-boardEnd*.62;
 k.box(Math.min(3.5,width-.7),.18,1.1,cx,.09,platformZ,'#b2aa95');
 k.box(Math.min(3.8,width-.7),1.15,.055,cx,1.85,boardZ,'#30514a');
 const desk={x:teacherDesk?.x??cx,z:teacherDesk?.z??platformZ,supportHeight:teacherDesk?.supportHeight??.18};
 k.box(1.2,.055,.6,desk.x,desk.supportHeight+.785,desk.z,wood);for(const x of [-.49,.49])for(const z of [-.22,.22])k.box(.05,.76,.05,desk.x+x,desk.supportHeight+.38,desk.z+z,metal);
 const tableW=Math.min(1.40,(width-1.6)/2),banks=[cx-width*.24,cx+width*.24],first=boardZ-boardEnd*2.05,rowPitch=Math.min(1.15,(depth-2.8)/Math.max(1,rows-1));
 for(let r=0;r<rows;r++)for(const x of banks){const z=first-boardEnd*r*rowPitch,seatZ=z-boardEnd*.53;k.box(tableW,.055,.48,x,.735,z,wood);k.box(tableW,.05,.26,x,.425,seatZ,wood);for(const a of [-1,1]){k.box(.04,.70,.04,x+a*(tableW/2-.1),.35,z,metal);k.box(.04,.40,.04,x+a*(tableW/2-.1),.20,seatZ,metal);}k.box(tableW,.19,.035,x,.58,seatZ-boardEnd*.13,wood);}
 k.finish();g.userData={rows,banks:2,seatsPerDesk:2,capacity:rows*4,teacherPlatform:true,teacherDesk:{...desk,width:1.2,depth:.6},boardEnd,doorU,estimatedInterior:true};return g;
}
