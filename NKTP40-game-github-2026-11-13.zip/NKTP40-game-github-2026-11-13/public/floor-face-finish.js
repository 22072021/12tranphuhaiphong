// Floor textures belong only on upward faces; slab edges are cement and soffits white.
export function finishFloorFaces(material){
 const compile=material.onBeforeCompile.bind(material),key=material.customProgramCacheKey.bind(material),previous=key();
 material.onBeforeCompile=shader=>{compile(shader);shader.vertexShader='varying vec3 vFloorFaceNormal;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <beginnormal_vertex>',`#include <beginnormal_vertex>
 vec3 floorFaceNormal=objectNormal;
 #ifdef USE_INSTANCING
 floorFaceNormal=mat3(instanceMatrix)*floorFaceNormal;
 #endif
 vFloorFaceNormal=normalize(mat3(modelMatrix)*floorFaceNormal);`);
 shader.fragmentShader='varying vec3 vFloorFaceNormal;\n'+shader.fragmentShader;
 shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>',`float floorFaceY=(gl_FrontFacing?1.0:-1.0)*normalize(vFloorFaceNormal).y;
 if(floorFaceY<0.72)diffuseColor.rgb=floorFaceY<-.72?vec3(.94,.94,.92):vec3(.64,.63,.59);
 #include <roughnessmap_fragment>`);
 shader.fragmentShader=shader.fragmentShader.replace('#include <emissivemap_fragment>',`#include <emissivemap_fragment>
 if(floorFaceY<-.72)totalEmissiveRadiance+=vec3(.42,.42,.41);`);
 };material.customProgramCacheKey=()=>previous+'-top-only-white-soffit-v214';material.userData.floorFacesOnly=true;return material;
}
