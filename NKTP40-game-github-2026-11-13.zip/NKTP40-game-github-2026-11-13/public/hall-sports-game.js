import {createBadmintonShuttle,orientShuttle} from './sports-equipment.js';
import {applySportsMotion} from './sports-motion.js';
import {createSportsSlots,sportsClock} from './sports-slots.js';
import * as T from './vendor/three.module.js';
import {importAsset,assetFailure} from './asset-retry.js';
import {registerNPC} from './npc-animation.js';
export function createSportsRacket(kind){const g=new T.Group(),mat=new T.MeshStandardMaterial({color:kind==='table'?'#a53d36':'#c5d5d7',roughness:.8});const handle=new T.Mesh(new T.CylinderGeometry(.014,.014,.20,8),mat);handle.position.y=-.10;g.add(handle);const head=kind==='table'?new T.Mesh(new T.CylinderGeometry(.095,.095,.016,16),mat):new T.Mesh(new T.TorusGeometry(.115,.009,6,24),mat);if(kind==='table')head.rotation.x=Math.PI/2;else head.scale.y=1.3;head.position.y=-.28;g.add(head);g.name='sports-racket';return g;}
export function createHallSportsGame({kind,x,z,index}){
 const root=new T.Group();root.name=kind+'-sports-game-'+index;root.position.set(x,0,z);root.userData={walkIgnore:true,animationRadius:6};
 const reach=kind==='table'?2.15:4.15,state={time:0},slots=createSportsSlots(root,state,kind==='table'?[new T.Vector3(-reach,0,0)]:[new T.Vector3(-reach,0,1.15),new T.Vector3(reach,0,-1.15)],{kind,title:kind==='table'?'Bóng bàn':'Cầu lông'});
 slots.forEach(s=>s.targetLocal.set(s.index===1?-reach:reach,0,0));
 const ready=importAsset(new URL('./student/student.js',import.meta.url).href).then(async({createStudent,badgeReady})=>{
  await badgeReady;for(let p=root;p;p=p.parent)if(p.userData.disposed)return;const actors=[];
  for(const side of (kind==='table'?[1]:[-1,1])){const a=createStudent({gender:side<0?'female':'male',season:'summer',scale:.93});a.root.name='sports-npc-'+side;a.root.position.set(side*reach,0,kind==='table'?0:side*1.15);a.root.rotation.y=side<0?Math.PI/2:-Math.PI/2;const r=createSportsRacket(kind);r.position.y=-.24;a.joints.rightElbow.add(r);root.add(a.root);actors.push({a,side});}
  const ball=kind==='table'?new T.Mesh(new T.SphereGeometry(.025,16,12),new T.MeshStandardMaterial({color:'#f5f2d9'})):createBadmintonShuttle();ball.name=kind==='table'?'table-tennis-ball':'badminton-shuttle';root.add(ball);if(ball.equipmentReady)await ball.equipmentReady;
  const duration=kind==='table'?.9:1.4;
  const endpoint=side=>{const slot=slots.find(s=>Math.sign(s.marker.position.x)===side&&s.occupied);return{slot,p:slot?slot.marker.position.clone():new T.Vector3(side*reach,0,kind==='table'?0:side*1.15)};};
  registerNPC(root,time=>{const waiting=kind==='table'&&!slots.some(s=>s.occupied);if(waiting){state.resetAt=time;state.previousTarget=null;state.clockRound=undefined;}const {n,u}=sportsClock(state,time,duration),from=n%2===0?-1:1,to=-from;ball.visible=!waiting;const start=endpoint(from),end=endpoint(to);state.target=waiting?null:end.slot;state.previousTarget=state.target;state.previousRound=n;
   for(const {a,side}of actors){a.update(time,'idle');const swing=!waiting&&!start.slot&&side===from?Math.max(0,1-u/.3):0;applySportsMotion(a.joints,{kind,swing});}
   ball.position.lerpVectors(start.p,end.p,u);ball.position.y=kind==='table'?.96+Math.abs(Math.sin(u*Math.PI*2))*.25:1.2+Math.sin(Math.PI*u)*1.6;if(kind!=='table')orientShuttle(ball,new T.Vector3(end.p.x-start.p.x,Math.PI*1.6*Math.cos(Math.PI*u),end.p.z-start.p.z));root.userData.waiting=waiting;
  });root.userData.ready=true;
 }).catch(e=>assetFailure(root,e));slots.forEach(s=>s.textureReady=ready);return root;
}
