import * as T from '../vendor/three.module.js';
// Reusable props. Metres; origin at bottom centre, suitable for a hand attachment.
const materials=new Map();
function material(color,extra={}){const key=color+JSON.stringify(extra);if(!materials.has(key))materials.set(key,new T.MeshStandardMaterial({color,roughness:.72,...extra}));return materials.get(key);}
function mesh(g,geo,color,x=0,y=0,z=0,extra={}){const m=new T.Mesh(geo,material(color,extra));m.position.set(x,y,z);m.userData.walkRole='none';g.add(m);return m;}
export function createBread(){
 const g=new T.Group();g.name='handheld-banh-mi';
 const loaf=mesh(g,new T.SphereGeometry(1,20,12),'#ce8b39',0,.055,0);loaf.scale.set(.052,.055,.16);
 // Shallow pale scores follow the upper crust, rather than cutting through the loaf.
 for(const z of[-.09,-.03,.03,.09]){const score=mesh(g,new T.CapsuleGeometry(.005,.058,3,8),'#ead0a0',0,.106,z);score.rotation.z=Math.PI/2;score.rotation.y=.35;}
 const filling=mesh(g,new T.SphereGeometry(1,12,6),'#795039',.047,.05,0);filling.scale.set(.006,.012,.105);
 for(const z of[-.065,0,.065]){const herb=mesh(g,new T.SphereGeometry(1,8,4),'#638440',.049,.063,z);herb.scale.set(.009,.005,.028);}
 return g;
}
export function createTeaCup(){
 const g=new T.Group();g.name='handheld-tra-che';
 // Same small handleless glass proportions as the existing Bac To tea stall.
 const profile=[[.025,0],[.028,.006],[.032,.075],[.029,.078],[.026,.009]].map(p=>new T.Vector2(...p));
 mesh(g,new T.LatheGeometry(profile,16),'#d6e4df',0,0,0,{transparent:true,opacity:.38,depthWrite:false,side:T.DoubleSide,roughness:.18});
 mesh(g,new T.CylinderGeometry(.027,.024,.045,16),'#8e963b',0,.029,0,{transparent:true,opacity:.82});
 return g;
}
export function createRicePaperCup(){
 const g=new T.Group();g.name='handheld-banh-trang-tron';
 const profile=[[.032,0],[.035,.004],[.047,.12],[.044,.123],[.032,.008]].map(p=>new T.Vector2(...p));
 mesh(g,new T.LatheGeometry(profile,16),'#eee5d4',0,0,0,{transparent:true,opacity:.65,side:T.DoubleSide,depthWrite:false});
 for(let i=0;i<22;i++){const a=i*2.399,r=.025*Math.sqrt((i+.5)/22);const strip=mesh(g,new T.BoxGeometry(.012,.003,.045),['#dfba77','#bb773d','#728a3d'][i%3],Math.cos(a)*r,.035+(i%6)*.012,Math.sin(a)*r);strip.rotation.y=a;}
 const rim=mesh(g,new T.TorusGeometry(.046,.002,5,24),'#f5eddf',0,.12,0);rim.rotation.x=Math.PI/2;
 for(const x of[-.007,.007]){const stick=mesh(g,new T.CylinderGeometry(.0018,.0025,.24,6),'#aa7d4d',x,.15,.008);stick.rotation.x=-.17;stick.rotation.z=.13;}
 return g;
}
export function createFoodBowl(){
 const g=new T.Group();g.name='handheld-noodle-bowl';
 const profile=[[.043,0],[.058,.008],[.083,.04],[.104,.077],[.108,.09]].map(p=>new T.Vector2(...p));
 mesh(g,new T.LatheGeometry(profile,24),'#eee9db',0,0,0,{side:T.DoubleSide,roughness:.45});
 const soup=mesh(g,new T.CircleGeometry(.098,24),'#bca36b',0,.079,0);soup.rotation.x=-Math.PI/2;
 for(let n=0;n<5;n++){const noodle=mesh(g,new T.TorusGeometry(.025+n*.008,.002,4,16,Math.PI*1.6),'#eee6c7',0,.082,0);noodle.rotation.x=Math.PI/2;}
 for(let n=0;n<3;n++){const fish=mesh(g,new T.BoxGeometry(.033,.009,.016),n===2?'#4d773c':'#dab473',(n-1)*.033,.086,.025);fish.rotation.y=n*.8;}
 return g;
}
export function createRiceBox(){const g=new T.Group();g.name='handheld-sticky-rice';mesh(g,new T.BoxGeometry(.15,.045,.11),'#f0eadd',0,.0225,0);mesh(g,new T.SphereGeometry(1,12,6),'#e6d9b6',0,.047,0).scale.set(.067,.021,.045);return g;}
export function createPanMeal(){const g=new T.Group();g.name='pan-bread-meal';mesh(g,new T.CylinderGeometry(.13,.12,.02,20),'#393936',0,.01,0);mesh(g,new T.SphereGeometry(1,12,6),'#f3ead1',-.025,.025,0).scale.set(.07,.006,.05);mesh(g,new T.SphereGeometry(.025,10,6),'#e5ac30',-.025,.035,0).scale.y=.25;mesh(g,new T.BoxGeometry(.06,.02,.05),'#89553e',.065,.03,.025);return g;}
export function createEatingChopsticks(){const g=new T.Group();g.name='food-eating-chopsticks';for(const x of[-.006,.006]){const stick=mesh(g,new T.CylinderGeometry(.0018,.0023,.22,6),'#aa7d4d',x,0,.06);stick.rotation.x=Math.PI/2;}return g;}
// Grip at z=0, fork head points along +Z (same attachment convention as chopsticks).
export function createEatingFork(){const g=new T.Group();g.name='food-eating-fork';const steel='#b9bec0';mesh(g,new T.BoxGeometry(.012,.006,.135),steel,0,0,.025,{metalness:.65,roughness:.3});mesh(g,new T.BoxGeometry(.029,.005,.025),steel,0,0,.103,{metalness:.65,roughness:.3});for(const x of[-.011,-.0037,.0037,.011])mesh(g,new T.BoxGeometry(.004,.004,.030),steel,x,0,.127,{metalness:.65,roughness:.3});return g;}
