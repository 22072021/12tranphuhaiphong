import * as T from '../vendor/three.module.js';
// Thin cast-stone slabs with eased edges and four separate tapered concrete legs.
export function createStoneBench(){
 const g=new T.Group();g.name='R01-stone-bench';const pink=new T.MeshStandardMaterial({color:'#bf9c92',roughness:.83}),white=new T.MeshStandardMaterial({color:'#d9d6c7',roughness:.9});
 function slab(w,h,d,x,y,z,material,bevel=.008){const s=new T.Shape();s.moveTo(-w/2,-h/2);s.lineTo(w/2,-h/2);s.lineTo(w/2,h/2);s.lineTo(-w/2,h/2);s.closePath();const geo=new T.ExtrudeGeometry(s,{depth:d-2*bevel,bevelEnabled:true,bevelSize:bevel,bevelThickness:bevel,bevelSegments:2,steps:1});geo.translate(0,0,-d/2+bevel);const m=new T.Mesh(geo,material);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;m.userData.walkRole='furniture';g.add(m);return m;}
 slab(1.62,.045,.43,0,.4075,-.025,pink);const back=slab(1.60,.29,.045,0,.685,.26,pink);back.rotation.x=.10;
 for(const side of [-1,1]){for(const end of [-1,1]){const leg=new T.Mesh(new T.CylinderGeometry(.067,.048,.385,4),white);leg.rotation.y=Math.PI/4;leg.position.set(side*.57,.1925,end*.145-.025);leg.castShadow=leg.receiveShadow=true;leg.userData.walkRole='furniture';g.add(leg);}const stay=slab(.065,.43,.065,side*.59,.60,.262,white,.004);stay.rotation.x=.10;stay.name='inclined-backrest-support';}
 g.userData.stoneBench={legs:4,manualSeat:true,seatHeight:.43};g.userData.seatLanes=[{xmin:-.72,xmax:.72,z:-.025,end:-1,height:.43,kind:'stone'}];return g;
}
