import * as T from '../vendor/three.module.js';
export function createBicycle({mini=false,color=null,accent=null,parked=true,lowDetail=false,animated=false}={}){
 const g=new T.Group();g.name=mini?'mini-step-through-bicycle':'mountain-bicycle';const paint=color||(mini?'#d8ceb1':'#22272a'),chrome='#a9b0b2',black='#202223';let assembly=g;const wheelGroups=[],pedals=[];
 function tube(points,r,color){const curve=new T.CatmullRomCurve3(points.map(p=>new T.Vector3(...p)));const m=new T.Mesh(new T.TubeGeometry(curve,points.length>2?(lowDetail?12:24):1,r,lowDetail?5:8,false),new T.MeshStandardMaterial({color,roughness:.42,metalness:color===chrome?.72:.15}));m.castShadow=true;assembly.add(m);return m;}
 function ring(x,y,z,r,t,color,arc=Math.PI*2){const m=new T.Mesh(new T.TorusGeometry(r,t,6,lowDetail?32:48,arc),new T.MeshStandardMaterial({color,roughness:.65,metalness:color===chrome?.75:0}));m.position.set(x,y,z);assembly.add(m);return m;}
 const R=mini?.315:.335,Y=R+.027;
 for(const x of [-.55,.55]){if(animated){assembly=new T.Group();g.add(assembly);wheelGroups.push({group:assembly,x,y:Y});}ring(x,Y,0,R,.026,black);ring(x,Y,0,R-.026,.008,chrome);tube([[x,Y,-.06],[x,Y,.06]],.018,chrome);for(let i=0;i<(lowDetail?20:32);i++){const a=i*Math.PI/(lowDetail?10:16);tube([[x,Y,(i%2?1:-1)*.045],[x+Math.cos(a)*(R-.03),Y+Math.sin(a)*(R-.03),0]],.0017,chrome);}if(!mini){ring(x,Y,.053,.072,.006,chrome);for(let i=0;i<6;i++){const a=i*Math.PI/3;tube([[x,Y,.055],[x+.07*Math.cos(a),Y+.07*Math.sin(a),.055]],.005,chrome);}for(let i=0;i<(lowDetail?24:48);i++){const a=i*Math.PI/(lowDetail?12:24);const tread=new T.Mesh(new T.BoxGeometry(.020,.012,.055),new T.MeshStandardMaterial({color:'#303232'}));tread.position.set(x+Math.cos(a)*(R+.024),Y+Math.sin(a)*(R+.024),0);tread.rotation.z=a-Math.PI/2;assembly.add(tread);}}else{if(animated)assembly=g;ring(x,Y,0,R+.039,.013,paint,Math.PI);for(const z of [-.045,.045])for(const sign of [-1,1])tube([[x,Y,z],[x+sign*.27,Y+.20,z]],.005,chrome);}}
 assembly=g;if(animated)for(const w of wheelGroups){w.group.position.set(w.x,w.y,0);for(const m of w.group.children)m.position.sub(w.group.position);}
 const bb=[-.08,.31,0],seat=[-.21,.77,0],head=[.40,.86,0],fork=[.45,.64,0];
 tube([bb,seat],.022,paint);tube([head,fork],.027,paint);
 for(const z of [-.045,.045]){tube([bb,[-.55,Y,z]],.012,paint);tube([seat,[-.55,Y,z]],.012,paint);tube([[.45,.68,z],[.55,Y,z]],.014,mini?chrome:paint);if(!mini)tube([[.43,.81,z],[.48,.57,z]],.010,chrome);}
 if(mini){tube([head,[.26,.47,0],[.02,.39,0],bb],.026,paint);tube([[.39,.72,0],[.18,.39,0],bb],.018,paint);}else{tube([seat,head],.021,paint);tube([bb,head],.033,paint);tube([[-.05,.36,.028],[.33,.78,.028]],.008,accent||'#b93327');tube([[-.18,.78,.022],[.38,.86,.022]],.005,accent||'#b93327');}
 tube([seat,[-.22,.88,0]],.012,chrome);
 const saddle=new T.Mesh(new T.SphereGeometry(1,24,12),new T.MeshStandardMaterial({color:mini?'#80503b':black,roughness:.8}));saddle.position.set(-.25,.90,0);saddle.scale.set(.135,.028,.078);g.add(saddle);
 tube([head,[.40,1.00,0]],.014,chrome);tube([[.40,1,0],[.36,1.01,-.12],[mini?.28:.38,.99,-.29]],.012,chrome);tube([[.40,1,0],[.36,1.01,.12],[mini?.28:.38,.99,.29]],.012,chrome);
 for(const z of [-1,1]){tube([[mini?.28:.38,.99,z*.21],[mini?.28:.38,.99,z*.30]],.017,mini?'#80503b':black);tube([[.36,.98,z*.18],[.30,.96,z*.25]],.005,black);tube([[.34,.98,z*.18],[.49,.87,z*.08],[.47,.65,z*.05]],.0025,black);}
 ring(bb[0],bb[1],.07,.095,.009,mini?paint:chrome);ring(-.55,Y,.067,.052,.007,chrome);
 tube([[bb[0],bb[1]+.095,.072],[-.55,Y+.052,.072]],.0035,black);tube([[bb[0],bb[1]-.095,.072],[-.55,Y-.052,.072]],.0035,black);
 const crankStart=g.children.length;
 for(const sign of [-1,1]){tube([[bb[0],bb[1],sign*.09],[bb[0]+sign*.10,bb[1]-sign*.10,sign*.09]],.008,chrome);const pedal=new T.Mesh(new T.BoxGeometry(.075,.018,.105),new T.MeshStandardMaterial({color:black}));pedal.position.set(bb[0]+sign*.10,bb[1]-sign*.10,sign*.12);g.add(pedal);if(animated)pedals.push(pedal);}
 if(animated){const pieces=g.children.slice(crankStart),crank=new T.Group();crank.position.set(bb[0],bb[1],0);g.add(crank);for(const m of pieces){m.position.sub(crank.position);crank.add(m);}g.bikeMotion={wheels:wheelGroups.map(w=>w.group),crank,pedals,radius:R+.026};}
 const kickstand=tube([[0,.33,-.05],parked?[-.16,.021,-.16]:[-.36,.36,-.065]],.006,chrome);kickstand.name='bicycle-kickstand';
 if(mini){for(const z of [-.065,.065]){tube([[-.73,.77,z],[-.29,.77,z]],.008,chrome);tube([[-.55,Y,z],[-.70,.77,z]],.006,chrome);}for(let x=-.73;x<-.29;x+=.07)tube([[x,.77,-.065],[x,.77,.065]],.005,chrome);
  const basket='#815239';for(let j=0;j<7;j++){const y=.73+j*.035,rx=.14+j*.006,rz=.125+j*.005,pts=[];for(let i=0;i<=48;i++){const a=i*Math.PI/24;pts.push([.68+Math.cos(a)*rx,y,Math.sin(a)*rz]);}tube(pts,.003,basket);}for(let i=0;i<(lowDetail?20:40);i++){const a=i*Math.PI/(lowDetail?10:20);tube([[.68+Math.cos(a)*.14,.73,Math.sin(a)*.125],[.68+Math.cos(a)*.176,.94,Math.sin(a)*.155]],.0025,basket);}tube([[.55,Y,-.04],[.70,.73,-.10]],.005,chrome);tube([[.55,Y,.04],[.70,.73,.10]],.005,chrome);
 }
 if(parked){g.rotation.x=-.12;g.updateMatrixWorld(true);g.position.y-=new T.Box3().setFromObject(g).min.y;g.userData.parkedLean={radians:-.12,side:'kickstand'};}
 return g;
}
