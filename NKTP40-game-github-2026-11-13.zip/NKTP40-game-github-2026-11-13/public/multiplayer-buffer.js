// Server-time playback: never chase individual packet arrival times.
const angle=(a,b,t)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*t;
export class MotionBuffer{
 constructor({delay=300,adaptive=true}={}){this.baseDelay=delay;this.adaptive=adaptive;this.samples=[];this.jitter=0;this.interval=100;this.offset=null;this.delay=delay;this.clock=null;this.lastArrival=null;this.lastStamp=null;this.output={root:[0,0,0,0],mode:'walk'};}
 push(data,arrival){const t=data.t;if(!Number.isFinite(t)||!data.root)return;const last=this.samples.at(-1);if(last&&t<last.t)return;
  if(last&&Math.hypot(...data.root.slice(0,3).map((v,i)=>v-last.root[i]))>5){this.samples=[];this.clock=null;}
  if(this.lastStamp!==null&&t>this.lastStamp){const spacing=t-this.lastStamp;if(spacing<600)this.interval+=.2*(spacing-this.interval);const variation=Math.abs((arrival-this.lastArrival)-spacing);this.jitter+=.15*(variation-this.jitter);}
  const offset=arrival-t;this.offset=this.offset===null?offset:Math.min(this.offset+.02,offset);this.lastArrival=arrival;this.lastStamp=t;
  if(last&&t===last.t)this.samples[this.samples.length-1]={...data};else this.samples.push({...data});if(this.samples.length>64)this.samples.shift();
 }
 sample(now,dt){const list=this.samples;if(!list.length)return null;const targetDelay=this.adaptive?Math.min(1000,Math.max(this.baseDelay,this.interval*2+this.jitter*4)):this.baseDelay;this.delay+=(targetDelay-this.delay)*Math.min(1,dt*2);const target=now-this.offset-this.delay;
  if(!this.adaptive)this.clock=this.clock===null?target:Math.max(this.clock,target);else if(this.clock===null)this.clock=target;else this.clock=Math.max(this.clock,Math.abs(target-this.clock)>2000?target:this.clock+dt*1000*Math.max(.8,Math.min(1.2,1+(target-this.clock)/1000)));
  while(list.length>2&&list[1].t<=this.clock)list.shift();let a=list[0],b=list[1]||a;const span=b.t-a.t;let mix=span>0?Math.max(0,Math.min(1,(this.clock-a.t)/span)):0;
  for(let i=0;i<3;i++)this.output.root[i]=a.root[i]+(b.root[i]-a.root[i])*mix;this.output.root[3]=angle(a.root[3],b.root[3],mix);this.output.mode=mix<1?a.mode:b.mode;
  if(this.clock>b.t){const ahead=Math.min(100,this.clock-b.t);if(span>0&&b.mode==='walk'){for(let i=0;i<3;i++){const velocity=Math.max(-10,Math.min(10,(b.root[i]-a.root[i])*1000/span));this.output.root[i]=b.root[i]+velocity*(ahead-ahead*ahead/200)/1000;}}else this.output.root.splice(0,4,...b.root);}
  const pose=a.pose&&b.pose?(this.output.pose??=Array(82).fill(0)):null;if(pose){for(let i=0;i<82;i++)pose[i]=i>=4&&(i-4)%6>=3||i===3?angle(a.pose[i],b.pose[i],mix):a.pose[i]+(b.pose[i]-a.pose[i])*mix;for(let i=0;i<4;i++)pose[i]=this.output.root[i];}else delete this.output.pose;
  return this.output;
 }
}
