import {corridorPattern} from './corridor-tiles.js';
import {drawStoneStep} from './stair-stone.js?v=218.0';
import {buildingAccessHeight,buildingBaseProfile,subtractFloorRect} from './building-bases.js?v=223.0';
import {APPROVED_ADDITIONS} from './approved-additions-data.js?v=213.0';
import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
const REAR_ROW_SHIFT=5;
export const PLATFORM={id:'PLATFORM',name:'Nền nối hành lang A2–B2',x:30.49,z:-.975,width:15.18,length:24.55,height:.45,rotation:0,basis:'2026-11-04: nền khu vệ sinh đồng mức hành lang A2/B2 theo yêu cầu.'};
export const foundationElevation=b=>Number.isFinite(b.baseElevation)?b.baseElevation:0;
export function groundHeight(x,z,buildings=[]){
 let buildingHeight=0;for(const b of [...buildings,...APPROVED_ADDITIONS.filter(b=>b.kind==='water')])buildingHeight=Math.max(buildingHeight,buildingAccessHeight(x,z,b));
 if(buildingHeight>0)return buildingHeight;
 x-=REAR_ROW_SHIFT;
 const q={...PLATFORM,x:PLATFORM.x-REAR_ROW_SHIFT},lo=q.z-q.length/2,hi=q.z+q.length/2;
 if(z>=-13.17&&z<=-8.93&&x<20.8){if(x>=19.9){const t=(x-19.9)/.9;return Math.abs(z-((-13.17-8.93)/2))<.42?q.height*t:q.height*Math.ceil(t*3)/3;}return 0;}
 if(z>=8.93&&z<=11.22&&x<20.8){if(x>=19.9){const t=(x-19.9)/.9;return Math.abs(z-10.075)<.42?q.height*t:q.height*Math.ceil(t*3)/3;}return 0;}
 if(x>=q.x-q.width/2&&x<=q.x+q.width/2&&z>=lo&&z<=hi)return q.height;
 if(x>=29.95&&x<=33.08&&z<lo&&z>lo-.9){const t=(z-(lo-.9))/.9;return Math.abs(x-31.515)<.42?q.height*t:q.height*Math.ceil(t*3)/3;}
 if(x>=29.45&&x<=33.08&&z>hi&&z<hi+.9){const t=(hi+.9-z)/.9;return Math.abs(x-31.265)<.42?q.height*t:q.height*Math.ceil(t*3)/3;}
 if(x>=18&&x<=20.1){if(z>hi&&z<hi+.9)return q.height*Math.ceil((hi+.9-z)/.30)/3;if(z<lo&&z>lo-.9)return q.height*Math.ceil((z-lo+.9)/.30)/3;}

 return 0;
}
export function createRaisedPlatform(layout){
 const g=new THREE.Group();g.name='raised-concrete-platform';g.userData={...PLATFORM};g.position.x=REAR_ROW_SHIFT;const k=geometryKit(g,{floorPattern:corridorPattern('A2')}),q={...PLATFORM,x:PLATFORM.x-REAR_ROW_SHIFT};
 let pieces=[{x0:q.x-q.width/2,x1:q.x+q.width/2,z0:q.z-q.length/2,z1:q.z+q.length/2}];
 for(const b of layout?.buildings||[])if(['WC','A2','B2','H'].includes(b.id)){const p=buildingBaseProfile(b);pieces=pieces.flatMap(r=>subtractFloorRect(r,{x0:b.x-REAR_ROW_SHIFT-b.width/2-p.bodyMargin,x1:b.x-REAR_ROW_SHIFT+b.width/2+p.bodyMargin,z0:b.z-b.length/2-p.bodyMargin,z1:b.z+b.length/2+p.bodyMargin}));}
 pieces=pieces.flatMap(r=>subtractFloorRect(r,{x0:q.x-q.width/2,x1:20.8,z0:7.2,z1:11.3})).flatMap(r=>subtractFloorRect(r,{x0:q.x-q.width/2,x1:20.8,z0:q.z-q.length/2,z1:-6.575}));
 for(const p of pieces){const x=(p.x0+p.x1)/2,z=(p.z0+p.z1)/2,w=p.x1-p.x0,l=p.z1-p.z0;k.box(w,q.height-.025,l,x,(q.height-.025)/2,z,'#8f938e');k.box(w,.025,l,x,q.height-.0125,z,'#bb9271');}


 // Front WC-A2 opening: recessed terrace, steps flanking the bicycle ramp.
 const accessZ=(8.93+11.22)/2,lane=(11.22-8.93-.84)/2;
 for(const side of [-1,1])for(let j=0;j<3;j++){const top=q.height*(3-j)/3;k.box(.30,top,lane,20.8-(j+.5)*.30,top/2,accessZ+side*(.42+lane/2),'#a8aaa0');}
 const frontRamp=new THREE.Group();frontRamp.name='WC-A2-front-bicycle-ramp';frontRamp.position.set(20.8,0,accessZ);frontRamp.rotation.y=Math.PI;
 const fp=[0,0,-.42,.9,0,-.42,0,.45,-.42,0,0,.42,0,.45,.42,.9,0,.42,0,.45,-.42,.9,0,-.42,.9,0,.42,0,.45,-.42,.9,0,.42,0,.45,.42],fg=new THREE.BufferGeometry();fg.setAttribute('position',new THREE.Float32BufferAttribute(fp,3));fg.computeVertexNormals();const fm=new THREE.Mesh(fg,new THREE.MeshStandardMaterial({color:'#a8aaa0',roughness:1,side:THREE.DoubleSide}));fm.userData.walkRole='none';frontRamp.add(fm);frontRamp.userData.walkRamp={x0:0,x1:.9,z0:-.42,z1:.42,height:q.height};g.add(frontRamp);
 // Replace the remaining old one-sided front steps at B2 with the same centred assembly.
 const b2GapStart=-13.17,b2GapEnd=-8.93,b2Center=(b2GapStart+b2GapEnd)/2,b2Lane=(b2GapEnd-b2GapStart-.84)/2;
 for(const side of [-1,1])for(let j=0;j<3;j++){const top=q.height*(3-j)/3;k.box(.30,top,b2Lane,20.8-(j+.5)*.30,top/2,b2Center+side*(.42+b2Lane/2),'#a8aaa0');}
 const b2FrontRamp=frontRamp.clone();b2FrontRamp.name='WC-B2-front-bicycle-ramp';b2FrontRamp.position.z=b2Center;g.add(b2FrontRamp);
 // A2 rear passage: two stair lanes with a narrow central bicycle channel.
 const cx=31.265,endZ=q.z+q.length/2,channel=.84,sideWidth=(33.08-29.45-channel)/2;
 for(const side of [-1,1])for(let j=0;j<3;j++){const top=q.height*(3-j)/3;k.box(sideWidth,top,.30,cx+side*(channel/2+sideWidth/2),top/2,endZ+(j+.5)*.30,'#a8aaa0');}
 const ramp=new THREE.Group();ramp.name='rear-passage-bicycle-ramp';ramp.position.set(cx,0,endZ);ramp.rotation.y=-Math.PI/2;
 const vertices=[0,0,-.42,.9,0,-.42,0,.45,-.42,0,0,.42,0,.45,.42,.9,0,.42,0,.45,-.42,.9,0,-.42,.9,0,.42,0,.45,-.42,.9,0,.42,0,.45,.42];
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.computeVertexNormals();const mesh=new THREE.Mesh(geo,new THREE.MeshStandardMaterial({color:'#a8aaa0',roughness:1,side:THREE.DoubleSide}));mesh.userData.walkRole='none';ramp.add(mesh);ramp.userData.walkRamp={x0:0,x1:.9,z0:-.42,z1:.42,height:q.height};g.add(ramp);
 // Mirrored B2 end: centred84cm channel, three equal concrete steps each side.
 const northZ=q.z-q.length/2,northCenter=(29.95+33.08)/2,northLane=(33.08-29.95-.84)/2;
 for(const side of [-1,1])for(let j=0;j<3;j++){const top=q.height*(3-j)/3;k.box(northLane,top,.30,northCenter+side*(.42+northLane/2),top/2,northZ-(j+.5)*.30,'#a8aaa0');}
 const northRamp=ramp.clone();northRamp.name='B2-rear-passage-bicycle-ramp';northRamp.position.set(northCenter,0,northZ);northRamp.rotation.y=Math.PI/2;g.add(northRamp);
 // Rear apron ends against the boundary; circulation remains inside the wall.
 g.userData.rearPassage={sealedOuterEdge:true,insideBoundary:true};
 k.finish();return g;
}
