import * as T from './vendor/three.module.js';
// Interaction anchors only: preserve all approved building meshes and collisions.
export function addStepSeats(root,b,q){
 const group=new T.Group();group.name='ground-floor-step-seats';group.userData.walkRole='none';root.add(group);
 function lane(x,z,yaw,width,top,bottom=0){if(width<.65||top-bottom<.10)return;const a=new T.Group();a.position.set(x,bottom,z);a.rotation.y=yaw;a.userData.seatLanes=[{kind:'step',xmin:-width/2,xmax:width/2,z:-.12,end:1,height:top-bottom,size:.42,rearEntry:true}];group.add(a);}
 // Ground-floor corridor lip, including the feet of internal stair cores.
 if(['classroom','admin','lab','heritage','hall','toilet','parking'].includes(b.kind))lane(q.side*(b.width/2+.02),0,q.side*Math.PI/2,b.length-.6,q.height+.012);
 for(const a of q.accesses){if(a.steps<1)continue;const half=a.edgeBase??(a.face==='front'?b.width/2:b.length/2),n=a.steps,div=a.riseDivisor??(b.id==='A1'&&n===1?2:n);
  for(let j=0;j<n;j++){const edge=a.sign*(half+a.front+(n-j)*a.tread),top=q.height*(j+1)/div+.012,bottom=j?q.height*j/div:0;
   lane(a.face==='front'?edge:a.u,a.face==='front'?a.u:edge,a.face==='front'?a.sign*Math.PI/2:a.sign>0?0:Math.PI,a.width-.12,top,bottom);}
 }
 for(const f of root.userData.stairPlan?.flights||[]){if(Math.abs(f.from.y)>.05)continue;const dir=Math.sign(f.to.x-f.from.x),run=Math.abs(f.to.x-f.from.x)/f.count,rise=(f.to.y-f.from.y)/f.count;for(let j=0;j<2;j++)lane(f.from.x+dir*run*j,f.from.z,-dir*Math.PI/2,f.width-.18,q.height+(j+1)*rise,q.height+j*rise);}
 const s=root.userData.classrooms?.stage;if(s){const front=s.x+q.side*s.depth/2;lane(front,s.z,q.side*Math.PI/2,s.width-.4,s.height);for(const sign of [-1,1])lane(s.x,s.z+sign*s.width/2,sign>0?0:Math.PI,s.depth-.4,s.height);}
 if(['A2','B2'].includes(b.id))root.traverse(o=>{const p=o.userData.walkPorch;if(!p)return;
  const height=.28,anchor=new T.Group();anchor.name='porch-roof-seat-edge';anchor.position.set(p.side*(p.wallX+p.depth-.06),p.eave+p.rise*.06/(p.depth-p.ridgeV)-height,p.u);anchor.rotation.y=p.side*Math.PI/2;anchor.userData.seatLanes=[{kind:'step',roof:true,xmin:-p.width/2+.45,xmax:p.width/2-.45,z:0,end:1,height,size:.42,rearEntry:true}];o.add(anchor);
 });
 return group;
}
