import {ENTRANCE} from './entrance-layout.js';
export const LEFT_STREET_HOUSES=Array.from({length:7},(_,i)=>({id:'LEFT-STREET-'+(i+1),from:-30-(i+1)*4.2,to:-30-i*4.2,floors:[3,3,3,3,3,3,4][i]}));
// Four existing shop frontages after the guardhouse: S01..S04.
export const STREET_WALK_LIMITS={left:-34.2,right:ENTRANCE.z+ENTRANCE.guard.z+ENTRANCE.guard.length/2+4.2+4.1+3+4.8};
export function insideStreetWalkLimit(x,z,radius=0){return x-radius>=ENTRANCE.x-.18||z-radius>=STREET_WALK_LIMITS.left&&z+radius<=STREET_WALK_LIMITS.right;}
