import {drawStoneStep} from './stair-stone.js?v=218.0';
import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
import {buildingBaseProfile} from './building-bases.js?v=223.0';
import {foundationElevation} from './raised-platform.js?v=223.0';
import {classroomStairPlan} from './stair-design.js?v=228.0';
export function a1HallLinkPlan(layout){
 const a=layout.buildings.find(b=>b.id==='A1'),h=layout.buildings.find(b=>b.id==='H');if(!a||!h)return null;
 const corridor=Math.min(2.25,a.width*.22),side=a.frontSide||-1,entry=new THREE.Vector3(side*(a.width/2-corridor/2),0,-a.length/2).applyMatrix4(new THREE.Matrix4().makeRotationY(-a.rotation*Math.PI/180).setPosition(a.x,0,a.z));
 const high=foundationElevation(a)+buildingBaseProfile(a).height+classroomStairPlan(a).levels[1]+.012,low=foundationElevation(h)+buildingBaseProfile(h).height+(h.hallLevel??(h.height*.46+.8)),exit={x:entry.x,z:h.z+h.length/2+.80,feet:low},run=Math.abs(entry.z-exit.z),count=Math.max(1,Math.ceil(Math.abs(low-high)/.16));
 return{entry:{x:entry.x,z:entry.z,feet:high},turn:{x:entry.x,z:entry.z,feet:high},start:{x:entry.x,z:entry.z,feet:high},exit,high,low,width:1.35,count,run,estimated:true};
}
export function createA1HallLink(layout){
 const g=new THREE.Group();g.name='A1-H-floor-2-link';g.userData.id='A1-H-LINK';const p=a1HallLinkPlan(layout);if(!p)return g;g.userData.plan=p;const k=geometryKit(g),half=p.width/2;
 for(let j=0;j<p.count;j++){const t=(j+.5)/p.count,top=p.high+(p.low-p.high)*(j+1)/p.count;drawStoneStep(k,{x:p.entry.x,y:top,z:p.entry.z+(p.exit.z-p.entry.z)*t,width:p.width,depth:p.run/p.count+.006,axis:'z'});}
 k.withCollision('barrier',()=>{for(const side of [-1,1]){const x=p.entry.x+side*half;for(const dy of [.2,.4,.6,.77])k.beam(new THREE.Vector3(x,p.high+dy,p.entry.z),new THREE.Vector3(x,p.low+dy,p.exit.z),.045,'#53594b');}});k.finish();return g;
}
