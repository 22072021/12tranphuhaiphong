import * as T from './vendor/three.module.js';
export function createDistantAvatar(data){
 const root=new T.Group();root.name='remote-player-'+data.id;root.userData.walkIgnore=true;
 const shirt=new T.MeshLambertMaterial({color:data.season==='winter'?0x70a9c0:0xe5e7e4}),pants=new T.MeshLambertMaterial({color:0x292c40}),skin=new T.MeshLambertMaterial({color:0xe1bc92}),hair=new T.MeshLambertMaterial({color:0x191713});
 const add=(name,geometry,material,y,z=0)=>{const mesh=new T.Mesh(geometry,material);mesh.name=name;mesh.position.set(0,y,z);root.add(mesh);};
 add('shirt',new T.CylinderGeometry(.16,.14,.5,6),shirt,.95);add('trousers',new T.BoxGeometry(.26,.62,.16),pants,.4);add('head',new T.SphereGeometry(.17,6,4),skin,1.4);
 add('hair-cap',new T.SphereGeometry(.182,6,3,0,Math.PI*2,0,Math.PI*.57),hair,1.4);
 if(data.gender==='female')add('long-hair-back',new T.BoxGeometry(.31,.29,.15),hair,1.34,-.10);
 return root;
}
