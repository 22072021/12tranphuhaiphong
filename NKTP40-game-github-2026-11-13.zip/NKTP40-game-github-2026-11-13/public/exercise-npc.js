import {importAsset,assetFailure} from './asset-retry.js';
import {registerNPC} from './npc-animation.js';
import * as T from './vendor/three.module.js';
export function createExerciseNPC({x,z,barY}){
 const g=new T.Group();g.name='npc-parallel-bars';g.position.set(x,.50,z);g.userData={npc:true,dialogue:'Úi, rách quần!',walkIgnore:true,animationPoses:3};
 if(typeof document==='undefined')return g;
 g.userData.textureReady=importAsset(new URL('./student/student.js',import.meta.url).href).then(async({createStudent,badgeReady})=>{await badgeReady;if(rootDisposed(g))return;const avatar=createStudent({gender:'male',season:'summer'});g.add(avatar.root);const j=avatar.joints;
 // Exact two-bone reach: hands stay fixed on the two rails throughout all poses.
 const reach=(side,x)=>{const shoulder=j[side+'Shoulder'],elbow=j[side+'Elbow'],target=new T.Vector3(x,barY-.50+.035,0).sub(new T.Vector3(side==='left'?.177:-.177,1.19,0)),d=target.length(),dir=target.clone().normalize(),along=(.235**2-.214**2+d*d)/(2*d),bend=Math.sqrt(Math.max(0,.235**2-along*along)),e=dir.clone().multiplyScalar(along).add(new T.Vector3(0,0,-bend));shoulder.quaternion.setFromUnitVectors(new T.Vector3(0,-1,0),e.clone().normalize());elbow.quaternion.setFromUnitVectors(new T.Vector3(0,-1,0),target.sub(e).normalize().applyQuaternion(shoulder.quaternion.clone().invert()));};
 const tick=t=>{avatar.update(0,'idle');const phase=(t/1.3)%3,k=Math.floor(phase),u=phase-k,e=u*u*(3-2*u),poses=[[.18,.30],[.55,.55],[.85,.65]],a=poses[k],b=poses[(k+1)%3],spread=T.MathUtils.lerp(a[0],b[0],e),bend=T.MathUtils.lerp(a[1],b[1],e);j.leftHip.rotation.z=spread;j.rightHip.rotation.z=-spread;j.leftHip.rotation.x=j.rightHip.rotation.x=-.55;j.leftKnee.rotation.x=j.rightKnee.rotation.x=bend;j.leftAnkle.rotation.x=j.rightAnkle.rotation.x=.55-bend;reach('left',.32);reach('right',-.32);j.head.rotation.x=.12;avatar.root.updateMatrixWorld(true);};tick(0);registerNPC(g,tick);g.userData.ready=true;window.dispatchEvent(new Event('nktp-texture-ready'));
 }).catch(error=>assetFailure(g,error));return g;
}

function rootDisposed(g){for(let p=g;p;p=p.parent)if(p.userData.disposed)return true;return false;}
