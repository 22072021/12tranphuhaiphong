// Owner-approved temporary show only. Permanent stage/apron are deliberately excluded.
export const A1_ENTERTAINMENT_NAMES=['A1-480-audience-stools','a1-ceremony-hide-stage-show'];
export function createA1EntertainmentModule(){
 let targets=[],saved=new Map();
 function restore(){for(const [o,s]of saved){o.visible=s.visible;if(s.ignore===undefined)delete o.userData.walkIgnore;else o.userData.walkIgnore=s.ignore;if(s.seats)o.userData.seatLanes=s.seats;}saved.clear();}
 function hide(){for(const o of targets){if(!saved.has(o))saved.set(o,{visible:o.visible,ignore:o.userData.walkIgnore});o.visible=false;o.userData.walkIgnore=true;o.traverse(c=>{if(c.userData.seatLanes){if(!saved.has(c))saved.set(c,{visible:c.visible,ignore:c.userData.walkIgnore,seats:c.userData.seatLanes});delete c.userData.seatLanes;}});}}
 return{bind(roots){restore();targets=[];for(const root of roots)root?.traverse(o=>{if(A1_ENTERTAINMENT_NAMES.includes(o.name))targets.push(o);});},hide,restore,get targets(){return targets;},dispose:restore};
}
