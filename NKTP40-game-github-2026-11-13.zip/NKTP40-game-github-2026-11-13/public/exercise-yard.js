import {createExerciseNPC} from './exercise-npc.js';
import * as T from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js';
export const EXERCISE_YARD={xmin:-22.351399221789883,xmax:-14.8,frontZ:-31.75,backZ:-36.75};
export function createExerciseYard(){
 const p=EXERCISE_YARD,g=new T.Group();g.name='recessed-earth-exercise-yard';
 const k=geometryKit(g),cx=(p.xmin+p.xmax)/2,cz=(p.frontZ+1+p.backZ)/2,w=p.xmax-p.xmin-.28,d=p.frontZ+1-p.backZ-.28;
 // Thin soil finish above the underlying slab, without two coplanar surfaces.
 const pixels=new Uint8Array(128*128*4);let seed=613;
 for(let i=0;i<128*128;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const n=(seed/4294967296-.5)*24;pixels[i*4]=158+n;pixels[i*4+1]=132+n;pixels[i*4+2]=88+n;pixels[i*4+3]=255;}
 const tx=new T.DataTexture(pixels,128,128,T.RGBAFormat);tx.wrapS=tx.wrapT=T.RepeatWrapping;tx.repeat.set(5,4);tx.colorSpace=T.SRGBColorSpace;tx.needsUpdate=true;
 const soil=new T.Mesh(new T.BoxGeometry(w,.035,d),new T.MeshStandardMaterial({color:'#ffffff',map:tx,roughness:1}));soil.position.set(cx,.055,cz);soil.name='earth-surface';soil.receiveShadow=true;g.add(soil);
 const metal='#70292b',bar='#70292b',ground=.0725;
 for(const x of [cx-w/2,cx+w/2])k.box(.12,.12,d+.12,x,.06,cz,'#b8b8aa');
 for(const z of [cz-d/2,cz+d/2])k.box(w-.12,.12,.12,cx,.06,z,'#b8b8aa');
 let anchorX=p.xmin+1.85;
 const tube=(a,b,r,color)=>{const vector=new T.Vector3().subVectors(b,a),mesh=k.solid(new T.CylinderGeometry(r,r,vector.length(),12),color,'exercise-steel-tube');mesh.position.copy(a).add(b).multiplyScalar(.5);mesh.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),vector.normalize());mesh.userData.walkRole='barrier';};
 const v=(x,y,z)=>new T.Vector3(anchorX+(z-cz),y+ground,cz-(x-anchorX));
 // R37 owner correction: bar axes perpendicular to accordion frontage (world Z).
 const pullX=p.xmin+1.85,pullZ=cz;
 for(const side of [-1,1]){const x=pullX+side*1.04;tube(v(x,0,pullZ),v(x,2.35,pullZ),.045,metal);k.box(.24,.08,.24,v(x,0,pullZ).x,.10,v(x,0,pullZ).z,'#969b90');}
 tube(v(pullX-1.04,2.35,pullZ),v(pullX+1.04,2.35,pullZ),.025,bar);
 const doubleX=p.xmax-1.85;anchorX=doubleX;
 for(const side of [-1,1]){const z=cz+side*.32;for(const end of [-1,1]){const x=doubleX+end*1.12;tube(v(x,0,z),v(x,1.25,z),.034,metal);k.box(.19,.07,.19,v(x,0,z).x,.105,v(x,0,z).z,'#969b90');}tube(v(doubleX-1.28,1.25,z),v(doubleX+1.28,1.25,z),.028,bar);}
 g.add(createExerciseNPC({x:doubleX,z:cz,barY:1.25+ground}));k.finish();g.userData={ownerAuthorized:true,ground:'earth',apparatus:['pull-up-bar','parallel-bars'],axesPerpendicularTo:'accordion-frontage-X',projectsForward:1,curbHeight:.12,historicalAccuracy:'owner-directed-addition'};return g;
}
