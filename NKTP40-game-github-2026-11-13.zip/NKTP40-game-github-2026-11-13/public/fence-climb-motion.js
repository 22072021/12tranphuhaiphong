import * as T from './vendor/three.module.js';
import {applyLadderPose} from './ladder-motion.js';
const smooth=t=>{t=T.MathUtils.clamp(t,0,1);return t*t*t*(t*(t*6-15)+10);};
const lerp=T.MathUtils.lerp,cache=new WeakMap(),up=new T.Vector3(0,1,0),down=new T.Vector3(0,-1,0);
export const FENCE_CLIMB_DURATION=12;
function rig(student){let r=cache.get(student);if(r)return r;r={};for(const side of ['left','right']){const j=student.joints,hand=j[side+'Elbow'].children.find(o=>o.isBone),mesh=hand.children.find(o=>o.isMesh);mesh.geometry.computeBoundingBox();const palm=mesh.geometry.boundingBox.getCenter(new T.Vector3());r[side]={hand,palm,arm1:j[side+'Elbow'].position.length(),arm2:hand.position.length()-palm.y};}cache.set(student,r);return r;}
// Analytic 3D two-bone IK: the pole chooses the natural knee/elbow bend plane.
function solve(upper,lower,target,pole,l1,l2){
 const p=upper.parent.worldToLocal(target.clone()).sub(upper.position),distance=T.MathUtils.clamp(p.length(),.005,l1+l2-.00001),dir=p.clone().normalize();
 const poleLocal=upper.parent.worldToLocal(pole.clone()).sub(upper.position),bend=poleLocal.addScaledVector(dir,-poleLocal.dot(dir)).normalize();
 if(bend.lengthSq()<.1)bend.set(1,0,0).addScaledVector(dir,-dir.x).normalize();
 const along=(l1*l1+distance*distance-l2*l2)/(2*distance),off=Math.sqrt(Math.max(0,l1*l1-along*along)),joint=dir.clone().multiplyScalar(along).addScaledVector(bend,off),first=joint.clone().normalize();
 const y=first.clone().negate(),x=new T.Vector3().crossVectors(first,bend).normalize(),z=new T.Vector3().crossVectors(x,y).normalize();
 upper.quaternion.setFromRotationMatrix(new T.Matrix4().makeBasis(x,y,z));
 const second=dir.multiplyScalar(distance).sub(joint).normalize().applyQuaternion(upper.quaternion.clone().invert());lower.quaternion.setFromUnitVectors(down,second);
 upper.updateWorldMatrix(true,true);return Math.max(0,p.length()-l1-l2);
}
function snapshot(root,j){return{p:root.position.clone(),q:root.quaternion.clone(),j:Object.fromEntries(Object.entries(j).map(([k,o])=>[k,{p:o.position.clone(),q:o.quaternion.clone()}]))};}
function blendPose(root,j,a,b,t){root.position.lerpVectors(a.p,b.p,t);root.quaternion.slerpQuaternions(a.q,b.q,t);for(const[k,o]of Object.entries(j)){o.position.lerpVectors(a.j[k].p,b.j[k].p,t);o.quaternion.slerpQuaternions(a.j[k].q,b.j[k].q,t);}root.updateMatrixWorld(true);}
// Preview only: no changes to live visitor traversal, collisions or permissions.
export function applyFenceClimb(student,time,{height=3.08}={}){
 const root=student.root,j=student.joints,t=T.MathUtils.clamp(time,0,FENCE_CLIMB_DURATION),baseHip=.726,r=rig(student);
 const ascentEnd=4.3,transferEnd=7.5,descentEnd=11.4,high=height-.72;
 function ladder(downward,u){student.update(0,'idle');root.rotation.set(0,0,0);const y=high*(downward?1-smooth(u):smooth(u)),yaw=downward?Math.PI:0;
  const spec={x:0,z:-.20,bottom:-.25,top:height+.08,exitSide:1,exit:{x:0,y:height,z:.4}};
  applyLadderPose(root,student,{x:0,z:downward?.40:-.40,feet:y,climbYaw:yaw,climbFrame:{spec,matrix:new T.Matrix4().makeRotationY(yaw),height:y,rungs:13,stage:downward&&u>.9?'approach':'climb',progress:downward&&u>.9?1-smooth((u-.9)/.1):u}},baseHip);
  if(downward)root.position.z+=.14*smooth((u-.9)/.1);
 }
 let phase,progress,contacts=null;
 if(t<ascentEnd||t>=transferEnd&&t<descentEnd){const descending=t>=transferEnd,u=descending?(t-transferEnd)/(descentEnd-transferEnd):t/ascentEnd;ladder(descending,u);phase=descending?'Hạ người vào sân':'Bám rào và leo lên';progress=u;
 }else if(t<transferEnd){
  const u=(t-ascentEnd)/(transferEnd-ascentEnd),travel=smooth(u),swing=Math.sin(Math.PI*travel);phase='Hai tay giữ rào · thân và hai chân duỗi cùng vung qua';progress=u;
  ladder(false,1);const a=snapshot(root,j);ladder(true,0);const b=snapshot(root,j);blendPose(root,j,a,b,travel);
  // Lean sideways around the planted hands; both legs follow the same swing.
  const weight=smooth(u/.20)*(1-smooth((u-.80)/.20));
  const tilt=1.70*swing,arc=lerp(-.80,.80,travel),legDirection=new T.Vector3(Math.sin(tilt)*Math.cos(arc),-Math.cos(tilt),Math.sin(tilt)*Math.sin(arc));
  // +Z is the chest: project world-down onto the plane normal to the body axis.
  // This prevents the old axial yaw from rolling the belly upward midway over the rail.
  const bodyUp=legDirection.clone().negate(),chest=down.clone().addScaledVector(bodyUp,-down.dot(bodyUp));
  if(chest.lengthSq()<1e-8)chest.set(0,0,travel<.5?1:-1);chest.normalize();
  const bodyRight=new T.Vector3().crossVectors(bodyUp,chest).normalize();
  root.quaternion.setFromRotationMatrix(new T.Matrix4().makeBasis(bodyRight,bodyUp,chest));
  j.pelvis.position.y=baseHip-.10;j.pelvis.rotation.set(0,0,0);j.torso.rotation.set(0,0,0);j.head.rotation.set(.08,0,0);root.updateMatrixWorld(true);
  const shoulderMid=j.leftShoulder.getWorldPosition(new T.Vector3()).add(j.rightShoulder.getWorldPosition(new T.Vector3())).multiplyScalar(.5);
  const desired=new T.Vector3(-.12*swing,height+.22,lerp(-.24,.24,travel));root.position.add(desired.sub(shoulderMid));root.updateMatrixWorld(true);
  // Legs stay almost straight along the torso. No foot-target IK that folds knees backwards.
  for(const side of ['left','right']){
   j[side+'Hip'].rotation.set(0,0,0);j[side+'Knee'].rotation.set(.035,0,0);j[side+'Ankle'].rotation.set(-.035,0,0);
  }
  root.updateMatrixWorld(true);
  const custom=snapshot(root,j);blendPose(root,j,a,b,travel);const baseline=snapshot(root,j);blendPose(root,j,baseline,custom,weight);
  // Keep the actual palm (not just the wrist origin) fixed on the same rail.
  const targets=[];for(const[i,side]of ['left','right'].entries()){
   const sign=i?-1:1,arm=r[side],handTarget=new T.Vector3(sign*.165,height+.015,0),pole=new T.Vector3(sign*.50,height+.12,root.position.z);
   const beforeUpper=j[side+'Shoulder'].quaternion.clone(),beforeLower=j[side+'Elbow'].quaternion.clone();
   const reachError=solve(j[side+'Shoulder'],j[side+'Elbow'],handTarget,pole,arm.arm1,arm.arm2);
   j[side+'Shoulder'].quaternion.slerpQuaternions(beforeUpper,j[side+'Shoulder'].quaternion.clone(),weight);j[side+'Elbow'].quaternion.slerpQuaternions(beforeLower,j[side+'Elbow'].quaternion.clone(),weight);root.updateMatrixWorld(true);
   const palm=arm.hand.localToWorld(arm.palm.clone());targets.push({side,target:handTarget.toArray(),palm:palm.toArray(),error:palm.distanceTo(handTarget),reachError});
  }contacts={weight,targets};
 }else{
  const u=smooth((t-descentEnd)/(FENCE_CLIMB_DURATION-descentEnd));student.update(0,'idle');phase='Tiếp đất trong sân';progress=u;root.position.set(0,0,lerp(.47,.80,u));root.rotation.set(0,Math.PI,0);j.pelvis.position.y=baseHip-.06*Math.sin(Math.PI*u);
  for(const side of ['left','right']){j[side+'Hip'].rotation.x=-.15*Math.sin(Math.PI*u);j[side+'Knee'].rotation.x=.3*Math.sin(Math.PI*u);j[side+'Ankle'].rotation.x=-.15*Math.sin(Math.PI*u);}
 }
 root.updateMatrixWorld(true);root.userData.fenceClimb={phase,progress,time:t,contacts};return root.userData.fenceClimb;
}
