import {ENTRANCE} from './entrance-layout.js';
import {auxiliaryGatePlan} from './entrance-side-gates.js';
// Fence bay beside the double auxiliary gate at the fish-noodle stall.
const lo=ENTRANCE.fence.from,hi=ENTRANCE.fence.to,bays=Math.max(9,Math.round((hi-lo)/3.2));
const gate=auxiliaryGatePlan(lo,hi,bays).find(g=>g.id==='noodle-side-double-gate');
export const FENCE_CLIMB={x:ENTRANCE.x,z:ENTRANCE.z+gate.z+gate.width/2+.65,height:3.40,distance:.60};
export function fenceClimbPoint(side){return{x:FENCE_CLIMB.x+side*FENCE_CLIMB.distance,z:FENCE_CLIMB.z};}
