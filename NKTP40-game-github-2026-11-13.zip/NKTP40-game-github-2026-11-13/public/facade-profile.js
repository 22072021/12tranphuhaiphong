// Ratios read after a four-point perspective correction of the named photographs.
// They describe visible facade proportions, not surveyed building dimensions.
export const FACADE_PROFILES={
 A1:{coreCentre:.5055,coreSpan:.1003,bays:9,source:'DSC_1780.JPG'},
 A2:{coreCentre:6.5/15,coreSpan:1.2/15,bays:15,source:'DSC_1788.JPG'},
 B1:{coreCentre:.5,coreSpan:1.5/13.5,bays:13,source:'DSC_1779.JPG'},
 B2:{coreCentre:.5,coreSpan:1.2/13.2,bays:13,source:'DSC_1801.JPG'}
};
