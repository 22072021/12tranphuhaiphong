import {applyA2ClassroomFloor} from './a2-classroom-floor.js?v=214.0';
import * as THREE from './vendor/three.module.js';
// Patterns traced as repeatable geometric motifs from P16, P26/P61 and P41.
// Tile pitches and colours remain estimates; no photo shadows are baked in.
export const TILE_DESIGNS={
 'a2-octagon':{pitch:.40,source:['user-image-drive-1B5zBcF9w5ULe6BWRp4B62euIO_O31c8k'],name:'A2 · gạch đỏ vàng bốn ô trắng'},
 'a1-star':{pitch:.40,source:['P16','user-image-drive-17iZ7JgD1yvf8iS2mJjag_FyNhVcaSG6b'],name:'Gạch đỏ hình học, sao tám cánh và dải viền'},
 'a1-border':{pitch:.24,source:['user-image-drive-17iZ7JgD1yvf8iS2mJjag_FyNhVcaSG6b'],name:'Viền gạch ô van'},
 'b1-flower':{pitch:.40,source:['P41'],name:'B1 · hoa tám cánh trong vòng tròn, dây lá ở góc'},
 'octagon-cross':{pitch:.18,source:['P26','P61'],name:'A2/B2 · ô tám cạnh xen màu và cụm bốn ô trắng'}
};
export const corridorPattern=id=>id==='B1'?'a2-aged-floral':id==='A1'?'a1-star':id==='A2'||id==='B2'||id==='WC'?'a2-octagon':id==='B1'?'b1-flower':'octagon-cross';
const textures=new Map(),rgb=hex=>hex.match(/\w\w/g).map(x=>parseInt(x,16));
const C={cream:rgb('d8c6a1'),white:rgb('e4dfcf'),red:rgb('ac6b45'),gold:rgb('c5a366'),line:rgb('96674b'),gray:rgb('99917c'),a1red:rgb('a86b4d'),a1line:rgb('81533e'),a1cream:rgb('dfc7a2'),a1star:rgb('ead4ae'),a1dark:rgb('a56747'),a1light:rgb('e0c49b'),a1edge:rgb('805440')};
export function tilePixel(style,x,y){
 const u=x-Math.floor(x),v=y-Math.floor(y),a=u-.5,b=v-.5,r=Math.hypot(a,b),t=Math.atan2(b,a),edge=Math.min(u,1-u,v,1-v);
 let color=C.cream;
 if(style==='octagon-cross'||style==='a2-octagon'){
  const cut=Math.abs(a)+Math.abs(b)>.79;
  color=cut?C.gray:((Math.floor(x)+Math.floor(y))%2?C.gold:C.red);
  // Four pale square tesserae around each junction, separated by a thin cross.
  const qx=Math.min(u,1-u),qy=Math.min(v,1-v);
  if(qx>.017&&qx<.096&&qy>.017&&qy<.096)color=C.white;
  if(edge<.006)color=C.line;
 }else if(style==='b1-flower'){
  if(r>.420&&r<.443)color=C.line;
  if(r<.415){color=C.white;const petal=.275+.092*Math.cos(8*t);if(r<petal&&r>.09)color=C.red;if(r<.065)color=C.gold;}
  const corner=Math.hypot(.5-Math.abs(a),.5-Math.abs(b));
  if(corner<.26&&corner>.22)color=C.red;
  if(corner<.18&&Math.cos(4*t)>.35)color=C.gold;
  if(edge<.006)color=C.line;
 }else if(style==='a1-border'){
  color=C.a1red;
  if(u<.10||u>.90)color=C.a1line;
  if(u>.11&&u<.20||u>.80&&u<.89)color=C.a1cream;
  const yy=(v*2)%1, oval=Math.hypot((u-.5)/.26,(yy-.43)/.34),dot=Math.hypot((u-.5)/.10,(yy-.88)/.12);
  if(oval<1.10||dot<1.12)color=C.a1line;
  if(oval<.91||dot<.90)color=C.a1cream;
 }else{
  // Geometric interpretation of the supplied reference: interlaced cream
  // lozenges and terracotta eight-point stars on a 2 by 2 tile repeat.
  color=C.a1red;
  const ax=Math.abs(a),ay=Math.abs(b),cross=Math.abs(ax+ay-.50);
  if(cross<.12)color=C.a1cream;
  const dx=Math.min(Math.hypot((a-.43)/.19,(b-.43)/.11),Math.hypot((a+.43)/.19,(b-.43)/.11),Math.hypot((a-.43)/.19,(b+.43)/.11),Math.hypot((a+.43)/.19,(b+.43)/.11));
  if(dx<1.12)color=C.a1line;if(dx<.94)color=C.a1cream;
  const theta=Math.atan2(b,a),star= .18+.065*Math.cos(8*theta);
  if(r<star+.018)color=C.a1line;if(r<star)color=C.a1cream;
  const inner=.095+.050*Math.cos(8*theta);if(r<inner)color=C.a1dark;
  if(Math.abs(u-.5)<.004||Math.abs(v-.5)<.004||edge<.004)color=C.a1edge;

 }
 return color;
}
export function corridorTexture(style='octagon-cross'){
 if(textures.has(style))return textures.get(style);
 // Browser uses the actual user-supplied image crops. The generated fallback
 // only supports non-browser geometry and collision tests.
 if(typeof document!=='undefined'&&(style==='a1-star'||style==='a1-border'||style==='a2-octagon')){
  const url=style==='a2-octagon'?new URL('./assets/tiles/a2-octagon-field.webp',import.meta.url).href:style==='a1-star'?new URL('./assets/tiles/a1-terracotta-field.webp',import.meta.url).href:new URL('./assets/tiles/a1-terracotta-border.png',import.meta.url).href;
  const texture=new THREE.TextureLoader().load(url);texture.colorSpace=THREE.SRGBColorSpace;texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.generateMipmaps=true;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;texture.anisotropy=8;texture.userData={style,pitch:TILE_DESIGNS[style].pitch,repeat:1,source:'original-user-image'};textures.set(style,texture);return texture;
 }
 const size=512,repeat=style==='octagon-cross'?2:1,data=new Uint8Array(size*size*4);
 for(let y=0;y<size;y++)for(let x=0;x<size;x++){const c=tilePixel(style,(x+.5)/size*repeat,(y+.5)/size*repeat),i=(y*size+x)*4;data.set(c,i);data[i+3]=255;}
 const texture=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);texture.colorSpace=THREE.SRGBColorSpace;texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.generateMipmaps=true;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;texture.anisotropy=8;texture.needsUpdate=true;texture.userData={style,pitch:TILE_DESIGNS[style].pitch,repeat};textures.set(style,texture);return texture;
}
export function applyCorridorTiles(material,profile={}){if(profile.floorPattern==='a2-aged-floral'){applyA2ClassroomFloor(material);return material;}
 const style=profile.floorPattern||'octagon-cross',texture=corridorTexture(style),size=texture.userData.pitch*texture.userData.repeat;
 // A small depth bias also separates tiles from nearly flush structural backing.
 material.polygonOffset=true;material.polygonOffsetFactor=0;material.polygonOffsetUnits=-2;
 material.onBeforeCompile=shader=>{
  shader.uniforms.corridorTileMap={value:texture};shader.uniforms.corridorTileSize={value:size};
  if(style==='a1-star'&&profile.floorOuterLimit){shader.uniforms.floorOuterLimit={value:profile.floorOuterLimit.limit};shader.uniforms.floorOuterSide={value:profile.floorOuterLimit.side};}
  if(style==='a1-star'&&profile.corridorEdges){shader.uniforms.corridorBorderMap={value:corridorTexture('a1-border')};shader.uniforms.corridorEdges={value:new THREE.Vector2(...profile.corridorEdges)};}
  shader.vertexShader='varying vec3 vTilePosition;\n'+shader.vertexShader;
  shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
   vec4 tilePoint=vec4(position,1.0);
   #ifdef USE_INSTANCING
    tilePoint=instanceMatrix*tilePoint;
   #endif
   vTilePosition=tilePoint.xyz;`);
  shader.fragmentShader='varying vec3 vTilePosition; uniform sampler2D corridorTileMap; uniform float corridorTileSize;\n'+(style==='a1-star'&&profile.corridorEdges?'uniform sampler2D corridorBorderMap; uniform vec2 corridorEdges;\n':'')+(style==='a1-star'&&profile.floorOuterLimit?'uniform float floorOuterLimit; uniform float floorOuterSide;\n':'')+shader.fragmentShader;
  shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
   diffuseColor.rgb=texture2D(corridorTileMap,vTilePosition.xz/corridorTileSize).rgb;
   ${style==='a1-star'&&profile.corridorEdges?'float bd=min(abs(vTilePosition.x-corridorEdges.x),abs(vTilePosition.x-corridorEdges.y)); if(bd<0.12) diffuseColor.rgb=texture2D(corridorBorderMap,vec2((vTilePosition.x-(abs(vTilePosition.x-corridorEdges.x)<abs(vTilePosition.x-corridorEdges.y)?corridorEdges.x:corridorEdges.y))/0.24+0.5,vTilePosition.z/0.24)).rgb;':''}
   ${style==='a1-star'&&profile.floorOuterLimit?'if(vTilePosition.x*floorOuterSide>floorOuterLimit) diffuseColor.rgb=vec3(0.70,0.67,0.59);':''}`);
 };
 material.customProgramCacheKey=()=> 'nktp-corridor-tiles-v108-'+style+(profile.corridorEdges?'-border-'+profile.corridorEdges.join(','):'');
 material.userData.surface='photo-referenced-corridor-tiles';material.userData.floorPattern=style;material.userData.tileSources=TILE_DESIGNS[style].source;return material;
}
