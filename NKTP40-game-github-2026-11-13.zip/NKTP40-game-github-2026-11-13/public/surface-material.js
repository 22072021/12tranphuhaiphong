import {applyCorridorTiles} from './corridor-tiles.js?v=222.0';
import {applyCeilingFinish} from './ceiling-finish.js?v=49.0';
import * as THREE from './vendor/three.module.js';

// Deterministic surface variation. These are material cues, not claims about
// the location of individual stains or damage in the historical photographs.
export function surfaceMaterial(color,profile={}){return applyCeilingFinish(createSurfaceMaterial(color,profile),color,profile.whiteUnderside);}
function createSurfaceMaterial(color,profile={}){
 const material=new THREE.MeshStandardMaterial({color,roughness:.94});
 if(['#b77d80','#c5af83','#865f69','#b6a19f','#c4bca3'].includes(color.toLowerCase())){
  material.onBeforeCompile=shader=>{
   shader.vertexShader='varying vec3 vStonePosition;\n'+shader.vertexShader;
   shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
    vec4 stonePoint=vec4(position,1.0);
    #ifdef USE_INSTANCING
     stonePoint=instanceMatrix*stonePoint;
    #endif
    vStonePosition=stonePoint.xyz;`);
   shader.fragmentShader='varying vec3 vStonePosition;\n'+shader.fragmentShader;
   shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
    vec3 cell=floor(vStonePosition*190.0);
    float speckle=fract(sin(dot(cell,vec3(12.9898,78.233,37.719)))*43758.5453);
    diffuseColor.rgb*=.94+.10*speckle;
    diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.80,.76,.65),smoothstep(.955,.99,speckle)*.30);
   `);
  };material.customProgramCacheKey=()=> 'nktp-admin-pink-yellow-terrazzo-v37';return material;
 }
 if(color.toLowerCase()==='#bb9271')return applyCorridorTiles(material,profile);
 const masonry=['#dec17a','#eee2bc','#e4dfcd','#e5e8df','#b8c6a4','#f0ede3','#f3efe5'].includes(color.toLowerCase());
 const glass=['#567e98'].includes(color.toLowerCase());
 if(glass){material.color.set('#526571');material.roughness=.24;material.metalness=.28;}
 if(!masonry||!profile.height)return material;
 material.onBeforeCompile=shader=>{
  shader.uniforms.surfaceHeight={value:profile.height};
  shader.uniforms.surfaceStorey={value:profile.storey||profile.height};
  shader.vertexShader='varying vec3 vSurfacePosition;\n'+shader.vertexShader;
  shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
   vec4 surfacePoint=vec4(position,1.0);
   #ifdef USE_INSTANCING
    surfacePoint=instanceMatrix*surfacePoint;
   #endif
   vSurfacePosition=surfacePoint.xyz;`);
  shader.fragmentShader=`varying vec3 vSurfacePosition;
   uniform float surfaceHeight; uniform float surfaceStorey;
   float surfaceHash(vec3 p){return fract(sin(dot(p,vec3(12.9898,78.233,37.719)))*43758.5453);}
   float surfaceNoise(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);
    return mix(mix(mix(surfaceHash(i),surfaceHash(i+vec3(1,0,0)),f.x),mix(surfaceHash(i+vec3(0,1,0)),surfaceHash(i+vec3(1,1,0)),f.x),f.y),mix(mix(surfaceHash(i+vec3(0,0,1)),surfaceHash(i+vec3(1,0,1)),f.x),mix(surfaceHash(i+vec3(0,1,1)),surfaceHash(i+vec3(1,1,1)),f.x),f.y),f.z);}
  `+shader.fragmentShader;
  shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
   vec3 p=vSurfacePosition;
   float grain=surfaceNoise(p*36.0);
   float mottling=surfaceNoise(p*2.3)*0.6+surfaceNoise(p*7.0)*0.4;
   float streak=surfaceNoise(vec3(p.x*9.0,p.y*0.32,p.z*9.0));
   float floorDistance=surfaceStorey-mod(max(0.0,p.y),surfaceStorey);
   float ledge=exp(-floorDistance*3.0)+exp(-abs(p.y-surfaceHeight)*2.3);
   float risingDamp=exp(-max(p.y,0.0)*2.5);
   float grime=clamp(ledge*(0.13+0.6*smoothstep(0.38,0.72,streak))+risingDamp*(0.13+0.30*mottling),0.0,0.7);
   grime*= ${Number(profile.weatheringScale??1).toFixed(3)};
   diffuseColor.rgb*=0.93+0.09*grain+0.08*(mottling-0.5);
   diffuseColor.rgb=mix(diffuseColor.rgb,${['#f0ede3','#f3efe5'].includes(color.toLowerCase())?'vec3(0.29,0.28,0.26)':'vec3(0.16,0.18,0.14)'},grime);
   float flaking=smoothstep(0.79,0.88,mottling)*0.36;
   diffuseColor.rgb=mix(diffuseColor.rgb,vec3(0.69,0.66,0.55),flaking);
  `);
 };
 material.customProgramCacheKey=()=>`nktp-stucco-v23-${profile.height}-${profile.storey}-${profile.weatheringScale??1}`;
 material.userData.surface='weathered-stucco-estimated';
 return material;
}
