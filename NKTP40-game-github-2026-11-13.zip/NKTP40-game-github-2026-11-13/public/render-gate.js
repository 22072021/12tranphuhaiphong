// Keep the live visitor animated; let static overview frames sleep on the GPU.
export function createRenderGate(){
 let dirty=true,signature='',pending=[];
 return {invalidate(roots=[]){dirty=true;if(roots.length)pending=[];for(const root of roots.filter(Boolean))root.traverse(o=>{for(const m of Array.isArray(o.material)?o.material:[o.material])if(m)for(const t of [m.map,m.normalMap,m.roughnessMap,m.alphaMap])if(t?.isTexture&&!t.image)pending.push(t);});},
 shouldRender(camera,width,height,animated=false){for(let i=pending.length-1;i>=0;i--)if(pending[i].image){pending.splice(i,1);dirty=true;}
 const next=[...camera.position.toArray(),...camera.quaternion.toArray(),...camera.projectionMatrix.elements,width,height].join(',');const changed=next!==signature;signature=next;const draw=animated||dirty||changed;dirty=false;return draw;}};
}
