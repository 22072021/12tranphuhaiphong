import {addBasketballCourt} from './basketball-court.js';
import * as T from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js';
export function createHeritageBasketball(layout){
 const b=layout.buildings.find(b=>b.id==='TRADITION'),g=new T.Group();g.name='heritage-side-basketball';if(!b)return g;
 g.position.set(b.x+2,0,b.z+b.length/2+3.1);const k=geometryKit(g),white='#e2e2d8';
 k.box(.70,.12,.9,0,.06,-.65,'#a9aaa0');k.beam(new T.Vector3(0,.12,-.65),new T.Vector3(0,3.5,.35),.09,white);
 for(const side of [-1,1])k.beam(new T.Vector3(side*.4,.12,-1),new T.Vector3(side*.67,3.20,.40),.035,white);
 k.box(1.8,1.05,.055,0,3.55,.44,white);
 k.withCollision('none',()=>{for(const x of [-.84,.84])k.box(.018,.98,.008,x,3.55,.474,'#565954');for(const y of [3.06,4.04])k.box(1.70,.018,.008,0,y,.474,'#565954');for(const x of [-.295,.295])k.box(.018,.45,.008,x,3.33,.482,'#555852');for(const y of [3.105,3.555])k.box(.59,.018,.008,0,y,.482,'#555852');});
 const rim=new T.Mesh(new T.TorusGeometry(.225,.016,8,48),new T.MeshStandardMaterial({color:'#ad5136',roughness:.7}));rim.rotation.x=Math.PI/2;rim.position.set(0,3.05,.70);rim.userData.walkRole='none';g.add(rim);
 k.withCollision('none',()=>{k.box(.15,.025,.12,0,3.05,.51,'#ad5136');for(let j=0;j<12;j++){const a=j*Math.PI/6,points=[];for(let r=0;r<4;r++){const yy=3.04-r*.12,rad=.22-r*.032,aa=a+(r%2?.14:0);points.push(new T.Vector3(Math.cos(aa)*rad,yy,.70+Math.sin(aa)*rad));}for(let r=1;r<4;r++)k.beam(points[r-1],points[r],.006,'#deded2');}for(let r=1;r<4;r++){const ring=new T.Mesh(new T.TorusGeometry(.22-r*.032,.0035,4,32),new T.MeshBasicMaterial({color:'#deded2'}));ring.rotation.x=Math.PI/2;ring.position.set(0,3.04-r*.12,.70);ring.userData.walkRole='none';g.add(ring);}});
 k.finish();addBasketballCourt(g);g.userData.source='P48: detached basketball assembly beside heritage building';return g;
}
