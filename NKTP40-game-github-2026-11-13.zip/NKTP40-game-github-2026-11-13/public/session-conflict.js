export function showSessionConflict(container){
 if(container.querySelector('[data-session-conflict]'))return;
 const overlay=document.createElement('div');overlay.dataset.sessionConflict='true';overlay.setAttribute('role','alertdialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','Tài khoản đang được sử dụng');
 Object.assign(overlay.style,{position:'fixed',inset:'0',zIndex:'10000',display:'grid',placeItems:'center',background:'#18382de0',padding:'24px',color:'#1d4035',font:'16px system-ui'});
 const box=document.createElement('div');Object.assign(box.style,{background:'#fffdf5',borderRadius:'18px',padding:'28px',maxWidth:'430px',lineHeight:'1.6'});
 const title=document.createElement('h2');title.textContent='Tài khoản đang chơi ở tab khác';title.style.fontSize='21px';
 const text=document.createElement('p');text.textContent='Bạn hãy quay lại tab đang chơi. Nếu muốn chơi tại đây, hãy đóng tab kia rồi bấm Thử lại.';
 const button=document.createElement('button');button.textContent='Thử lại';Object.assign(button.style,{background:'#205c49',color:'white',border:'0',borderRadius:'10px',padding:'12px 22px',font:'inherit',cursor:'pointer'});button.onclick=()=>location.reload();box.append(title,text,button);overlay.append(box);container.append(overlay);window.dispatchEvent(new Event('blur'));button.focus();
}
