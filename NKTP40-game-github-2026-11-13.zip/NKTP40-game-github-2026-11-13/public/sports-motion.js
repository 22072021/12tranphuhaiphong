// One anatomical pose track for both controllable avatars and sports NPCs.
const ease=t=>t*t*(3-2*t);
function track(t,keys){for(let i=1;i<keys.length;i++)if(t<=keys[i][0]){const [a,x]=keys[i-1],[b,y]=keys[i];return x+(y-x)*ease((t-a)/(b-a));}return keys.at(-1)[1];}
export function applySportsMotion(j,{kind,swing=0,anticipation=0}){
 const active=swing>0,t=1-Math.min(1,Math.max(0,swing)),v=keys=>active?track(t,keys):0;
 for(const key of ['torso','head','leftShoulder','rightShoulder','leftElbow','rightElbow','leftHip','rightHip','leftKnee','rightKnee','leftAnkle','rightAnkle'])j[key]?.rotation.set(0,0,0);
 const r=(key,x=0,y=0,z=0)=>j[key]?.rotation.set(x,y,z);
 if(kind==='shuttlecock'){
  // Supporting leg stays planted; the other leg folds, swings from the hip,
  // extends at contact, then retracts. Arms never strike the shuttle.
  const hip=v([[0,.15],[.24,-.58],[.43,-1.20],[.65,-.65],[1,0]]),knee=v([[0,.08],[.24,1.12],[.43,.32],[.65,.75],[1,0]]);
  r('rightHip',hip,0,.10);r('rightKnee',knee);r('rightAnkle',v([[0,0],[.43,.35],[.65,.12],[1,0]]));r('leftKnee',.07+anticipation*.08);r('leftHip',-.07);
  r('torso',v([[0,0],[.43,-.12],[1,0]]),v([[0,0],[.43,-.12],[1,0]]),.035);
  r('leftShoulder',.08,0,.16);r('rightShoulder',.06,0,-.18);r('leftElbow',-.18);r('rightElbow',-.20);
 }else if(kind==='basketball'){
  const lift=v([[0,.45],[.28,1.6],[.46,2.4],[.65,2.1],[1,.45]]);r('leftShoulder',-.35-lift,0,.1);r('rightShoulder',-.35-lift,0,-.1);
  const elbow=v([[0,-.3],[.28,-1.05],[.46,-.12],[.65,-.16],[1,-.3]]);r('leftElbow',elbow);r('rightElbow',elbow);r('leftKnee',.10);r('rightKnee',.10);r('leftHip',-.10);r('rightHip',-.10);
 }else{
  const overhead=kind==='badminton';
  r('leftHip',-.10);r('rightHip',-.16);r('leftKnee',.10);r('rightKnee',.16);
  r('rightShoulder',overhead?v([[0,-.45],[.25,-2.35],[.44,-2.05],[.7,-.65],[1,-.45]]):v([[0,-.55],[.25,-.8],[.44,-1.0],[.7,-.45],[1,-.55]]),v([[0,0],[.25,-.45],[.44,.2],[.7,.5],[1,0]]),-.12);
  r('rightElbow',v([[0,-.4],[.25,-1.25],[.44,-.15],[.7,-.45],[1,-.4]]));r('leftShoulder',-.25,0,.20);r('leftElbow',-.55);
  r('torso',.06,v([[0,0],[.25,-.25],[.44,.1],[.7,.28],[1,0]]));
 }
}
