// One-off event, Vietnam time UTC+7. Shared with the read-only server clock endpoint.
export const FLAG_CEREMONY=Object.freeze({
 id:'flag-2026-11-09',enabled:true,
 prepareAt:Date.parse('2026-11-09T07:30:00+07:00'),
 startAt:Date.parse('2026-11-09T08:00:00+07:00'),
 endAt:Date.parse('2026-11-09T08:30:00+07:00'),
 tracks:[{title:'Quốc ca',url:'./audio/tien-quan-ca.mp3?v=flag1',duration:91.499683},{title:'Đoàn ca',url:'./audio/doan-ca.mp3?v=flag1',duration:61.209252}]
});
export function ceremonyPhase(now,plan=FLAG_CEREMONY){return !plan.enabled||now>=plan.endAt?'ended':now>=plan.startAt?'active':now>=plan.prepareAt?'preparing':'countdown';}
export function ceremonyTrack(now,plan=FLAG_CEREMONY){if(ceremonyPhase(now,plan)!=='active')return null;const total=plan.tracks.reduce((s,t)=>s+t.duration,0);let offset=((now-plan.startAt)/1000)%total;for(let index=0;index<plan.tracks.length;index++){const track=plan.tracks[index];if(offset<track.duration)return {index,offset,track};offset-=track.duration;}return null;}
export function ceremonyRemaining(ms){const t=Math.max(0,Math.ceil(ms/1000)),h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=t%60;return `${h?`${h} giờ `:''}${String(m).padStart(2,'0')} phút ${String(s).padStart(2,'0')} giây`;}
export function inCeremonyCourtyard(state,a1){return !!state&&!!a1&&state.x>=a1.x-42&&state.x<=a1.x-4&&Math.abs(state.z-a1.z)<=17&&state.feet<1.5;}
