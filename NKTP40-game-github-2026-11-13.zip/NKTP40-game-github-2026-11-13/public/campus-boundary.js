import {createAdminWaterNotice} from './admin-water-notice.js';
import {makeOpeningWall} from './wall-openings.js';
import {createStairDoor} from './interactive-door.js';
import {LEFT_INFILL} from './left-boundary-infill.js';
import {APPROVED_ADDITIONS} from './approved-additions-data.js';
import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
import {CAMPUS_GROUND_BOUNDS,CAMPUS_REAR} from './campus-limits.js';
import {ENTRANCE} from './entrance-layout.js?v=34.0';
export function campusBoundaryPlan(layout){
 const b1=layout.buildings.find(b=>b.id==='B1'),b2=layout.buildings.find(b=>b.id==='B2');if(!b1||!b2)return null;
 const outer=b=>{const a=-(b.rotation||0)*Math.PI/180,c=Math.cos(a),s=Math.sin(a),pts=[];for(const x of [-b.width/2,b.width/2])for(const z of [-b.length/2,b.length/2])pts.push({x:b.x+c*x-s*z,z:b.z+s*x+c*z});return {xmin:Math.min(...pts.map(p=>p.x)),xmax:Math.max(...pts.map(p=>p.x)),zmin:Math.min(...pts.map(p=>p.z)),zmax:Math.max(...pts.map(p=>p.z))};};
 const a=outer(b1),b=outer(b2),a2=outer(layout.buildings.find(v=>v.id==='A2')||b2),clearance=.65,north=Math.min(a.zmin,b.zmin)-clearance,east=CAMPUS_GROUND_BOUNDS.xmax-.12,south=Math.max(b.zmax,a2.zmax)+clearance;
 const points=[{x:LEFT_INFILL.innerX,z:north},{x:east,z:north},{x:east,z:south},{x:a2.xmax-.18,z:south},{x:a2.xmax-.18,z:a2.zmax-.18}];const returns=[[{x:(a.xmin+a.xmax)/2,z:north},{x:(a.xmin+a.xmax)/2,z:a.zmin+.18}]];const admin=layout.buildings.find(v=>v.id==='ADMIN'),water=APPROVED_ADDITIONS.find(v=>v.id==='D04');let southClosure=null;if(admin&&water){const angle=-(admin.rotation||0)*Math.PI/180,x=admin.width/2,z=-admin.length/2,end={x:admin.x+Math.cos(angle)*x-Math.sin(angle)*z,z:admin.z+Math.sin(angle)*x+Math.cos(angle)*z},start={x:water.x-water.width/2,z:water.z+water.length/2-.12},length=Math.hypot(end.x-start.x,end.z-start.z),overlap=.15,dx=(end.x-start.x)/length,dz=(end.z-start.z)/length;start.x-=dx*overlap;start.z-=dz*overlap;end.x+=dx*overlap;end.z+=dz*overlap;southClosure=[start,end];returns.push([start,end]);const roomCorner={x:admin.x+Math.cos(angle)*(x-2.25)-Math.sin(angle)*(z+.15),z:admin.z+Math.sin(angle)*(x-2.25)+Math.cos(angle)*(z+.15)};returns.push([end,roomCorner]);southClosure.returnEnd=roomCorner;const rearJoin=points.at(-1),waterRear={x:water.x+water.width/2-.12,z:water.z+water.length/2-.12};returns.push([rearJoin,waterRear]);}let wcWash=null;const wc=layout.buildings.find(v=>v.id==='WC');if(wc){const rear=outer(wc);wcWash={x:(b.xmax+rear.xmax)/2,z0:b.zmax-.02,z1:rear.zmin+.02,frontX:rear.xmin,wcFace:rear.zmin};returns.push([{x:b.xmax,z:b.zmax-.02},{x:rear.xmax,z:rear.zmin+.02}]);}const corridor=Math.min(2.25,b2.width*.22),lockedGate={x:b.xmin+corridor/2,z:north,width:corridor-.24,bottom:.45,height:2.2};return{points,returns,southClosure,lockedGate,wcWash,height:2.95,thickness:.24,fenceFrom:LEFT_INFILL.z-ENTRANCE.z,clearance,b2Bounds:b,a2Bounds:a2,rearX:east};
}
export function createCampusBoundary(plan){const g=new THREE.Group();g.name='campus-left-boundary';if(!plan)return g;g.add(createAdminWaterNotice(plan));const k=geometryKit(g),{points:p,height:h,thickness:t}=plan;
 const segments=p.slice(1).map((b,i)=>[p[i],b]).concat(plan.returns||[]);for(const [i,[a,b]]of segments.entries()){const dx=b.x-a.x,dz=b.z-a.z,len=Math.hypot(dx,dz),ry=Math.atan2(dx,dz);if(i===0&&plan.lockedGate){const q=plan.lockedGate,left=q.x-q.width/2,right=q.x+q.width/2,top=q.bottom+q.height;k.box(left-a.x,h,t,(a.x+left)/2,h/2,a.z,'#e3ca8c');k.box(b.x-right,h,t,(right+b.x)/2,h/2,a.z,'#e3ca8c');k.box(q.width,q.bottom,t,q.x,q.bottom/2,a.z,'#e3ca8c');k.box(q.width,h-top,t,q.x,(h+top)/2,a.z,'#e3ca8c');g.add(createLockedEndGate(q));}else if(plan.wcWash&&i===segments.length-1){const q=plan.wcWash,u=q.z0+1.35;makeOpeningWall(g,{side:1,wallX:q.x,faceV:0,from:q.z0,to:q.z1,height:h,color:'#e3ca8c',openings:[{kind:'door',u,y:1.55,width:2.3,height:2.2}]});const door=createStairDoor({side:1,wallX:q.x,u,y:1.55,v:0,width:2.26,height:2.16,color:'#285c43',single:false,grilled:true});door.name='WC-rear-green-passage-gate';door.userData.setOpen(true);delete door.userData.door;delete door.userData.animateDoor;door.userData.alwaysOpen=true;g.add(door);}else k.box(t,h,len,(a.x+b.x)/2,h/2,(a.z+b.z)/2,'#e3ca8c',0,ry);k.box(t+.08,.10,len,(a.x+b.x)/2,h+.05,(a.z+b.z)/2,'#eadbb3',0,ry);}
 if(plan.wcWash){const q=plan.wcWash,y=.45,start=q.z0+3.2,end=q.wcFace-.08,x=q.x-.15,white='#e4e6df',joint='#b5bab2';
 // Two wall-mounted tiled troughs meet at the inner corner; no solid countertop over basin.
 const arm=(length,cx,cz,angle)=>{const part=new THREE.Group();part.name='WC-white-tiled-wash-trough';part.position.set(cx,y,cz);part.rotation.y=angle;g.add(part);const k=geometryKit(part);
 k.box(.035,1.12,length,0,.56,0,white);k.box(.48,.10,length,-.24,.57,0,white);k.box(.045,.25,length,-.46,.70,0,white);for(const z of [-length/2,length/2])k.box(.48,.25,.035,-.24,.70,z,white);
 k.withCollision('none',()=>{for(const face of [-.023,.023]){for(let z=-length/2+.3;z<length/2;z+=.3)k.box(.008,1.12,.008,face,.56,z,joint);for(const yy of [.3,.6,.9])k.box(.008,.008,length,face,yy,0,joint);}for(let z=-length/2+.55;z<length/2-.2;z+=1.0){k.box(.06,.12,.06,-.08,.96,z,'#979f98');k.box(.17,.035,.045,-.16,.99,z,'#b8bdb5');}k.cylinder(.035,.12,-.25,.49,0,'#767e76');});k.finish();part.traverse(o=>{if(o.material&&o.material.color?.equals(new THREE.Color(white)))o.material.roughness=.22;});};
 arm(end-start,x,(start+end)/2,0);const length=Math.min(5.2,q.x-q.frontX-.5);arm(length,q.x-length/2-.15,q.wcFace-.15,-Math.PI/2);
 g.userData.wcWashing={shape:'L',gate:true,tiled:true};}
 // Solid piers seal corner seams; caps have no protrusions into the walkways.
 for(const a of p.slice(1,-1))k.box(t,h+.10,t,a.x,(h+.10)/2,a.z,'#e3ca8c');k.finish();g.userData.boundary=plan;return g;}

// A fixed grille and visible padlock; deliberately absent from automatic door controllers.
function createLockedEndGate(q){
 const g=new THREE.Group();g.name='B2-locked-end-gate';g.position.set(q.x,q.bottom,q.z);g.userData={locked:true,operable:false,opening:{width:q.width,height:q.height},basis:'Owner marked corridor-end gate 2026-11-04'};
 const k=geometryKit(g),steel='#294b42',frame=.065,depth=.07;
 for(const x of [-q.width/2,q.width/2])k.box(frame,q.height,depth,x,q.height/2,0,steel);
 for(const y of [.035,q.height-.035])k.box(q.width,frame,depth,0,y,0,steel);
 k.box(.045,q.height-.10,.055,0,q.height/2,0,steel);
 for(const y of [.48,1.15,1.85])k.box(q.width-.08,.035,.045,0,y,.006,steel);
 const count=Math.ceil((q.width-.12)/.12);for(let i=1;i<count;i++)k.box(.022,q.height-.12,.028,-q.width/2+.06+i*(q.width-.12)/count,q.height/2,.005,steel);
 k.withCollision('none',()=>{k.box(.28,.045,.045,.015,1.06,-.075,'#76827a');k.box(.085,.11,.045,.035,.99,-.105,'#b9a66d');k.ring(.045,.035,1.065,-.10,'#a9aaa0',0);for(const x of [-q.width/2+.035,q.width/2-.035])for(const y of [.28,1.92])k.box(.04,.13,.10,x,y,0,steel);});
 k.finish();return g;
}
