import * as THREE from './vendor/three.module.js';
// One doorway at a time; finish passage safely before switching to another doorway.
export function createDoorController(doors,{refreshDoors,blocked}){
 const info=new Map(doors.map(d=>{d.updateWorldMatrix(true,false);return[d,{point:d.getWorldPosition(new THREE.Vector3()),inverse:d.matrixWorld.clone().invert()}];}));let suppressed=null,active=null;
 const local=(door,x,z)=>new THREE.Vector3(x,info.get(door).point.y,z).applyMatrix4(info.get(door).inverse);
 const distance=(door,x,z)=>{const p=local(door,x,z);return Math.hypot(p.x,Math.max(0,Math.abs(p.z)-door.userData.door.width/2));};
 const sameFloor=(door,feet)=>Math.abs(info.get(door).point.y-feet-door.userData.door.height/2)<.65;
 const inPassage=(door,x,z,feet)=>{if(!sameFloor(door,feet))return false;const p=local(door,x,z),half=door.userData.door.width/2;return Math.abs(p.x)<half+.55&&Math.abs(p.z)<half+.35;};
 function nearestDoor(x,z,feet,range=1.65){let best=null,min=range;for(const door of doors){if(door.userData.door.locked)continue;const d=distance(door,x,z);if(d<min&&sameFloor(door,feet)){min=d;best=door;}}return best;}
 function interact(x,z,feet,animated=false){const door=active&&!active.userData.door.locked&&inPassage(active,x,z,feet)?active:nearestDoor(x,z,feet);if(!door)return false;const was=door.userData.door.open;
  if(was&&inPassage(door,x,z,feet))return false;
  if(animated){suppressed=was?door:null;if(was)door.userData.requestOpen(false);return true;}
  for(const other of doors)if(other!==door&&(other.userData.door.progress||other.userData.door.open)){const old=other.userData.door.progress||0,open=other.userData.door.open;other.userData.setOpen(false);refreshDoors();if(blocked(x,z,feet)){other.userData.setProgress(old);other.userData.requestOpen(open);refreshDoors();return false;}}
  if(!was)door.userData.openAwayFrom?.({x,z});door.userData.setOpen(!was);refreshDoors();if(blocked(x,z,feet)){door.userData.setOpen(was);refreshDoors();return false;}suppressed=was?door:null;active=was?null:door;return true;
 }
 function advance(door,dt,x,z,feet){const old=door.userData.door.progress||0;if(!door.userData.animateDoor(dt*1.8))return false;refreshDoors();if(blocked(x,z,feet)){door.userData.setProgress(old);refreshDoors();}return true;}
 function updateDoors(dt,x,z,feet){if(suppressed&&(!sameFloor(suppressed,feet)||distance(suppressed,x,z)>=1.8))suppressed=null;
  let forced=false;for(const door of doors)if(door.userData.door.locked){if(door.userData.door.progress||door.userData.door.open){door.userData.setOpen(false);forced=true;}if(active===door)active=null;if(suppressed===door)suppressed=null;}if(forced)refreshDoors();
  let desired=active&&(active.userData.door.progress||0)>0&&inPassage(active,x,z,feet)?active:nearestDoor(x,z,feet);if(desired===suppressed)desired=null;let changed=false;
  for(const door of doors)if(door!==desired){door.userData.requestOpen(false);changed=advance(door,dt,x,z,feet)||changed;}
  const anotherOpen=doors.some(d=>d!==desired&&(d.userData.door.progress||0)>1e-6);
  if(desired){if(!anotherOpen&&(desired.userData.door.progress||0)<=1e-6)desired.userData.openAwayFrom?.({x,z});desired.userData.requestOpen(!anotherOpen);changed=advance(desired,dt,x,z,feet)||changed;if(!anotherOpen)active=desired;}else if(active&&(active.userData.door.progress||0)<=1e-6)active=null;
  return changed||forced;
 }
 // If 07:00 catches someone on the gate plane, keep them on their current side.
 function lockedPassageExit(x,z,feet){for(const door of doors){if(!door.userData.door.locked||!sameFloor(door,feet))continue;const p=local(door,x,z);if(Math.abs(p.x)>=.45||Math.abs(p.z)>door.userData.door.width/2+.15)continue;p.x=p.x<0?-.50:.50;const point=p.applyMatrix4(door.matrixWorld);if(!blocked(point.x,point.z,feet))return point;}return null;}
 return{nearestDoor,interact,updateDoors,lockedPassageExit};
}
