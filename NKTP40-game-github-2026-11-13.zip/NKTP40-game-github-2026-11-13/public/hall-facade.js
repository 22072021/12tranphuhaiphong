import {createHallPottedPine} from './hall-potted-pine.js';
import {buildingBaseProfile} from './building-bases.js';
import * as THREE from './vendor/three.module.js';
import {facadeRibbon} from './curved-surfaces.js?v=28.0';
import {createHallEntry} from './openings/hall-entry.js';
import {createGlassPane} from './openings/glass.js?v=49.0';
import {hallFrontProfile} from './hall-front-profile.js?v=128.0';
export function drawHallFacade(ctx){
 const {b,g,kit,box,fb,w,l,h,side,wall,trim,record,feature}=ctx;
 const brown='#594b44',entryV=-5.1+hallFrontProfile(b).forwardShift,p=hallFrontProfile(b),{level,half,face,roof,canopy,soffit,signTop}=p;
 const window=(u,y,width,height,upper=false)=>{
  if(!upper)record('window',u,y,width,height,.10);
  const v=upper?face(u):entryV,frame=.065;
  for(const s of [-1,1]){fb(u+s*width/2,y,v+.13,frame,height+.08,.10,brown);fb(u,y+s*height/2,v+.13,width+.08,frame,.10,brown);}
  fb(u,y,v+.14,.045,height,.08,brown);
  // Upper room: six panes; P49 entrance windows: eight panes.
  const cuts=upper?[-.20,.26]:[-.25,0,.25];
  for(const t of cuts)fb(u,y+height*t,v+.14,width,.05,.08,brown);
  createGlassPane(g,{x:side*(w+v+.115),y,z:u,width:width-.07,height:height-.07,name:upper?'hall-upper-six-pane-window':'hall-front-glazing'});
 };
 // A planar central face with chamfered returns, four separate narrow windows.
 const bounds=[...Array.from({length:161},(_,i)=>-l+2*l*i/160),-l,l,-8.70,-7.60,-6.30,-4.75,4.75,6.30,-(l-1.30),l-1.30,
  ...p.windows.flatMap(u=>[u-p.windowWidth/2,u+p.windowWidth/2])].sort((a,b)=>a-b);
 for(let i=0;i<bounds.length-1;i++){
  const a=bounds[i],z=bounds[i+1],u=(a+z)/2;
  const glazed=p.windows.some(c=>Math.abs(u-c)<p.windowWidth/2+.0001);
  const passage=false;
  const bands=passage?[[level+2.15,roof]]:glazed?[[level,p.windowBottom],[p.windowTop,roof]]:[[level,roof]];
  for(const [bottom,top] of bands)facadeRibbon(kit,side,w,{from:a,to:z,curve:face,bottom,top,thickness:p.wallThickness,color:wall,segments:4,name:'hall-upper-chamfered-wall'});
 }
 for(const u of p.windows)window(u,(p.windowBottom+p.windowTop)/2,p.windowWidth,p.windowTop-p.windowBottom,true);
 // P49: four moving leaves and a single four-pane fixed transom above them.
 record('door',0,1.42,4.80,2.84,.10);
 g.add(createHallEntry({side,wallX:w+entryV,width:4.80,height:2.84,color:brown}));
 record('window',0,3.25,4.80,.72,.10);
 for(const s of [-1,1]){fb(s*2.4,3.25,entryV+.035,.065,.80,.12,brown);fb(0,3.25+s*.36,entryV+.035,4.87,.065,.12,brown);}
 for(const u of [-1.2,0,1.2])fb(u,3.25,entryV+.035,.055,.72,.12,brown);
 for(const u of [-1.8,-.6,.6,1.8])createGlassPane(g,{x:side*(w+entryV+.035),y:3.25,z:u,width:1.14,height:.65,name:'hall-entry-four-pane-transom'});
 // Two distinct windows on each side, separated by a visible masonry pier.
 const entryWindows=[];for(const wing of [-1,1])for(const distance of [3.85,6.40]){const u=wing*distance;window(u,2.20,1.20,2.40);entryWindows.push({u,width:1.20,height:2.40,sill:1.0,side:wing,columns:2,rows:4});}
 for(const wing of [-1,1])for(const [u,width]of [[2.55,.18],[5.125,.12],[7.85,.25]])for(const v of [entryV+.10,entryV-.24])fb(wing*u,level/2,v,width,level,.24,wall);
 // Continuous curved canopy with a true rounded fascia.
 const shape=new THREE.Shape();shape.moveTo(-half,face(-half));shape.lineTo(half,face(half));
 for(let i=0;i<=96;i++){const u=half-2*half*i/96;shape.lineTo(u,canopy(u));}shape.closePath();
 const geo=new THREE.ExtrudeGeometry(shape,{depth:.18,bevelEnabled:false}),pos=geo.attributes.position;
 for(let i=0;i<pos.count;i++){const u=pos.getX(i),v=pos.getY(i),d=pos.getZ(i);pos.setXYZ(i,side*(w+v),soffit+d,u);}geo.computeVertexNormals();kit.solid(geo,trim,'hall-rounded-canopy-slab');
 facadeRibbon(kit,side,w,{from:-half,to:half,curve:canopy,bottom:soffit+.08,top:signTop,thickness:.12,color:'#2877ad',name:'hall-curved-blue-sign-fascia'});
 if(typeof document!=='undefined'){
  const c=document.createElement('canvas');c.width=2048;c.height=192;
  const t=c.getContext('2d');t.textAlign='center';t.fillStyle='#e8cd80';t.font='bold 37px Arial';t.fillText('TRƯỜNG TRUNG HỌC PHỔ THÔNG CHUYÊN TRẦN PHÚ',1024,46,1900);t.fillStyle='#ffffff';t.font='bold 112px Arial';t.fillText('NHÀ ĐA NĂNG',1024,158,1630);
  const texture=new THREE.CanvasTexture(c);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=8;
  const positions=[],uv=[],indices=[];
  for(let i=0;i<=96;i++){const f=i/96,u=-half+2*half*f;for(const yy of [soffit+.10,signTop-.02]){positions.push(side*(w+canopy(u)+.071),yy,u);uv.push(side<0?f:1-f,yy<signTop-.1?0:1);}if(i<96){const j=i*2;indices.push(j,j+1,j+3,j,j+3,j+2);}}
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geometry.setIndex(indices);geometry.computeVertexNormals();
  const mesh=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({map:texture,transparent:true,side:THREE.DoubleSide,depthWrite:false}));mesh.name='hall-curved-sign-lettering';mesh.userData.walkRole='none';g.add(mesh);
 }
 // Inner and outer porch supports are circular; outer columns remain full-height.
 for(const u of [-2.53,2.53]){
  const geometry=new THREE.CylinderGeometry(.24,.24,soffit,32);geometry.translate(side*(w+face(u)-.16),soffit/2,u);kit.curved(geometry,wall,'hall-round-porch-column');
 }
 for(const wing of [-1,1]){
  const u=wing*p.outerU;
  const outerColumn=new THREE.CylinderGeometry(.21,.21,p.outerTop,32);outerColumn.translate(side*(w+p.outerV),p.outerTop/2,u);kit.curved(outerColumn,wall,'hall-round-outer-porch-column');
  // The outer upright remains visibly detached and is tied back by beams.
  const back=face(u)-p.wallThickness/2,end=p.outerV+.21;for(const y of [level-.125,p.outerTop-.24])box(end-back,.25,.34,side*(w+(back+end)/2),y,u,trim);
  const wingShape=new THREE.Shape(),a=wing<0?-l:half,z=wing<0?-half:l;
  wingShape.moveTo(a,face(a));for(let j=1;j<=64;j++){const u=a+(z-a)*j/64;wingShape.lineTo(u,face(u));}wingShape.lineTo(z,3.1);wingShape.lineTo(a,3.1);
  wingShape.closePath();
  const geometry=new THREE.ExtrudeGeometry(wingShape,{depth:.18,bevelEnabled:false}),q=geometry.attributes.position;
  for(let i=0;i<q.count;i++){const u=q.getX(i),v=q.getY(i),d=q.getZ(i);q.setXYZ(i,side*(w+v),level-.18+d,u);}geometry.computeVertexNormals();kit.withCollision('none',()=>kit.solid(geometry,trim,'hall-wing-slab-with-spiral-opening'));
 }
 // Five continuous ribs form a rectangular clock frame above the facade.
 const frameClear=(p.ribs[4]-p.ribs[0])/4-.28,frameTop=h+frameClear+.10,frameBase=h+frameClear/2-.44;
 for(const u of p.ribs)fb(u,(level+frameTop)/2,face(u)+.28,.28,frameTop-level,.44,wall);
 fb(0,frameTop,face(0)+.28,p.ribs[4]-p.ribs[0]+.28,.20,.44,wall);
 const clock=new THREE.Mesh(new THREE.PlaneGeometry(.90,.90),new THREE.MeshBasicMaterial({color:'#eee9d9',side:THREE.DoubleSide}));
 clock.position.set(side*(w+face(0)+.52),frameBase+.44,0);clock.rotation.y=side*Math.PI/2;clock.name='hall-square-clock';clock.userData.walkRole='none';g.add(clock);
 if(typeof document!=='undefined'){const c=document.createElement('canvas');c.width=c.height=512;const t=c.getContext('2d');t.fillStyle='#f1efe5';t.fillRect(0,0,512,512);t.strokeStyle='#555b51';t.lineWidth=12;t.strokeRect(6,6,500,500);t.fillStyle='#343e38';t.font='46px Arial';t.textAlign='center';t.textBaseline='middle';for(let n=1;n<=12;n++){const a=n*Math.PI/6;t.fillText(String(n),256+Math.sin(a)*183,256-Math.cos(a)*183);}t.lineWidth=12;t.beginPath();t.moveTo(256,256);t.lineTo(256,115);t.moveTo(256,256);t.lineTo(169,221);t.stroke();const tx=new THREE.CanvasTexture(c);tx.colorSpace=THREE.SRGBColorSpace;clock.material.map=tx;clock.material.needsUpdate=true;}
 // Removed the surplus raised roof band and its sloping caps; clock frame remains.
 for(const u of [-half*.35,half*.35]){const light=new THREE.Mesh(new THREE.CircleGeometry(.12,24),new THREE.MeshBasicMaterial({color:'#dddcd2',side:THREE.DoubleSide}));light.rotation.x=Math.PI/2;light.position.set(side*(w+1.0),soffit-.012,u);light.name='hall-canopy-recessed-light';light.userData.walkRole='none';g.add(light);}
 // The source elevation retains the permanent topiary pair, without event banners.
 for(const u of [-half-1.15,half+1.15]){
  const tree=createHallPottedPine();tree.position.set(side*(w+4.15),-buildingBaseProfile(b).height,u);g.add(tree);
 }
 g.userData.hallFacade={roofFrameClearHeight:frameClear,roofFrameClearWidth:frameClear,entryWallV:entryV,entryOpeningWidth:4.80,entryDoorLeaves:4,entryTransomPanes:4,facadeRibProjection:.22,entranceWindowSill:1.0,entranceWindowsPerSide:2,entranceWindows:entryWindows,entranceWindowsMirrored:true,removedRaisedRoofBand:true,upperWindows:4,upperWindowPanes:6,facadeRibs:5,projectingRibs:5,beveledEnds:true,curvedSign:true,curvedCanopy:true,roundColumns:4,outerColumnsRound:true,outerPiers:2,canopyHalf:half,frontPlane:p.terraceEdge,upperShift:p.forwardShift,sources:['P49','P57','P46','P48','R111','R113','R114']};
 feature('hall-R114-four-six-pane-windows');feature('hall-five-continuous-ribs');feature('hall-two-round-columns-two-tall-piers');feature('hall-rounded-canopy-and-blue-sign');
}
