import {LANGUAGE_ALLEY_PUBLIC} from './foreign-language-alley-layout.js';
let allowed=false,request=0;
export const canAccessLanguageAlley=()=>LANGUAGE_ALLEY_PUBLIC||allowed;
export async function refreshAlleyAdminAccess(){if(LANGUAGE_ALLEY_PUBLIC)return;const id=++request;allowed=false;try{const r=await fetch('/api/player-profile',{credentials:'same-origin',cache:'no-store',headers:window.nktpAdminToken?{'X-NKTP-Admin-Token':window.nktpAdminToken}:{}});const data=await r.json();if(id===request)allowed=r.ok&&data.isAdmin===true;}catch{}}
