import * as THREE from './vendor/three.module.js';

// One indexed, smooth surface per swept profile. Straight frames remain straight;
// the silhouette is not assembled from individual rectangular blocks.
export function facadeRibbon(kit,side,wallX,{from,to,curve=()=>0,bottom,top,thickness=.16,color,name='continuous-curve',segments=96}){
 const pos=[],indices=[];
 const value=(f,u)=>typeof f==='function'?f(u):f;
 function point(u,edge){const v=curve(u),d=value(thickness,u)/2;
  return[side*(wallX+v+(edge===0||edge===3?-d:d)),value(edge<2?bottom:top,u),u];}
 // Separate normals at the cross-section edges, shared normals along the curve.
 for(const [a,b] of [[0,1],[1,2],[2,3],[3,0]]){
  const start=pos.length/3;
  for(let i=0;i<=segments;i++){const u=from+(to-from)*i/segments;pos.push(...point(u,a),...point(u,b));}
  for(let i=0;i<segments;i++){const k=start+i*2;indices.push(k,k+1,k+3,k,k+3,k+2);}
 }
 for(const u of [from,to]){const k=pos.length/3;for(let j=0;j<4;j++)pos.push(...point(u,j));indices.push(k,k+1,k+2,k,k+2,k+3);}
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setIndex(indices);geo.computeVertexNormals();kit.curved(geo,color,name);
}
export function smoothArc(kit,points,radius,color,name='continuous-arc'){
 const curve=new THREE.CatmullRomCurve3(points);kit.curved(new THREE.TubeGeometry(curve,Math.max(64,points.length*3),radius,8,false),color,name);
}
