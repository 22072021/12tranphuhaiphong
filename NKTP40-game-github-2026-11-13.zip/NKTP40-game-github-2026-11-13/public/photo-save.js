// One locally encoded JPEG is reused by both actions; no photo upload or server request.
export function showPhotoSave(blob,{filename='12TranPhu-'+new Date().toISOString().replace(/[:.]/g,'-')+'.jpg'}={}){
 if(!(blob instanceof Blob)||blob.type!=='image/jpeg')throw Error('Ảnh JPG chưa sẵn sàng.');
 document.querySelector('#photoSaveDialog')?.close();
 const file=new File([blob],filename,{type:'image/jpeg'}),url=URL.createObjectURL(blob),dialog=document.createElement('dialog');
 dialog.id='photoSaveDialog';dialog.setAttribute('aria-labelledby','photoSaveTitle');
 dialog.style.cssText='box-sizing:border-box;width:min(92vw,430px);max-height:88dvh;padding:18px;border:1px solid #c2d2cc;border-radius:18px;background:#f6f8f4;color:#183e32;font:15px system-ui;overflow:auto';
 dialog.innerHTML='<h2 id="photoSaveTitle" style="font-size:19px;margin:0 0 12px">Ảnh kỷ niệm</h2><img alt="Ảnh vừa chụp trong trò chơi" style="display:block;max-width:100%;max-height:48dvh;margin:auto;border-radius:8px"><p style="line-height:1.5">Chọn chia sẻ để lưu vào Ảnh hoặc gửi cho bạn bè, tùy thiết bị.</p><div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" data-share>Chia sẻ / Lưu ảnh</button><button type="button" data-download>Tải ảnh JPG</button><button type="button" data-close>Đóng</button></div><p role="status" style="line-height:1.5;margin-bottom:0"></p>';
 dialog.querySelector('img').src=url;const status=dialog.querySelector('[role=status]'),share=dialog.querySelector('[data-share]'),download=dialog.querySelector('[data-download]');
 for(const button of dialog.querySelectorAll('button'))button.style.cssText='min-height:44px;padding:10px 13px;border:1px solid #a6bcb2;border-radius:10px;background:#fff;color:#183e32;font:600 14px system-ui;cursor:pointer';
 const data={files:[file]};let canShare=false;try{canShare=typeof navigator.share==='function'&&navigator.canShare?.(data)===true;}catch{}
 share.hidden=!canShare;share.style.background='#205443';share.style.color='white';
 if(!canShare)status.textContent='Ảnh tải về thường nằm trong thư mục Downloads / Tải xuống của thiết bị.';
 share.onclick=async()=>{share.disabled=true;download.disabled=true;try{
  // Called directly from this click, preserving iOS/Android user activation.
  await navigator.share(data);status.textContent='Đã hoàn tất thao tác chia sẻ.';
 }catch(error){status.textContent=error.name==='AbortError'?'Đã hủy chia sẻ. Ảnh chưa được tự tải xuống.':'Chưa chia sẻ được. Bạn có thể chọn Tải ảnh JPG.';
 }finally{share.disabled=false;download.disabled=false;}};
 download.onclick=()=>{const a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();status.textContent='Đã gửi yêu cầu tải ảnh JPG. Kiểm tra mục Tải xuống của thiết bị.';};
 dialog.querySelector('[data-close]').onclick=()=>dialog.close();
 dialog.addEventListener('close',()=>{dialog.remove();URL.revokeObjectURL(url);},{once:true});
 document.body.append(dialog);dialog.showModal();(canShare?share:download).focus();
 return dialog;
}
