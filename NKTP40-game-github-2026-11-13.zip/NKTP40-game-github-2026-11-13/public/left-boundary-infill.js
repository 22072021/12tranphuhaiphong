import {ENTRANCE} from './entrance-layout.js';import * as T from './vendor/three.module.js';import{geometryKit}from'./geometry-kit.js';
import {ACCORDION_HOUSE,createAccordionHouse} from './accordion-house.js';
import {createAccordionNeighbours,accordionNeighbourPlan} from './accordion-neighbours.js';
import {EXERCISE_YARD as Y,createExerciseYard} from './exercise-yard.js';
import {createExerciseBoundaryBacks} from './exercise-boundary-backs.js';
export const LEFT_INFILL={frontX:ENTRANCE.x,innerX:-14.8,z:-30,northZ:-54.6,depth:.24};
export function createLeftBoundaryInfill(){
 const g=new T.Group();g.name='left-stepped-boundary-wall';const k=geometryKit(g);
 const p=[{x:ENTRANCE.x,z:-30},{x:-42.8,z:-30},{x:-42.8,z:ACCORDION_HOUSE.frontZ},{x:ACCORDION_HOUSE.xmin,z:ACCORDION_HOUSE.frontZ},{x:ACCORDION_HOUSE.xmax,z:ACCORDION_HOUSE.frontZ},{x:accordionNeighbourPlan()[2].xmax,z:Y.frontZ},{x:Y.xmin,z:Y.backZ},{x:Y.xmax,z:Y.backZ},{x:-14.8,z:-54.6}];
 for(let i=1;i<p.length;i++){if([3,4,5,8].includes(i))continue;const a=p[i-1],b=p[i],dx=b.x-a.x,dz=b.z-a.z,len=Math.hypot(dx,dz),r=Math.atan2(dx,dz);k.box(.24,2.95,len,(a.x+b.x)/2,1.475,(a.z+b.z)/2,'#dfc98e',0,r);k.box(.28,.1,len,(a.x+b.x)/2,3,(a.z+b.z)/2,'#eadbb5',0,r);}
 k.finish();g.add(createAccordionHouse(),createAccordionNeighbours(),createExerciseYard(),createExerciseBoundaryBacks());g.userData={boundary:p,accessible:false};return g;
}
