export const normalizeClassName=value=>/^song ngữ(?: pháp)?$/i.test(String(value||'').trim())?'Song Ngữ':String(value||'').trim();
// Shared by the entry form and identity API. Count Unicode characters consistently.
export function profileDetailsError(value,role='student'){
 const length=v=>Array.from(String(v||'').trim()).length;
 if(!length(value?.name))return 'Vui lòng nhập tên trước khi tiếp tục.';
 if(length(value.name)>25)return 'Tên được nhập tối đa 25 ký tự.';
 if(role==='teacher'){
  if(length(value.subject)<2)return 'Kính mời thầy/cô nhập bộ môn giảng dạy, tối thiểu 2 ký tự.';
  if(length(value.subject)>10)return 'Bộ môn giảng dạy được nhập tối đa 10 ký tự.';
 }else if(!length(value.className)||!/^\d{4}$/.test(String(value.grade))||+value.grade<1986||+value.grade>2026)return 'Vui lòng chọn lớp và năm nhập học từ 1986 đến 2026.';
 if(length(value.note)>64)return 'Ghi chú được nhập tối đa 64 ký tự.';
 return '';
}
