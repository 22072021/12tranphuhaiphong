import {drawStoneStep,STAIR_STONE} from './stair-stone.js?v=218.0';
import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
// Owner-requested arrangement, not a claim about photographed historical furniture.
export function createAdministrationAuditorium(p){
 const g=new THREE.Group();g.name='admin-third-floor-auditorium';g.position.y=2*p.step+.020;
 const k=geometryKit(g),oak='#936338',edge='#6d472b',frame='#66492f',woodLight='#ae8050';
 const roomLeft=p.u(1/7),roomRight=p.u(5/7),leftSign=Math.sign(roomLeft-roomRight),back=roomLeft-leftSign*.33,front=back-leftSign*2.4,stageLo=-p.w+.9,stageHi=1.25,stageX=(stageLo+stageHi)/2;
 const stage=new THREE.Group();stage.name='auditorium-stage';stage.userData={side:'building-left-as-seen-from-courtyard',height:.45,width:stageHi-stageLo,depth:2.4,front,back};g.add(stage);const sk=geometryKit(stage);
 sk.box(stageHi-stageLo,.40,2.4,stageX,.20,(front+back)/2,edge);sk.box(stageHi-stageLo,.05,2.4,stageX,.425,(front+back)/2,oak);
 // Fine plank seams sit within the deck, rather than overlapping its top face.
 for(let x=stageLo+.22;x<stageHi;x+=.22)sk.withCollision('none',()=>sk.box(.008,.002,2.35,x,.451,(front+back)/2,frame));
 for(let j=0;j<2;j++){const height=(j+1)*.15,z=front-leftSign*((2-j-.5)*.30);drawStoneStep(sk,{x:stageX,y:height,z,width:2.8,depth:.302,thickness:height,axis:'z'});}sk.finish();
 const roomMin=-p.w+.25,roomMax=p.w-p.corridor-.24,aisle=1.55,tableWidth=Math.min(3,(roomMax-roomMin-aisle-.56)/2),benchWidth=tableWidth-.08,banks=[roomMin+.28+tableWidth/2,roomMax-.28-tableWidth/2],rows=5,rowPitch=1.75,firstRow=front-leftSign*2.15;
 for(let row=0;row<rows;row++)for(let bank=0;bank<banks.length;bank++){
  const x=banks[bank],z=firstRow-leftSign*row*rowPitch,deskZ=z+leftSign*.35,seatZ=z-leftSign*.40;
  const desk=new THREE.Group();desk.name=`auditorium-desk-${row+1}-${bank+1}`;desk.userData={row:row+1,bank:bank+1,seats:4,facing:leftSign};g.add(desk);const dk=geometryKit(desk);
  dk.box(tableWidth,.055,.62,x,.7475,deskZ,oak);for(const dz of [-.105,.105])dk.withCollision('none',()=>dk.box(tableWidth-.06,.002,.007,x,.776,deskZ+dz,frame));
  for(const xx of [-tableWidth/2+.12,tableWidth/2-.12])for(const dz of [-.23,.23])dk.box(.065,.72,.065,x+xx,.36,deskZ+dz,frame);
  for(const dz of [-.265,.265])dk.box(tableWidth-.16,.13,.045,x,.655,deskZ+dz,edge);for(const xx of [-tableWidth/2+.12,tableWidth/2-.12])dk.box(.045,.11,.50,x+xx,.655,deskZ,edge);dk.box(tableWidth-.20,.055,.055,x,.22,deskZ,frame);dk.finish();
  const bench=new THREE.Group();bench.name=`auditorium-bench-${row+1}-${bank+1}`;bench.userData={row:row+1,bank:bank+1,capacity:4,width:benchWidth,seatHeight:.43,facing:leftSign};g.add(bench);const bk=geometryKit(bench);
  bk.box(benchWidth,.055,.36,x,.4025,seatZ,woodLight);bk.withCollision('none',()=>bk.box(benchWidth-.05,.002,.007,x,.431,seatZ,edge));
  for(const xx of [-benchWidth/2+.13,0,benchWidth/2-.13])for(const dz of [-.12,.12])bk.box(.055,.375,.055,x+xx,.1875,seatZ+dz,frame);
  for(const dz of [-.13,.13])bk.box(benchWidth-.15,.08,.04,x,.32,seatZ+dz,edge);bk.box(benchWidth-.20,.055,.055,x,.16,seatZ,frame);bk.finish();
 }
 g.userData={floor:3,source:'owner-design-request',rows,banks:2,tables:10,benches:10,capacity:40,seatsPerBench:4,stageLeft:true,estimatedDimensions:true,centralAisle:aisle,centralAisleX:(banks[0]+banks[1])/2,banksX:banks,tableWidth,sideDoorClearance:true};k.finish();return g;
}
