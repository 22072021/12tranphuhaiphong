import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
import {createGlassPane} from './openings/glass.js?v=49.0';
// Local X is depth, Z is the opening width. Frames sit in the reveal.
export function heritageWindow({width=1.15,height=1.65,shutters=true}={}){
 const g=new THREE.Group(),k=geometryKit(g),white='#dedfd3',dark='#637974';g.name='heritage-white-paired-sash';
 for(const s of [-1,1]){k.box(.08,height+.12,.06,0,0,s*(width/2+.025),white);k.box(.08,.06,width+.12,0,s*(height/2+.025),0,white);}
 k.box(.07,height,.05,.005,0,0,white);
 for(const side of [-1,1]){const z=side*width/4,ww=width/2-.06;createGlassPane(g,{x:-.014,y:0,z,width:ww,height:height-.09});for(const sign of [-1,1])k.box(.035,.035,ww,.025,sign*height/6,z,white);
  if(shutters)for(let row=0;row<3;row++)for(let j=0;j<9;j++){const yy=-height/2+row*height/3+.045+j*(height/3-.09)/9;k.box(.025,.018,ww-.015,.038,yy,z,dark);}
  for(let y=-height/2+.12;y<height/2;y+=.20)k.box(.025,.017,ww,-.07,y,z,'#63756b');
 }
 k.box(.20,.07,width+.20,.02,-height/2-.07,0,'#d7d8cd');k.finish();return g;
}
