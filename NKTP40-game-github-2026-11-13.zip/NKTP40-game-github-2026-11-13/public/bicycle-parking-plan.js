import {CAMPUS_REAR} from './campus-limits.js';
export const BICYCLE_COLORS=['#242b30','#365e8c','#853c3f','#46715d','#d8ceb1','#bc939f','#809f91','#576978'];
const palette=BICYCLE_COLORS;
export function bicycleParkingPlacements(layout){const placements=[];
 for(const id of ['A2','B2']){const b=layout.buildings.find(b=>b.id===id);if(!b)continue;const start=b.z-b.length/2+1.4,end=b.z+b.length/2-1.4;
  for(let z=start,i=0;z<=end;z+=.90,i++)placements.push({x:CAMPUS_REAR.a2-1.07,z,mini:i%3!==0,color:(i+(id==='B2'?3:0))%palette.length,building:id});
 }
 // Three rear rows per A1/B1; 1.6m between rows, central crossing and clear ends.
 for(const id of ['A1','B1']){const b=layout.buildings.find(b=>b.id===id);if(!b)continue;const side=-(b.frontSide||-1),angle=b.rotation*Math.PI/180,c=Math.cos(angle),s=Math.sin(angle);
  for(let row=0;row<3;row++)for(let z=-b.length/2+2.8,i=0;z<=b.length/2-2.8;z+=.90,i++){if(Math.abs(z)<3.7)continue;const x=side*(b.width/2+2.7+row*3.5);placements.push({x:b.x+c*x-s*z,z:b.z+s*x+c*z,mini:(i+row)%3!==0,color:(i+row*3)%palette.length,building:id,row:row+1,rotation:-angle});}
 }
return placements.map((p,i)=>({...p,id:'parking:'+i}));}
