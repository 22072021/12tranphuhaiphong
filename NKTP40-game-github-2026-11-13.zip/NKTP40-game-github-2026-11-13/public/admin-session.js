// Credentials exist only during login. Authorization thereafter is HttpOnly cookie.
try{localStorage.removeItem('nktp40-admin-code');}catch{}
export async function loginAdmin(code){const r=await fetch('/api/admin-session',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({code})});const data=await r.json();if(!r.ok)throw Error(data.error||'Chưa đăng nhập được.');return data;}
export async function logoutAdmin(){await fetch('/api/admin-session',{method:'DELETE',credentials:'same-origin',headers:{'Content-Type':'application/json'}});}
export const adminFetch=(url,options={})=>fetch(url,{...options,credentials:'same-origin',cache:'no-store'});
