import {applySportsMotion} from './sports-motion.js';
import {createSportsSlots,sportsClock} from './sports-slots.js';
import * as T from './vendor/three.module.js';
import {importAsset,assetFailure} from './asset-retry.js';
import {registerNPC} from './npc-animation.js';
// A compact single-hoop practice court, chalk only; preserves the existing concrete.
export function addBasketballCourt(hoop){
 const court=new T.Group();court.name='heritage-basketball-chalk-court';court.userData.walkIgnore=true;hoop.add(court);
 const white=new T.MeshBasicMaterial({color:'#ebe8de',side:T.DoubleSide});
 const line=(x,z,w,d)=>{const m=new T.Mesh(new T.PlaneGeometry(w,d),white);m.rotation.x=-Math.PI/2;m.position.set(x,.016,z);m.userData.walkRole='none';court.add(m);};
 const arc=(x,z,r,start,end)=>{const m=new T.Mesh(new T.RingGeometry(r-.023,r+.023,72,1,start,end-start),white);m.rotation.x=-Math.PI/2;m.position.set(x,.017,z);m.userData.walkRole='none';court.add(m);};
 for(const x of [-6,6])line(x,4.7,.045,11);for(const z of [-.8,10.2])line(0,z,12,.045);
 for(const x of [-2.45,2.45])line(x,2.1,.045,5.8);line(0,5,4.9,.045);arc(0,5,1.8,0,Math.PI*2);arc(0,.7,6.0,Math.PI,Math.PI*2);
 court.userData.chalkOnly=true;
 const team=new T.Group();team.name='basketball-playing-npcs';team.userData={walkIgnore:true,npc:true,animationRadius:7};hoop.add(team);const state={},slots=createSportsSlots(team,state,[new T.Vector3(1,0,7.8),new T.Vector3(-3,0,3)],{kind:'basketball',title:'Bóng rổ',target:new T.Vector3(0,0,.7)});state.onPlayerHit=slot=>{if(state.target!==slot||state.progress<.55||state.playerShot)return false;slot.rally++;state.lastHitRound=state.round;state.playerShot={slot,start:state.time};return true;};
 team.userData.textureReady=importAsset(new URL('./student/student.js',import.meta.url).href).then(async({createStudent,badgeReady})=>{
  await badgeReady;for(let p=hoop;p;p=p.parent)if(p.userData.disposed)return;
  const actors=[];for(const [i,x,z]of [[0,-1.4,4.1],[1,2.7,5.5],[2,-3.8,6.5]]){const a=createStudent({gender:i===1?'female':'male',season:'summer',scale:.93});a.root.name='basketball-player-'+(i+1);a.root.position.set(x,0,z);a.root.rotation.y=Math.atan2(-x,.7-z);team.add(a.root);actors.push(a);}
  const ball=new T.Mesh(new T.SphereGeometry(.12,16,12),new T.MeshStandardMaterial({color:'#c77b33',roughness:.9}));ball.name='basketball';team.add(ball);const seams=new T.MeshBasicMaterial({color:'#49382c'});for(const rotation of [[0,0,0],[Math.PI/2,0,0],[0,Math.PI/2,0]]){const ring=new T.Mesh(new T.TorusGeometry(.1205,.003,4,40),seams);ring.rotation.set(...rotation);ball.add(ring);}
  const start=new T.Vector3(),rim=new T.Vector3(0,3.05,.70);
  const tick=time=>{const {n,u}=sportsClock(state,time,9),cycle=u*9,shooter=n%3,a=actors[shooter];const occupied=slots.filter(s=>s.occupied),receiver=occupied.length?occupied[n%occupied.length]:null;state.target=cycle>=6.5?receiver:null;state.previousTarget=state.target;state.previousRound=n;actors.forEach((v,i)=>{v.update(time+i,'idle');applySportsMotion(v.joints,{kind:'basketball',swing:i===shooter&&cycle>=3&&cycle<5?1-(cycle-3)/2:0});});
   start.set(.18,1.15,.23).applyEuler(a.root.rotation).add(a.root.position);
   if(cycle<3){ball.position.copy(start);ball.position.y=.15+Math.abs(Math.cos(cycle*Math.PI*2.4))*.85;}
   else if(cycle<4){ball.position.copy(start);ball.position.y=1.1+(cycle-3)*.65;}
   else if(cycle<5.5){const u=(cycle-4)/1.5;start.y=1.75;ball.position.lerpVectors(start,rim,u);ball.position.y+=Math.sin(Math.PI*u)*1.7;}
   else if(cycle<6.5){ball.position.copy(rim);ball.position.y=3.05-(cycle-5.5)*2.9;}
   else{const next=actors[(shooter+1)%3];if(receiver)start.copy(receiver.marker.position);else start.set(.18,1.15,.23).applyEuler(next.root.rotation).add(next.root.position);const u=(cycle-6.5)/2.5;ball.position.lerpVectors(new T.Vector3(0,.15,.7),start,u);ball.position.y=.15+u*.95+Math.sin(Math.PI*u)*.65;}
   if(state.playerShot){state.previousTarget=null;const shot=state.playerShot,t=time-shot.start;start.copy(shot.slot.marker.position);start.y=1.75;if(t<1.5){const f=t/1.5;ball.position.lerpVectors(start,rim,f);ball.position.y+=Math.sin(Math.PI*f)*1.7;}else if(t<2.4){ball.position.copy(rim);ball.position.y=3.05-(t-1.5)*3.2;}else{state.playerShot=null;state.resetAt=time;state.clockRound=undefined;state.lastHitRound=undefined;}}
   ball.rotation.x=time*3;ball.rotation.z=time*2;team.userData.activeShooter=shooter+1;
  };tick(0);registerNPC(team,tick);team.userData.ready=true;
 }).catch(e=>assetFailure(team,e));slots.forEach(s=>s.textureReady=team.userData.textureReady);return court;
}
