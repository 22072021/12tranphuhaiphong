import * as T from './vendor/three.module.js';
// Hands target the actual keyboard and mouse, including rotated desk rows.
export function applyGamingPose(root,joints,station){
 if(!station)return;root.updateMatrixWorld(true);const down=new T.Vector3(0,-1,0);
 for(const [side,local]of [['left',[-.07,.83,-.20]],['right',[-.40,.83,-.20]]]){
  const shoulder=joints[side+'Shoulder'],elbow=joints[side+'Elbow'];if(!shoulder||!elbow)continue;
  const origin=shoulder.getWorldPosition(new T.Vector3()),target=station.localToWorld(new T.Vector3(...local));
  const scale=shoulder.getWorldScale(new T.Vector3()).y,a=.235*scale,b=.214*scale,delta=target.clone().sub(origin),distance=T.MathUtils.clamp(delta.length(),.02,a+b-.002),direction=delta.normalize();
  const along=(a*a-b*b+distance*distance)/(2*distance),height=Math.sqrt(Math.max(0,a*a-along*along));
  const bend=new T.Vector3(0,-1,0).addScaledVector(direction,direction.y).normalize();const joint=origin.clone().addScaledVector(direction,along).addScaledVector(bend,height);
  function aim(bone,to){const from=bone.getWorldPosition(new T.Vector3()),q=new T.Quaternion().setFromUnitVectors(down,to.clone().sub(from).normalize()),parent=bone.parent.getWorldQuaternion(new T.Quaternion()).invert();bone.quaternion.copy(parent.multiply(q));root.updateMatrixWorld(true);}
  aim(shoulder,joint);aim(elbow,origin.clone().addScaledVector(direction,distance));
 }
}
