import * as THREE from './vendor/three.module.js';
// Small shared panorama: blue overhead, pale blue at the horizon. No network asset.
let sky;
export function applyBlueSky(scene){
 if(!sky){
  const width=128,height=64,data=new Uint8Array(width*height*4);
  for(let y=0;y<height;y++){
   const elevation=Math.max(0,Math.sin((y/(height-1)-.5)*Math.PI)),t=Math.pow(elevation,.55);
   const rgb=[Math.round(208-145*t),Math.round(231-75*t),Math.round(244-22*t)];
   for(let x=0;x<width;x++){const i=(y*width+x)*4;data.set([...rgb,255],i);}
  }
  sky=new THREE.DataTexture(data,width,height);sky.colorSpace=THREE.SRGBColorSpace;sky.mapping=THREE.EquirectangularReflectionMapping;sky.magFilter=THREE.LinearFilter;sky.minFilter=THREE.LinearFilter;sky.needsUpdate=true;
 }
 scene.background=sky;if(scene.fog)scene.fog.color.set('#d0e7f4');
}
