import * as T from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js';
import {createCampusNPC} from './campus-npcs.js';
import {createSquarePlasticStool} from './furniture/plastic-square-stool.js';

// +X is into the alley; +Z is the right-hand wall when entering.
export function createPanBreadStall({crabNoodles=false}={}){
 const g=new T.Group();g.name=crabNoodles?'crab-noodle-stall':'pan-bread-stall';const k=geometryKit(g),{box,cylinder}=k;
 const blue='#2469ac',steel='#b7bfba',tableColor=crabNoodles?'#ba343c':blue;
 function table(x,z,w,d,h,color){k.withCollision('furniture',()=>{box(w,.045,d,x,h-.0225,z,color);for(const sx of[-1,1])for(const sz of[-1,1])box(.045,h-.045,.045,x+sx*(w/2-.07),(h-.045)/2,z+sz*(d/2-.07),color);});}
 // The existing approved stool mesh is shared by all six customer seats.
 const prototype=createSquarePlasticStool({color:'#b52d37',height:.36,size:.37});
 for(const x of[1.10,2.50]){table(x,-.85,1.25,.68,.53,tableColor);for(const z of[-.27,-1.43]){const chair=prototype.clone(true);chair.position.set(x,0,z);chair.rotation.y=z<-.85?0:Math.PI;g.add(chair);}}
 for(const [x,y,z,yaw] of [[.25,0,-.85,Math.PI/2],[3.35,0,-.85,-Math.PI/2]]){const chair=prototype.clone(true);chair.position.set(x,y,z);chair.rotation.y=yaw;g.add(chair);}
 table(5.10,-.98,1.65,.65,.76,crabNoodles?tableColor:steel);
 const seat=createSquarePlasticStool({color:blue,height:.44/.765,size:.40/.765});delete seat.userData.seatLanes;seat.userData.npcReserved=true;seat.position.set(5.10,0,-.27);seat.rotation.y=Math.PI;g.add(seat);
 // Slotted plastic backrest, matching the established street vendors' chairs.
 k.withCollision('none',()=>{for(const x of[4.91,5.29])box(.035,.47,.035,x,.68,-.06,blue);box(.40,.07,.035,5.10,.91,-.06,blue);for(let i=0;i<5;i++)box(.025,.33,.025,4.96+i*.07,.72,-.06,blue);});
 const seller=createCampusNPC({id:crabNoodles?'crab-noodle':'pan-bread',name:crabNoodles?'Cô bánh đa cua':'Cô bán bánh mì chảo',female:true,seated:true,seatHeight:.46754,clothingPalette:crabNoodles?{shirt:'#914c70',navy:'#914c70',pants:'#323039'}:{}});seller.position.set(5.10,0,-.27);seller.rotation.y=Math.PI;seller.userData.dialogue=crabNoodles?'Bánh đa cua đây!':'Pa tê mới nấu còn nóng đây';g.add(seller);g.userData.textureReady=seller.userData.textureReady;
 const glass=new T.MeshStandardMaterial({color:'#d5e8e5',transparent:true,opacity:.18,depthWrite:false,roughness:.18,metalness:.05,side:T.DoubleSide});
 function pane(w,h,d,x,y,z){const p=new T.Mesh(new T.BoxGeometry(w,h,d),glass);p.position.set(x,y,z);p.userData.walkRole='none';g.add(p);}
 k.withCollision('none',()=>{
  // Small glass cabinet on the worktop: metal perimeter, visible trays of pâté and eggs.
  for(const x of[4.63,5.47])for(const z of[-1.25,-.77])box(.018,.46,.018,x,1.005,z,steel);
  for(const y of[.78,1.23]){box(.88,.018,.52,5.05,y,-1.01,steel);}
  pane(.84,.43,.006,5.05,1.005,-1.25);pane(.006,.43,.48,4.63,1.005,-1.01);pane(.006,.43,.48,5.47,1.005,-1.01);pane(.84,.006,.48,5.05,1.23,-1.01);
  if(crabNoodles){
   // Three shallow metal ingredient trays, with raised rims and separate food portions.
   for(let i=0;i<3;i++){const x=4.77+i*.28;box(.25,.018,.36,x,.805,-1.01,steel);for(const side of[-1,1]){box(.25,.045,.012,x,.825,-1.01+side*.174,steel);box(.012,.045,.36,x+side*.119,.825,-1.01,steel);}for(let j=0;j<10;j++)box(.045,.018,.035,x-.075+(j%3)*.06,.835+Math.floor(j/3)*.004,-1.12+Math.floor(j/3)*.06,['#8a5638','#8d9b48','#bd8151'][i]);}
  }else{
  box(.35,.025,.35,4.84,.805,-1.01,steel);box(.29,.095,.29,4.84,.865,-1.01,'#8b6350');box(.31,.022,.34,5.28,.805,-1.01,'#e2dbcb');
  const eggGeo=new T.SphereGeometry(1,8,6),eggMat=new T.MeshStandardMaterial({color:'#eadcc1',roughness:.8});for(let i=0;i<6;i++){const egg=new T.Mesh(eggGeo,eggMat);egg.scale.set(.037,.05,.037);egg.position.set(5.19+(i%3)*.08,.86,-1.09+Math.floor(i/3)*.13);egg.userData.walkRole='none';g.add(egg);}
  }
  // Compact coal stove at the vendor's right (-X while facing the alley).
  cylinder(.22,.32,4.07,.16,-.47,'#725e4b');box(.11,.09,.025,4.07,.13,-.69,'#272722');
  if(crabNoodles){
   // Reuse the noodle stall's cylindrical steel stockpot, lid and side handles.
   cylinder(.27,.34,4.07,.49,-.47,steel);cylinder(.285,.025,4.07,.6725,-.47,steel);
   box(.11,.035,.055,4.07,.705,-.47,'#444a46');for(const side of[-1,1])box(.12,.035,.06,4.07+side*.29,.55,-.47,'#727b77');
  }else{
  cylinder(.26,.035,4.07,.3375,-.47,'#252b2c');cylinder(.23,.008,4.07,.359,-.47,'#b78c45');box(.20,.025,.045,4.37,.345,-.47,'#383c3b');
  const white=new T.Mesh(new T.SphereGeometry(1,12,6),new T.MeshStandardMaterial({color:'#f5eed9',roughness:.65}));white.scale.set(.11,.009,.085);white.position.set(4.07,.372,-.47);white.userData.walkRole='none';g.add(white);cylinder(.075,.018,4.07,.386,-.47,'#efb836');
  }
  function sauce(x,y,z,color){cylinder(.075,.19,x,y+.095,z,color);cylinder(.042,.065,x,y+.222,z,color);cylinder(.023,.055,x,y+.282,z,'#eee8cd');box(.09,.07,.002,x,y+.10,z-.038,'#edddb8');}
  for(const [x,y,z]of[[1.10,.53,-.85],[2.50,.53,-.85],[5.77,.76,-.98]]){sauce(x-.08,y,z,'#b83127');if(!crabNoodles)sauce(x+.08,y,z,'#d24c2d');}
 });
 // Stove is furniture, never a platform that visitors can step onto.
 k.withCollision('furniture',()=>box(.42,.36,.42,4.07,.18,-.47,'#655542'));
 k.finish();g.userData.layout='two adjacent customer tables, vendor further inside, back to right wall';return g;
}
