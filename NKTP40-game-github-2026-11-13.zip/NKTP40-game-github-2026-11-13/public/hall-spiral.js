import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
import {STUDENT_STAIR_STONE} from './stair-stone.js?v=218.0';
import {smoothArc} from './curved-surfaces.js?v=28.0';
export function hallSpiralPlan(b,wing){return{cx:(b.frontSide||-1)*(b.width/2+1.20),cz:wing*(b.length/2-2.05),inner:.23,outer:1.20,path:.80,start:0,dir:-wing,total:Math.PI*2.5,height:(b.hallLevel??(b.height*.46+.8)),count:Math.ceil((b.hallLevel??(b.height*.46+.8))/.16),wing};}
export function hallSpiralPoint(p,t,r=p.path){const a=p.start+p.dir*p.total*t;return{x:p.cx+r*Math.cos(a),z:p.cz+r*Math.sin(a),y:p.height*t};}
export function drawHallSpiral(parent,b,wing){
 const p=hallSpiralPlan(b,wing),g=new THREE.Group();g.name='hall-spiral-'+wing;g.position.set(p.cx,0,p.cz);g.userData.walkHelix={...p};g.userData.source=['P46','P57','R38','R52'];g.userData.finish={treadCentre:'#b77d80',treadEdges:'#c5af83',handrail:'#b77d80',steel:'#c5af83',descentFacesHallWindows:true};parent.add(g);const k=geometryKit(g);
 function wedge(r0,r1,a0,a1,top,color){const shape=new THREE.Shape();for(let i=0;i<=8;i++){const a=a0+(a1-a0)*i/8,x=r0*Math.cos(a),z=r0*Math.sin(a);i?shape.lineTo(x,z):shape.moveTo(x,z);}for(let i=8;i>=0;i--){const a=a0+(a1-a0)*i/8;shape.lineTo(r1*Math.cos(a),r1*Math.sin(a));}shape.closePath();const geo=new THREE.ExtrudeGeometry(shape,{depth:p.height/p.count+.006,bevelEnabled:false,steps:1}),pos=geo.attributes.position;for(let i=0;i<pos.count;i++){const x=pos.getX(i),z=pos.getY(i),d=pos.getZ(i);pos.setXYZ(i,x,top-d,z);}geo.computeVertexNormals();k.withCollision('none',()=>k.curved(geo,color,'hall-spiral-stone-tread'));}
 for(let j=0;j<p.count-1;j++){const a=p.start+p.dir*p.total*j/p.count,c=p.start+p.dir*p.total*(j+1)/p.count,y=p.height*(j+1)/p.count;wedge(p.inner,p.inner+.15,a,c,y,STUDENT_STAIR_STONE.yellow);wedge(p.inner+.15,p.outer-.15,a,c,y,STUDENT_STAIR_STONE.red);wedge(p.outer-.15,p.outer,a,c,y,STUDENT_STAIR_STONE.yellow);}
 k.cylinder(.23,p.height+1,0,(p.height+1)/2,0,'#eee8da');
 k.withCollision('barrier',()=>{for(let j=2;j<=p.count-2;j++){const t=j/p.count,a=p.start+p.dir*p.total*t;k.box(.045,.95,.045,p.outer*Math.cos(a),p.height*t+.475,p.outer*Math.sin(a),'#c5af83');}});
 const points=Array.from({length:129},(_,i)=>{const t=2/p.count+(1-4/p.count)*i/128,a=p.start+p.dir*p.total*t;return new THREE.Vector3(p.outer*Math.cos(a),p.height*t+.95,p.outer*Math.sin(a));});k.withCollision('none',()=>smoothArc(k,points,.065,'#b77d80','hall-spiral-continuous-handrail'));k.finish();return p;
}
