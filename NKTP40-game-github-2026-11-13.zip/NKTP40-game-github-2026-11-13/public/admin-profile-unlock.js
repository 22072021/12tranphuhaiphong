let pending;
export function unlockAdminProfile(){
 if(pending)return pending;
 pending=new Promise(resolve=>{
  const dialog=document.createElement('dialog');dialog.className='identity-notice';dialog.setAttribute('aria-labelledby','adminUnlockTitle');
  dialog.innerHTML='<h2 id="adminUnlockTitle">Xác nhận tài khoản admin</h2><p>Vui lòng nhập mã để truy cập hồ sơ admin.</p><form><label>Mã truy cập<input type="password" required maxlength="64" autocomplete="off" aria-label="Mã truy cập admin" style="box-sizing:border-box;width:100%;padding:10px;margin:8px 0 14px;border:1px solid #a6b7af;border-radius:8px;font:16px system-ui"></label><p role="status" class="profile-error" hidden></p><button type="submit">Xác nhận</button></form>';
  const form=dialog.querySelector('form'),error=dialog.querySelector('[role=status]'),button=dialog.querySelector('button');form.onsubmit=async event=>{event.preventDefault();button.disabled=true;try{const response=await fetch('/api/player-profile?action=unlock',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:dialog.querySelector('input').value})});const data=await response.json();if(!response.ok||!data.adminToken)throw Error(data.error||'Chưa xác nhận được mã.');window.nktpAdminToken=data.adminToken;dialog.close();dialog.remove();pending=null;resolve(data.adminToken);}catch(e){error.textContent=e.message;error.hidden=false;dialog.querySelector('input').focus();}finally{button.disabled=false;}};
  dialog.addEventListener('cancel',e=>e.preventDefault());dialog.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();}});document.body.append(dialog);dialog.showModal();dialog.querySelector('input').focus();
 });return pending;
}
