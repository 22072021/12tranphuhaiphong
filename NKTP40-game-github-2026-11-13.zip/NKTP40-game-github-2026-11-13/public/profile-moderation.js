// Shared lightweight policy for browser, profile API and multiplayer relay.
// Whole words/phrases avoid substring matches inside ordinary Vietnamese names.
const abbreviations=new Set(['loz','dm','dmm','dcm','dcmm','dkm','dkmm','clm','clmm','vcl','vkl','vl','cc','cmm','cmnr','cml','wtf','stfu','fck']);
const words=new Set(['địt','đụ','đù','đéo','cặc','buồi','lồn','đĩ','fuck','fucking','fucker','motherfucker','shit','bitch','cunt','cock','dick','pussy','asshole']);
const englishWords=new Set([...words].filter(w=>/^[a-z]+$/.test(w)));
const foldedWords=new Set(['dit','deo','cac','buoi','lon','di',...englishWords]);
const phrases=['dit con me','con moe','dit me','du me','du ma','con cac','vai lon','an lon','an cac','chich nhau','do ngu','oc cho','suc vat','fuck you','shut the fuck up'];
const compactPhrases=new Set(phrases.map(s=>s.replaceAll(' ','')));
function normalize(value){return String(value||'').normalize('NFKC').toLowerCase().replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g,'').replace(/[013457@$!]/g,c=>({'0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','@':'a','$':'s','!':'i'}[c]));}
const fold=s=>s.normalize('NFD').replace(/\p{M}/gu,'').replaceAll('đ','d');
export function inappropriateProfileText(value){
 const raw=normalize(value),tokens=raw.match(/[\p{L}\p{N}]+/gu)||[];
 if(tokens.some(t=>fold(t)==='dit'||words.has(t)||englishWords.has(fold(t))||abbreviations.has(fold(t))))return true;
 const plain=tokens.map(fold).join(' ');
 if(phrases.some(p=>(' '+plain+' ').includes(' '+p+' ')))return true;
 if(tokens.some(t=>compactPhrases.has(fold(t))))return true;
 // Catch punctuation/spacing between letters, without flattening entire names.
 const fragments=raw.split(/\s+/).filter(Boolean);
 for(const fragment of fragments){if(!/[^\p{L}\p{N}]/u.test(fragment))continue;const compact=fold(fragment.replace(/[^\p{L}\p{N}]/gu,''));if(abbreviations.has(compact)||compactPhrases.has(compact)||foldedWords.has(compact))return true;}
 const letterRuns=plain.match(/(?:\b[a-z]\s+){1,7}[a-z]\b/g)||[];
 return letterRuns.some(run=>{const joined=run.replaceAll(' ','');return abbreviations.has(joined)||compactPhrases.has(joined)||foldedWords.has(joined);});
}
export const MODERATION_MESSAGE='Nội dung chưa phù hợp với môi trường học đường. Vui lòng sử dụng từ ngữ lịch sự.';
export function profileModerationError(profile){return ['name','subject','className','note'].some(k=>inappropriateProfileText(profile?.[k]))?MODERATION_MESSAGE:'';}
export function safeProfileFields(profile){const result={...profile};for(const k of ['name','subject','className','note'])if(inappropriateProfileText(result[k]))result[k]='';return result;}
