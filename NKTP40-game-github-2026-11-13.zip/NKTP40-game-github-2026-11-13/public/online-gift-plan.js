export const ONLINE_GIFT=Object.freeze({id:'admin-online-20261111-2100',at:Date.parse('2026-11-11T21:00:00+07:00'),amount:40000});
