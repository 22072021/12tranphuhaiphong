import * as T from './vendor/three.module.js';
import {importAsset,assetFailure} from './asset-retry.js';
import {punishmentPlan} from './punishment-plan.js';

// Static teacher reuses the áo dài rig and approved left-arm pointing pose.
export function createFlagpoleTeacher(layout){
 const g=new T.Group();g.name='flagpole-punishment-teacher';const points=punishmentPlan(layout);if(!points.length)return g;
 const center=new T.Vector3();for(const p of points)center.add(new T.Vector3(p.x,p.feet,p.z));center.multiplyScalar(1/points.length);
 const forward=new T.Vector3(Math.sin(points[0].yaw),0,Math.cos(points[0].yaw));
 g.position.copy(center).addScaledVector(forward,2.5);g.rotation.y=Math.atan2(-forward.x,-forward.z);
 g.userData={npc:true,dialogue:'Đứng hết tiết 2 mới cho vào lớp',pose:'left-hand-point-ground-in-front',facing:center.toArray()};
 const obstacle=new T.Mesh(new T.BoxGeometry(.44,1.65,.44),new T.MeshBasicMaterial({visible:false}));obstacle.position.y=.825;obstacle.userData.walkRole='barrier';g.add(obstacle);
 if(typeof document==='undefined')return g;
 g.userData.textureReady=importAsset(new URL('./characters/teacher.js',import.meta.url).href).then(({createTeacher})=>{
  for(let p=g;p;p=p.parent)if(p.userData.disposed)return;
  const avatar=createTeacher({gender:'female',studentScale:.93,aoDaiColor:'#b8a1c8'});avatar.root.userData.walkIgnore=true;g.add(avatar.root);avatar.update(0,'idle');const j=avatar.joints;
  // Left hand points at the ground directly in front of her, with a relaxed elbow.
  j.leftShoulder.rotation.set(-.34,0,.12);j.leftElbow.rotation.set(-.12,0,0);
  j.rightShoulder.rotation.set(0,0,0);j.rightElbow.rotation.set(-.04,0,0);
  const hand=avatar.root.getObjectByName('left-hand'),finger=new T.Mesh(new T.CapsuleGeometry(.009,.055,3,6),new T.MeshStandardMaterial({color:'#F2C69D',roughness:.95}));finger.position.set(0,-.095,.01);hand.add(finger);
  avatar.updateGarment?.(0);g.updateMatrixWorld(true);g.userData.ready=true;window.dispatchEvent(new Event('nktp-texture-ready'));
 }).catch(e=>assetFailure(g,e));return g;
}
