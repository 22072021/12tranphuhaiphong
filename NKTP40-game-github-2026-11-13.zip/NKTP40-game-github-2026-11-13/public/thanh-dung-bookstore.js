import {createSignCanvas} from './sign-canvas.js';
import * as T from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js';
// Two adjacent frontage bays. Location within alley is provisional; address follows supplied photo.
export const BOOKSTORE={firstBay:17,bays:2,width:8.4,depth:4.8,address:'36/49 Trần Phú'};
export function createThanhDungBookstore(){
 const g=new T.Group();g.name='thanh-dung-bookstore';g.userData={id:'THANH-DUNG-BOOKSTORE',address:BOOKSTORE.address,placement:'right side entering alley, around house18; owner confirmed',reference:'owner yellow-frontage photograph'};
 const k=geometryKit(g),{box}=k,W=BOOKSTORE.width,D=BOOKSTORE.depth,yellow='#edbd35',wood='#775237',paper=['#e7dfc4','#c8d4b3','#b7d5cf','#c7a657','#b58b68','#93a9ba'];
 box(.18,6.6,D,-W/2+.09,3.3,D/2,'#bcb6a3');box(.18,6.6,D,W/2-.09,3.3,D/2,'#bcb6a3');box(W,6.6,.18,0,3.3,D-.09,'#bcb6a3');
 box(W,.14,D,0,.02,D/2,'#87867a');box(W,.16,D,0,3.32,D/2,'#eeeadc');box(W,3.2,D,0,5.0,D/2,'#bcb6a3');box(W+.15,.16,D+.12,0,6.68,D/2,'#858a80');
 // Recessed threshold, open entrance and yellow sign piers: no solid box behind storefront.
 for(const [x,w]of[[-4.04,.32],[-1.12,.40],[4.04,.32]])box(w,2.55,.25,x,1.375,0,yellow);
 box(W,.95,.30,0,3.02,-.035,yellow);box(W,.14,.6,0,3.56,.05,'#d4a438');
 for(const x of[-2.55,1.75]){box(2.45,1.7,.06,x,5.05,-.025,'#536c69');for(const xx of[x-1.23,x,x+1.23])box(.045,1.76,.08,xx,5.05,-.07,'#d7d2c0');for(const yy of[4.18,5.92])box(2.5,.045,.08,x,yy,-.07,'#d7d2c0');}
 function sign(name,w,h,x,y,z,paint){const c=createSignCanvas(w,h,paint);const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;tex.anisotropy=4;const m=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshBasicMaterial({map:tex}));m.rotation.y=Math.PI;m.position.set(x,y,z);m.name=name;m.userData.walkRole='none';g.add(m);return m;}
 function text(c,t,x,y,size,color,width){c.fillStyle=color;c.textAlign='center';c.font=`700 ${size}px Arial, sans-serif`;c.fillText(t,x,y,width);}
 function logo(c,x,y,r){c.fillStyle='#f6f1dc';c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();c.strokeStyle='#466980';c.lineWidth=r*.075;for(let j=0;j<3;j++){c.beginPath();c.moveTo(x-r*.7,y+j*r*.13);c.quadraticCurveTo(x-r*.35,y-r*.3+j*r*.13,x,y+r*.1+j*r*.13);c.quadraticCurveTo(x+r*.35,y-r*.3+j*r*.13,x+r*.7,y+j*r*.13);c.stroke();}c.beginPath();c.moveTo(x,y-r*.35);c.lineTo(x+r*.25,y-r*.55);c.stroke();}
 sign('thanh-dung-yellow-fascia',W-.05,.91,0,3.02,-.193,(c,w,h)=>{c.fillStyle='#f4c433';c.fillRect(0,0,w,h);logo(c,105,h*.51,74);text(c,'Nhà sách ngoại ngữ chuyên nghiệp',w*.44,h*.31,62,'#393b26',w*.66);text(c,'THÀNH DŨNG',w*.44,h*.83,133,'#e97020',w*.68);text(c,'091.485.6662 - 083.695.9999',w*.85,h*.42,28,'#393b26',w*.28);text(c,'36/49 Trần Phú',w*.85,h*.71,43,'#393b26',w*.28);});
 // Slim printed yellow panels flank the wide main entrance.
 for(const x of[-1.12,4.04])sign('bookstore-yellow-side-panel',x<0?.38:.30,2.45,x,1.38,-.135,(c,w,h)=>{c.fillStyle='#efbd2d';c.fillRect(0,0,w,h);logo(c,w/2,h*.12,w*.34);for(const [i,t]of['NHÀ SÁCH','THÀNH DŨNG','36/49','TRẦN PHÚ'].entries())text(c,t,w/2,h*(.35+i*.12),w*.14,'#3d3b29',w*.92);});
 let bookCount=0;
 // Furniture collides, books and small trim don't produce thousands of physics bodies.
 function shelf(x,z,w,d,h=2.55){box(w,h,d,x,.12+h/2,z,wood);for(let row=0;row<Math.floor((h-.2)/.46);row++){const y=.20+row*.46;box(w,.045,d+.035,x,y,z,'#ad8154');k.withCollision('none',()=>{const n=Math.floor(w/.11);for(let b=0;b<n;b++){const bh=.28+((b*7+row*3)%5)*.026;box(.073,bh,.16,x-w/2+.09+b*(w-.12)/n,y+.025+bh/2,z-d/2-.06,paper[(b+row)%paper.length]);bookCount++;}});}}
 // Side and rear shelves form an actual room with a clear customer aisle.
 shelf(-2.62,3.92,2.6,.42);shelf(.43,4.18,2.9,.42);shelf(2.93,4.18,1.8,.42);
 for(const x of[-3.69,3.69])for(let j=0;j<3;j++){const unit=new T.Group();const other=geometryKit(unit);other.box(.40,2.60,1.1,0,1.42,0,wood);for(let row=0;row<5;row++){other.box(.45,.045,1.13,0,.22+row*.48,0,'#ad8154');other.withCollision('none',()=>{for(let n=0;n<8;n++){other.box(.15,.32,.075,x<0?.25:-.25,.41+row*.48,-.46+n*.125,paper[(n+row+j)%6]);bookCount++;}});}other.finish();unit.position.set(x,0,1.25+j*1.13);g.add(unit);}
 // Low wheeled book rack in left bay, like the photo.
 shelf(-2.65,.62,2.1,.50,1.58);
 for(const x of[-3.55,-1.75]){const wheel=new T.Mesh(new T.CylinderGeometry(.065,.065,.045,10),new T.MeshStandardMaterial({color:'#525a54'}));wheel.rotation.z=Math.PI/2;wheel.position.set(x,.09,.4);wheel.userData.walkSupport=false;g.add(wheel);}
 // Right entrance display and red cashier cabinet leave the centre opening clear.
 shelf(1.77,.60,.85,.48,1.38);box(1.55,1.02,.70,3.05,.63,.61,'#ae5140');box(1.62,.055,.76,3.05,1.17,.61,'#c9cbc0');
 const glass=new T.MeshStandardMaterial({color:'#c8dedb',transparent:true,opacity:.20,roughness:.18,depthWrite:false});const pane=new T.Mesh(new T.BoxGeometry(1.55,.52,.018),glass);pane.position.set(3.05,1.46,.27);pane.userData.walkRole='none';g.add(pane);
 for(const x of[2.28,3.82])box(.035,.58,.035,x,1.46,.27,'#b7c3bd');for(const y of[1.19,1.72])box(1.58,.035,.035,3.05,y,.27,'#b7c3bd');
 k.withCollision('none',()=>{for(let pile=0;pile<3;pile++)for(let j=0;j<5;j++)box(.36,.035,.24,2.6+pile*.42,1.2+j*.038,.60,paper[(pile+j)%6]);});
 sign('red-book-counter-logo',.46,.46,3.05,.65,.25,(c,w,h)=>{c.fillStyle='#ae5140';c.fillRect(0,0,w,h);logo(c,w/2,h/2,w*.44);});
 // Interior banner and bright ceiling strips.
 sign('bookstore-interior-motto',3.6,.56,.5,2.63,3.94,(c,w,h)=>{c.fillStyle='#ddbc40';c.fillRect(0,0,w,h);text(c,'BIẾT THÊM MỘT NGOẠI NGỮ',w/2,h*.45,105,'#394235',w*.94);text(c,'LÀ SỐNG THÊM MỘT CUỘC ĐỜI',w/2,h*.86,92,'#394235',w*.94);});
 for(const x of[-2.55,.4,2.8]){const lamp=new T.Mesh(new T.BoxGeometry(.08,.035,2.5),new T.MeshBasicMaterial({color:'#fff8da'}));lamp.position.set(x,3.22,2.2);lamp.userData.walkRole='none';g.add(lamp);}
 // Potted plant beside the red counter, with stems attached to the pot.
 const pot=new T.Mesh(new T.CylinderGeometry(.25,.19,.48,14),new T.MeshStandardMaterial({color:'#6b6c61',roughness:1}));pot.position.set(3.85,.34,-.15);pot.userData.walkSupport=false;g.add(pot);
 k.box(.045,1.45,.045,3.85,1.05,-.15,'#75644a');
 const leaves=new T.InstancedMesh(new T.SphereGeometry(1,8,5),new T.MeshStandardMaterial({color:'#5f7b46',roughness:1}),24),matrix=new T.Matrix4(),q=new T.Quaternion();for(let i=0;i<24;i++){const angle=i*2.4,y=.75+(i%8)*.13;matrix.compose(new T.Vector3(3.85+Math.cos(angle)*.23,y,-.15+Math.sin(angle)*.23),q.setFromEuler(new T.Euler(0,angle,.45)),new T.Vector3(.20,.06,.09));leaves.setMatrixAt(i,matrix);}leaves.userData.walkRole='none';g.add(leaves);
 k.finish();
 // Front is viewed toward +Z: reverse placement X, keeping lettering unmirrored.
 g.traverse(o=>{if(o===g)return;o.position.x*=-1;if(o.isInstancedMesh){const m=new T.Matrix4();for(let i=0;i<o.count;i++){o.getMatrixAt(i,m);m.elements[12]*=-1;o.setMatrixAt(i,m);}o.instanceMatrix.needsUpdate=true;o.computeBoundingBox();o.computeBoundingSphere();}});
 g.userData.books=bookCount;return g;
}
