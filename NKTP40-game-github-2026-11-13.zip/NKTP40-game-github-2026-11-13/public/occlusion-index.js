import * as THREE from './vendor/three.module.js';
// Static instance bounds are indexed once, not triangle-tested across the campus per ray.
export function createOcclusionIndex(roots,cellSize=6){
 const grid=new Map(),dynamic=[],m=new THREE.Matrix4(),w=new THREE.Matrix4(),probe=new THREE.Mesh(),point=new THREE.Vector3();
 probe.matrixAutoUpdate=false;
 const visible=o=>{for(let p=o;p;p=p.parent)if(!p.visible)return false;return true;};
 for(const root of roots.filter(Boolean)){root.updateWorldMatrix(true,true);root.traverse(o=>{
  if(!o.isMesh||o.userData.walkRole==='none'||o.userData.signText)return;for(let p=o;p;p=p.parent)if(p.userData.npc||p.userData.walkIgnore)return;let moving=false;for(let p=o;p;p=p.parent)if(p.userData.door||p.userData.operableWindow)moving=true;
  if(moving){dynamic.push(o);return;}
  if(!o.geometry.boundingBox)o.geometry.computeBoundingBox();
  for(let i=0;i<(o.isInstancedMesh?o.count:1);i++){if(o.isInstancedMesh){o.getMatrixAt(i,m);w.multiplyMatrices(o.matrixWorld,m);}else w.copy(o.matrixWorld);const box=o.geometry.boundingBox.clone().applyMatrix4(w),entry={object:o,index:o.isInstancedMesh?i:undefined,box,matrix:w.clone()};
   for(let x=Math.floor(box.min.x/cellSize);x<=Math.floor(box.max.x/cellSize);x++)for(let z=Math.floor(box.min.z/cellSize);z<=Math.floor(box.max.z/cellSize);z++){const k=x+','+z;if(!grid.has(k))grid.set(k,[]);grid.get(k).push(entry);}
  }
 });}
 return {intersect(raycaster){const hits=[],candidates=new Set(),end=raycaster.ray.at(raycaster.far,point),start=raycaster.ray.origin;
  for(let x=Math.floor(Math.min(start.x,end.x)/cellSize);x<=Math.floor(Math.max(start.x,end.x)/cellSize);x++)for(let z=Math.floor(Math.min(start.z,end.z)/cellSize);z<=Math.floor(Math.max(start.z,end.z)/cellSize);z++)for(const e of grid.get(x+','+z)||[])candidates.add(e);
  for(const e of candidates){if(!visible(e.object)||!raycaster.ray.intersectsBox(e.box))continue;probe.geometry=e.object.geometry;probe.material=e.object.material;probe.matrixWorld.copy(e.matrix);const local=[];probe.raycast(raycaster,local);for(const hit of local)hits.push({...hit,object:e.object,instanceId:e.index});}
  for(const o of dynamic)if(visible(o))raycaster.intersectObject(o,false,hits);
  return hits;
 },stats:{cells:grid.size,dynamic:dynamic.length}};
}
