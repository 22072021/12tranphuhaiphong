import * as T from './vendor/three.module.js';
import {createCampusNPC} from './campus-npcs.js';
export function createStickyRiceStall(){
 const g=new T.Group();g.name='sticky-rice-vendor-demo';
 const mat=(color,extra={})=>new T.MeshStandardMaterial({color,roughness:.8,...extra});
 const metal=mat('#c5cbd0',{metalness:.65,roughness:.32}),white=mat('#eee9dd'),basket=mat('#a27b4e'),blanket=mat('#8c6970');
 function mesh(geo,m,x,y,z,parent=g){const o=new T.Mesh(geo,m);o.position.set(x,y,z);parent.add(o);return o;}
 const box=(w,h,d,x,y,z,m,parent=g)=>mesh(new T.BoxGeometry(w,h,d),m,x,y,z,parent);
 const cyl=(r,h,x,y,z,m)=>mesh(new T.CylinderGeometry(r,r,h,32),m,x,y,z);
 // Small freestanding glass cabinet, with aluminium rails and two food trays.
 const cabinet=new T.Group();cabinet.name='small-glass-food-cabinet';g.add(cabinet);
 const glass=mat('#cce5e6',{transparent:true,opacity:.16,roughness:.12,depthWrite:false,side:T.DoubleSide});
 for(const x of [-.37,.37])for(const z of [.15,.65])box(.025,.68,.025,x,.67,z,metal,cabinet);
 for(const y of [.34,1.0]){box(.79,.028,.55,0,y,.40,metal,cabinet);for(const z of [.135,.665])box(.79,.026,.022,0,y,z,metal,cabinet);}
 box(.74,.60,.008,0,.67,.656,glass,cabinet);for(const x of [-.375,.375])box(.008,.60,.49,x,.67,.40,glass,cabinet);
 box(.74,.013,.49,0,.61,.40,metal,cabinet);
 const plastic=mat('#e4e1d5',{transparent:true,opacity:.62,depthWrite:false});
 for(const [x,y]of [[-.18,.64],[.18,.36]]){box(.31,.023,.37,x,y,.40,white);for(const xx of [x-.155,x+.155])box(.008,.115,.37,xx,y+.06,.40,plastic);for(const z of [.215,.585])box(.31,.115,.008,x,y+.06,z,plastic);for(let i=0;i<13;i++){const meat=mesh(new T.SphereGeometry(1,10,6),mat(i%3?'#97573b':'#c68a60'),x-.1+(i%4)*.063,y+.05+Math.floor(i/4)*.018,.28+((i*7)%5)*.052);meat.scale.set(.041,.019,.029);meat.rotation.y=i*.7;}}
 // Woven basket to the vendor's left, surrounding the heat-insulated rice pot.
 const bx=-.86,bz=.12;
 const profile=[[.23,0],[.29,.10],[.33,.40],[.34,.46]].map(([r,y])=>new T.Vector2(r,y));mesh(new T.LatheGeometry(profile,40),basket,bx,.025,bz);
 for(let n=0;n<15;n++){const ring=mesh(new T.TorusGeometry(.245+n*.006,.009,5,40),mat(n%2?'#bd996b':'#806443'),bx,.045+n*.029,bz);ring.rotation.x=Math.PI/2;}
 for(let n=0;n<40;n++){const a=n*Math.PI/20,rod=mesh(new T.CylinderGeometry(.005,.005,.44,5),mat('#c4a578'),bx+Math.cos(a)*.293,.25,bz+Math.sin(a)*.293);rod.rotation.z=-Math.cos(a)*.18;rod.rotation.x=Math.sin(a)*.18;}
 // Folded quilt wrapped around pot; opening exposes rice instead of a closed lid.
 const cloth=mesh(new T.TorusGeometry(.235,.085,12,40),blanket,bx,.43,bz);cloth.rotation.x=Math.PI/2;cloth.scale.z=1.7;
 for(let n=0;n<10;n++){const a=n*Math.PI/5,fold=mesh(new T.SphereGeometry(1,12,8),mat(n%2?'#ad8585':'#92737b'),bx+Math.cos(a)*.23,.43,bz+Math.sin(a)*.23);fold.scale.set(.085,.13,.085);}
 cyl(.185,.10,bx,.46,bz,metal);cyl(.176,.02,bx,.517,bz,mat('#f0e4bd'));
 const riceGeo=new T.SphereGeometry(.009,5,4),riceMat=mat('#eee4c7');for(let i=0;i<65;i++){const a=i*2.4,r=.16*Math.sqrt((i+.5)/65),grain=mesh(riceGeo,riceMat,bx+Math.cos(a)*r,.535+(i%4)*.003,bz+Math.sin(a)*r);grain.scale.set(1.7,.55,.7);}
 // Foam takeaway boxes, condiment bottle and serving spoon on top.
 for(let n=0;n<4;n++)box(.22,.027,.16,-.18,1.03+n*.027,.40,white);
 cyl(.035,.15,.20,1.09,.40,mat('#b8412e'));cyl(.025,.03,.20,1.18,.40,mat('#e1bd42'));
 const spoon=mesh(new T.SphereGeometry(1,12,6),metal,bx+.11,.55,bz);spoon.scale.set(.04,.008,.065);box(.018,.012,.22,bx+.11,.55,bz+.12,metal);
 const chair=box(.40,.04,.37,-.23,.40,-.48,mat('#466ba4'));for(const x of [-.39,-.07])for(const z of [-.62,-.34])box(.035,.39,.035,x,.195,z,chair.material);
 const seller=createCampusNPC({id:'sticky-rice',name:'Chị bán xôi',female:true,seated:true,seatHeight:.42});seller.position.set(-.23,0,-.48);seller.userData.dialogue='Xôi mới nấu ngon lắm!';g.add(seller);
 g.userData.textureReady=seller.userData.textureReady?.then(()=>{const head=seller.getObjectByName('head');if(!head)return;
 // Checked brimmed hat and blue padded vest inspired by the supplied photo.
 const canvas=document.createElement('canvas');canvas.width=canvas.height=64;const c=canvas.getContext('2d');c.fillStyle='#c7c6bd';c.fillRect(0,0,64,64);c.fillStyle='#4d5155';for(let x=0;x<64;x+=8)for(let y=0;y<64;y+=8)if((x+y)%16===0)c.fillRect(x,y,4,4);const tex=new T.CanvasTexture(canvas);tex.colorSpace=T.SRGBColorSpace;tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.repeat.set(4,2);const hat=mat('#ffffff',{map:tex});mesh(new T.CylinderGeometry(.145,.185,.16,24),hat,0,.34,0,head);mesh(new T.CylinderGeometry(.255,.26,.018,32),hat,0,.264,0,head);
 const torso=seller.getObjectByName('torso');for(const x of [-.096,.096])for(let n=0;n<5;n++)box(.176,.052,.22,x,.07+n*.054,.005,mat(n%2?'#305fba':'#3b6ecc'),torso);
 });return g;
}
