import {createMaleUniform,createMaleSleeve} from './male-uniform.js?v=237.0';
import {createFemaleUniform,createSleevePiping} from './female-uniform.js?v=237.0';
import {softAvatarForm} from './avatar-shapes.js?v=236.0';
import * as THREE from './vendor/three.module.js';

export const AVATAR={height:1.494,scale:.9,hip:.855,upperLeg:.39,lowerLeg:.39,ankle:.075,stride:1.12};
const damp=(a,b,k,dt)=>a+(b-a)*(1-Math.exp(-k*dt));
export function turnToward(angle,target,dt,rate=12){return angle+Math.atan2(Math.sin(target-angle),Math.cos(target-angle))*(1-Math.exp(-rate*dt));}
export function solveLeg(y,z){const a=AVATAR.upperLeg,b=AVATAR.lowerLeg,d=THREE.MathUtils.clamp(Math.hypot(y,z),.08,a+b-.003),direction=Math.atan2(-z,-y),alpha=Math.acos(THREE.MathUtils.clamp((a*a+d*d-b*b)/(2*a*d),-1,1)),knee=Math.PI-Math.acos(THREE.MathUtils.clamp((a*a+b*b-d*d)/(2*a*b),-1,1));return{hip:direction-alpha,knee};}

export function createVisitorAvatar({appearance='male'}={}){
 const root=new THREE.Group();root.name='visitor-avatar';root.scale.setScalar(.9);root.userData.walkIgnore=true;const hips=new THREE.Group();root.add(hips);
 const materials={},meshes=[];const mat=(name,color)=>materials[name]??=(new THREE.MeshStandardMaterial({color,roughness:.83}));
 const shirt=mat('shirt','#e8e5dc'),pants=mat('pants','#354c64'),skin=mat('skin','#bb8f6a'),hair=mat('hair','#302b28'),shoe=mat('shoe','#303738'),trim=mat('trim','#a9b4b6'),navy=mat('uniform-piping','#202e49'),badgeMat=mat('sleeve-badge','#ffffff');
 if(typeof document!=='undefined'){const badgeTexture=new THREE.TextureLoader().load('/assets/uniform/sleeve-badge.png?v=237');badgeTexture.colorSpace=THREE.SRGBColorSpace;badgeMat.map=badgeTexture;}
 function mesh(parent,geometry,material,x=0,y=0,z=0){const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=false;m.receiveShadow=true;parent.add(m);meshes.push(m);return m;}
 const torso=new THREE.Group();hips.add(torso);
 const body=mesh(torso,softAvatarForm([[-.085,.164,.108],[.015,.158,.103],[.08,.154,.099],[.20,.153,.10],[.35,.177,.11],[.44,.173,.095],[.49,.115,.07],[.515,.056,.05]]),shirt);
 const femaleBody=mesh(torso,softAvatarForm([[-.10,.169,.108],[.015,.157,.100],[.08,.142,.09],[.18,.127,.083],[.29,.143,.096],[.38,.158,.100],[.44,.150,.084],[.485,.10,.063],[.515,.05,.046]]),shirt);femaleBody.name='female-tailored-blouse';
 const pelvisMesh=mesh(hips,softAvatarForm([[-.11,.12,.08],[-.05,.157,.098],[.025,.145,.09]]),pants);
 const uniform=createFemaleUniform(torso,mesh,shirt,navy),maleUniform=createMaleUniform(torso,mesh,shirt,trim);
 for(let i=0;i<5;i++)mesh(torso,new THREE.SphereGeometry(.006,8,6),trim,0,.12+i*.066,.103);

 mesh(torso,new THREE.CylinderGeometry(.052,.063,.10,24),skin,0,.54,0);
 const head=new THREE.Group();head.position.y=.68;torso.add(head);const face=mesh(head,new THREE.SphereGeometry(.122,32,24),skin);face.scale.set(.88,1.10,.94);face.name='blank-face-surface';face.userData={blankFace:true,futureFaceTexture:true,forwardAxis:'+Z'};
 mesh(head,new THREE.SphereGeometry(.133,32,20,0,Math.PI*2,0,Math.PI*.54),hair,0,.017,-.006).scale.set(.91,1.04,.98);
 for(const side of [-1,1]){mesh(head,new THREE.SphereGeometry(.024,16,12),skin,side*.116,-.002,-.003);}
 const longHair=new THREE.Group();longHair.name='female-long-hair';head.add(longHair);
 const hairFall=mesh(longHair,softAvatarForm([[-.39,.054,.025],[-.34,.103,.04],[-.23,.122,.05],[-.09,.123,.058],[.02,.113,.055],[.075,.085,.032]],{segments:32,rings:28,fold:.018}),hair,0,0,-.077);hairFall.name='soft-long-hair-fall';
 for(const sign of [-1,1]){const path=new THREE.CatmullRomCurve3([new THREE.Vector3(sign*.074,.10,.058),new THREE.Vector3(sign*.111,.015,.028),new THREE.Vector3(sign*.118,-.13,-.005),new THREE.Vector3(sign*.096,-.26,-.06)]);mesh(longHair,new THREE.TubeGeometry(path,24,.018,8,false),hair);}
 const arms=[],legs=[];
 for(const side of [-1,1]){
  const arm=new THREE.Group();arm.position.set(side*.19,.45,0);arm.rotation.z=side*.02;torso.add(arm);mesh(arm,softAvatarForm([[-.20,.041,.042],[-.15,.049,.048],[-.07,.054,.05],[.015,.036,.035]],{rings:18}),shirt);
  const shoulder=mesh(arm,new THREE.SphereGeometry(.052,24,16),shirt,0,-.018,0);shoulder.scale.set(1,1,.94);shoulder.name='connected-shirt-shoulder';
  const upperArm=mesh(arm,softAvatarForm([[-.285,.036,.035],[-.23,.038,.037],[-.16,.042,.04],[-.12,.043,.04]],{rings:18}),skin);upperArm.name='continuous-upper-arm';const sleevePipe=createSleevePiping(arm,mesh,navy);
  const elbow=new THREE.Group();elbow.position.y=-.265;arm.add(elbow);mesh(elbow,new THREE.SphereGeometry(.041,24,16),skin);mesh(elbow,softAvatarForm([[-.23,.025,.025],[-.17,.030,.028],[-.08,.037,.034],[.025,.037,.036]],{rings:18}),skin);mesh(elbow,new THREE.SphereGeometry(.037,24,16),skin,0,-.245,0);const maleSleeve=createMaleSleeve(arm,elbow,mesh,shirt);if(side===1){const badge=mesh(arm,new THREE.PlaneGeometry(.050,.062),badgeMat,.055,-.085,0);badge.rotation.y=Math.PI/2;badge.name='left-school-sleeve-badge';}arms.push({arm,elbow,upperArm,sleevePipe,shoulder,maleSleeve});
  const leg=new THREE.Group();leg.position.set(side*.105,0,0);hips.add(leg);const thigh=mesh(leg,softAvatarForm([[-.405,.048,.05],[-.31,.058,.057],[-.17,.07,.066],[.025,.077,.071]],{rings:22}),pants);
  const knee=new THREE.Group();knee.position.y=-AVATAR.upperLeg;leg.add(knee);const kneecap=mesh(knee,new THREE.SphereGeometry(.049,24,16),pants);const shin=mesh(knee,softAvatarForm([[-.39,.035,.034],[-.31,.041,.04],[-.16,.052,.052],[.018,.048,.05]],{rings:22}),pants);
  const ankle=new THREE.Group();ankle.position.y=-AVATAR.lowerLeg;knee.add(ankle);const footShape=new THREE.CapsuleGeometry(.061,.15,8,24);footShape.rotateX(Math.PI/2);const foot=mesh(ankle,footShape,shoe,0,-.035,.055);foot.scale.y=.65;legs.push({leg,knee,ankle,side,thigh,kneecap,shin,foot});
 }
 let hipSpread=.10;function setAppearance(value){appearance=value==='female'?'female':'male';const female=appearance==='female';longHair.visible=female;body.visible=!female;femaleBody.visible=female;uniform.visible=female;maleUniform.visible=!female;pelvisMesh.scale.x=female?1.08:1;hipSpread=female?.092:.10;face.scale.set(female?.86:.9,1.10,.94);
 for(let i=0;i<2;i++){const a=arms[i].arm,j=legs[i];a.position.x=(i?1:-1)*(female?.155:.182);a.rotation.z=(i?1:-1)*.045;a.scale.x=female?.89:1;a.scale.z=female?.9:1;j.leg.position.x=j.side*hipSpread;j.leg.scale.x=female?.87:1;j.thigh.visible=true;j.thigh.material=pants;j.kneecap.material=pants;j.shin.material=pants;arms[i].sleevePipe.visible=female;arms[i].maleSleeve.top.visible=arms[i].maleSleeve.rolled.visible=!female;j.foot.scale.set(female?.87:1,female?.52:.65,female?.88:1);}
 root.userData.appearance=appearance;root.userData.blankFace=true;}setAppearance(appearance);
 const alpha=new Uint8Array(32*32*4);for(let y=0;y<32;y++)for(let x=0;x<32;x++){const i=(y*32+x)*4,r=Math.hypot((x-15.5)/15.5,(y-15.5)/15.5);alpha[i+3]=Math.round(110*Math.max(0,1-r)**2);}
 const texture=new THREE.DataTexture(alpha,32,32);texture.magFilter=THREE.LinearFilter;texture.minFilter=THREE.LinearFilter;texture.needsUpdate=true;const shadow=new THREE.Mesh(new THREE.PlaneGeometry(.80,.70),new THREE.MeshBasicMaterial({map:texture,transparent:true,depthWrite:false}));shadow.rotation.x=-Math.PI/2;shadow.visible=false;root.add(shadow);
 let phase=0,blend=0,vertical=0,pelvis=0,time=0,heading=0,lastFeet=0,stairBlend=0,sitBlend=0,seatPhase=0,seatMotion=0,seatDirection=0,lastStep=0,slideX=0,slideZ=0,ankleHeights=[NaN,NaN];
 function reset(state,facing=0){phase=0;blend=0;time=0;lastStep=-100;vertical=state.feet;lastFeet=state.feet;pelvis=0;slideX=0;slideZ=0;ankleHeights=[NaN,NaN];heading=facing;root.position.set(state.x,state.feet,state.z);root.rotation.y=facing;update(0,{...state,dx:0,dz:0},()=>state.feet);}
 function update(dt,state,support){
  dt=Math.min(dt,.1);time+=dt;const distance=Math.hypot(state.dx||0,state.dz||0),speed=dt?distance/dt:0;
  if(distance>.0001&&!state.seated){heading=Math.atan2(state.dx,state.dz);phase+=Math.min(distance/THREE.MathUtils.lerp(speed>2.5?1.85:AVATAR.stride,.76,stairBlend),dt*2.15)*Math.PI*2;}
  if(state.seated)heading=state.seatYaw??heading;
  blend=damp(blend,Math.min(1,speed/1.1),12,dt);root.rotation.y=turnToward(root.rotation.y,heading,dt);
  if(Math.abs(state.feet-lastFeet)>.035)lastStep=time;lastFeet=state.feet;stairBlend=damp(stairBlend,time-lastStep<.35?1:0,9,dt);
  const centerGround=support(state.x,state.z,state.feet+.28),groundedTarget=state.feet-centerGround<.30&&state.feet>=centerGround?centerGround:state.feet;vertical=damp(vertical,groundedTarget,16,dt);slideX=damp(slideX,state.sliding?(state.slideOffsetX||0):0,state.sliding?18:5,dt);slideZ=damp(slideZ,state.sliding?(state.slideOffsetZ||0):0,state.sliding?18:5,dt);root.position.set(state.x+slideX,vertical,state.z+slideZ);const yaw=root.rotation.y,c=Math.cos(yaw),s=Math.sin(yaw),targets=[];
  for(let i=0;i<2;i++){const p=(phase+i*Math.PI)%(Math.PI*2),swing=p<Math.PI?Math.sin(p):0,t=p/Math.PI,stepZ=p<Math.PI?(-.25+.5*t*t*(3-2*t)):(.25-.5*(t-1)),z=stepZ*THREE.MathUtils.lerp(AVATAR.stride,.76,stairBlend)*blend,x=legs[i].side*hipSpread;
   const ground=support(state.x+c*x+s*z,state.z-s*x+c*z,state.feet+.30),lift=(.055+.10*stairBlend)*swing*blend;
   const desiredY=ground+AVATAR.ankle*AVATAR.scale+lift;ankleHeights[i]=Number.isFinite(ankleHeights[i])?Math.max(ground+AVATAR.ankle*AVATAR.scale,damp(ankleHeights[i],desiredY,22,dt)):desiredY;targets.push({y:ankleHeights[i]-vertical,z,ground});
  }
  const lower=Math.min(...targets.map(p=>p.ground))-vertical,compensation=Math.max(-.16,Math.min(0,lower));pelvis=damp(pelvis,compensation,14,dt);
  hips.position.y=AVATAR.hip+pelvis+Math.cos(phase*2)*.009*blend;hips.rotation.z=Math.sin(phase)*(appearance==='female'?.022:.012)*blend;hips.rotation.y=Math.sin(phase)*.022*blend;torso.rotation.x=(speed>2.5?.035:.015)*blend;torso.rotation.y=-hips.rotation.y*.75;torso.rotation.z=-hips.rotation.z*.40;
  for(let i=0;i<2;i++){const t=targets[i],pose=solveLeg(t.y/AVATAR.scale-hips.position.y,t.z),p=phase+i*Math.PI;legs[i].leg.rotation.x=pose.hip;legs[i].knee.rotation.x=pose.knee;legs[i].ankle.rotation.x=-pose.hip-pose.knee;arms[i].arm.rotation.x=-Math.cos(p-.15)*.30*blend;arms[i].elbow.rotation.x=-.12-Math.max(0,-Math.cos(p-.15))*.20*blend;}
  head.rotation.y=THREE.MathUtils.clamp(Math.atan2(Math.sin(heading-yaw),Math.cos(heading-yaw))*.35,-.3,.3);head.rotation.x=Math.sin(time*.8)*.015*(1-blend);
  sitBlend=damp(sitBlend,state.seated?1:0,14,dt);
  const seatVelocity=state.seated&&dt?((state.dx||0)*Math.cos(state.seatYaw??0)-(state.dz||0)*Math.sin(state.seatYaw??0))/dt:0;
  seatMotion=damp(seatMotion,state.sliding?0:Math.min(1,Math.abs(seatVelocity)/.5),12,dt);seatDirection=damp(seatDirection,Math.sign(seatVelocity),10,dt);if(state.seated&&!state.sliding)seatPhase+=distance/.70*Math.PI*2;
  if(sitBlend>.001){
   root.rotation.y=turnToward(root.rotation.y,state.seatYaw??heading,dt,16);
   // Pelvis rests above the timber, thighs slope gently down and shins stay vertical.
   const shuffle=state.sliding?0:Math.sin(seatPhase),press=state.sliding?0:(1-Math.cos(seatPhase))*.5;
   hips.position.y=THREE.MathUtils.lerp(hips.position.y,((state.seatHeight??.43)+.09)/.9+press*.018*seatMotion,sitBlend);
   hips.position.x=shuffle*.018*seatMotion*sitBlend;hips.rotation.z=-seatDirection*.055*seatMotion*sitBlend;hips.rotation.y*=1-sitBlend;
   torso.rotation.x=THREE.MathUtils.lerp(torso.rotation.x,-.04,sitBlend);torso.rotation.z=seatDirection*.085*seatMotion*sitBlend;
   for(const j of legs){j.leg.rotation.x=THREE.MathUtils.lerp(j.leg.rotation.x,-1.30,sitBlend);j.knee.rotation.x=THREE.MathUtils.lerp(j.knee.rotation.x,1.30,sitBlend);j.ankle.rotation.x=THREE.MathUtils.lerp(j.ankle.rotation.x,0,sitBlend);j.leg.rotation.z=j.side*shuffle*.035*seatMotion*sitBlend;j.ankle.position.y=-AVATAR.lowerLeg;}
   for(let i=0;i<arms.length;i++){const j=arms[i],brace=(i===0?-1:1)*seatDirection;j.arm.rotation.x=(-.65+brace*.16*press*seatMotion)*sitBlend;j.elbow.rotation.x=(-.90-brace*.12*press*seatMotion)*sitBlend;j.arm.rotation.z=(i===0?-1:1)*(.02+.08*seatMotion*press)*sitBlend;}
  }else{hips.position.x=0;for(const j of legs){j.ankle.position.y=-AVATAR.lowerLeg;j.leg.rotation.z=0;}}
  body.scale.y=femaleBody.scale.y=1+Math.sin(time*1.7)*.003*(1-blend);longHair.rotation.z=damp(longHair.rotation.z,Math.sin(phase-.35)*.035*blend,6,dt);longHair.rotation.x=damp(longHair.rotation.x,-torso.rotation.x*.4,6,dt);shadow.position.y=centerGround-vertical+.015;root.updateMatrixWorld(true);
 }
 function fade(opacity){for(const material of Object.values(materials)){material.transparent=opacity<.99;material.opacity=opacity;material.depthWrite=opacity>.95;}}
 return{root,update,reset,fade,setAppearance,get pose(){return{phase,blend,heading:root.rotation.y,visualFeet:vertical,pelvis,seated:sitBlend,seatMotion,seatPhase};},get joints(){return{hips,head,arms,legs};},dispose(){const geometries=new Set();root.traverse(o=>{if(o.geometry)geometries.add(o.geometry);});for(const g of geometries)g.dispose();for(const m of Object.values(materials)){m.map?.dispose();m.dispose();}texture.dispose();shadow.material.dispose();}};
}
