import {importAsset,assetFailure} from './asset-retry.js';
import {registerNPC} from './npc-animation.js';
import * as T from './vendor/three.module.js';
// Four modern dance poses, stepped every550ms with no soft interpolation.
const POSES=[[1.6,-.4,-.3,-1.4,.10],[.4,-1.6,-1.4,-.3,-.10],[2.3,-2.3,-.4,-.4,.03],[1.1,-1.1,-1.5,-1.5,-.05]];
export function createStagePerformers({side,back,center,width,depth,top}){
 const root=new T.Group();root.name='A1-stage-five-performers';
 for(let i=0;i<5;i++){
  const singer=i===4,g=new T.Group();g.name=singer?'stage-male-singer':`stage-female-dancer-${i+1}`;
  g.position.set(side*(back+(singer?depth-.65:1.25)),top+.02,center+(singer?0:(i-1.5)*1.45));g.rotation.y=side*Math.PI/2;root.add(g);const collider=new T.Mesh(new T.BoxGeometry(.40,1.5,.35),new T.MeshBasicMaterial({visible:false}));collider.position.y=.75;collider.userData.walkRole='barrier';g.add(collider);
  if(typeof document==='undefined')continue;
  g.userData.textureReady=importAsset(new URL('./student/student.js',import.meta.url).href).then(async({createStudent,badgeReady})=>{
   await badgeReady;if(rootDisposed(g))return;const avatar=createStudent({gender:singer?'male':'female',season:'summer',scale:singer?1:.98});g.add(avatar.root);avatar.root.userData.walkIgnore=true;const j=avatar.joints;
   if(singer){const hand=avatar.root.getObjectByName('right-hand'),mic=new T.Group();mic.name='held-microphone';const stem=new T.Mesh(new T.CylinderGeometry(.018,.022,.17,10),new T.MeshStandardMaterial({color:'#34383b',metalness:.6,roughness:.4}));stem.position.y=-.015;mic.add(stem);const head=new T.Mesh(new T.SphereGeometry(.035,12,8),new T.MeshStandardMaterial({color:'#a9afb2',metalness:.6,roughness:.65}));head.position.y=.09;mic.add(head);hand.add(mic);mic.position.set(0,-.035,.02);}
   const tick=time=>{avatar.update(0,'idle');if(singer){j.rightShoulder.rotation.set(-.60,0,-.08);j.rightElbow.rotation.x=-1.75;j.torso.rotation.z=Math.sin(time*1.7)*.025;j.head.rotation.x=Math.sin(time*2)*.025;}
    else{const phase=(time/.55+i)%4,index=Math.floor(phase),u=0,a=POSES[index],b=POSES[(index+1)%4],v=a.map((n,k)=>T.MathUtils.lerp(n,b[k],u));j.leftShoulder.rotation.set(-.35,0,v[0]);j.rightShoulder.rotation.set(-.35,0,v[1]);j.leftElbow.rotation.x=v[2];j.rightElbow.rotation.x=v[3];j.torso.rotation.z=v[4];j.head.rotation.z=-v[4]*.5;j.leftHip.rotation.x=Math.sin(index*Math.PI/2+i)*.12;j.rightHip.rotation.x=-Math.sin(index*Math.PI/2+i)*.12;j.leftKnee.rotation.x=Math.max(0,Math.sin(index*Math.PI/2+i))*.20;j.rightKnee.rotation.x=Math.max(0,-Math.sin(index*Math.PI/2+i))*.20;}
    avatar.root.updateMatrixWorld(true);
   };tick(0);registerNPC(g,tick);g.userData.ready=true;window.dispatchEvent(new Event('nktp-texture-ready'));
  }).catch(error=>assetFailure(g,error));
 }
 return root;
}

function rootDisposed(g){for(let p=g;p;p=p.parent)if(p.userData.disposed)return true;return false;}
