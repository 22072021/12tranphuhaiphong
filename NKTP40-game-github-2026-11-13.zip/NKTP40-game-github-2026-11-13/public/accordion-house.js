import * as T from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js';

// P38 locates the frontage; R115–R117 document the actual lattice and handles.
// Hidden depth is provisional. The closed gate remains a campus boundary.
export const ACCORDION_HOUSE={xmin:-33.14860077821012,xmax:-28.351399221789883,frontZ:-31.75,depth:3.6,eaves:3.82,rearRoof:4.34,openingHeight:2.73,jamb:.29};
export function createAccordionHouse(){
 const p=ACCORDION_HOUSE,g=new T.Group();g.name='p38-accordion-house';
 const width=p.xmax-p.xmin,cx=(p.xmin+p.xmax)/2;
 g.position.set(cx,.3,p.frontZ);
 const k=geometryKit(g),wall='#a5a5a0',steel='#b6babe',shadow='#353732',roof='#4d5050',gateWidth=width-2*p.jamb;
 // Solid side/rear walls, lintel and grounded cement threshold. No yellow wall
 // or opaque panel is left behind the gate: its diamonds are real openings.
 for(const side of [-1,1]){
  k.box(p.jamb,p.eaves,p.depth,side*(width-p.jamb)/2,p.eaves/2,-p.depth/2,wall);
  k.box(.11,.09,p.depth+.36,side*(width/2+.01),p.eaves-.13,-p.depth/2+.12,'#77796f');
 }
 const roofY=z=>(p.eaves+p.rearRoof)/2-Math.tan(Math.atan2(p.rearRoof-p.eaves,p.depth+.65))*(z+p.depth/2-.13);
 const rearHeight=roofY(-p.depth);
 k.box(width,rearHeight,.2,0,rearHeight/2,-p.depth+.1,wall);
 k.box(gateWidth,p.eaves-p.openingHeight,.23,0,(p.eaves+p.openingHeight)/2,0,wall);
 k.box(width,roofY(0)-p.eaves,.23,0,(roofY(0)+p.eaves)/2,0,wall);
 // Side-wall wedges follow the sloping sheet, closing the gap above the eaves.
 for(const side of [-1,1]){
  const x0=side<0?-width/2:width/2-p.jamb,x1=x0+p.jamb;
  const v=[[x0,p.eaves,0],[x1,p.eaves,0],[x1,roofY(0),0],[x0,roofY(0),0],[x0,p.eaves,-p.depth],[x1,p.eaves,-p.depth],[x1,rearHeight,-p.depth],[x0,rearHeight,-p.depth]];
  const geo=new T.BufferGeometry(),pts=[];
  for(const face of [[0,1,2,3],[4,7,6,5],[0,4,5,1],[3,2,6,7],[0,3,7,4],[1,5,6,2]])for(const i of [face[0],face[1],face[2],face[0],face[2],face[3]])pts.push(...v[i]);
  geo.setAttribute('position',new T.Float32BufferAttribute(pts,3));geo.computeVertexNormals();k.solid(geo,wall,'sloping-side-wall');
 }
 k.box(width,.39,p.depth,0,-.105,-p.depth/2,'#999b98');
 k.box(width,.365,.34,0,-.1175,.07,'#999b98');
 // Roof sheet pitches down towards the yard and projects over the gate.
 const roofDepth=p.depth+.65,rise=p.rearRoof-p.eaves,angle=Math.atan2(rise,roofDepth);
 k.box(width+.5,.065,Math.hypot(roofDepth,rise),0,(p.eaves+p.rearRoof)/2,-p.depth/2+.13,roof,angle);
 k.withCollision('none',()=>{
  for(let x=-width/2-.2;x<=width/2+.2;x+=.13)k.box(.027,.035,Math.hypot(roofDepth,rise),x,(p.eaves+p.rearRoof)/2+.05,-p.depth/2+.13,'#626565',angle);
  k.box(width+.5,.15,.065,0,p.eaves-.005,.455,'#565951');
 });
 const photoHeight=p.openingHeight-.09,photoWidth=photoHeight*1224/1285;
 // Fit masonry to the unmodified image's aspect ratio; do not crop or stretch.
 for(const side of [-1,1])k.box((width-photoWidth)/2,p.openingHeight,.23,side*(width+photoWidth)/4,p.openingHeight/2,0,wall);
 const imageMaterial=new T.MeshBasicMaterial({color:'white',toneMapped:false});
 const face=new T.Mesh(new T.PlaneGeometry(photoWidth,photoHeight),imageMaterial);
 face.position.set(0,.09+photoHeight/2,.125);face.name='unaltered-owner-accordion-photo';face.userData.walkRole='none';
 if(typeof document!=='undefined')face.userData.textureReady=new T.TextureLoader().loadAsync(new URL('./assets/runtime/accordion-gate.webp',import.meta.url).href).then(texture=>{texture.colorSpace=T.SRGBColorSpace;texture.anisotropy=8;imageMaterial.map=texture;imageMaterial.needsUpdate=true;});
 g.add(face);

 k.finish();
 // Invisible, full-width blocking surface: lattice holes never create exits.
 const barrier=new T.Mesh(new T.BoxGeometry(gateWidth,p.openingHeight,.09),new T.MeshBasicMaterial({visible:false}));
 barrier.position.set(0,p.openingHeight/2,.03);barrier.name='closed-accordion-boundary';barrier.userData.walkRole='barrier';g.add(barrier);
 g.userData={accessible:false,referencePhotos:['P38','R115','R116','R117'],estimatedDimensions:true,gateWidth:photoWidth,closed:true,photoAspect:1224/1285,photoUncropped:true};
 return g;
}
