import * as THREE from './vendor/three.module.js';
let photoState;
function concretePhoto(){if(!photoState){const fallback=new THREE.DataTexture(new Uint8Array([150,153,155,255]),1,1);fallback.colorSpace=THREE.SRGBColorSpace;fallback.wrapS=fallback.wrapT=THREE.RepeatWrapping;fallback.needsUpdate=true;photoState={texture:fallback,uniforms:new Set()};if(typeof document!=='undefined'){const state=photoState;new THREE.TextureLoader().load(new URL('./textures/concrete-archival-v2.jpg',import.meta.url).href,texture=>{texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=4;state.texture=texture;for(const uniform of state.uniforms)uniform.value=texture;window.dispatchEvent(new Event('nktp-texture-ready'));},undefined,()=>window.dispatchEvent(new Event('nktp-texture-ready')));}}return photoState;}
// Large cast-concrete panels, subtle aggregate/age and shallow expansion joints.
export function applyConcreteSlabs(material,{pitch=4.00}={}){
 if(material.userData.concreteSlabs)return material;
 const photo=concretePhoto(),previous=material.onBeforeCompile.bind(material),key=material.customProgramCacheKey.bind(material),oldKey=key();
 material.onBeforeCompile=shader=>{previous(shader);const photoUniform={value:photo.texture};photo.uniforms.add(photoUniform);shader.uniforms.concretePhotoMap=photoUniform;shader.uniforms.concretePitch={value:pitch};shader.vertexShader='varying vec3 vConcretePosition; varying vec3 vConcreteNormal;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
 vec4 cp=vec4(position,1.0);vec3 cn=normal;
 #ifdef USE_INSTANCING
 cp=instanceMatrix*cp;cn=mat3(instanceMatrix)*cn;
 #endif
 vConcretePosition=(modelMatrix*cp).xyz;vConcreteNormal=normalize(mat3(modelMatrix)*cn);`);
 shader.fragmentShader='varying vec3 vConcretePosition; varying vec3 vConcreteNormal; uniform float concretePitch; uniform sampler2D concretePhotoMap;\n'+shader.fragmentShader;
 shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
 if(normalize(vConcreteNormal).y>.72){vec2 p=vConcretePosition.xz;vec2 cell=floor(p/concretePitch);vec2 f=fract(p/concretePitch);float edge=min(min(f.x,1.0-f.x),min(f.y,1.0-f.y))*concretePitch;float aa=max(fwidth(p.x),fwidth(p.y));float joint=1.0-smoothstep(.005,.010+aa,edge);float age=fract(sin(dot(cell,vec2(12.9898,78.233)))*43758.5453);vec3 photograph=texture2D(concretePhotoMap,p/3.80).rgb;float grey=dot(photograph,vec3(.2126,.7152,.0722));vec3 concrete=mix(photograph,vec3(grey),.90)*vec3(.90,.95,1.00)*(.985+age*.03);diffuseColor.rgb=mix(concrete,concrete*.60,joint*.60);}
 `);};
 material.customProgramCacheKey=()=>oldKey+'-concrete-archival-photo-v4-grey-'+pitch;material.roughness=.99;material.userData.concreteSlabs=true;material.userData.textureSource=['P12 DSC_1780.JPG','P49 IMG_2940.JPG'];material.userData.panelPitch=pitch;return material;
}
