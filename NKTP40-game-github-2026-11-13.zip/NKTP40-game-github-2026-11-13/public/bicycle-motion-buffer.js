import {MotionBuffer} from './multiplayer-buffer.js';
export const BICYCLE_PLAYBACK_DELAY=250;
// One server-time timeline for the frame, crank, wheels, both riders and rear camera.
// Reuse normal multiplayer interpolation, with a fixed delay and no prediction.
export class BicycleMotionBuffer{
 constructor(){this.motion=new MotionBuffer({delay:BICYCLE_PLAYBACK_DELAY,adaptive:false});this.version=null;}
 push(row,stamp,arrival){
  if(!Number.isFinite(stamp)||!Number.isFinite(arrival))return;
  const version=row.travelVersion||0;if(this.version!==version){this.motion=new MotionBuffer({delay:BICYCLE_PLAYBACK_DELAY,adaptive:false});this.version=version;}
  const last=this.motion.samples.at(-1);if(last&&stamp<last.t)return;
  let phase=Number.isFinite(row.phase)?row.phase:0;
  if(last){const distance=Math.hypot(row.root[0]-last.root[0],row.root[2]-last.root[2]),expected=last.phase-distance*4*Math.sign(row.speed||1);phase+=Math.round((expected-phase)/(Math.PI*2))*Math.PI*2;}
  this.motion.push({t:stamp,root:[...row.root],phase,speed:row.speed||0,mode:'bicycle'},arrival);
 }
 sample(now,dt){
  const out=this.motion.sample(now,dt);if(!out)return null;const list=this.motion.samples,a=list[0],b=list[1]||a,span=b.t-a.t,mix=span>0?Math.max(0,Math.min(1,(this.motion.clock-a.t)/span)):0;
  out.phase=a.phase+(b.phase-a.phase)*mix;out.speed=this.motion.clock>b.t?0:a.speed+(b.speed-a.speed)*mix;return out;
 }
}
