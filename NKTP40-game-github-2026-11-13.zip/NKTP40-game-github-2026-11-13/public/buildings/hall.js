import {createHallBadminton} from '../hall-badminton.js';
import {drawHallSideWindows} from '../hall-side-windows.js';
import {hallFrontProfile} from '../hall-front-profile.js?v=128.0';
import {createGlassPane} from '../openings/glass.js?v=49.0';
import {drawHallFacade} from '../hall-facade.js?v=247.0';
import {drawHallSpiral} from '../hall-spiral.js?v=247.0';
import {drawStoneStep,STAIR_STONE} from '../stair-stone.js?v=218.0';
import * as THREE from '../vendor/three.module.js';
import {makeOpeningWall} from '../wall-openings.js?v=222.0';
import {stairGuard} from '../stair-design.js?v=228.0';
import {createStairDoor} from '../interactive-door.js?v=222.0';
import {gableRoof} from '../geometry-kit.js?v=222.0';

export function buildHall(ctx){
 const {b,g,kit,box,ring,beam,w,l,h,floors,step,side,wall,trim,green,brown,dark,floor,feature,apertures,doorRecords,record,fb,windowAt,doorAt,vent,rail,plaque,archOpening,flatRoof,canopy,stairCore}=ctx;

  // P17: the hall body has lower eaves and a steep roof; the front two-storey volume stays intact.
  const sideH=h-2.0,roofRise=3.6;
  const rearDepth=3.0,rearX=-side*(w-rearDepth),frontProfile=hallFrontProfile(b),bodyStart=side*(w-5.1+frontProfile.forwardShift),bodyEnd=-side*(w-rearDepth),bodyMin=Math.min(bodyStart,bodyEnd),bodyMax=Math.max(bodyStart,bodyEnd),bodyWidth=bodyMax-bodyMin,bodyCentre=(bodyStart+bodyEnd)/2;
  g.add(createHallBadminton({bodyMin,bodyMax,halfLength:l,side}));
  const rearFrame=new THREE.Group();g.add(rearFrame);
  makeOpeningWall(rearFrame,{side:-side,wallX:w-rearDepth,faceV:0,from:-l,to:l,height:sideH,color:wall,openings:[-1,1].map(a=>({u:a*l*.48,y:1.15,width:1.3,height:2.3,kind:'door'}))});
  for(const a of [-1,1]){const u=a*l*.48;rearFrame.add(createStairDoor({side:-side,wallX:w-rearDepth,u,y:1.15,v:0,width:1.3,height:2.3,color:brown,glazed:false}));}
  box(.22,3.05,b.length,-side*(w-.11),1.525,0,wall);
  for(const z of [-l,0,l])box(rearDepth,3.05,.20,-side*(w-rearDepth/2),1.525,z,wall);
  box(rearDepth,.18,b.length,-side*(w-rearDepth/2),3.14,0,'#eee2bc');
  g.userData.hallRearRooms={depth:rearDepth,height:3.05,rooms:['changing-room','storage'],doorsToHall:2,estimated:true};
  const gable=new THREE.BufferGeometry(),gx=-side*(w-rearDepth-.11),gpoints=[gx,sideH,-l,gx,sideH,l,gx,sideH+roofRise,0];
  gable.setAttribute('position',new THREE.Float32BufferAttribute(gpoints,3));gable.computeVertexNormals();kit.withCollision('none',()=>kit.solid(gable,wall,'hall-rear-gable-wall'));
  const bays=12,sideDoors=[-b.width*.25,0,b.width*.25];
  const endFrames={};for(const a of [-1,1]){const rotated=new THREE.Group();rotated.rotation.y=Math.PI/2;g.add(rotated);endFrames[a]=rotated;const wallHoles=[];const count=bays;for(let j=0;j<count;j++){const u=bodyMin+(j+.5)*bodyWidth/count,overLink=false;wallHoles.push({u,y:overLink?sideH-.35:sideH-1.30,width:.96,height:overLink?.40:1.90,kind:'window'});};for(const x of sideDoors)wallHoles.push({u:x,y:1.25,width:1.34,height:2.52,kind:'door'});makeOpeningWall(rotated,{side:-a,wallX:l,faceV:0,from:bodyMin,to:bodyMax,height:sideH,color:wall,openings:wallHoles,profile:{height:h,storey:step}});}
  drawHallSideWindows(g,{bodyMin,bodyWidth,bays,l,sideH,linkX:side*(w-4.539)});
  const sidePierXs=[];for(let j=2;j<bays;j+=2){let x=bodyMin+j*bodyWidth/bays;for(const doorX of sideDoors)if(Math.abs(x-doorX)<1.0)x=doorX+Math.sign(x-doorX||1)*1.0;sidePierXs.push(x);}
  for(const a of [-1,1])for(const x of sidePierXs)box(.46,sideH+.45,.82,x,(sideH-.45)/2,a*(l+.36),'#d4b671');
  g.userData.hallInteriorAudit={sidePierXs,sideDoors,doorClearance:.12,doubleHeight:true,upperFloorStopsAtPartition:true};
  for(const a of [-1,1])for(const x of sideDoors){const z=a*(l+.04);for(const q of [-1,1])box(.07,2.55,.14,x+q*.68,1.27,z,brown);box(1.43,.07,.14,x,2.52,z,brown);box(1.42,.05,.20,x,.025,z,trim);const panel=new THREE.Group();panel.rotation.y=Math.PI/2;g.add(panel);panel.add(createStairDoor({side:-a,wallX:l,u:x,y:1.25,v:.04,width:1.32,height:2.42,color:brown,glazed:true}));box(1.6,.12,.50,x,2.65,a*(l+.25),trim);}
  drawHallFacade(ctx);
  // Keep the spiral and its direct landing; the former outer walkway was redundant.
  drawHallSpiral(g,b,-1);
  // Walkable landing connects the spiral directly to the opening in the upper room.
  // Landing links the spiral exit to the room floor through the opening.
  // Landing is provided by the room floor around its opening; no slab crosses the helix.
  // Upper room occupies only the front bay; the main hall remains double-height.
  const roomDepth=5.1,roomY=(b.hallLevel??(h*.46+.8)),front=hallFrontProfile(b);
  // An actual opening through the floor surrounds the spiral and clears the walker.
  const stairZ=-(l-2.05),stairV=1.20,openingRadius=1.20,parts=240,dz=(b.length-.36)/parts;
  for(let i=0;i<parts;i++){
   const z=-l+.18+dz*(i+.5),limit=front.face(z),delta=Math.abs(z-stairZ);
   const cut=delta<openingRadius?Math.sqrt(openingRadius**2-delta**2):0;
   const ranges=cut?[[-roomDepth+front.forwardShift,Math.min(limit,stairV-cut)],[Math.max(-roomDepth,stairV+cut),limit]]:[[-roomDepth+front.forwardShift,limit]];
   for(const [a,c] of ranges)if(c-a>.001)box(c-a,.18,dz,side*(w+(a+c)/2),roomY-.09,z,trim);
  }
  // White guard follows the floor opening, leaving only the stair approach open.
  const guardStart=2.12,guardEnd=1.02+Math.PI*2,guardRadius=openingRadius+.025,guardPoint=a=>({x:side*(w+stairV+guardRadius*Math.cos(a)),y:roomY,z:stairZ+guardRadius*Math.sin(a)});
  kit.withCollision('barrier',()=>{for(let j=0;j<24;j++){const a=guardPoint(guardStart+(guardEnd-guardStart)*j/24),c=guardPoint(guardStart+(guardEnd-guardStart)*(j+1)/24);for(const [height,width,color]of [[.95,.065,'#b77d80'],[.46,.035,'#c5af83']])kit.beam(new THREE.Vector3(a.x,a.y+height,a.z),new THREE.Vector3(c.x,c.y+height,c.z),width,color);box(.035,.95,.035,a.x,a.y+.475,a.z,'#c5af83');}});
  kit.withCollision('barrier',()=>{for(const a of [1.02,2.12]){const from=guardPoint(a),to={x:side*(w+stairV)+Math.sign(from.x-side*(w+stairV))*.45,y:roomY,z:stairZ+1.0};for(const [height,width,color]of [[.95,.065,'#b77d80'],[.46,.035,'#c5af83']])kit.beam(new THREE.Vector3(from.x,from.y+height,from.z),new THREE.Vector3(to.x,to.y+height,to.z),width,color);box(.035,.95,.035,to.x,to.y+.475,to.z,'#c5af83');}});
  g.userData.hallSpiralTopGuard={radius:guardRadius,height:.95,gap:[1.02,2.12],centre:[side*(w+stairV),stairZ],level:roomY,collision:true,closedRim:true,entranceWidth:.90};
  // Solid top landing joins the final tread to floor and is anchored into the central pier.
  const landingX=side*(w+stairV),landingZ=stairZ+1.0;
  box(.90,.145,1.60,landingX,roomY-.1075,landingZ,wall);
  box(.60,.035,1.60,landingX,roomY-.0175,landingZ,'#b77d80');
  for(const s of [-1,1])box(.15,.035,1.60,landingX+s*.375,roomY-.0175,landingZ,'#c5af83');
  box(.30,.28,1.55,landingX,roomY-.32,stairZ+.775,wall);
  g.userData.hallSpiralTopLanding={width:.90,length:1.60,top:roomY,anchoredToPier:true,flushWithFloor:true};
  // Move the room as a complete volume; retain the rear link passages at their anchors.
  box(.16,h-roomY,b.length-.35,side*(w-roomDepth+front.forwardShift),roomY+(h-roomY)/2,0,wall);

  // The front room has its own ceiling and roof; the hall behind remains open.
  const roomRearV=-roomDepth+front.forwardShift,ceilingBackDepth=-2-roomRearV;box(ceilingBackDepth,.18,b.length-.35,side*(w+(roomRearV-2)/2),h-.09,0,'#f4f1e7');for(let i=0;i<80;i++){const z=-l+.18+(b.length-.36)*(i+.5)/80,v=front.face(z);if(v+2>.001)box(v+2,.18,(b.length-.36)/80,side*(w+(v-2)/2),h-.09,z,'#f4f1e7');}
  // The projecting room ends at the chamfered shoulders. Side passages remain open.
  for(const end of [-1,1]){
   const z=end*(l-.15),centre=end===1?-13.261-b.x:side*(w-3.55+front.forwardShift),roomH=h-roomY;
   // Close the ground-storey return between recessed entrance and hall side wall.
   const groundFront=bodyStart,groundReturnDepth=Math.abs(groundFront-bodyStart);
   if(groundReturnDepth>.001)box(groundReturnDepth+.04,roomY,.24,(groundFront+bodyStart)/2,roomY/2,end*(l-.10),wall);
   // Backing across the wall junction eliminates the vertical seam, without covering the upper passage.
   box(.16,h-roomY-2.15,.30,bodyStart,roomY+2.15+(h-roomY-2.15)/2,end*(l-.10),wall);

   if(end===-1){box(3.10,roomH,.20,centre,roomY+roomH/2,z,wall);}else{
    for(const q of [-1,1])box(.95,roomH,.20,centre+q*1.075,roomY+roomH/2,z,wall);
    box(3.10,roomH-2.15,.20,centre,roomY+2.15+(roomH-2.15)/2,z,wall);
    const upperDoorFace=new THREE.Group();upperDoorFace.rotation.y=Math.PI/2;g.add(upperDoorFace);
    upperDoorFace.add(createStairDoor({side:-end,wallX:l-.15,u:centre,y:roomY+1.075,v:0,width:1.20,height:2.15,color:brown,glazed:true,swingDirection:-1}));
   }
   // Close the uncovered return between the hall end wall and chamfered facade.
   const rear=-.35,outer=front.face(end*(l-.10))+.10;
   box(outer-rear,roomH,.30,side*(w+(rear+outer)/2),roomY+roomH/2,end*(l-.12),wall);
   const flankFrom=-.35,flankTo=front.face(end*(l-.10)),flankLength=flankTo-flankFrom;
   for(const v of [flankFrom+.10,flankTo-.12])box(.18,roomH,.16,side*(w+v),roomY+roomH/2,end*(l+.05),wall);
   box(flankLength,.16,.16,side*(w+(flankFrom+flankTo)/2),h-.24,end*(l+.05),wall);
   // Owner removed the external downpipes.

  }
  feature('hall-upper-room-ceiling');
  g.userData.hallUpperRoom={externalDownpipes:false,depth:roomDepth+1.35,width:b.length-.35,projection:1.35+front.forwardShift,forwardShift:front.forwardShift,finishedFrontPlane:front.terraceEdge,sideDoorX:-13.261-b.x,estimated:true,level:roomY,spiralSide:'left',link:'A1',closedGroundReturns:true,ceilingMatchesRearWall:true,separateFromHall:true,upperSideDoors:1,sideWalls:'solid-chamfered-returns',source:'P57'};
  const upperY=(b.hallLevel??(h*.46+.8)),upperX=-13.261-b.x,upperZ=l-.90;
  const roomDoorX=-13.261-b.x,linkMin=Math.min(roomDoorX,upperX)-.775,linkMax=Math.max(roomDoorX,upperX)+.775;
  box(linkMax-linkMin,.16,1.35,(linkMin+linkMax)/2,upperY-.08,l+.50,trim);
  kit.withCollision('barrier',()=>{
   for(const [a,c]of [[linkMin,upperX-.70],[upperX+.70,linkMax]])if(c>a)stairGuard(kit,{x:a,y:upperY,z:l+1.175},{x:c,y:upperY,z:l+1.175},'#f4f4ef');
   for(const x of [linkMin,linkMax])stairGuard(kit,{x,y:upperY,z:l-.175},{x,y:upperY,z:l+1.175},'#f4f4ef');
  });
  g.userData.a1LinkLanding={x:upperX,z:upperZ,y:upperY};
  feature('left-spiral-hall-stair');feature('hall-upper-front-room');
  for(const a of [-1,1])box(bodyWidth+.45,.40,.62,bodyCentre,sideH-.08,a*(l+.12),trim);
  const ceilingBottom=sideH-.12,ceilingGeo=new THREE.BoxGeometry(bodyWidth,.10,b.length-.06);ceilingGeo.translate(bodyCentre,ceilingBottom+.05,0);const plasterCeiling=kit.solid(ceilingGeo,'#f4f3eb','hall-plasterboard-ceiling');plasterCeiling.material.roughness=.98;plasterCeiling.material.emissive.set('#ffffff');plasterCeiling.material.emissiveIntensity=.12;g.userData.hallCeiling={finish:'white-plasterboard',bottom:ceilingBottom,clearOfClerestory:true,exposedCrossBraces:false};
  const hallRoof=gableRoof(kit,bodyWidth,b.length,sideH,'#48403b',roofRise);g.userData.hallSideOpenings={panesPerWindow:6,windowWidth:.96,frameFinish:'stainless-steel',windowsPerSide:{left:bays,right:bays},doorsPerSide:sideDoors.length,roofEave:sideH,roofRise,estimated:true,bodyFront:bodyStart,bodyRear:bodyEnd,source:'P47/P57: clerestory confined to main hall behind the solid front room; opposite side provisionally mirrored'};hallRoof.position.x=bodyCentre;
  makeOpeningWall(g,{side,wallX:w-5.1+front.forwardShift,faceV:0,from:-l,to:l,height:roomY,color:wall,openings:apertures,profile:{height:h,storey:step}});feature('real-hall-door-openings');
  feature('hall-louvred-four-pane-windows');feature('pitched-hall-roof');feature('high-clerestory-windows');feature('hall-entrance-sign');feature('hall-side-piers-and-door');

}
