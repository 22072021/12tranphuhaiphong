import {buildingBaseProfile} from '../building-bases.js';
import {foundationElevation} from '../raised-platform.js';
import {rearVentBlade,rearVentReveal} from './b1-rear-vent-paint.js?v=219.0';
import {drawB1Planter} from './b1-planter.js?v=211.0';
import * as THREE from '../vendor/three.module.js';
import {createSchoolWindow} from '../openings/school-window.js?v=222.0';
import {makeOpeningWall} from '../wall-openings.js?v=222.0';
import {createClassroomInteriors} from '../classroom-template.js?v=223.0';
import {classroomStairPlan} from '../stair-design.js?v=228.0';
import {drawCorridorGuard} from '../corridor-guard.js?v=219.0';
import {facadeRibbon} from '../curved-surfaces.js?v=28.0';
export function buildB1(ctx){
 const {b,g,kit,box,fb,w,l,h,step,side,wall,trim,green,doorAt,apertures,stairCore,flatRoof,feature}=ctx;
 const p=classroomStairPlan(b),corridor=Math.min(2.25,b.width*.22),face=w-corridor,front=[],rear=[],specs=[],pitch=(b.length-p.span)/12;
 const schedules=[['wide','wide','door'],['wide','wide','door'],['door','wide','wide'],['wide','door','wide']];
 const rooms=schedules.map((kinds,i)=>{const start=i<2?-l+i*3*pitch:p.center+p.span/2+(i-2)*3*pitch;return{index:i,zmin:start,zmax:start+3*pitch,kinds,centers:kinds.map((_,j)=>start+(j+.5)*pitch)};});
 g.userData.coreCenter=p.center;g.userData.coreSpan=p.span;
 for(const u of [...new Set(rooms.flatMap(r=>[r.zmin,r.zmax]))])box(b.width-corridor,h,.18,-side*corridor/2,h/2,u,wall);
 for(let f=0;f<=b.floors;f++)for(const [lo,hi]of [[-l,p.center-p.span/2],[p.center+p.span/2,l]])box(b.width,.12,hi-lo,0,f*step-.06-(f===0?.03:0),(lo+hi)/2,trim);
 const threeVents=(holes,u,y,width,columns=1)=>{for(let c=0;c<columns;c++)for(const dy of (width>1.6?[-.085,.085]:[-.12,0,.12]))holes.push({kind:'vent',u:u+(c-(columns-1)/2)*(width/columns+.06),y:y+dy,width:columns===2?(width-.12)/2:width,height:.065});};
 for(let f=0;f<b.floors;f++){
  const level=f*step;
  for(const r of rooms){
   for(let j=0;j<3;j++){const u=r.centers[j],door=r.kinds[j]==='door',width=door?1.16:2.32*.8;
    if(door)doorAt(u,level+1.36,-corridor+.01,1.16,2.72,green);else{const o={kind:'window',u,y:level+1.83,width,height:1.65};front.push(o);g.add(createSchoolWindow({side,wallX:face,u,y:o.y,width,height:o.height,open:true,leafCount:4,hingeAtFrame:true,referenceLouver:true,color:green}));}
    const rr={kind:'window',u,y:level+1.83,width:2.32*.8,height:1.65};rear.push(rr);g.add(createSchoolWindow({side:-side,wallX:w,u,y:rr.y,width:rr.width,height:rr.height,open:true,leafCount:4,hingeAtFrame:true,referenceLouver:true,color:green}));
    threeVents(front,u,level+step-.52,Math.min(width,1.8),2);
    threeVents(rear,u,level+step-.52,1.8,2);
   }
   const xmin=Math.min(side*face,-side*w)+.28,xmax=Math.max(side*face,-side*w)-.25;
   specs.push({buildingId:'B1',roomIndex:r.index,floor:f+1,side,xmin,xmax,zmin:r.zmin+.15,zmax:r.zmax-.15,doorU:r.centers[r.kinds.indexOf('door')],boardEnd:r.index<2?1:-1,teacherDesk:r.index===3?{x:xmax-.75}:undefined,rows:5,level:level+.02,clearHeight:step-.24,divider:false});
  }
  for(const [lo,hi]of [[-l,p.center-p.span/2],[p.center+p.span/2,l]]){
   if(f)box(corridor,.02,hi-lo,side*(w-corridor/2),level+.01,(lo+hi)/2,'#bb9271');
   if(f)drawCorridorGuard(kit,{id:'B1',x:side*(w-.13),z:(lo+hi)/2,y:level,width:hi-lo-.18,wall,trim});
   else {const direction=(lo+hi)/2<p.center?-1:1,inner=p.center+direction*p.span/2;
    for(const [a,bayEnd] of [[0,3],[4,6]]){const start=inner+direction*a*pitch,end=inner+direction*bayEnd*pitch;drawCorridorGuard(kit,{id:'B1',x:side*(w-.13),z:(start+end)/2,y:0,width:Math.abs(end-start)-.26,wall,trim});}
   }
  }
  // Four flower boxes: bays 2 and 5 from each end. The same bays have curved soffits.
  for(const index of [1,4,7,10]){const room=rooms[Math.floor(index/3)],u=room.centers[index%3],from=u-pitch*.44,to=u+pitch*.44;
   if(f>0)drawB1Planter(kit,{x:side*(w+.36),y:level,z:u,width:pitch*.65,side});
   facadeRibbon(kit,side,w,{from,to,curve:()=>-.12,bottom:z=>(f+1)*step-.04-2*(.09+.33*(1-Math.sqrt(Math.max(0,1-((z-u)/(pitch*.44))**2)))),top:(f+1)*step-.04,thickness:.48,color:wall,name:'B1-P34-flower-bay-curved-soffit'});
  }
 }
 for(const end of [-1,1])drawCorridorGuard(kit,{id:'B1',x:side*(w-corridor/2),z:end*(l-.10),y:0,width:corridor-.12,angle:Math.PI/2,wall,trim});
 g.userData.groundCorridor={exitBayFromCore:4,guardedFirstBays:3,endGuards:true};
 const columnUs=[...new Set(rooms.flatMap(r=>Array.from({length:4},(_,j)=>r.zmin+j*pitch)))];
 for(const u of columnUs){fb(u,h/2,-.15,.25,h,.28,wall);for(let f=1;f<=b.floors;f++)box(corridor,.22,.25,side*(w-corridor/2),f*step-.11,u,trim);}
 front.push(...apertures);apertures.push(...front.filter(o=>o.kind==='window'||o.kind==='vent'));
 for(const [lo,hi]of [[-l,p.center-p.span/2],[p.center+p.span/2,l]]){makeOpeningWall(g,{side,wallX:w,faceV:-corridor,from:lo,to:hi,height:h,color:wall,openings:front});makeOpeningWall(g,{side:-side,wallX:w,faceV:0,from:lo,to:hi,height:h,color:wall,openings:rear});}
 // Keep the stair shaft open through the roof, with perimeter roof slabs.
 for(const [lo,hi]of [[-l,p.center-p.span/2],[p.center+p.span/2,l]]){box(b.width+.05,.12,hi-lo,0,h+.15,(lo+hi)/2,'#aaa98e');for(const edge of [-1,1])box(.18,.90,hi-lo,edge*(w+.04),h+.45,(lo+hi)/2,wall);}
 for(const sign of [-1,1])box(b.width,.90,.18,0,h+.45,sign*l,wall);
 stairCore(p.span,false,p.center);
 // P34: projecting solid stair tower with vertically aligned narrow rectangular openings.
 const towerH=h+.18+step-.24,towerHoles=[{kind:'door',u:p.center,y:(step-.28)/2,width:p.span-.22,height:step-.28}];
 for(let f=1;f<=b.floors;f++){const level=f===b.floors?p.levels[f]:f*step,bottom=level+1.0,top=f===b.floors?towerH-.18:(f+1)*step-.20;towerHoles.push({kind:'vent',u:p.center+p.span*.24,y:(bottom+top)/2,width:p.span*.25,height:top-bottom});}
 makeOpeningWall(g,{side,wallX:w,faceV:.27,from:p.center-p.span/2,to:p.center+p.span/2,height:towerH,color:wall,openings:towerHoles});
 for(const edge of [-1,1])fb(p.center+edge*p.span/2,towerH/2,.14,.22,towerH,.55,wall);
 fb(p.center,towerH-.10,.10,p.span+.15,.20,.65,wall);box(b.width+.40,.40,p.span+.40,0,towerH+.20,p.center,trim);const roofLevel=p.levels[b.floors],roomHeight=towerH-roofLevel;
 for(const edge of [-1,1]){const rotated=new THREE.Group();rotated.name='B1-rooftop-room-side-'+edge;rotated.position.set(0,roofLevel,p.center);rotated.rotation.y=Math.PI/2;g.add(rotated);makeOpeningWall(rotated,{side:-edge,wallX:p.span/2,faceV:0,from:-w-.27,to:w+.15,height:roomHeight,color:wall,openings:[{kind:'door',u:side*(w-corridor/2),y:1.025,width:1.35,height:2.05}]});}
 g.userData.roofAccess={walkable:true,covered:true,enclosed:true,sideExits:2,level:roofLevel};
 const nose=z=>.70+.85*Math.sqrt(Math.max(0,1-((z-p.center)/(p.span/2))**2));facadeRibbon(kit,side,w,{from:p.center-p.span/2,to:p.center+p.span/2,curve:z=>nose(z)/2,bottom:step-.47,top:step-.05,thickness:nose,color:wall,name:'B1-rounded-entrance-canopy'});

 // P35: paired banks of rear louvres, with a 2 m clear passage beneath the tower.
 const rearHoles=[{kind:'door',u:p.center,y:1.0,width:p.span-.26,height:2.0}];
 const rearBottom=2.0,rearTop=towerH;
 for(let y=2.38;y<rearTop-.55;y+=1.45)for(const wing of [-1,1]){const u=p.center+wing*p.span*.24,hh=Math.min(1.12,rearTop-.25-y);if(hh<.25)continue;rearHoles.push({kind:'window',u,y:y+hh/2,width:p.span*.30,height:hh});for(let yy=y+.07;yy<y+hh;yy+=.14)rearVentBlade(kit,{x:-side*(w+.23),y:yy,z:u,width:p.span*.30,side:-side,yellow:wall});}
 for(const o of rearHoles.filter(o=>o.kind==='window'))rearVentReveal(kit,{x:-side*(w+.04),y:o.y,z:o.u,width:o.width,height:o.height});
 makeOpeningWall(g,{side:-side,wallX:w,faceV:.15,from:p.center-p.span/2,to:p.center+p.span/2,height:rearTop,color:wall,openings:rearHoles});
 for(const edge of [-1,1])box(.48,rearTop-2,.18,-side*(w+.10),(rearTop+2)/2,p.center+edge*p.span/2,wall);
 box(1.20,.35,p.span+.70,-side*(w+.43),2.175,p.center,wall);
 for(let f=0;f<b.floors;f++)for(const [lo,hi]of [[-l,p.center-p.span/2],[p.center+p.span/2,l]])box(.48,.10,hi-lo,-side*(w+.22),f*step+2.93,(lo+hi)/2,trim);
 g.userData.rearTower={source:'P35',pairedLouvres:true,exteriorPaint:'yellow',revealPaint:'white',passageClearHeight:2.0,top:rearTop};
 g.add(createClassroomInteriors(specs));
 // Two roofed display cases with two wire-mesh doors each, right of the entrance.
 for(const [i,u]of [l-1.5*pitch,l-.5*pitch].entries()){
  const x=side*(w+1.15),y=1.25,W=pitch*.85,H=1.28,c='#426b57';box(.14,H,W,x,y,u,'#deddd0');
  for(const z of [-W/2,0,W/2])box(.055,H+.10,.045,x+side*.10,y,u+z,c);
  for(const yy of [-H/2,H/2])box(.055,.045,W,x+side*.10,y+yy,u,c);
  for(let z=-W/2+.10;z<W/2;z+=.16)box(.012,H,.012,x+side*.13,y,u+z,'#83877d');for(let yy=-H/2+.10;yy<H/2;yy+=.16)box(.012,.012,W,x+side*.13,y+yy,u,'#83877d');
  const legBottom=-buildingBaseProfile(b).height-foundationElevation(b);
  for(const z of [-W*.40,W*.40]){box(.09,1-legBottom,.09,x,(1+legBottom)/2,u+z,c);box(.05,.16,.025,x+side*.16,y-.05,u+Math.sign(z)*.10,c);}box(.70,.10,W+.25,x,y+H/2+.13,u,'#c5c3b8');
 }
 g.userData.noticeBoardWidth=pitch*.85;
 g.userData.classrooms={roomsPerFloor:4,rooms,source:'P34 and explicit user schedule',exceptionRoom:4};g.userData.ventPattern={doorRows:3,windowRows:2,windowColumns:2,frontBlades:'white',rearUnchanged:true};g.userData.planterBays=[2,5,8,11];g.userData.planterReference='P42-tapered-brick';g.userData.flowerBayArchThicknessScale=2;feature('B1-P34-four-classrooms');feature('B1-A1-type-concrete-stairs');feature('B1-two-roofed-wire-notice-boards');
}
