import {createBicycle} from '../furniture/bicycle.js';
import {rearVentBlade,rearVentReveal} from './b1-rear-vent-paint.js?v=219.0';
import {buildB1} from './b1.js?v=228.0';
import {createSlidingGrille} from '../openings/sliding-grille.js?v=222.0';
import {addVentSlots} from '../openings/vent-slot.js?v=220.0';
import {createSchoolWindow} from '../openings/school-window.js?v=222.0';
import {createClassroomInteriors,classroomWingRooms} from '../classroom-template.js?v=223.0';
import {buildA1} from './a1.js?v=228.0';
import * as THREE from '../vendor/three.module.js';
import {makeOpeningWall} from '../wall-openings.js?v=222.0';
import {createPorchRoof} from '../porch-roof.js?v=222.0';
import {facadeRibbon} from '../curved-surfaces.js?v=28.0';
import {FACADE_PROFILES} from '../facade-profile.js?v=217.0';
import {gableRoof} from '../geometry-kit.js?v=222.0';

export function buildClassroom(ctx){
 if(ctx.b.id==='A1')return buildA1(ctx);if(ctx.b.id==='B1')return buildB1(ctx);
 const {b,g,kit,box,ring,beam,w,l,h,floors,step,side,wall,trim,green,brown,dark,floor,feature,apertures,doorRecords,record,fb,windowAt,doorAt,vent,rail,plaque,archOpening,flatRoof,canopy,stairCore}=ctx;

  const profile=FACADE_PROFILES[b.id],corridor=Math.min(2.25,b.width*.22),core=profile?b.length*profile.coreSpan:Math.min(4,b.length*.13),coreCenter=profile?-side*(profile.coreCentre-.5)*b.length:0,body=b.width-corridor;
  g.userData.facadeProfile=profile||null;g.userData.coreCenter=coreCenter;g.userData.coreSpan=core;
  const left=coreCenter-core/2+l,right=l-coreCenter-core/2;
  // Hollow building envelope: corridor-facing masonry is assembled after openings are known.
  for(const u of [-l,-l+left,coreCenter+core/2,l])box(body,h,.18,-side*corridor/2,h/2,u,wall);
  const cutVent=(u,y,v,width)=>addVentSlots(apertures,{u,y,width});
  const rearApertures=[]; // Openings in the rear classroom wall, recorded per bay and storey.
  for(let f=0;f<=floors;f++){if(left>0)box(b.width+.22,.16,left,0,(f===0?-.11:f*step+.05),-l+left/2,trim);if(right>0)box(b.width+.22,.16,right,0,(f===0?-.11:f*step+.05),coreCenter+core/2+right/2,trim);}
  const bays=profile?.bays||Math.max(6,Math.round(b.length/4.25)),bay=b.length/bays;
  // Facade viewed from outside, left-to-right: two large rooms, core,
  // two large rooms and the smaller end room, as specified by the user.
  const rightStart=coreCenter+core/2,small=right/4,rightRoom=(right-small)/2;
  const a2Rooms=[
   {zmin:-l,zmax:-l+left/2,kinds:['door','wide','wide']},
   {zmin:-l+left/2,zmax:coreCenter-core/2,kinds:['door','wide','wide']},
   {zmin:rightStart,zmax:rightStart+rightRoom,kinds:['wide','wide','door']},
   {zmin:rightStart+rightRoom,zmax:rightStart+2*rightRoom,kinds:['wide','wide','door']},
   {zmin:rightStart+2*rightRoom,zmax:l,kinds:['door','narrow'],small:true}
  ].map(r=>{const count=r.kinds.length,pitch=(r.zmax-r.zmin)/count;return {...r,openings:r.kinds.map((kind,i)=>({kind,u:r.zmin+(i+.5)*pitch}))};});
  const b2Pitch=(b.length-core)/12;
  const b2Rooms=f=>[['wide','wide','door'],['wide','wide','door'],f===0?['door','wide','wide']:['wide','wide','door'],f===0?['door','wide','door']:['wide','wide','door']].map((kinds,i)=>{const zmin=i<2?-l+i*3*b2Pitch:coreCenter+core/2+(i-2)*3*b2Pitch;return{zmin,zmax:zmin+3*b2Pitch,kinds,openings:kinds.map((kind,j)=>({kind,u:zmin+(j+.5)*b2Pitch}))};});
  const schedule=f=>b.id==='B2'?b2Rooms(f):a2Rooms;
  if(b.id==='B2'){const us=[...new Set(b2Rooms(0).flatMap(r=>Array.from({length:4},(_,i)=>r.zmin+i*b2Pitch)))];for(const u of us)fb(u,h/2,-.15,.25,h,.28,wall);g.userData.openingSchedule={source:'P43-user-2026-11-08-upper-right-room',floors:Array.from({length:floors},(_,f)=>b2Rooms(f).map(r=>r.kinds)),columnPitch:b2Pitch,coreWidth:core,glassCoversAdjacentDoors:true};}
  const a2Edges=Array.from({length:16},(_,i)=>i===6?coreCenter-core/2:i===7?coreCenter+core/2:-l+b.length*i/15).filter((_,i)=>i!==14);
  const balconyRanges=f=>[-1,1].map(wing=>{const pitch=b.id==='B2'?b2Pitch:b.length/15,center=b.id==='B2'?wing*(l-2.5*pitch):coreCenter+wing*4*pitch,width=(f===1?1:2)*pitch;return{wing,center,width,from:center-width/2,to:center+width/2};});
  const a2GlassSpan=core+2*b.length/15;
  if(b.id==='A2')for(const u of a2Edges.filter(u=>Math.abs(u-coreCenter)>a2GlassSpan/2+.02))fb(u,h/2,-.15,.25,h,.28,wall);
  for(let j=0;j<=bays&&b.id!=='A2'&&b.id!=='B2';j++){const u=-l+j*bay;if(Math.abs(u-coreCenter)<core*.46)continue;fb(u,h/2,-.15,.25,h,.28,wall);}
  for(let f=0;f<floors;f++){
   for(let j=0;j<bays;j++){const u=-l+(j+.5)*bay;if(Math.abs(u-coreCenter)<core*.52)continue;
    if(b.id!=='A2'&&b.id!=='B2'){
    windowAt(u+(j%2?.28:0),f*step+step*.55,-corridor+.03,Math.min(j%2?1.8:2.7,bay*(j%2?.48:.72)),step*.43,(b.id==='A2'||b.id==='B2')&&f>=1?brown:green);
    if(j%2)doorAt(u-bay*.30,f*step+step*.38,-corridor+.06,.84,step*.72,(b.id==='A2'||b.id==='B2')&&f>=1?brown:green);cutVent(u,f*step+step*.87,-corridor+.08,Math.min(1.7,bay*.55));
    if(f)rail(u,f*step,-.13,bay-.18,trim,false);
    }

   }
   if(b.id==='A2'||b.id==='B2'){
    for(const r of schedule(f)){
     for(const o of r.openings){const y=f*step,col='#704137';
      if(o.kind==='door'){doorAt(o.u,y+step*.32,-corridor+.06,1.16,step*.64,col);box(.38,f?.18:.03,1.16,side*(w-corridor),y+(f?.09:-.015),o.u,floor);}
      else windowAt(o.u,y+step*.46,-corridor+.03,o.kind==='wide'?2.32:1.16,step*.44,col);
      cutVent(o.u,y+step*.81,-corridor+.08,o.kind==='wide'?1.70:1.04);
     }
     if(f){let intervals=[[r.zmin,r.zmax]];
      for(const cut of [...balconyRanges(f),...([{from:coreCenter-(b.id==='B2'?core+2*b2Pitch:a2GlassSpan)/2,to:coreCenter+(b.id==='B2'?core+2*b2Pitch:a2GlassSpan)/2}])])intervals=intervals.flatMap(([a,z])=>cut.to<=a||cut.from>=z?[[a,z]]:[[a,Math.max(a,cut.from)],[Math.min(z,cut.to),z]].filter(([x,y])=>y-x>.12));
      for(const [a,z]of intervals)rail((a+z)/2,f*step,.08,z-a,trim,false);
     }
    }
    if(b.id==='A2')g.userData.openingSchedule={source:'user-2026-10-30',left:['door,wide,wide','door,wide,wide'],right:['wide,wide,door','wide,wide,door','door,narrow'],central:'one-bay-stairs-with-three-bay-blue-glazing',columnPitch:b.length/15,columnCount:a2Edges.length,status:'user-specified'};
   }
   if(f>0){
    // The stone landing already occupies the stair core at this elevation.
    // End the tiled corridor at each side of the core to avoid coplanar faces.
    for(const [from,to] of [[-l,coreCenter-core/2],[coreCenter+core/2,l]])if(to-from>.001)fb((from+to)/2,f*step+.12,-corridor/2,to-from,.12,corridor,floor);
   }
   for(let j=0;j<bays;j++){const u=-l+(j+.5)*bay;kit.cylinder(.11,.055,side*(w-corridor/2),(f+1)*step-.14,u,'#d5d0b9');}
  }
  // Mirror each classroom opening across the room: doors face a two-leaf window.
  for(const o of apertures.filter(o=>(o.kind==='door'||o.kind==='window')&&Math.abs(o.u-coreCenter)>core/2&&o.y<h-.1)){
   const leafCount=o.kind==='door'?2:(o.width-.08>1.7?4:2),width=(leafCount===4?2.32:1.16)*.8;
   const rearWindow=createSchoolWindow({side:-side,wallX:w,u:o.u,y:o.kind==='door'?o.y-o.height/2+step*.46:o.y,width,height:step*.44,open:true,color:b.id==='A2'?'#704137':green,leafCount,flushFrame:b.id==='A2'||b.id==='B2'});rearWindow.name=b.id+'-rear-mirrored-window';rearWindow.userData.oppositeKind=o.kind;g.add(rearWindow);
   rearApertures.push({kind:'window',u:o.u,y:o.kind==='door'?o.y-o.height/2+step*.46:o.y,width:width+.08,height:step*.44+.06});
   if(b.id==='A2'||b.id==='B2'){const f=Math.floor(o.y/step),ventY=f*step+step*(b.id==='B2'?.90:.81);addVentSlots(rearApertures,{u:o.u,y:ventY,width:width*.90});kit.withCollision('none',()=>box(.48,.09,width+.24,-side*(w+.22),f*step+step*(b.id==='B2'?.82:.71),o.u,trim));}
  }
  for(const [from,to] of [[-l,coreCenter-core/2],[coreCenter+core/2,l]])if(to>from){const rearWall=makeOpeningWall(g,{side:-side,wallX:w,faceV:0,from,to,height:h,color:wall,openings:rearApertures,profile:{height:h,storey:step}});rearWall.name='rear-classroom-opening-wall';}
  feature('real-rear-classroom-window-openings');
  flatRoof();gableRoof(kit,b.width-.35,b.length-.35,h+.18,b.roof,.38);feature('shallow-classroom-roof');feature('recessed-open-corridors');feature('round-corridor-ceiling-lights');feature('shutter-windows');feature('floor-vent-slots');
  stairCore(Math.min(core,4.2),b.id==='A1',coreCenter);
  if(b.id==='A2'){
   // Permanently locked screened storage below the returning stair flight.
   const stair=g.userData.stairPlan,flight=stair.flights[1],x=flight.to.x+(flight.from.x-flight.to.x)*.55,z=flight.to.z,width=flight.width,color='#49544e';
   const blocker=new THREE.Mesh(new THREE.BoxGeometry(.08,1.85,width),new THREE.MeshBasicMaterial({visible:false}));blocker.name='a2-locked-under-stair-blocker';blocker.position.set(x,.925,z);blocker.userData.walkRole='barrier';g.add(blocker);
   const screen=new THREE.Group();screen.name='a2-locked-under-stair-grille';screen.userData.walkRole='none';g.add(screen);
   const metal=new THREE.MeshStandardMaterial({color,roughness:.7}),add=(dx,dy,dz,xx,yy,zz)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(dx,dy,dz),metal);m.position.set(xx,yy,zz);m.userData.walkRole='none';screen.add(m);};
   for(let i=0;i<=8;i++)add(.07,1.85,.035,x,.925,z-width/2+i*width/8);for(const y of [.06,.93,1.80])add(.07,.055,width,x,y,z);
   screen.userData.locked=true;feature('A2-locked-under-stair-space');
  }
  if(b.id==='B1')for(let f=1;f<=floors;f++)for(let j=0;j<bays;j++){
   const u=-l+(j+.5)*bay;if(Math.abs(u-coreCenter)<core*.55)continue;
   const radius=(bay-.3)/2;
   facadeRibbon(kit,side,w,{from:u-radius,to:u+radius,curve:()=>-.12,bottom:z=>f*step-.12-.48*(1-Math.sqrt(Math.max(0,1-((z-u)/radius)**2))),top:f*step-.05,thickness:.28,color:wall,name:'B1-continuous-arch'});
   if(f<floors&&j%2===0){fb(u,f*step+.45,.45,bay*.40,.50,.95,'#a76d54');fb(u,f*step+.72,.45,bay*.43,.08,1.0,'#b77c5e');fb(u,f*step+.73,.45,bay*.34,.04,.78,'#5b5944');for(let vine=0;vine<4;vine++){const vu=u+(vine-1.5)*bay*.07;for(let k=0;k<7;k++){const yy=f*step+.77-k*.10;fb(vu+Math.sin(k*1.7+vine)*.07,yy,.97,.12,.055,.12,green);}}}
  }
  if(b.id==='B1'){feature('segmental-corridor-arches');feature('projecting-brick-planters');}
  if(b.id==='A1')plaque('A1',core/2+.8,2.7,-corridor+.13,.6,.32,'#31564e');
  if(b.id==='B1'){
   for(const u of [-core/2,core/2])fb(u,(h+1.7)/2,.40,.34,h+1.7,.75,wall);
   fb(coreCenter,(h+1.7)/2,.35,core*.65,h+1.7,.50,wall);
   fb(coreCenter,h*.58,.64,core*.30,h*.60,.08,dark);for(let f=1;f<=floors;f++)fb(coreCenter,f*step+.18,.71,core*.31,.12,.10,trim);feature('B1-central-vertical-stair-slot');
   fb(0,h+1.05,.65,.70,1.0,.08,dark);
   for(let f=1;f<=floors;f++){fb(0,f*step,.60,core,.22,1.1,trim);if(f<floors)rail(0,f*step,.94,core-.2,wall);}
   fb(0,h+1.65,.44,core,.20,.85,wall);
   const rx=-side*(w+.18),screenBottom=step*.88,screenTop=h+1.35;
   for(const a of [-1,0,1])box(.32,screenTop-screenBottom,.18,rx,(screenTop+screenBottom)/2,coreCenter+a*core*.35,wall);
   for(let k=0;k<5;k++){const y=screenBottom+k*(screenTop-screenBottom)/5;box(.32,.20,core*.88,rx,y,coreCenter,wall);for(let j=0;j<7;j++)for(const a of [-1,1])box(.12,.055,core*.28,rx-side*.08,y+.24+j*.15,coreCenter+a*core*.18,'#706f5a');}
   feature('paired-rear-louvre-tower');
   const nose=u=>.65+.75*Math.sqrt(Math.max(0,1-(u/(core/2))**2));facadeRibbon(kit,side,w,{from:-core/2,to:core/2,curve:u=>nose(u)/2,bottom:step-.33,top:step-.03,thickness:nose,color:wall,name:'B1-rounded-canopy'});
   feature('rounded-B1-entrance-canopy');feature('raised-central-stair-tower');
  }
  if(b.id==='A2'||b.id==='B2'){
   const span=b.id==='A2'?core+2*b.length/15:core+2*b2Pitch,segments=b.id==='A2'?12:9;g.userData.glassSegments=segments;
   // Ground-floor enclosure behind the entrance porch; the glass stair core
   // was previously left as an empty hole down to the ground.
   // Ground-floor wall around the core is cut along with the wings below.
   if(b.id==='A2'){
    record('door',coreCenter,step*.47,core-.12,step*.94,-corridor+.17);g.add(createSlidingGrille({side,wallX:w,u:coreCenter,y:step*.47,v:-corridor+.17,width:core-.12,height:step*.94}));
   }
   const rearVents=[];for(let yy=2.38;yy<h-.55;yy+=1.45)for(const wing of [-1,1]){const u=coreCenter+wing*core*.24,hh=Math.min(1.12,h-.25-yy);if(hh<.25)continue;rearVents.push({kind:'window',u,y:yy+hh/2,width:core*.30,height:hh});rearVentReveal(kit,{x:-side*(w+.03),z:u,y:yy+hh/2,width:core*.30,height:hh});for(let y=yy+.07;y<yy+hh;y+=.14)rearVentBlade(kit,{x:-side*(w+.22),y,z:u,width:core*.30,side:-side,yellow:wall});}
   makeOpeningWall(g,{side:-side,wallX:w,faceV:.14,from:coreCenter-core/2,to:coreCenter+core/2,height:h,color:wall,openings:rearVents});
   g.userData.rearStairVents={horizontal:true,exterior:'yellow',interior:'white'};
   feature('enclosed-ground-floor-stair-lobby');g.userData.glassJunction={railingRemoved:true,mergedColumns:true,sillHeight:.80,porchBack:.52};

   const bow=local=>b.id==='A2'&&Math.abs(local)<span*.23?.55+.85*Math.sqrt(Math.max(0,1-(local/(span*.23))**2)):.55;
   for(let f=1;f<floors;f++){
    const glassKit={curved(geo){const mesh=new THREE.Mesh(geo,new THREE.MeshStandardMaterial({color:'#426f78',transparent:true,opacity:.40,roughness:.2,metalness:.08,side:THREE.DoubleSide,depthWrite:false}));mesh.name=b.id+'-blue-green-glass';mesh.userData.walkRole='none';g.add(mesh);}};
    facadeRibbon(glassKit,side,w,{from:coreCenter-span/2,to:coreCenter+span/2,curve:u=>f===2?bow(u-coreCenter):(b.id==='A2'?.40:.55),bottom:f*step+.80,top:(f+1)*step-.20,thickness:.07,color:'#567e98',name:'smooth-glazed-stair-core'});
    facadeRibbon(kit,side,w,{from:coreCenter-span/2,to:coreCenter+span/2,curve:u=>(f===2?bow(u-coreCenter):.55)/2,bottom:f*step+.02,top:f*step+.18,thickness:u=>f===2?bow(u-coreCenter):.55,color:floor,name:'glazed-core-floor-slab'});
    facadeRibbon(kit,side,w,{from:coreCenter-span/2,to:coreCenter+span/2,curve:u=>f===2?bow(u-coreCenter):(b.id==='A2'?.40:.55),bottom:f*step+.18,top:f*step+.80,thickness:.23,color:wall,name:b.id+'-raised-glazing-sill'});
    for(let j=0;j<=segments;j++){const local=-span/2+j*span/segments,v=f===2?bow(local):(b.id==='A2'?.40:.55),glassBottom=f*step+.80,glassTop=(f+1)*step-.20;fb(coreCenter+local,(glassBottom+glassTop)/2,v,.055,glassTop-glassBottom,.07,'#4e5557');}
    for(const [y,height,col] of [...([]),[(f+1)*step-.20,.12,trim],[f*step+step*.48,.055,'#4e5557']])facadeRibbon(kit,side,w,{from:coreCenter-span/2,to:coreCenter+span/2,curve:u=>(f===2?bow(u-coreCenter):.55)+.10,bottom:y-height/2,top:y+height/2,thickness:.15,color:col,name:'smooth-core-spandrel'});
   }
   for(const local of [-span/2,-core/2,core/2,span/2])fb(coreCenter+local,(h+step)/2,.40,.23,h-step,.42,wall);
   if(b.id==='A2')facadeRibbon(kit,side,w,{from:coreCenter-span/2,to:coreCenter+span/2,curve:u=>bow(u-coreCenter),bottom:h-.07,top:h+.23,thickness:.27,color:wall,name:'A2-continuous-bowed-crown'});
   for(const wing of [-1,1])for(let f=1;f<floors;f++){
    const data=balconyRanges(f).find(r=>r.wing===wing);
    const wingSpan=data?.width??Math.min(f===1?3.2:6.1,b.length*.17),center=data?.center??wing*b.length*.24,from=center-wingSpan/2,to=center+wingSpan/2;
    // Circular segment meets the straight parapet at a distinct shoulder, as in P19/P33.
    const halfSpan=wingSpan/2,sagitta=.8,arcRadius=(halfSpan*halfSpan+sagitta*sagitta)/(2*sagitta);
    const curve=u=>.08+Math.sqrt(Math.max(0,arcRadius*arcRadius-(u-center)**2))-(arcRadius-sagitta);
    if(b.id==='A2'||b.id==='B2'){
     // Render smooth curves while collision follows short segments at the actual edge.
     kit.withCollision('none',()=>{
      facadeRibbon(kit,side,w,{from,to,curve:u=>(curve(u)-.10)/2,bottom:f*step-.04,top:f*step+.12,thickness:u=>curve(u)+.10,color:trim,name:'A2-walkable-curved-balcony-slab'});
      facadeRibbon(kit,side,w,{from,to,curve,bottom:f*step+.01,top:f*step+.54,thickness:.18,color:wall,name:'A2-curved-parapet'});
      facadeRibbon(kit,side,w,{from,to,curve,bottom:f*step+.88,top:f*step+1.00,thickness:.21,color:'#865f69',name:'A2-granito-balcony-cap'});
      const cells=Math.max(1,Math.round(wingSpan/.38)),pitch=wingSpan/cells,iron='#c6ad69';
      for(let j=0;j<cells;j++){const u=from+(j+.5)*pitch,ww=pitch*.48,hh=.18,v=curve(u),dx=side*(w+v),yy=f*step+.71;
       for(const sign of [-1,1]){box(.035,.018,ww,dx,yy+sign*hh/2,u,iron);box(.035,hh,.018,dx,yy,u+sign*ww/2,iron);}
       for(const sign of [-1,1])box(.025,.17,.018,dx,yy+sign*(hh/2+.085),u,iron);box(.025,.34,.018,side*(w+curve(u+pitch/2)),yy,u+pitch/2,iron);
      }
     });
     const pieces=48,dz=wingSpan/pieces;
     const blockers=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshBasicMaterial({visible:false}),pieces);
     blockers.name='A2-balcony-edge-collision';blockers.userData.walkRoles=Array(pieces).fill('barrier');g.add(blockers);
     for(let j=0;j<pieces;j++){const u=from+(j+.5)*dz,v=curve(u),depth=v+.12;
      box(depth,.12,dz+.002,side*(w+(v-.12)/2),f*step+.08,u,floor);
      const matrix=new THREE.Matrix4().compose(new THREE.Vector3(side*(w+v),f*step+.52,u),new THREE.Quaternion(),new THREE.Vector3(.18,1.04,dz+.01));blockers.setMatrixAt(j,matrix);
     }blockers.instanceMatrix.needsUpdate=true;blockers.computeBoundingBox();blockers.computeBoundingSphere();
    }else{
     facadeRibbon(kit,side,w,{from,to,curve:u=>curve(u)/2,bottom:f*step-.04,top:f*step+.14,thickness:u=>1.1+curve(u),color:trim,name:'continuous-balcony-slab'});
     for(const [lo,hi,d,c] of [[.01,.67,.20,wall],[.66,.76,.24,'#b8c6a4'],[.77,.87,.27,'#865f68']])facadeRibbon(kit,side,w,{from,to,curve,bottom:f*step+lo,top:f*step+hi,thickness:d,color:c,name:'continuous-curved-balustrade'});
    }
   }
   if(b.id==='A2'||b.id==='B2'){g.userData.walkableBalconies=[...balconyRanges(1).map(r=>({...r,floor:2})),...balconyRanges(2).map(r=>({...r,floor:3}))];feature('A2-walkable-one-and-two-bay-balconies');}
   if(b.id==='B2')kit.withCollision('none',()=>{for(let f=0;f<floors;f++)for(const r of b2Rooms(f))for(let j=0;j<3;j++){const u=r.openings[j].u,y=(f+1)*step-.18,W=b2Pitch-.28,x=side*(w+.015),white='#f1f0e8';
    if(r===undefined)continue;
    if(Math.abs(Math.abs(u)-(l-2.5*b2Pitch))<.01){let prev=null;for(let q=0;q<=24;q++){const t=-1+q/12,point=new THREE.Vector3(x,y-.42+.38*Math.sqrt(Math.max(0,1-t*t)),u+t*W/2);if(prev)kit.beam(prev,point,.04,white);prev=point;}}
    else{for(const dy of [0,-.34])box(.045,.035,W,x,y+dy,u,white);for(const dz of [-W/2,0,W/2])box(.045,.34,.035,x,y-.17,u+dz,white);}
   }});
   feature('continuous-curved-surfaces');
   feature('square-perforated-masonry-rails');feature('circular-infill-balustrade');feature('stepped-curved-balcony-widths');
   const porch=createPorchRoof({backV:b.id==='A2'?.52:b.id==='B2'?.22:null,side,wallX:w,u:coreCenter,width:(b.id==='A2'||b.id==='B2')?4*(b.id==='B2'?b2Pitch:b.length/15):Math.min(16,b.length*.46),hipLength:(b.id==='A2'||b.id==='B2')?(b.id==='B2'?b2Pitch/2:b.length/30):null,postPositions:(b.id==='A2'||b.id==='B2')?[-1.5,-.5,.5,1.5].map(n=>n*(b.id==='B2'?b2Pitch:b.length/15)):null,depth:2.9,eave:(b.id==='A2'||b.id==='B2')?step+.80-.58:Math.min(3.10,step*.76),rise:(b.id==='A2'||b.id==='B2')?.85:.58,color:b.id==='A2'?'#365d9b':'#904c57'});if(['A2','B2'].includes(b.id)){
    const spec={...porch.userData,side,wallX:w,u:coreCenter,back:b.id==='A2'?.52:.22,ridgeV:(b.id==='A2'?.52:.22)+.24,floor:step+.18,portalOffset:(b.id==='A2'?core+2*b.length/15:core+2*b2Pitch)/2+.48};
    porch.userData.walkPorch=spec;
    // Tiles, seams and soffit share the analytic surface; their bounding boxes must not obstruct it.
    porch.traverse(o=>{if(!o.isMesh)return;o.geometry.computeBoundingBox();if(o.isInstancedMesh){const matrix=new THREE.Matrix4();o.userData.walkRoles??=Array(o.count).fill(null);for(let i=0;i<o.count;i++){o.getMatrixAt(i,matrix);if(o.geometry.boundingBox.clone().applyMatrix4(matrix).min.y>=spec.eave-.35)o.userData.walkRoles[i]='none';}}else if(o.geometry.boundingBox.min.y>=spec.eave-.35)o.userData.walkRole='none';});
   }
   if(b.id==='A2'){
    const spec=porch.userData.walkPorch,v=1.12,bicycle=createBicycle({mini:false,color:'#853c3f',parked:false,lowDetail:true}),mount=new THREE.Group();
    mount.name='A2-upside-down-porch-bicycle';mount.userData.rideBikeId='roof:A2';bicycle.rotation.set(Math.PI,Math.PI/2,0);mount.add(bicycle);
    const slope=-spec.rise/(spec.depth-spec.ridgeV),height=spec.eave+spec.rise*(spec.depth-v)/(spec.depth-spec.ridgeV);
    mount.rotation.z=Math.atan(side*slope);mount.position.set(side*(w+v),height,coreCenter);mount.updateMatrixWorld(true);
    // Rest the actual saddle/handlebar geometry on the sloping tiles, with no floating gap.
    let clearance=Infinity;mount.traverse(o=>{if(!o.isMesh)return;o.userData.walkRole='barrier';const a=o.geometry.attributes.position;for(let i=0;i<a.count;i++){const q=new THREE.Vector3().fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld),vv=side*q.x-w,roofY=spec.eave+spec.rise*(spec.depth-vv)/(spec.depth-spec.ridgeV);clearance=Math.min(clearance,q.y-roofY);}});mount.position.y+=.018-clearance;
    mount.userData.placement={building:'A2',surface:'porch-roof',inverted:true,center:coreCenter,offsetFromGlass:v-.40};porch.add(mount);
   }g.add(porch);feature('detailed-tiled-ground-floor-porch');
   if(b.id==='A2'){
    for(const v of [.40,-corridor+.40])for(const u of [-span/2,-span/6,span/6,span/2])fb(coreCenter+u,h+1.326,v,.25,2.652,.50,wall);
    fb(coreCenter,h+2.652,-corridor/2+.40,span+.30,.20,corridor+1.0,wall);
    fb(coreCenter,h+2.782,.45,span+.40,.09,.60,trim);
    g.userData.roofFrame={bays:3,posts:8,height:2.652,coveredSlab:true,source:['DSC_1792.JPG','DSC_1793.JPG']};feature('A2-three-bay-covered-rooftop-frame');
   }
   if(b.id==='B2'){
    const vertices=[side*(w+.75),h-.2,coreCenter-span/2,side*(w+.75),h+1.35,coreCenter,side*(w+.75),h-.2,coreCenter+span/2];
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.computeVertexNormals();kit.solid(geo,trim,'triangular-pediment');for(const end of [-1,1])beam(new THREE.Vector3(side*(w+.85),h+1.35,coreCenter),new THREE.Vector3(side*(w+.85),h-.2,coreCenter+end*span/2),.16,wall);feature('triangular-glass-pediment');
   }else feature('bowed-blue-glass-stair-core');
   feature('curved-wing-balconies');feature(b.id==='A2'?'blue-entrance-canopy':'burgundy-entrance-canopy');
  }
  for(const range of [[-l,coreCenter-core/2],[coreCenter+core/2,l]])if(range[1]-range[0]>.01)makeOpeningWall(g,{side,wallX:w,faceV:-corridor,from:range[0],to:range[1],height:h,color:wall,openings:apertures,profile:{height:h,storey:step}});

  const groundOpenings=apertures.filter(o=>o.y<step-.1).map(o=>({...o,width:o.roomWidth??o.width})),roomRanges=b.id==='A2'?a2Rooms.map((r,i)=>({zmin:r.zmin,zmax:r.zmax,doorU:r.openings.find(o=>o.kind==='door').u,divider:i===0||i===2||i===3,small:!!r.small})):[[-l,coreCenter-core/2],[coreCenter+core/2,l]].flatMap(([from,to])=>classroomWingRooms(from,to,groundOpenings).map(r=>({...r,divider:r.zmax<to-.1}))),interiorSpecs=[];
  for(let f=0;f<floors;f++)for(const [i,r] of (b.id==='B2'?b2Rooms(f).map(r=>({...r,doorU:r.openings.find(o=>o.kind==='door').u,divider:r.zmax<coreCenter-core/2-.1||r.zmax>coreCenter+core/2+.1&&r.zmax<l-.1})):roomRanges).entries())interiorSpecs.push({buildingId:b.id,roomIndex:i,floor:f+1,side,boardEnd:b.id==='B2'?(r.doorU<(r.zmin+r.zmax)/2?-1:1):undefined,xmin:Math.min(side*(w-corridor),-side*w)+(b.id==='B1'?.28:.25),xmax:Math.max(side*(w-corridor),-side*w)-.25,zmin:r.zmin+.15,zmax:r.zmax-.15,doorU:r.doorU,rows:r.small?2:5,level:f*step+(f?.18:.002),clearHeight:step-.32,divider:r.divider});
  g.add(createClassroomInteriors(interiorSpecs));g.userData.standardClassroomTemplate='school-classroom-v63';g.userData.classroomRooms=roomRanges;feature('shared-standard-classroom-interiors');
  feature('real-corridor-door-and-window-openings');

}
