import {makeOpeningWall} from '../wall-openings.js?v=222.0';
import {gableRoof} from '../geometry-kit.js?v=222.0';
import {furnishClassroom} from '../classroom-furniture.js?v=222.0';
import {createSchoolWindow} from '../openings/school-window.js?v=222.0';
export function buildLab(ctx){
 const {b,g,kit,box,w,l,h,side,wall,trim,green,feature,apertures,fb,doorAt}=ctx,veranda=Math.min(1.6,b.width*.24),face=w-veranda;
 const schedule=[['door','window'],['window','window','door'],['window','window','door'],['window','window','window','door'],['door','window','window','window'],['door','window']],pitch=b.length/18,rooms=[];let count=0;
 box(.22,h,b.length,-side*(w-.11),h/2,0,wall);box(b.width,.14,b.length,0,-.10,0,'#bba47e');
 for(const row of schedule){const hi=l-count*pitch,lo=hi-row.length*pitch,centres=row.map((_,j)=>hi-(j+.5)*pitch);rooms.push({lo,hi,doorU:centres[row.indexOf('door')],schedule:row});
  row.forEach((kind,j)=>{const u=centres[j];if(kind==='door')doorAt(u,1.18,-veranda+.01,1.12,2.36,green);else{const o={kind:'window',u,y:1.55,width:1.18,height:1.35};apertures.push(o);g.add(createSchoolWindow({side,wallX:face,u,y:o.y,width:o.width,height:o.height,open:true,glazed:true}));}
   const vy=h-.40;fb(u,vy,-veranda+.04,1.35,.28,.05,trim);for(let cell=-1;cell<=1;cell++){const cu=u+cell*.42;fb(cu,vy,-veranda+.075,.31,.21,.04,'#707e70');fb(cu,vy,-veranda+.10,.045,.21,.035,trim);fb(cu,vy,-veranda+.10,.31,.04,.035,trim);}
  });count+=row.length;
 }
 for(const u of [...new Set(rooms.flatMap(r=>[r.lo,r.hi]))]){box(b.width-veranda,h,.18,-side*veranda/2,h/2,u,wall);}
 for(let j=0;j<=12;j++)fb(-l+j*b.length/12,h/2,-.10,.24,h,.28,wall);
 for(const r of rooms)g.add(furnishClassroom({xmin:-w+.25,xmax:face-.25,zmin:r.lo+.20,zmax:r.hi-.20,doorU:r.doorU,level:.02,rows:Math.max(2,Math.min(5,Math.floor((r.hi-r.lo-2.6)/1.05)+1))}));
 box(b.width+.35,.12,b.length+.5,0,h-.06,0,'#d8d4bb');gableRoof(kit,b.width,b.length,h,b.roof,.90);fb(0,h-.06,.12,b.length+.5,.24,.18,'#8f4b54');
 makeOpeningWall(g,{side,wallX:w,faceV:-veranda,from:-l,to:l,height:h,color:wall,openings:apertures});g.userData.laboratory={schedule,rooms:6,windows:12,doors:6,roofRise:.90,steps:1,furnished:true};
 feature('real-laboratory-openings');feature('six-furnished-laboratory-rooms');feature('patterned-laboratory-vents');feature('single-storey-laboratory');feature('green-laboratory-doors');feature('red-laboratory-roof');feature('veranda-column-row');
}
