import * as THREE from '../vendor/three.module.js';
// Split real faces by paint; no coincident colour overlays.
export function rearVentBlade(k,{x,y,z,width,side,yellow}){
 const geo=new THREE.BoxGeometry(.24,.055,width);geo.translate(x,y,z);
 const position=geo.attributes.position,normal=geo.attributes.normal;
 for(const color of [yellow,'#f2f1eb']){const vertices=[],normals=[];for(let face=0;face<6;face++){const exterior=(face===(side===1?0:1));if((color===yellow)!==exterior)continue;const group=geo.groups[face];for(let j=group.start;j<group.start+group.count;j++){const i=geo.index.getX(j);vertices.push(position.getX(i),position.getY(i),position.getZ(i));normals.push(normal.getX(i),normal.getY(i),normal.getZ(i));}}const part=new THREE.BufferGeometry();part.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));part.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));k.curved(part,color,'B1-rear-vent-painted-blade');}geo.dispose();
}
export function rearVentReveal(k,{x,z,y,width,height,depth=.22}){
 const x0=x-depth/2,x1=x+depth/2,y0=y-height/2+.002,y1=y+height/2-.002,z0=z-width/2+.002,z1=z+width/2-.002,quads=[[[x0,y0,z0],[x1,y0,z0],[x1,y1,z0],[x0,y1,z0]],[[x0,y0,z1],[x0,y1,z1],[x1,y1,z1],[x1,y0,z1]],[[x0,y0,z0],[x0,y0,z1],[x1,y0,z1],[x1,y0,z0]],[[x0,y1,z0],[x1,y1,z0],[x1,y1,z1],[x0,y1,z1]]],v=[];
 for(const q of quads)for(const i of [0,1,2,0,2,3])v.push(...q[i]);const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(v,3));geo.computeVertexNormals();k.withCollision('none',()=>k.curved(geo,'#f2f1eb','B1-white-vent-reveal'));
}
