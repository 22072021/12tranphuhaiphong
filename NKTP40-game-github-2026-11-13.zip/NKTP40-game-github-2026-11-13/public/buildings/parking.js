import {parkingPosts} from '../layout-state.js?v=127.1';
import {gableRoof} from '../geometry-kit.js?v=222.0';

export function buildParking(ctx){
 const {b,g,kit,box,ring,beam,w,l,h,floors,step,side,wall,trim,green,brown,dark,floor,feature,apertures,doorRecords,record,fb,windowAt,doorAt,vent,rail,plaque,archOpening,flatRoof,canopy,stairCore}=ctx;

  for(const p of parkingPosts(b)){box(.20,h,.20,p.x,h/2,p.z,'#b0b7aa');box(.45,.2,.45,p.x,.1,p.z,'#a6a595');}
  for(const s of [-1,1])box(.16,.16,b.length,s*(w-.3),h-.15,0,'#737d75');
  const count=Math.ceil(b.length/6);for(let j=0;j<=count;j++){const z=-l+j*b.length/count;box(b.width,.12,.12,0,h-.12,z,'#747e76');}
  gableRoof(kit,b.width,b.length,h,b.roof,.8);
  feature('open-column-parking-shed');feature('red-metal-roof');

}
