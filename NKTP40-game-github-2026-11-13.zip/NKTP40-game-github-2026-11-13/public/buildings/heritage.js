import {geometryKit} from '../geometry-kit.js?v=222.0';
import {heritageWindow} from '../heritage-window.js?v=231.0';
import {createHeritageInterior} from '../heritage-interior.js?v=231.0';
import {drawStoneStep,STAIR_STONE} from '../stair-stone.js?v=247.0';
import * as THREE from '../vendor/three.module.js';
import {makeOpeningWall} from '../wall-openings.js?v=222.0';
import {buildingBaseProfile} from '../building-bases.js?v=247.0';
import {createStairDoor} from '../interactive-door.js?v=222.0';
import {facadeRibbon,smoothArc} from '../curved-surfaces.js?v=28.0';
export function buildHeritage(ctx){
 const {b,g,kit,box,w,l,h,step,side,wall,trim,feature,fb}=ctx;
 const rearSetback=b.width*.18,mainDepth=b.width-rearSetback,wingLength=b.length*2/5,xRear=-side*(w-rearSetback),xmin=side*w,xmax=xRear;
 const white='#dedfd3',stone='#f0ede3';
 // All facades share the same opening data for masonry and joinery.
 function elevation(parent,sign,face,from,to,openings){
  // Lower the complete upper-window opening before masonry, joinery and crowns are drawn.
  for(const o of openings)if(o.kind==='window'&&o.y>step)o.y-=.30;
  makeOpeningWall(parent,{side:sign,wallX:Math.abs(face),faceV:0,from,to,height:h,color:wall,openings});
  for(const o of openings){if(o.kind==='window'){const win=heritageWindow({width:o.width,height:o.height});win.position.set(face-sign*.04,o.y,o.u);parent.add(win);}else if(o.door){parent.add(createStairDoor({side:sign,wallX:Math.abs(face),u:o.u,y:o.y,v:-.04,width:o.width,height:o.height,color:white,glazed:true}));}
   if(parent!==g&&o.kind==='window'&&o.y>step){const pts=Array.from({length:25},(_,i)=>{const t=i/24*Math.PI;return new THREE.Vector3(face+sign*.06,o.y+o.height/2+.12+.30*Math.sin(t),o.u+(o.width+.20)/2*Math.cos(t));});const local=geometryKit(parent);smoothArc(local,pts,.035,white,'heritage-white-sash-crown');local.box(.10,.06,o.width+.50,face+sign*.04,o.y+o.height/2+.54,o.u,white);local.finish();}
   if(o.arch){const center=o.y+o.height/2-o.arch;facadeRibbon(kit,sign,Math.abs(face),{from:o.u-o.width/2,to:o.u+o.width/2,curve:()=>0,bottom:u=>center+o.arch*Math.sqrt(Math.max(0,1-((u-o.u)/(o.width/2))**2)),top:o.y+o.height/2,thickness:.22,color:wall,name:'heritage-real-arch-haunch'});}
  }
 }
 const bay=b.length/5,front=[];
 for(let f=0;f<2;f++)for(const j of [0,1,3,4]){if(f===0&&(j===1||j===3))continue;const u=-l+(j+.5)*bay,isDoor=f===0&&(j===0||j===4);front.push({u,y:f*step+(isDoor?1.25:step*.55),width:isDoor?1.15:1.15,height:isDoor?2.5:step*.45,kind:isDoor?'door':'window',door:isDoor});}
 front.push({u:0,y:1.3,width:1.55,height:2.6,kind:'door',door:true},{u:0,y:step+1.35,width:1.8,height:2.7,kind:'door',arch:.32});
 elevation(g,side,side*w,-l,l,front);
 // Rear extension has its own hollow shell; no internal solid block.
 const rearOpen=[{u:0,y:1.3,width:1.55,height:2.6,kind:'door',arch:.32},{u:0,y:step+1.35,width:1.8,height:2.7,kind:'door',arch:.32}];
 for(let f=0;f<2;f++)for(const u of [-l+bay*.5,-l+bay*1.5])rearOpen.push({u,y:f*step+step*.55,width:1.15,height:step*.45,kind:'window'});
 elevation(g,-side,xRear,-l,l-wingLength,rearOpen);
 const wingOpen=[];for(let f=0;f<2;f++)wingOpen.push({u:l-wingLength/2,y:f*step+step*.55,width:1.18,height:step*.46,kind:'window'});
 elevation(g,-side,-side*w,l-wingLength,l,wingOpen);
 // Owner marked the return-face doors at both storeys.
 const returnFace=new THREE.Group();returnFace.name='heritage-return-door-wall';returnFace.rotation.y=Math.PI/2;g.add(returnFace);const returnU=-side*(w-rearSetback/2),returnZ=l-wingLength,returnHoles=[0,1].map(f=>({kind:'door',u:returnU,y:f*step+1.25,width:1.15,height:2.5}));
 makeOpeningWall(returnFace,{side:-1,wallX:returnZ,faceV:0,from:Math.min(xRear,-side*w),to:Math.max(xRear,-side*w),height:h,color:wall,openings:returnHoles});
 for(const o of returnHoles)returnFace.add(createStairDoor({side:-1,wallX:returnZ,u:o.u,y:o.y,v:0,width:o.width,height:o.height,color:white,glazed:true}));
 for(const end of [-1,1]){const face=new THREE.Group();face.rotation.y=Math.PI/2;g.add(face);const count=end===1?5:4,xEnd=end===1?-side*w:xRear,from=Math.min(xmin,xEnd),to=Math.max(xmin,xEnd),open=[];for(let f=0;f<2;f++)for(let j=0;j<count;j++)open.push({u:from+(j+.5)*(to-from)/count,y:f*step+step*.55,width:1.10,height:step*.46,kind:'window'});elevation(face,-end,-end*l,from,to,open);}
 // Slabs follow the L footprint, with clean white soffits and masonry cornices.
 const roofLift=.30;
 for(const y of [step,h]){const lift=y===h?roofLift:0;box(mainDepth,.18+lift,b.length,side*rearSetback/2,y-.09+lift/2,0,y===h?wall:'#bba47e');box(rearSetback,.18+lift,wingLength,-side*(w-rearSetback/2),y-.09+lift/2,l-wingLength/2,y===h?wall:'#acac9d');}
 for(const y of [step-.08,h+roofLift+.06,h+roofLift+.22]){fb(0,y,.07,b.length+.16,.12,.18,stone);for(const end of [-1,1])box(end===1?b.width:mainDepth,.12,.16,end===1?0:side*rearSetback/2,y,end*(l+.03),stone);}
 fb(0,h+roofLift+.32,0,b.length+.08,.18,.18,wall);for(const end of [-1,1])box(end===1?b.width:mainDepth,.26,.18,end===1?0:side*rearSetback/2,h+roofLift+.12,end*(l-.06),wall);box(.18,.26,b.length-wingLength,xRear,h+roofLift+.12,-wingLength/2,wall);box(.18,.26,wingLength,-side*w,h+roofLift+.12,l-wingLength/2,wall);box(rearSetback,.26,.18,-side*(w-rearSetback/2),h+roofLift+.12,l-wingLength,wall);
 g.userData.heritageRoofLift=roofLift;g.userData.heritageUpperWindowsLowered=.30;
 // Upper white segmental crowns and stepped keyed lintels, aligned to each sash.
 for(const o of front.filter(o=>o.y>step)){const rise=o.u===0?.32:.32,spring=o.y+o.height/2+.10,ww=o.width+.22;const pts=Array.from({length:33},(_,i)=>{const t=i/32*Math.PI;return new THREE.Vector3(side*(w+.08),spring+rise*Math.sin(t),o.u+ww/2*Math.cos(t));});smoothArc(kit,pts,.036,white,'heritage-segmental-window-crown');fb(o.u,spring+rise+.13,.05,ww+.28,.065,.10,white);fb(o.u,spring+rise+.02,.07,.13,.23,.11,white);}
 for(let j=0;j<=5;j++){const u=-l+j*bay;for(let y=.30;y<h-.42;y+=.40)fb(u,y,.025,.24,.12,.055,wall);}
 // P56 rear window crowns and keyed lintels repeat the original front moulding.
 for(const [face,openings]of [[xRear,rearOpen],[-side*w,wingOpen]])for(const o of openings.filter(o=>o.y>step)){const spring=o.y+o.height/2+.10,ww=o.width+.22,points=Array.from({length:33},(_,i)=>{const a=i/32*Math.PI;return new THREE.Vector3(face-side*.07,spring+.32*Math.sin(a),o.u+ww/2*Math.cos(a));});smoothArc(kit,points,.036,white,'heritage-rear-window-crown');box(.10,.065,ww+.28,face-side*.05,spring+.45,o.u,white);box(.11,.23,.13,face-side*.07,spring+.34,o.u,white);}
 // P56: orthogonal L balcony connecting corridor and wing return door.
 const backSign=-side,rearFace=xRear,halfBalcony=1.05,nose=1.10;
 const balconyOutline=[[rearFace,-halfBalcony],[rearFace,returnZ],[-side*w,returnZ],[-side*w,.40],[rearFace+backSign*nose,.40],[rearFace+backSign*nose,-halfBalcony]];
 const tri=new THREE.Shape();balconyOutline.forEach(([x,z],i)=>i?tri.lineTo(x,z):tri.moveTo(x,z));tri.closePath();
 const slab=new THREE.ExtrudeGeometry(tri,{depth:.16,bevelEnabled:false}),pos=slab.attributes.position;for(let i=0;i<pos.count;i++){const x=pos.getX(i),z=pos.getY(i),d=pos.getZ(i);pos.setXYZ(i,x,step-d,z);}slab.computeVertexNormals();kit.curved(slab,wall,'heritage-rear-L-balcony-slab');
 // Same stone floor and 60cm joint grid as the corridor, clipped to the L footprint.
 const tile=new THREE.ExtrudeGeometry(tri,{depth:.04,bevelEnabled:false}),tp=tile.attributes.position;
 for(let i=0;i<tp.count;i++){const x=tp.getX(i),z=tp.getY(i),d=tp.getZ(i);tp.setXYZ(i,x,step+.04-d,z);}tile.computeVertexNormals();kit.curved(tile,'#b3ada0','heritage-rear-continuous-floor');
 const strips=[{x0:rearFace,x1:rearFace+backSign*nose,z0:-halfBalcony,z1:returnZ},{x0:rearFace+backSign*nose,x1:-side*w,z0:.40,z1:returnZ}];
 kit.withCollision('none',()=>{for(const r of strips){for(let x=-w+.2;x<Math.max(r.x0,r.x1);x+=.6)if(x>Math.min(r.x0,r.x1)+.004)box(.007,.002,r.z1-r.z0,x,step+.041,(r.z0+r.z1)/2,'#88877c');for(let z=-l+.2;z<r.z1;z+=.6)if(z>r.z0+.004)box(Math.abs(r.x1-r.x0),.002,.007,(r.x0+r.x1)/2,step+.041,z,'#88877c');}});

 const guardPath=[balconyOutline[0],balconyOutline[5],balconyOutline[4],balconyOutline[3],balconyOutline[2]];
 for(let i=1;i<guardPath.length;i++){const a={x:guardPath[i-1][0],z:guardPath[i-1][1]},tip={x:guardPath[i][0],z:guardPath[i][1]},dx=tip.x-a.x,dz=tip.z-a.z,len=Math.hypot(dx,dz),angle=Math.atan2(dx,dz),cx=(a.x+tip.x)/2,cz=(a.z+tip.z)/2;box(.14,.22,len,cx,step+.11,cz,wall,0,angle);box(.16,.12,len,cx,step+.83,cz,stone,0,angle);const count=Math.max(2,Math.round(len/.38));for(let j=0;j<=count;j++){const t=j/count;box(.15,.50,.12,a.x+dx*t,step+.49,a.z+dz*t,wall,0,angle);}}
 g.userData.heritageRear={wingWindowsPerFloor:1,groundCorridorDoor:false,openRearArch:true,returnDoorWidth:1.15,balconyFloor:'corridor-stone-60cm',railingFinish:'yellow-body-white-coping',balcony:'L',balconyVertices:balconyOutline,guardPath,returnDoors:2,returnDoorCentre:[returnU,returnZ],upperWindowCrowns:true,source:'P56 DSC_1807.JPG'};
 g.add(createHeritageInterior(b,{rearSetback,mainDepth}));
 g.userData.heritageEvidence={front:'P50/P51',corridor:'P52',rooms:'P53/P54',rear:'P55/P56',estimatedDimensions:true};
 feature('real-heritage-front-openings');feature('heritage-rear-setback');feature('heritage-rear-balcony');
  const landing=3.0,flightWidth=1.40,outer=3.65,turnV=1.18,footV=4.1,stairBase=buildingBaseProfile(b).height,riserHeight=(step+stairBase)/20,mid=11*riserHeight-stairBase;
  fb(0,step-.1175,turnV-.15,landing,.165,flightWidth-.30,wall);fb(0,step-.0175,turnV-.15,landing,.035,flightWidth-.30,'#b77d80');
  // Close the former48cm gap between the stair rear edge and the facade.
  const attachBack=-.05,attachFront=turnV-flightWidth/2,attachDepth=attachFront-attachBack;
  fb(0,step-.1175,(attachFront+attachBack)/2,landing,.165,attachDepth,wall);fb(0,step-.0175,(attachFront+attachBack)/2,landing,.035,attachDepth,'#b77d80');
  for(const wing of [-1,1]){const from=wing*(outer-flightWidth/2),to=wing*landing/2;for(let j=0;j<9;j++){const t=(j+.5)/9,y=mid+(step-mid)*(j+1)/9;fb(from+(to-from)*t,(y-.035-stairBase)/2,(attachFront+attachBack)/2,Math.abs(to-from)/9+.003,y-.035+stairBase,attachDepth,wall);fb(from+(to-from)*t,y-.0175,(attachFront+attachBack)/2,Math.abs(to-from)/9+.003,.035,attachDepth,'#b77d80');}fb(wing*outer,(mid-stairBase)/2,(attachFront+attachBack)/2,flightWidth,mid+stairBase,attachDepth,wall);}
  g.userData.heritageStairAttachment={gapClosed:attachFront,removedGroundWindows:2,facadeConnected:true};
  function stairWall(a,c,thickness=.20){
   const du=c.u-a.u,dv=c.v-a.v,len=Math.hypot(du,dv),nu=-dv/len*thickness/2,nv=du/len*thickness/2;
   function panel(t0,t1,bottom,top,color,depth=thickness){
    const points=[];for(const offset of [-1,1])for(const [t,level] of [[t0,bottom],[t1,bottom],[t1,top],[t0,top]]){
     const base=a.y+(c.y-a.y)*t;points.push([side*(w+a.v+dv*t+nv*offset*depth/thickness),(level===-.18&&Math.abs(a.y-c.y)>.001?-stairBase-.02:base+level),a.u+du*t+nu*offset*depth/thickness]);
    }
    const vertices=[];for(const face of [[0,1,2],[0,2,3],[4,6,5],[4,7,6],[0,4,5],[0,5,1],[1,5,6],[1,6,2],[2,6,7],[2,7,3],[3,7,4],[3,4,0]])for(const i of face)vertices.push(...points[i]);
    const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geometry.computeVertexNormals();kit.curved(geometry,color,'heritage-stair-guard');
   }
   // Actual openings between masonry piers, not painted rectangles or metal rails.
   panel(0,1,-.18,.25,wall);panel(0,1,.63,.75,wall);
   const bays=Math.max(3,Math.round(len/.60));for(let i=0;i<=bays;i++){const t=i/bays,half=.21/len;panel(Math.max(0,t-half),Math.min(1,t+half),.25,.63,wall);}
   panel(0,1,.75,.89,'#f0ede3',.30);
  }
  function stairFlight(a,c,width,count){
   const du=c.u-a.u,dv=c.v-a.v,run=Math.hypot(du,dv);
   for(let j=0;j<count;j++){
    const t=(j+.5)/count,y=a.y+(c.y-a.y)*(j+1)/count;
    drawStoneStep(kit,{x:side*(w+a.v+dv*t),y:y,z:a.u+du*t,width,depth:run/count,thickness:y+stairBase,riserColor:wall,nosing:.01,axis:Math.abs(dv)>0?'x':'z',finish:{red:'#b77d80',yellow:'#b77d80',border:0}});
   }
   const nu=-dv/run*width/2,nv=du/run*width/2;
   for(const edge of [-1,1]){if(a.y>0&&Math.abs(dv)<.001&&edge*nv<0)continue;stairWall({u:a.u+edge*nu,v:a.v+edge*nv+(a.y<0?.75:0),y:a.y},{u:c.u+edge*nu,v:c.v+edge*nv,y:c.y});}
  }
  for(const wing of [-1,1]){
   const u=wing*outer;
   // P51: each foot is framed by square newels with broad white square caps.
   for(const edge of [-1,1]){const z=u+edge*flightWidth/2,x=side*(w+footV+.75);box(.34,.85+stairBase,.34,x,(.85-stairBase)/2,z,wall);box(.46,.14,.46,x,.82,z,'#f0ede3');}
   stairFlight({u,v:footV,y:-stairBase},{u,v:turnV+flightWidth/2,y:mid},flightWidth,11);
   fb(u,(mid-.035)/2,turnV,flightWidth,mid-.035,flightWidth,wall);fb(u,mid-.0175,turnV,flightWidth,.035,flightWidth,'#b77d80');
   // Rear and outer returns enclose the side landing; both flight openings stay clear.
   stairWall({u:u+wing*flightWidth/2,v:-.05,y:mid},{u:u+wing*flightWidth/2,v:turnV+flightWidth/2,y:mid});
   stairFlight({u:wing*(outer-flightWidth/2),v:turnV,y:mid},{u:wing*landing/2,v:turnV,y:step},flightWidth,9);
  }
  stairWall({u:-landing/2,v:turnV+flightWidth/2,y:step},{u:landing/2,v:turnV+flightWidth/2,y:step});
  // White underside beneath the pink upper landing, yellow masonry reveals.
  kit.withCollision('none',()=>fb(0,step-.207,(turnV+flightWidth/2+attachBack)/2,landing,.012,turnV+flightWidth/2-attachBack,'#f4f3eb'));
  // Open arch below the upper landing, leaving a walk-through ground-floor entrance.
  const archW=2.15,archRise=.40,spring=step-.88,archTop=step-.18;
  for(const sign of [-1,1])fb(sign*(landing+archW)/4,(archTop-stairBase)/2,turnV+flightWidth/2,(landing-archW)/2,archTop+stairBase,.30,wall);
  facadeRibbon(kit,side,w,{from:-archW/2,to:archW/2,curve:()=>turnV+flightWidth/2,bottom:u=>spring+archRise*Math.sqrt(Math.max(0,1-(u/(archW/2))**2)),top:archTop,thickness:.30,color:wall,name:'continuous-entrance-arch'});
  g.userData.heritageStairs={riserHeight,treadOnlyGranito:true,treadNosing:.01,riserFinish:wall,entranceSoffit:'#f4f3eb',topology:'mirrored-quarter-turn',flights:4,sideLandings:2,centralLanding:1,lowerSteps:11,upperSteps:9,dimensions:'estimated-from-DSC_1775',newelsPerFlight:2,newelCapWidth:.46,handrailFinish:'white-limewash',handrailWidth:.30,footRailExtension:.75,wallSideUpperRail:false,landingRailEndsInFacade:true};
  feature('mirrored-quarter-turn-exterior-staircases');feature('masonry-slotted-stair-parapets');feature('open-arch-below-central-landing');feature('arched-window-mouldings');feature('white-shutters');

}
