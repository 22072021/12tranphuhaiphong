import {drawStoneStep,drawStoneLanding,STAIR_STONE} from '../stair-stone.js?v=218.0';
import {subtractFloorRect} from '../building-bases.js?v=223.0';
import {createGlassPane} from '../openings/glass.js?v=48.0';
import {createAdministrationWindow,ADMIN_WINDOW} from '../admin-window.js?v=222.0';
import {smoothArc} from '../curved-surfaces.js?v=28.0';
import {createAdministrationRooms} from '../admin-rooms.js?v=222.0';
import {administrationPlan} from '../admin-design.js?v=56.0';
import * as THREE from '../vendor/three.module.js';
import {makeOpeningWall} from '../wall-openings.js?v=222.0';
import {drawStairUnderSlab,stairGuard} from '../stair-design.js?v=228.0';
import {geometryKit} from '../geometry-kit.js?v=222.0';

export function buildAdmin(ctx){
 const {b,g,kit,box,ring,beam,w,l,h,floors,step,side,wall,trim,green,brown,dark,floor,feature,apertures,doorRecords,record,fb,windowAt,doorAt,vent,rail,plaque,archOpening,flatRoof,canopy,stairCore}=ctx;

  const p=administrationPlan(b),{corridor,bay,endBay=bay}=p,frontV=-corridor;
  // A hollow single large room on each floor, not a filled building mass.
  const ventWidth=p.stairBay-.42,ventHeight=1.45,rearEdge=-side*w;
  const firstLanding=p.landings[0],grilleHole={u:p.wellU,y:firstLanding.y+.95,width:ventWidth,height:ventHeight,kind:'window'};
  // Only the first half-landing uses the confirmed welded grille.
  // Upper rear glazing spans beam to beam, without intermediate ceilings.
  const rearGlass=Array.from({length:floors-1},(_,i)=>{const f=i+1,bottom=f*step+.06,top=(f+1)*step-(f===floors-1?p.structure.roofBeam:p.structure.floorBeam);return{u:p.wellU,y:(bottom+top)/2,width:p.stairBay-p.columnWidth,height:top-bottom,bottom,top,kind:'window'};});
  const ventHoles=[grilleHole,...rearGlass];
  // One perforated exterior wall: no second solid wall behind the grilles.
  const ventWall=makeOpeningWall(g,{side:-side,wallX:w,faceV:0,from:-l,to:l,height:h,color:wall,openings:ventHoles,profile:{height:h,storey:step}});ventWall.name='admin-landing-vent-wall';
  ventWall.userData.exterior=true;
  // Left end stays solid; right stairwell end has actual landing-side apertures.
  box(b.width-corridor-.5,h,.22,-side*(corridor+.5)/2,h/2,side*(l-.11),wall);
  const endWall=new THREE.Group();endWall.rotation.y=Math.PI/2;endWall.name='admin-right-landing-side-wall';g.add(endWall);
  const sideHoles=p.landings.map(a=>({u:-side*(w-.22-1.40),y:a.y+1.05,width:2.40,height:1.0,kind:'window'}));
  makeOpeningWall(endWall,{side,wallX:l,faceV:0,from:-w,to:w-corridor-.25,height:h,color:wall,openings:sideHoles,profile:{height:h,storey:step}});
  const ek=geometryKit(endWall);for(const hole of sideHoles){for(const zz of [hole.u-hole.width/2,hole.u+hole.width/2])ek.box(.28,hole.height+.10,.06,side*(l-.10),hole.y,zz,trim);for(const yy of [hole.y-hole.height/2,hole.y+hole.height/2])ek.box(.30,.06,hole.width+.10,side*(l-.10),yy,hole.u,trim);for(let j=1;j<4;j++)ek.box(.045,.035,hole.width-.03,side*(l+.015),hole.y-hole.height/2+j*hole.height/4,hole.u,'#31544a');}ek.finish();
  endWall.userData={source:'owner-request-with-partial-photo-coverage',vents:sideHoles};
  const roomLo=Math.min(p.u(1/7),p.u(5/7)),roomHi=Math.max(p.u(1/7),p.u(5/7));
  const leftU=p.u(.5/7),rightHallU=p.u(5.5/7),stairU=p.stairU;
  for(let f=0;f<=floors;f++){
   const level=f*step,thickness=f===floors?p.structure.roofSlab:p.structure.floorSlab;
   // Room and the two full-depth side corridors.
   box(b.width,thickness,b.length-p.stairBay,0,level-thickness/2-(f===0?.004:0),side*p.stairBay/2,trim);
   // Front and rear landings and the narrow return gallery leave the flight open.
   const fx=(side*w+p.front)/2,fd=Math.abs(side*w-p.front);
   box(fd,thickness,p.stairBay,fx,level-thickness/2-(f===0?.004:0),p.u(6.5/7),trim);
   // Match the ground-floor octagonal tiles on upper galleries and side halls.
   // Thin finish stays flush within the walking tolerance; leave the stairwell open.
   if(f>0&&f<floors){
    const roomCut={x0:-p.w+.25,x1:p.w-p.corridor-.24,z0:roomLo+.15,z1:roomHi-.15};
    const body={x0:-w,x1:w,z0:side*p.stairBay/2-(b.length-p.stairBay)/2,z1:side*p.stairBay/2+(b.length-p.stairBay)/2};
    for(const r of subtractFloorRect(body,roomCut))box(r.x1-r.x0,.012,r.z1-r.z0,(r.x0+r.x1)/2,level+.006,(r.z0+r.z1)/2,floor);
    box(fd,.012,p.stairBay,fx,level+.006,p.u(6.5/7),floor);
   }
   // The well stays open: no full-floor return gallery across the flights.
   if(f===floors)box(b.width,thickness,p.stairBay,0,level-thickness/2,p.u(6.5/7),trim);
  }
  // Side-room partitions stop at the front veranda; each room remains one large volume.
  g.add(createAdministrationRooms(b,p));
  for(const u of p.edges)fb(u,h/2,-.15,p.columnWidth,h,p.structure.columnDepth,trim);
  for(let f=0;f<floors;f++){
   const level=f*step,yy=level+1.55;
   const schedule=f<2?['door','window','window','door']:['door','door','door','window'];
   for(let j=0;j<4;j++){
    const u=p.u((j+1.5)/7),kind=schedule[j],ww=kind==='door'?Math.min(1.65,bay*.52):Math.min(2.85,bay*.82);
    if(kind==='door'){doorAt(u,level+1.45,frontV+.01,ww,2.90,brown,0,true);if(j===0){const door=g.children.find(o=>o.userData.door&&Math.abs(o.position.z-u)<.01&&Math.abs(o.position.y-level-1.45)<.01);door.userData.role='admin-main-entry';door.userData.floor=f+1;}}
    else{const size=ADMIN_WINDOW.size,y=level+ADMIN_WINDOW.top-size/2;apertures.push({kind:'window',u,y,width:size*.8,height:size,v:frontV+.01});g.add(createAdministrationWindow({side,wallX:w+frontV+.01,u,level}));}
    // Glazed transom over the doors, with timber dividers.
    if(kind==='door'){record('window',u,level+3.20,ww,.42,frontV+.01);createGlassPane(g,{x:side*(w+frontV-.02),y:level+3.20,z:u,width:ww,height:.42,name:'admin-door-glass-transom'});for(const t of [-.5,0,.5])fb(u+t*ww,level+3.20,frontV+.035,.045,.49,.055,brown);for(const y of [level+2.96,level+3.44])fb(u,y,frontV+.035,ww+.08,.05,.055,brown);}
   }
   for(let j=0;j<p.edges.length-1;j++){
    const u=(p.edges[j]+p.edges[j+1])/2,width=Math.abs(p.edges[j+1]-p.edges[j])-.5;
    if(f)rail(u,level,-.13,width,trim,true);
    const depth=f===floors-1?p.structure.roofBeam:p.structure.floorBeam;fb(u,level+step-depth/2,-.06,width,depth,.48,trim);fb(u,level+step-depth-.26,-.12,width,.10,.23,trim);fb(u,level+step-depth-.12,-.12,.12,.28,.23,trim);
   }
  }
  for(let f=1;f<floors;f++)for(const end of [-1,1])stairGuard(kit,{x:side*(w-corridor-.3),y:f*step,z:end*(l-.14)},{x:side*(w-.12),y:f*step,z:end*(l-.14)},'#343d37');
  makeOpeningWall(g,{side,wallX:w,faceV:frontV,from:roomLo,to:roomHi,height:h,color:wall,openings:apertures,profile:{height:h,storey:step}});
  // Ground-floor side passages are closed by expandable metal gates, not windows.
  for(const u of [leftU,rightHallU]){
   const width=p.hallBay-.54,height=3.12,v=frontV-.08;
   for(const sign of [-1,1])fb(u+sign*width/2,height/2,v,.065,height,.11,'#8e8c72');
   for(const y of [.06,height])fb(u,y,v,width,.055,.10,'#8e8c72');
   const count=12;for(let j=0;j<=count;j++){const z=u-width/2+j*width/count;fb(z,height/2,v,.025,height,.055,'#b4aa87');}
   for(let j=0;j<count;j++)for(let y=.12;y<height-.2;y+=.44){const z=u-width/2+(j+.5)*width/count,du=width/count/2;for(const sign of [-1,1])beam(new THREE.Vector3(side*(w+v+.015),y,z-sign*du),new THREE.Vector3(side*(w+v+.015),y+.44,z+sign*du),.018,'#b4aa87');}
   fb(u,height+.26,v,width,.42,.035,'#48544a');for(let j=0;j<=6;j++)fb(u-width/2+j*width/6,height+.26,v+.03,.035,.42,.04,'#b4aa87');
  }
  // Half-storey landings terminate at framed welded ventilation openings.
  // Rear grille is mounted directly in the exterior wall at the end of the landing.
  for(const a of p.landings)drawStoneLanding(kit,{x:a.x,y:a.y,z:a.z,width:a.sx,depth:a.sz,thickness:.18});
  for(const a of [firstLanding]){
   const vent=new THREE.Group();vent.name='admin-welded-landing-vent';vent.userData={kind:'welded-steel-vent',level:a.y,width:ventWidth,height:ventHeight};g.add(vent);const vk=geometryKit(vent),x=rearEdge+side*.11,y=a.y+.95;
   for(const z of [a.z-ventWidth/2,a.z+ventWidth/2])vk.box(.08,ventHeight+.12,.065,x,y,z,'#244c42');
   for(const yy of [y-ventHeight/2,y+ventHeight/2])vk.box(.08,.065,ventWidth+.12,x,yy,a.z,'#244c42');
   for(let j=1;j<8;j++)vk.box(.075,.055,ventWidth-.03,x,y-ventHeight/2+j*ventHeight/8,a.z,'#2a5148');
   for(const dz of [-ventWidth/6,ventWidth/6])vk.box(.07,ventHeight,.035,x,y,a.z+dz,'#244c42');vk.finish();
  }
  const glazing=new THREE.Group();glazing.name='admin-rear-stair-glazing';glazing.userData={openings:rearGlass,beamToBeam:true,noIntermediateCeiling:true};g.add(glazing);const rk=geometryKit(glazing),rx=rearEdge+side*.11;
  for(const q of rearGlass){createGlassPane(glazing,{x:rx,y:q.y,z:q.u,width:q.width,height:q.height,name:'admin-rear-beam-to-beam-glass'});for(const z of [q.u-q.width/2,q.u+q.width/2])rk.box(.075,q.height+.10,.065,rx,q.y,z,'#514e45');for(const yy of [q.bottom,q.top])rk.box(.075,.065,q.width+.10,rx,yy,q.u,'#514e45');for(const t of [-.25,0,.25])rk.box(.065,q.height,.04,rx,q.y,q.u+t*q.width,'#514e45');rk.box(.065,.045,q.width,rx,q.y,q.u,'#514e45');}rk.finish();
  const {red:pink,yellow,border}=STAIR_STONE;
  for(const a of p.flights){
   const dx=a.to.x-a.from.x,depth=Math.abs(dx)/a.count+.008;
   for(let j=0;j<a.count;j++){
    const t=(j+.5)/a.count,y=a.from.y+(a.to.y-a.from.y)*(j+1)/a.count,x=a.from.x+dx*t;
    drawStoneStep(kit,{x,y,z:a.from.z,width:a.width,depth});
    // Fine joint/nosing lines separate pink central stone treads; yellow strips continue down the risers.
    box(.018,.008,a.width-2*border,x-Math.sign(dx)*depth/2+.009*Math.sign(dx),y+.003,a.from.z,'#a97577');
   }
   drawStairUnderSlab(kit,a.from,a.to,a.width,'#c9b8a0');
   // Only the open well edge has a handrail. The wall-facing edge stays bare.
   const sign=Math.sign(p.wellU-a.from.z),handrail=new THREE.Group();handrail.name='admin-flight-handrail';handrail.userData={edge:'open-well',wallSide:false};g.add(handrail);const hk=geometryKit(handrail);
   stairGuard(hk,{...a.from,z:a.from.z+sign*a.width/2},{...a.to,z:a.to.z+sign*a.width/2},'#59605b');hk.finish();
  }
  stairGuard(kit,{x:p.front,y:(floors-1)*step,z:p.stairU-p.stairWidth/2},{x:p.front,y:(floors-1)*step,z:p.stairU+p.stairWidth/2},'#343d37');
  // Recessed side enclosure between the room-side corridor and the stairwell.
  box(b.width-corridor-.30,h,.18,-side*(corridor+.30)/2,h/2,p.u(6/7),wall);
  // The top-floor slab is the roof deck; use one structural surface and a red coping.
  for(const end of [-1,1]){box(.14,.18,b.length+.28,end*(w+.02),h+.09,0,wall);box(b.width,.18,.14,0,h+.09,end*(l+.02),wall);}
  fb(0,h+.20,.03,b.length+.22,.06,.28,'#865e51');feature('flat-parapet-roof');
  // P07: wide ground porch below floor 2, and a deeper canopy/pediment above floor 3.
  const porchU=p.u(3/7),porchW=2*bay+.45,porchD=1.60;
  fb(porchU,step-.14,porchD/2-.1,porchW,p.structure.porchSlab,porchD+.25,trim);
  fb(porchU,step+.40,porchD-.11,porchW-.10,.80,.20,wall);fb(porchU,step+.85,porchD-.11,porchW+.03,.10,.30,'#95695b');
  plaque('THI ĐUA DẠY TỐT - HỌC TỐT',porchU,step+.42,porchD+.02,porchW-.25,.64,'#b87996');
  for(const u of [p.u(2/7),p.u(4/7)]){fb(u,step/2,porchD*.45,p.structure.porchColumn,step,.60,trim);fb(u,step*.50,porchD*.45+.315,p.structure.porchColumn+.01,step*.80,.025,'#b87996');}
  const roofD=1.85,span=2*bay+.55;fb(porchU,h+.06,roofD/2-.08,span,p.structure.roofCanopySlab,roofD+.30,trim);
  const face=side*(w+roofD-.05),top=h+1.45,low=h+.20,vertices=[];
  const pts=[[-span/2,low],[-span/2,top-.26],[0,top],[span/2,top-.26],[span/2,low]];
  for(let i=1;i<pts.length-1;i++)for(const k of [0,i,i+1])vertices.push(face,pts[k][1],porchU+pts[k][0]);
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.computeVertexNormals();kit.solid(geo,trim,'administration-parapet');
  const pk=kit,back=side*(w-.12),returnD=Math.abs(face-back),returnH=top-.26-low;
  for(const end of [-1,1]){pk.box(returnD,returnH,.18,(face+back)/2,low+returnH/2,porchU+end*(span/2-.09),wall);pk.box(returnD+.04,.08,.22,(face+back)/2,top-.26,porchU+end*(span/2-.09),'#90645c');}g.userData.roofPedimentReturns={sides:2,depth:returnD,height:returnH};
  for(let j=0;j<pts.length;j++){const a=pts[j],c=pts[(j+1)%pts.length];beam(new THREE.Vector3(face+.03*side,a[1],porchU+a[0]),new THREE.Vector3(face+.03*side,c[1],porchU+c[0]),.10,'#90645c');}
  for(const u of [p.u(2/7),p.u(4/7)])fb(u,step*2+.06,.32,.70,.25,.95,trim);
  const lamp=new THREE.Group();lamp.name='admin-second-floor-wall-lamp';lamp.userData={floor:2,source:['P05','P06','P07'],estimatedDimensions:true};g.add(lamp);const lk=geometryKit(lamp),lampU=p.u(5/7),lampX=side*(w+.40);
  lk.withCollision('none',()=>{lk.cylinder(.022,3.75,lampX,step+2.35,lampU,'#6b6258');for(const y of [step+.65,step+1.75]){lk.box(.05,.15,.13,side*(w+.23),y,lampU,'#66665f');lk.beam(new THREE.Vector3(side*(w+.23),y,lampU),new THREE.Vector3(lampX,y,lampU),.04,'#6b6258');}smoothArc(lk,Array.from({length:17},(_,i)=>{const t=i/16;return new THREE.Vector3(side*(w+.40+.23*t*t),step+4.18+.20*t,lampU);}),.022,'#6b6258','lamp-curved-arm');});lk.finish();
  const housing=new THREE.Mesh(new THREE.SphereGeometry(.12,20,16),new THREE.MeshStandardMaterial({color:'#8b9798',roughness:.6}));housing.scale.set(.55,1.85,1.05);housing.position.set(side*(w+.65),step+4.35,lampU);housing.rotation.z=-side*.20;housing.userData.walkRole='none';lamp.add(housing);const lens=new THREE.Mesh(new THREE.SphereGeometry(.10,20,16),new THREE.MeshStandardMaterial({color:'#d5dad4',roughness:.35}));lens.scale.set(.16,1.8,.95);lens.position.copy(housing.position);lens.position.x+=side*.066;lens.userData.walkRole='none';lamp.add(lens);
  g.userData.administration={stairFinish:{pink,yellow,border,handrail:'open-well-side-only',landingVent:'welded-steel-frame'},topology:'recessed-right-half-storey-switchback',plan:p,roomsPerFloor:1,sideGroundGates:2,porch:{center:porchU,width:porchW,depth:porchD},roofCanopyDepth:roofD};
  feature('real-administration-openings');feature('administration-subdivided-window-sashes');feature('projecting-administration-porch');feature('recessed-right-half-storey-switchback');feature('ground-floor-folding-side-gates');feature('single-large-room-per-floor');

}
