import * as THREE from '../vendor/three.module.js';
// P42: hollow projecting brick planter, tapered sides and fine trailing stems.
export function drawB1Planter(k,{x,y,z,width,side}){
 const depth=.70,low=y-.20,high=y+.235,lowW=width*.82,lowD=depth*.72;
 const corners=(w,d,h)=>[[-d/2,h,-w/2],[d/2,h,-w/2],[d/2,h,w/2],[-d/2,h,w/2]],bottom=corners(lowW,lowD,low),top=corners(width,depth,high),v=[];
 for(let i=0;i<4;i++){const j=(i+1)%4;for(const p of [bottom[i],top[j],bottom[j],bottom[i],top[i],top[j]])v.push(x+p[0],p[1],z+p[2]);}
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(v,3));geo.computeVertexNormals();k.curved(geo,'#9d6653','B1-P42-tapered-planter');
 k.box(lowD,.07,lowW,x,low+.035,z,'#a16d50');k.box(depth-.12,.04,width-.12,x,high-.10,z,'#514d39');
 // Three staggered brick courses on the courtyard-facing wall, with narrow mortar joints.
 for(let row=0;row<3;row++){const t=(row+.5)/3,w=lowW+(width-lowW)*t,d=lowD+(depth-lowD)*t,n=Math.ceil(w/.28),pitch=w/n;
  for(let col=0;col<n;col++)k.box(.035,.115,pitch-.012,x+side*d/2,low+(row+.5)*(high-low)/3,z-w/2+(col+.5)*pitch,'#a45e4d');}
 for(const sign of [-1,1]){k.box(.075,.055,width+.06,x+sign*(depth/2-.025),high+.015,z,'#ad7059');k.box(depth-.10,.055,.075,x,high+.015,z+sign*width/2,'#ad7059');}
 k.withCollision('none',()=>{for(let n=0;n<24;n++){const u=z+(n+.5)/24*width-width/2,sway=Math.sin(n*2.4),length=.28+.58*(.5+.5*Math.sin(n*1.83));let prev=new THREE.Vector3(x+side*(depth/2+.015),high+.07,u);
  for(let q=1;q<=5;q++){const t=q/5,p=new THREE.Vector3(x+side*(depth/2+.06+.09*Math.sin(t*3+n)),high+.07-length*t,u+sway*.13*t);k.beam(prev,p,.008,'#73805b');if(q%2===0)for(const sign of [-1,1])k.beam(p,new THREE.Vector3(p.x+side*.025,p.y+.035,p.z+sign*.06),.012,'#667650');prev=p;}
 }for(let n=0;n<15;n++)k.beam(new THREE.Vector3(x,high-.06,z+(n/15-.5)*width*.9),new THREE.Vector3(x+.13*Math.sin(n),high+.12+.18*(.5+.5*Math.sin(n*2)),z+(n/15-.5)*width),.009,'#7c805e');});
}
