import {createA1EventStage} from '../a1-event-stage.js';
import {createA1MedalSign} from '../a1-medal-sign.js?v=121.0';
import {addVentSlots} from '../openings/vent-slot.js?v=220.0';
import {a1GroundEntries} from '../a1-ground-entries.js?v=217.0';
import {drawCorridorGuard} from '../corridor-guard.js?v=219.0';
import {buildingBaseProfile} from '../building-bases.js?v=223.0';
import * as THREE from '../vendor/three.module.js';
import {makeOpeningWall} from '../wall-openings.js?v=222.0';
import {classroomStairPlan} from '../stair-design.js?v=228.0';
import {createSchoolWindow} from '../openings/school-window.js?v=222.0';
import {createClassroomInteriors} from '../classroom-template.js?v=223.0';
export function buildA1(ctx){
 const {b,g,kit,box,fb,w,l,h,side,wall,trim,green,floor,feature,doorAt,apertures,stairCore,flatRoof,plaque}=ctx,p=classroomStairPlan(b),corridor=Math.min(2.25,b.width*.22),face=w-corridor,frontHoles=[],rearHoles=[],rooms=[],doorWidth=1.16,teacherDeskX=-side*(w-.22-.15-.60),interiorSpecs=[];
 const wings=[[-l,p.center-p.span/2],[p.center+p.span/2,l]];
 for(const [lo,hi]of wings)for(let j=0;j<2;j++){const zmin=lo+(hi-lo)*j/2,zmax=lo+(hi-lo)*(j+1)/2;rooms.push({zmin,zmax,centres:[.25,.61,.80].map(t=>zmin+t*(zmax-zmin))});}
 for(const u of [...new Set(rooms.flatMap(r=>[r.zmin,r.zmax]))])box(b.width-corridor,b.height,.18,-side*corridor/2,h/2,u,wall);
 for(const y of [...p.levels,h])for(const [lo,hi]of wings){const thickness=y===0?.16:.08;box(b.width,thickness,hi-lo,0,y-thickness/2-(y===0?.03:0),(lo+hi)/2,trim);}
 // P16: transverse ceiling beams connect the classroom wall to each outer column.
 for(const ceiling of [...p.levels.slice(1),h])for(const u of [...new Set(rooms.flatMap(r=>[r.zmin,(r.zmin+r.zmax)/2,r.zmax]))])box(corridor,.22,.25,side*(w-corridor/2),ceiling-.19,u,trim);
 // Fascia descends in front of the beam ends at each corridor ceiling.
 for(const ceiling of [...p.levels.slice(1),h])for(const [lo,hi] of wings)box(.18,.36,hi-lo,side*(w+.04),ceiling-.18,(lo+hi)/2,wall);
 // Carry the roof fascia down to the top of the central breeze-block screen.
 box(.18,.75,p.span,side*(w+.04),h-.375,p.center,wall);
 feature('A1-central-screen-roof-fascia');
 feature('A1-balcony-roof-fascia');
 for(const y of p.levels.slice(1))for(const [lo,hi]of wings){const tileDepth=corridor-.29;box(tileDepth,.012,hi-lo,side*(w-(corridor+.29)/2),y+.006,(lo+hi)/2,floor);}
 for(const y of p.levels){for(const r of rooms){
  const doorU=r.centres[2];for(let j=0;j<3;j++){const u=r.centres[j];if(j===2){doorAt(u,y+1.36,-corridor+.01,doorWidth,2.72,green);box(.28,.012,doorWidth,side*(face-.14),y+.014,u,floor);}else{const o={kind:'window',u,y:y+1.83,width:(j===0?2.32:1.16)*.8,height:1.65};frontHoles.push(o);g.add(createSchoolWindow({side,wallX:face,u,y:o.y,width:o.width,height:o.height,open:true,hingeAtFrame:true,referenceLouver:true,color:green,leafCount:j===0?4:2}));}
   // P14/P64: the rear opening opposite the doorway is narrower than the other two.
   const rearU=u,rr={kind:'window',u:rearU,y:y+1.83,width:(j===0?2.32:j===1?1.16:doorWidth)*.8,height:1.65};rearHoles.push(rr);const rearWindow=createSchoolWindow({side:-side,wallX:w,u:rearU,y:rr.y,width:rr.width,height:rr.height,open:true,hingeAtFrame:true,referenceLouver:true,color:green,leafCount:j===0?4:2});rearWindow.name='A1-rear-classroom-window';Object.assign(rearWindow.userData,{opening:{...rr},oppositeDoor:j===2});g.add(rearWindow);
   // Narrow ventilation slot above every front opening.
   addVentSlots(frontHoles,{u,y:y+3.14,width:j===0?1.0:1.10,groups:j===0?2:1,groupSpacing:1.30});
   addVentSlots(rearHoles,{u:rearU,y:y+3.14,width:j===0?1.0:1.10,groups:j===0?2:1,groupSpacing:1.30});
  }
  interiorSpecs.push({buildingId:b.id,roomIndex:rooms.indexOf(r),floor:p.levels.indexOf(y)+1,clearHeight:b.height/b.floors-.22,xmin:Math.min(side*face,-side*w)+.28,xmax:Math.max(side*face,-side*w)-.25,zmin:r.zmin+.18,zmax:r.zmax-.18,doorU,level:y+.02,side,teacherDesk:{x:teacherDeskX,z:doorU,supportHeight:0}});
 }}
 // P14: continuous rain ledges on both wings, between windows and vents.
 for(const y of p.levels)for(const [lo,hi]of wings)kit.withCollision('none',()=>box(.46,.10,hi-lo,-side*(w+.20),y+2.80,(lo+hi)/2,'#a5a294'));
 g.userData.rearVentRainLedges={source:'P14',levels:p.levels.length,segments:2,ledgeHeight:2.80,ventHeight:3.14,estimatedProjection:.46};
 feature('A1-rear-vents-and-rain-ledges');
 g.add(createClassroomInteriors(interiorSpecs));g.userData.standardClassroomTemplate='school-classroom-v63';
 frontHoles.push(...apertures);apertures.push(...frontHoles.filter(o=>o.kind==='window'));
 for(const [lo,hi]of wings){makeOpeningWall(g,{side,wallX:w,faceV:-corridor,from:lo,to:hi,height:h,color:wall,openings:frontHoles});const rear=makeOpeningWall(g,{side:-side,wallX:w,faceV:0,from:lo,to:hi,height:h,color:wall,openings:rearHoles});rear.name='rear-classroom-opening-wall';}
 for(const u of [...new Set(rooms.flatMap(r=>[r.zmin,(r.zmin+r.zmax)/2,r.zmax]))])fb(u,h/2,-.15,.25,h,.28,wall);
 // P12: the ground-floor balustrade also has two narrow side entrances.
 for(const [index,[lo,hi]]of wings.entries()){const {u:entry,width:sideAccess}=a1GroundEntries(b)[index],ranges=[[lo,entry-sideAccess/2],[entry+sideAccess/2,hi]];for(const [a,z]of ranges)if(z-a>.22)drawCorridorGuard(kit,{id:b.id,x:side*(w-.13),z:(a+z)/2,y:0,width:z-a-.12,wall,trim});}
 for(const end of [-1,1])drawCorridorGuard(kit,{id:b.id,x:side*(w-corridor/2),z:end*(l-.10),y:0,width:corridor,angle:Math.PI/2,wall,trim});
 feature('A1-ground-balustrade-two-side-entrances');feature('A1-ground-corridor-end-guards');
 // P12 solid balustrade with a thin horizontal ventilation slot, capped above waist height.
 for(const y of p.levels.slice(1))for(const [lo,hi]of wings)drawCorridorGuard(kit,{id:b.id,x:side*(w-.13),z:(lo+hi)/2,y,width:hi-lo-.22,wall,trim});
 for(let f=0;f<p.levels.length;f++)for(const r of rooms)for(const u of [r.zmin+(r.zmax-r.zmin)*.25,r.zmin+(r.zmax-r.zmin)*.75])kit.cylinder(.11,.055,side*(w-corridor/2),(p.levels[f+1]??h)-.16,u,'#d5d0b9');
 flatRoof();stairCore(p.span,true,p.center);g.add(createA1MedalSign({side,w,h,center:p.center,span:p.span}));feature('A1-medal-school-sign-R99-R106');plaque('A1',p.center+p.span/2+.65,2.8,-corridor+.13,.6,.32,'#31564e');
 // The assembly stage attaches to the plinth at the midpoint of the whole facade.
 // A small overlap prevents a seam; the existing stair entrance remains walkable across it.
 const baseY=buildingBaseProfile(b).height,stageBack=w-.04,stageWidth=7.2,stageDepth=3.9,stageX=side*(stageBack+stageDepth/2),stageZ=p.center;
 box(stageDepth,.44,stageWidth,stageX,.22-baseY,stageZ,'#9a9689');box(stageDepth+.04,.03,stageWidth+.04,stageX,.455-baseY,stageZ,'#bab3a0');
 g.add(createA1EventStage({side,back:stageBack,center:stageZ,width:stageWidth,depth:stageDepth,baseY}));
 const poleX=side*(stageBack+stageDepth+1.05);box(1.1,.16,1.1,poleX,.08-baseY,stageZ,'#a2a299');kit.cylinder(.045,8.5,poleX,4.4-baseY,stageZ,'#c4c8c2');
 const flag=new THREE.Group();flag.name='vietnam-national-flag';flag.position.set(poleX,7.8-baseY,stageZ);flag.rotation.y=side*Math.PI/2;g.add(flag);const red=new THREE.Mesh(new THREE.PlaneGeometry(1.5,1),new THREE.MeshStandardMaterial({color:'#d9232b',side:THREE.DoubleSide,roughness:.85}));red.position.x=.75;red.userData.walkRole='none';flag.add(red);const shape=new THREE.Shape();for(let j=0;j<10;j++){const a=Math.PI/2+j*Math.PI/5,r=j%2?.12:.30,x=.75+Math.cos(a)*r,y=Math.sin(a)*r;if(j)shape.lineTo(x,y);else shape.moveTo(x,y);}shape.closePath();for(const s of [-1,1]){const star=new THREE.Mesh(new THREE.ShapeGeometry(shape),new THREE.MeshBasicMaterial({color:'#ffdf32',side:THREE.DoubleSide}));star.position.z=s*.006;star.userData.walkRole='none';flag.add(star);}
 g.userData.classrooms={roomsPerFloor:4,roomsPerWing:2,front:['four-leaf-window','two-leaf-window','door'],rear:['window','window','window'],rearWindowWidths:[2.32,1.16,doorWidth],teacherDeskAtRearWindow:true,rooms,layers:['outer-timber','inner-iron'],railHeight:.775,stage:{x:stageX,z:stageZ,width:stageWidth,depth:stageDepth,height:.47,reference:'R83',backdrop:true},flagpole:{x:poleX,z:stageZ,height:8.5}};
 g.userData.ventPattern={fourLeaf:{groups:2,linesPerGroup:2},twoLeaf:{groups:1,linesPerGroup:2},door:{groups:1,linesPerGroup:2},rearAligned:true};feature('A1-four-real-classrooms-per-floor');feature('A1-right-start-full-span-stair');feature('A1-assembly-stage-and-national-flag');feature('A1-layered-school-windows');
}
