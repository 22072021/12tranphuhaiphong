import {createBicycle} from '../furniture/bicycle.js';
import {makeOpeningWall} from '../wall-openings.js?v=222.0';
import {createStairDoor} from '../interactive-door.js';
import * as THREE from '../vendor/three.module.js';

// P58/P59: masonry + high ventilating apertures, separate metal screen and roofs.
// Owner plan: male west/left, female east/right, divided along the long axis. Counts provisional.
export function buildToilet(ctx){
 const {b,g,kit,box,w,l,side,wall,feature,fb,doorAt,apertures}=ctx;
 const radius=.80;
 const height=2.40,steel='#60594f',blue='#477eaa',depth=.22;
 const entry=-l+.68;
 const frontHoles=[{kind:'door',u:entry,y:1.04,width:1.20,height:2.08}];
 for(let z=-l+.55;z<l-.3;z+=1.15){if(Math.abs(z-entry)<.85)continue;frontHoles.push({kind:'vent',u:z,y:2.13,width:.62,height:.27});}
 makeOpeningWall(g,{side,wallX:w,faceV:0,from:-l,to:l-radius,height,color:wall,openings:frontHoles,profile:{height,storey:height}});g.userData.R33Windows={count:0,privacy:true};
 // R33 shows the masonry turning around a rounded corner beside the A2 passage.
 const corner=new THREE.Shape(),cx=-w+radius,cz=l-radius;
 for(let i=0;i<=20;i++){const a=Math.PI-i*Math.PI/40,x=cx+radius*Math.cos(a),z=cz+radius*Math.sin(a);i?corner.lineTo(x,z):corner.moveTo(x,z);}
 for(let i=20;i>=0;i--){const a=Math.PI-i*Math.PI/40;corner.lineTo(cx+(radius-depth)*Math.cos(a),cz+(radius-depth)*Math.sin(a));}corner.closePath();
 const rounded=new THREE.ExtrudeGeometry(corner,{depth:height,bevelEnabled:false}),rp=rounded.attributes.position;for(let i=0;i<rp.count;i++){const x=rp.getX(i),z=rp.getY(i),y=rp.getZ(i);rp.setXYZ(i,x,y,z);}rounded.computeVertexNormals();const roundWall=new THREE.Mesh(rounded,new THREE.MeshStandardMaterial({color:wall,roughness:1}));roundWall.name='R33-rounded-WC-corner';g.add(roundWall);
 // Opposite boundary wall; end walls are split around real rectangular vents.
 box(depth,height,b.length,-side*(w-depth/2),height/2,0,wall);
 const endVents=[];
 for(const end of [-1,1]){
  if(end===1){const face=new THREE.Group();face.name='R33-A2-passage-wall';face.rotation.y=-Math.PI/2;g.add(face);const openings=[];for(let u=-w+.65;u<w-.3;u+=.92)openings.push({kind:'vent',u,y:2.13,width:.58,height:.27});makeOpeningWall(face,{side:1,wallX:l,faceV:0,from:-w,to:w-radius,height,color:wall,openings,profile:{height,storey:height}});for(const o of openings.filter(o=>o.kind==='window')){const sill=new THREE.Mesh(new THREE.BoxGeometry(.30,.055,.72),new THREE.MeshStandardMaterial({color:'#c9c8b6',roughness:1}));sill.position.set(l-.10,o.y-o.height/2,o.u);face.add(sill);}continue;}
  const z=end*(l-depth/2),holes=[];for(let x=-w+.65;x<w-.3;x+=.92)holes.push({left:x-.29,right:x+.29});
  box(b.width,1.96,depth,0,.98,z,wall);box(b.width,.17,depth,0,2.315,z,wall);
  let x=-w;for(const hole of [...holes,{left:w,right:w}]){if(hole.left>x)box(hole.left-x,.27,depth,(x+hole.left)/2,2.095,z,wall);x=hole.right;}
  kit.withCollision('none',()=>{for(const hole of holes){const center=(hole.left+hole.right)/2;for(const yy of [2.055,2.135])box(hole.right-hole.left,.025,.11,center,yy,z,'#e9e6d9');}});
  endVents.push({z,holes});
 }
 // Three roof patches leave a genuinely open inner slot; no full blue lid.
 function sheet(name,x,z,width,length,y,slope=0){
  const panel=new THREE.Group();panel.name=name;panel.position.set(x,y,z);panel.rotation.z=slope;g.add(panel);
  const base=new THREE.Mesh(new THREE.BoxGeometry(width,.045,length),new THREE.MeshStandardMaterial({color:blue,roughness:.84,metalness:.20}));base.name='corrugated-sheet';panel.add(base);
  for(let u=-length/2+.08;u<length/2;u+=.18){const rib=new THREE.Mesh(new THREE.BoxGeometry(width,.018,.018),base.material);rib.position.set(0,.028,u);rib.userData.walkRole='none';panel.add(rib);}
  return panel;
 }
 const frontX=-w+.775;
 sheet('wc-full-blue-privacy-roof',0,0,b.width+.32,b.length+.32,height+.055,0);
 // P45: the toilet-cell row has a masonry roof, not the blue aisle canopy.
 box(1.32,.13,b.length-2.0,-.72,2.22,0,'#949388');
 // Female section is deliberately solid, with no traversable interior.
 const femaleFromX=0;box(w-.10,2.36,b.length-.24,w/2,1.18,0,wall);box(.16,2.4,b.length,0,1.2,0,wall);
 const femaleEntryZ=l-.72;
 // The female entrance is a fixed painted door on solid backing, never an interactive opening.
 box(.045,2.08,1.00,w+.028,1.04,femaleEntryZ,'#4a6b5c');
 for(const dz of [-.52,.52])box(.075,2.14,.045,w+.04,1.07,femaleEntryZ+dz,'#315244');
 box(.075,.055,1.08,w+.04,2.14,femaleEntryZ,'#315244');
 box(.04,.13,.035,w+.075,1.05,femaleEntryZ+.34,'#b2b5a8');
 g.userData.femaleWC={solid:true,visitable:false,fromX:femaleFromX,division:'longitudinal',planSide:'right/east',entry:{x:w,z:femaleEntryZ,width:1,decorative:true,operable:false}};

 // Close all four eaves against masonry; roof is seated on the wall, not floating.
 for(const sign of [-1,1]){box(.10,.16,b.length+.32,sign*(w+.08),height+.015,0,blue);box(b.width+.32,.16,.10,0,height+.015,sign*(l+.08),blue);}
 g.userData.roofSeat={wallTop:height,roofBottom:height+.0325,eaveBottom:height-.065,sealed:true};
 // Exterior washing corner is built with the adjoining passage wall.
 // Confirmed male interior: continuous urinal opposite individual closed cubicles.
 const urinalStart=entry+1.0,urinalLength=b.length-2.4,ux=side*(w-.43),uz=urinalStart+urinalLength/2;
 kit.withCollision('barrier',()=>{box(.52,.10,urinalLength,ux,.16,uz,'#dadcd3');box(.055,.17,urinalLength,side*(w-.72),.22,uz,'#d3d7cc');box(.055,.95,urinalLength,side*(w-.25),.57,uz,'#e6e7de');});
 const urinalBarrier=new THREE.Mesh(new THREE.BoxGeometry(.58,1.15,urinalLength),new THREE.MeshBasicMaterial());urinalBarrier.name='urinal-no-climb-barrier';urinalBarrier.position.set(ux,.575,uz);urinalBarrier.visible=false;urinalBarrier.userData.walkRole='barrier';g.add(urinalBarrier);
 const cubicles=[];const cellPitch=1.42,cellCount=Math.floor((b.length-2.0)/cellPitch);for(let i=0;i<cellCount;i++){const z=-l+1.35+i*cellPitch,x=-.72,doorX=-1.36;
 box(1.28,2.0,.08,x,1.0,z-.71,'#e0dfca');
 const cell=new THREE.Group();cell.name='wc-cubicle-'+(i+1);g.add(cell);makeOpeningWall(cell,{side:1,wallX:doorX,faceV:0,from:z-.71,to:z+.71,height:2.0,color:'#e1dfca',openings:[{kind:'door',u:z,y:.96,width:.74,height:1.88}]});
 const door=createStairDoor({side:1,wallX:doorX,u:z,y:.96,v:0,width:.72,height:1.86,color:'#59746a',single:true,swingDirection:-1});door.name='wc-cubicle-door-'+(i+1);cell.add(door);
 box(.58,.16,.78,-.65,.14,z,'#ededdf');const pan=new THREE.Mesh(new THREE.TorusGeometry(.19,.045,8,20),new THREE.MeshStandardMaterial({color:'#f0eee2',roughness:.5}));pan.rotation.x=Math.PI/2;pan.position.set(-.65,.24,z);pan.name='wc-toilet-pan';g.add(pan);cubicles.push({z,doorX});}
 box(1.28,2,.08,-.72,1,-l+1.35+(cellCount-1)*cellPitch+.71,'#e0dfca');
 g.userData.maleWC={division:'longitudinal',planSide:'left/west',xMin:-w,xMax:0,entry:{x:side*w,z:entry,width:1.2},urinalLength,cubicles,layoutConfirmed:true,countEstimated:true,washbasin:'L-shaped wall-mounted tiled trough',blueRoofRole:'walkway and urinal',toiletRowRoof:'masonry, no blue sheets'};
 // One parked mini bicycle against the far interior wall, clear of the entrance/cubicles.
 const bike=createBicycle({mini:true,color:'#d989b2',parked:true,lowDetail:true});bike.name='wc-male-pink-mini-bicycle';bike.userData.rideBikeId='wc:pink';bike.position.x=-1.55;bike.position.z=l-.43;bike.traverse(o=>{if(o.isMesh)o.userData.walkRole='none';});g.add(bike);
 const bikeBarrier=new THREE.Mesh(new THREE.BoxGeometry(1.90,1.15,.62),new THREE.MeshBasicMaterial());bikeBarrier.name='wc-male-pink-bicycle-barrier';bikeBarrier.userData.rideBikeId='wc:pink';bikeBarrier.position.set(-1.55,.575,l-.43);bikeBarrier.visible=false;bikeBarrier.userData.walkRole='barrier';g.add(bikeBarrier);g.userData.maleWC.bicycle={mini:true,color:'#d989b2',x:-1.55,z:l-.43,parked:true};feature('male-wc-pink-mini-bicycle');
 function paintedNam(position,rotation,words='NAM'){const m=new THREE.Mesh(new THREE.PlaneGeometry(.70,.24),new THREE.MeshBasicMaterial({color:'#a15f5d',transparent:true,depthWrite:false,side:THREE.DoubleSide}));m.name='wc-painted-NAM';m.position.copy(position);m.rotation.y=rotation;m.userData={walkRole:'none',signText:words,textColor:'#9e5654',transparentSign:true};g.add(m);}
 paintedNam(new THREE.Vector3(side*(w+.012),1.72,entry+1.15),side*Math.PI/2);
 paintedNam(new THREE.Vector3(side*(w-.70),1.72,-l-.012),Math.PI);
 paintedNam(new THREE.Vector3(w+.025,2.25,femaleEntryZ),Math.PI/2,'NỮ');
 g.userData.wcPhotoStudy={sources:['P58','P59','P45','R33'],endVents,roofPatches:1,fullBlueRoof:true,openSlot:null,fixtureCountEstimated:true,entranceConfirmedByOwner:true};
 feature('compound-blue-roof');feature('raised-blue-metal-screen');feature('real-high-ventilation');feature('corner-tiled-washing-wall');feature('painted-NAM-two-faces');feature('open-roof-slot');
}
