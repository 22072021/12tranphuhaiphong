// Shared factory retained under the existing import name for every building module.
export {createStairDoor} from './openings/door-template.js?v=245.0';
