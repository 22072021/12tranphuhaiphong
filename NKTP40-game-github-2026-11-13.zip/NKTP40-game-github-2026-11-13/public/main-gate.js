import * as THREE from './vendor/three.module.js';
import {isMainGateLocked} from './main-gate-schedule.js';
import {geometryKit} from './geometry-kit.js';
import {smoothArc} from './curved-surfaces.js';

// Owner front reference: four green pressed-steel leaves, solid lower fields,
// two curved crown rails rising more steeply towards the central ball.
export const MAIN_GATE_PROFILE=Object.freeze({edgeTop:2.98,centreTop:3.48,panelTop:1.98,bottom:.055,crownDrop:.19});
export function createMainGate({gateAngle=0,width=4.4}={}){
 const g=new THREE.Group();g.name='interactive-school-gate';g.position.y=1.925;
 g.userData.door={open:gateAngle>0,progress:0,width,height:3.85};
 Object.defineProperty(g.userData.door,'locked',{get:()=>isMainGateLocked(),enumerable:true});
 const green='#205244',inset='#194b3c',mould='#3c6b59',pairs=[],half=width/2,leafWidth=half/2,q=MAIN_GATE_PROFILE;
 const top=d=>q.edgeTop+(q.centreTop-q.edgeTop)*Math.pow(d/half,1.65);
 for(const side of [-1,1]){
  const outer=new THREE.Group(),inner=new THREE.Group();outer.name='gate-outer-folding-leaf';inner.name='gate-inner-folding-leaf';
  outer.position.set(.045,-1.925,side*half);inner.position.set(0,0,-side*leafWidth);
  outer.add(inner);g.add(outer);pairs.push({outer,inner,side});
  for(const [index,leaf]of [outer,inner].entries()){
   const k=geometryKit(leaf),span=leafWidth-.006,start=index*leafWidth,mid=-side*span/2;
   k.box(.052,q.panelTop-q.bottom,span,0,(q.panelTop+q.bottom)/2,mid,green);
   // Substantial perimeter stiles and rails, with the shallow rectangular field
   // above the taller scalloped pressed panel, as visible in the supplied image.
   for(const y of [.095,.255,1.645,1.935])k.box(.078,.065,span,0,y,mid,green);
   for(const d of [.025,span-.025]){const h=top(start+d);k.box(.078,h-q.bottom,.062,0,(h+q.bottom)/2,-side*d,green);}
   for(const face of [-1,1]){
    const x=face*.034,hw=span*.382,lo=.35,hi=1.56,r=.065;
    const shape=new THREE.Shape();shape.moveTo(-hw+r,lo);shape.lineTo(hw-r,lo);shape.quadraticCurveTo(hw-r,lo+r,hw,lo+r);shape.lineTo(hw,hi-r);shape.quadraticCurveTo(hw-r,hi-r,hw-r,hi);shape.lineTo(-hw+r,hi);shape.quadraticCurveTo(-hw+r,hi-r,-hw,hi-r);shape.lineTo(-hw,lo+r);shape.quadraticCurveTo(-hw+r,lo+r,-hw+r,lo);
    const field=k.solid(new THREE.ShapeGeometry(shape),inset,'scalloped-solid-pressed-panel');field.rotation.y=face*Math.PI/2;field.position.set(x,0,mid);field.userData.walkRole='none';
    const outline=shape.getPoints(12).map(p=>new THREE.Vector3(x+face*.008,p.y,mid+p.x));
    k.withCollision('none',()=>smoothArc(k,outline,.009,mould,'scalloped-raised-pressed-moulding'));
    // Second fine inset line follows the same scalloped silhouette.
    const innerOutline=shape.getPoints(12).map(p=>new THREE.Vector3(x+face*.01,.955+(p.y-.955)*.955,mid+p.x*.94));
    k.withCollision('none',()=>smoothArc(k,innerOutline,.0045,'#123c2e','inner-pressed-moulding'));
    for(const y of [1.70,1.875])k.withCollision('none',()=>k.box(.014,.013,span*.79,x,y,mid,mould));
    for(const d of [-span*.395,span*.395])k.withCollision('none',()=>k.box(.014,.175,.014,x,1.7875,mid+d,mould));
    for(const size of [.155,.113,.065]){
     const pts=[[0,.94+size],[size,.94],[0,.94-size],[-size,.94],[0,.94+size]];
     for(let j=1;j<pts.length;j++)k.withCollision('none',()=>k.beam(new THREE.Vector3(x+face*.014,pts[j-1][1],mid+pts[j-1][0]),new THREE.Vector3(x+face*.014,pts[j][1],mid+pts[j][0]),.011,mould));
    }
   }
   for(let j=1;j<10;j++){const d=span*j/10,h=top(start+d)-.045;k.box(.022,h-q.panelTop,.022,0,(h+q.panelTop)/2,-side*d,green);const spear=k.solid(new THREE.ConeGeometry(.023,.17,4),green,'slender-anti-climb-spear');spear.position.set(0,h+.13,-side*d);spear.userData.walkRole='none';}
   for(const drop of [0,q.crownDrop]){
    // Sweep a rectangular steel section: no round pipe substituted for flat bar.
    const vertices=[],indices=[],n=48,depth=drop?.052:.08,barHeight=drop?.035:.065;
    for(let i=0;i<=n;i++){const d=span*i/n,y=top(start+d)-drop,z=-side*d;for(const [x,dy]of [[-depth/2,-barHeight/2],[depth/2,-barHeight/2],[depth/2,barHeight/2],[-depth/2,barHeight/2]])vertices.push(x,y+dy,z);}
    for(let i=0;i<n;i++)for(let e=0;e<4;e++){const a=i*4+e,b=i*4+(e+1)%4,c=b+4,d=a+4;indices.push(a,b,c,a,c,d);}indices.push(0,2,1,0,3,2);const end=n*4;indices.push(end,end+1,end+2,end,end+2,end+3);
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.setIndex(indices);geo.computeVertexNormals();k.solid(geo,green,'reference-curved-flat-steel-crown');
   }
   if(index===1){
    // Each centre leaf carries one physical half of the spear, never a ball.
    const tip=new THREE.Shape(),points=[[0,3.79],[side*.115,3.48],[0,3.48]];
    points.forEach(([z,y],i)=>i?tip.lineTo(-z,y):tip.moveTo(-z,y));tip.closePath();
    const arrow=k.solid(new THREE.ExtrudeGeometry(tip,{depth:.06,bevelEnabled:false}),green,'split-central-arrow-half');arrow.rotation.y=Math.PI/2;arrow.position.set(-.03,0,-side*(span+.006));arrow.userData.walkRole='none';
   }
   for(const y of [.31,1.78,2.72]){k.cylinder(.026,.15,0,y,0,'#244638');k.box(.065,.09,.13,0,y,-side*.06,green);}
   if(index===1){
    for(const face of [-1,1]){
     const z=-side*(span-.075),x=face*.075;
     const curve=new THREE.CatmullRomCurve3([new THREE.Vector3(x,1.36,z),new THREE.Vector3(x+face*.035,1.39,z),new THREE.Vector3(x+face*.035,1.53,z),new THREE.Vector3(x,1.56,z)]);
     const handle=k.solid(new THREE.TubeGeometry(curve,12,.013,6,false),'#233b2e','central-gate-pull-handle');handle.userData.walkRole='none';
     k.box(.018,.1,.036,x,1.25,z,'#162c23');
    }
   }
   k.finish();
   leaf.traverse(o=>{if(o.isMesh){o.material.metalness=.32;o.material.roughness=.58;}});
  }
 }
 let progress=THREE.MathUtils.clamp(gateAngle/88,0,1),target=progress;
 const pose=()=>{const t=progress*progress*(3-2*progress);for(const{outer,inner,side}of pairs){outer.rotation.y=-side*88*Math.PI/180*t;inner.rotation.y=side*176*Math.PI/180*t;inner.position.x=.07*t;}g.userData.door.progress=progress;g.updateMatrixWorld(true);};
 g.userData.requestOpen=open=>{open=!!open&&!isMainGateLocked();target=open?1:0;g.userData.door.open=open;};
 g.userData.setProgress=value=>{progress=isMainGateLocked()?0:THREE.MathUtils.clamp(value,0,1);pose();};
 g.userData.setOpen=open=>{open=!!open&&!isMainGateLocked();target=progress=open?1:0;g.userData.door.open=open;pose();};
 g.userData.animateDoor=dt=>{const old=progress;if(isMainGateLocked()){progress=target=0;g.userData.door.open=false;}else progress+=Math.sign(target-progress)*Math.min(Math.abs(target-progress),dt/1.25);if(old===progress)return false;pose();return true;};
 g.userData.gateStructure={source:'owner-gate-white-reference-20261105',leaves:4,foldingPairs:2,opens:'courtyard',lowerPanels:'solid-green-pressed-steel',crown:'rising-to-centre',openAngle:88};
 if(isMainGateLocked()){progress=target=0;g.userData.door.open=false;}pose();return g;
}
