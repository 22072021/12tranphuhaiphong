// Required client for the public food and per-account wallet release.
export const CLIENT_RELEASE='20261110-food-public-1';
