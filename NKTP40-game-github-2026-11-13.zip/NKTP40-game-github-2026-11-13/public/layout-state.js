import {ENTRANCE} from './entrance-layout.js?v=34.0';
export const STORAGE_KEY='nktp40-layout-draft-v1';
const LIMITS={x:[-150,150],z:[-150,150],width:[1,100],length:[1,150],height:[1,60],rotation:[-360,360]};
export function validateLayout(input){
 if(!input||input.schema!=='nktp40-layout/v1'||input.units!=='m'||!Array.isArray(input.buildings)||input.buildings.length<1||input.buildings.length>50)throw new Error('Tệp cần có từ 1 đến 50 khối nhà, đúng định dạng NKTP40 và đơn vị mét.');
 const ids=new Set();
 const buildings=input.buildings.map(b=>{
  if(!b||typeof b.id!=='string'||!/^[a-zA-Z0-9_-]{1,80}$/.test(b.id)||ids.has(b.id))throw new Error('Mã khối nhà bị trùng hoặc không hợp lệ.');ids.add(b.id);
  const out={id:b.id,name:String(b.name||b.id).trim().slice(0,80),roof:typeof b.roof==='string'&&/^#[0-9a-fA-F]{6}$/.test(b.roof)?b.roof:'#777968',note:String(b.note||'Khối do người dùng hiệu chỉnh').slice(0,600)};
  out.kind=['classroom','hall','heritage','admin','toilet','parking','lab'].includes(b.kind)?b.kind:(b.id==='H'?'hall':'classroom');
  if(b.baseElevation!==undefined){if(!Number.isFinite(b.baseElevation)||b.baseElevation<0||b.baseElevation>20)throw Error('Cao độ nền không hợp lệ.');out.baseElevation=b.baseElevation;}
  if(b.plinthHeight!==undefined){if(!Number.isFinite(b.plinthHeight)||b.plinthHeight<.03||b.plinthHeight>2)throw Error('Chiều cao chân nền không hợp lệ.');out.plinthHeight=b.plinthHeight;}
  if(b.hallLevel!==undefined){if(!Number.isFinite(b.hallLevel)||b.hallLevel<=0||b.hallLevel>=b.height)throw Error('Cao độ tầng nhà đa năng không hợp lệ.');out.hallLevel=b.hallLevel;}
  out.floors=Number.isInteger(b.floors)&&b.floors>=1&&b.floors<=15?b.floors:Math.max(1,Math.round(b.height/3.5));
  out.region=typeof b.region==='string'?b.region.slice(0,20):'';
  out.frontSide=b.frontSide===1?1:b.frontSide===-1?-1:out.kind==='admin'?1:-1;
  for(const [key,[min,max]] of Object.entries(LIMITS)){if(typeof b[key]!=='number'||!Number.isFinite(b[key])||b[key]<min||b[key]>max)throw new Error('Thông số '+key+' của '+out.name+' không hợp lệ ('+min+' đến '+max+').');out[key]=b[key];}
  return out;
 });
 return {schema:'nktp40-layout/v1',revision:String(input.revision||'user-draft').slice(0,60),units:'m',buildings};
}
export function cloneLayout(layout){return structuredClone(layout);}
export function readDraft(storage=localStorage){try{const raw=storage.getItem(STORAGE_KEY);if(!raw)return null;const draft=validateLayout(JSON.parse(raw)),admin=draft.buildings.find(b=>b.id==='ADMIN');if(admin && (admin.width===8.6 || (admin.width===16&&!draft.revision.includes('v49')))){admin.width=11.6;admin.note+=' V56: áp dụng chiều sâu mặc định mới11,6m; giữ các thông số khác của bản nháp.';}for(const [target,source,legacy]of [['B1','A1',9.8],['B2','A2',10.3]]){const b=draft.buildings.find(b=>b.id===target),a=draft.buildings.find(b=>b.id===source);if(b&&a&&b.width===legacy&&a.width===(source==='A1'?9.9:8.7))b.width=a.width;}return draft;}catch{return null;}}
export function writeDraft(layout,storage=localStorage){storage.setItem(STORAGE_KEY,JSON.stringify(validateLayout(layout)));}
export function footprint(building){const a=building.rotation*Math.PI/180,c=Math.cos(a),s=Math.sin(a);return [[-1,-1],[1,-1],[1,1],[-1,1]].map(([x,z])=>({x:building.x+c*x*building.width/2-s*z*building.length/2,z:building.z+s*x*building.width/2+c*z*building.length/2}));}
export function containsPoint(x,z,building,padding=0){const a=-building.rotation*Math.PI/180,dx=x-building.x,dz=z-building.z;const lx=Math.cos(a)*dx-Math.sin(a)*dz,lz=Math.sin(a)*dx+Math.cos(a)*dz;return Math.abs(lx)<building.width/2+padding&&Math.abs(lz)<building.length/2+padding;}
export function parkingPosts(b){const count=Math.max(2,Math.ceil(b.length/6)+1),posts=[];for(const side of [-1,1])for(let i=0;i<count;i++)posts.push({x:side*(b.width/2-.3),z:-b.length/2+.3+i*(b.length-.6)/(count-1)});return posts;}
export function blocksPoint(x,z,b,padding=.45){if(b.kind!=='parking')return containsPoint(x,z,b,padding);const a=-b.rotation*Math.PI/180,dx=x-b.x,dz=z-b.z,lx=Math.cos(a)*dx-Math.sin(a)*dz,lz=Math.sin(a)*dx+Math.cos(a)*dz;return parkingPosts(b).some(p=>Math.abs(lx-p.x)<.12+padding&&Math.abs(lz-p.z)<.12+padding);}
export function walkSpawn(layout){const candidates=[{x:ENTRANCE.x-6,z:ENTRANCE.z,yaw:-Math.PI/2},{x:0,z:22},{x:-35,z:22},{x:0,z:65}];for(let z=-140;z<=140;z+=20)for(let x=-140;x<=140;x+=20)candidates.push({x,z});return candidates.find(p=>!layout.buildings.some(b=>blocksPoint(p.x,p.z,b,.6)))||null;}
