export const FOOD_CATALOG=Object.freeze([
 {id:'bread',name:'Bánh mì',price:10000,station:'p38-accordion-house',seated:false},
 {id:'fish',name:'Bún cá',price:15000,station:'fish-noodle-stall',seated:true},
 {id:'pan',name:'Bánh mì chảo',price:15000,station:'pan-bread-stall',seated:true},
 {id:'crab',name:'Bánh đa',price:15000,station:'crab-noodle-stall',seated:true},
 {id:'rice',name:'Hộp xôi',price:10000,station:'sticky-rice-stall',seated:false},
 {id:'paper',name:'Bánh tráng trộn',price:10000,station:'bac-sanh-rice-paper-stall',seated:false},
 {id:'tea',name:'Nước chè',price:2000,station:'bac-to-tea-stall',seated:true}
]);
// A Vietnamese day begins at06:00: UTC+7 minus six hours = UTC+1.
export const foodCreditDay=now=>new Date(now+3600000).toISOString().slice(0,10);
