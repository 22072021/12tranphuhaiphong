// Two real horizontal openings per vent group; the wall between them remains masonry.
// Coordinates use the same facade-local u/y convention as makeOpeningWall.
export function addVentSlots(openings,{u,y,width,groups=width>1.6?2:1,groupSpacing=width/2+.025,slotHeight=.065,slotOffset=.085}){
 for(let i=0;i<groups;i++){
  const center=u+(i-(groups-1)/2)*groupSpacing;
  for(const offset of [-slotOffset,slotOffset])openings.push({kind:'vent',u:center,y:y+offset,width:groups===2&&width>1.6?(width-.10)/2:width,height:slotHeight});
 }
}
