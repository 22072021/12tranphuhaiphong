// P41 and the supplied green door/window reference: framed, open louvres and recessed panels.
export function drawClassicTimberLeaf(k,{width,height,z=0,color,door=false}){
 const stile=Math.min(.065,width*.14),rail=.065,lo=-height/2,hi=height/2,inner=width-2*stile,shade='#315044';
 for(const sign of [-1,1])k.box(.045,height,stile,0,0,z+sign*(width-stile)/2,color);
 const band=(bottom,top)=>{for(const y of [bottom+rail/2,top-rail/2])k.box(.045,rail,inner,0,y,z,color);const a=bottom+rail,b=top-rail,count=Math.max(3,Math.round((b-a)/.055)),spacing=(b-a)/count;
  for(let j=0;j<count;j++)k.box(.055,spacing*.80,inner,0,a+(j+.5)*spacing,z,color,0,0,-.45);
 };
 if(door){const split=lo+height*.34,mid=split+(hi-split)*.48;band(split,mid);band(mid,hi);
  // P41 lower panels are recessed solid timber, including the narrow reveals.
  // One inset backing closes all decorative gaps on both faces.
  k.box(.018,split-lo,inner,0,(lo+split)/2,z,color);
  const panel=(cx,cy,w,h)=>{k.box(.022,h,w,0,cy,cx,color);for(const face of [-1,1]){for(const sign of [-1,1]){k.box(.008,.018,w,face*.018,cy+sign*(h-.018)/2,cx,shade);k.box(.008,h,.018,face*.018,cy,cx+sign*(w-.018)/2,color);}}};
  const y0=lo+rail,y1=split-rail,divide=y0+(y1-y0)*.68;k.box(.045,rail,inner,0,lo+rail/2,z,color);k.box(.045,rail,inner,0,split-rail/2,z,color);k.box(.045,rail,inner,0,divide,z,color);panel(z,(divide+y1)/2,inner,y1-divide-rail);for(const sign of [-1,1])panel(z+sign*inner*.25,(y0+divide)/2,inner*.46,divide-y0-rail);
 }else{band(lo,0);band(0,hi);}
}
