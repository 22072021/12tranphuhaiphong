import * as THREE from '../vendor/three.module.js';
import {geometryKit} from '../geometry-kit.js';
import {createGlassPane} from './glass.js';

// P49: four timber leaves, not a two-leaf door flanked by fixed sidelights.
// The paired folding motion is a reconstruction; the photograph shows one pose.
export function createHallEntry({side,wallX,width=4.80,height=2.84,color='#594238'}){
 const g=new THREE.Group();g.name='interactive-hall-four-leaf-door';
 g.position.set(side*(wallX+.035),height/2,0);
 g.userData.door={open:false,progress:0,swingSign:1,width,height};
 g.userData.templateId='hall-P49-four-timber-glass-leaves';
 const fixed=geometryKit(g),clearance=.005,leafWidth=(width-.03)/4,leafHeight=height-.012,pairs=[];
 for(const z of [-width/2,width/2])fixed.box(.12,height+.04,.07,-side*.055,0,z,color);
 fixed.box(.12,.07,width+.07,-side*.055,height/2,0,color);fixed.finish();
 for(const dir of [1,-1]){
  const outer=new THREE.Group(),inner=new THREE.Group();outer.name='hall-door-outer-leaf';inner.name='hall-door-inner-leaf';
  outer.position.z=-dir*(width/2-clearance);inner.position.set(-side*.065,0,dir*(leafWidth+.003));outer.add(inner);g.add(outer);pairs.push({outer,inner,dir});
  for(const leaf of [outer,inner]){
   const k=geometryKit(leaf),z=dir*leafWidth/2,lo=-leafHeight/2,hi=leafHeight/2,split=lo+leafHeight*.34,stile=.065,rail=.075;
   for(const zz of [dir*stile/2,dir*(leafWidth-stile/2)])k.box(.065,leafHeight,stile,0,0,zz,color);
   for(const yy of [lo+rail/2,split,hi-rail/2])k.box(.065,rail,leafWidth,0,yy,z,color);
   const glassBottom=split+rail/2,glassTop=hi-rail;
   k.box(.065,glassTop-glassBottom,.042,0,(glassBottom+glassTop)/2,z,color);
   for(const col of [-1,1])createGlassPane(leaf,{x:0,y:(glassBottom+glassTop)/2,z:z+col*(leafWidth-2*stile)/4,width:(leafWidth-2*stile-.042)/2,height:glassTop-glassBottom,name:'hall-door-tall-glass'});
   // Solid lower timber with recessed rectangular panels on both faces.
   const panelBottom=lo+rail,panelTop=split-rail/2;
   k.box(.040,panelTop-panelBottom,leafWidth-2*stile,0,(panelBottom+panelTop)/2,z,color);
   for(const face of [-1,1])for(const col of [-1,1]){
    const pw=(leafWidth-2*stile)*.40,ph=(panelTop-panelBottom)*.70,cz=z+col*(leafWidth-2*stile)*.25,cy=(panelBottom+panelTop)/2;
    for(const sign of [-1,1]){k.box(.008,.016,pw,face*.024,cy+sign*ph/2,cz,'#443127');k.box(.008,ph,.016,face*.024,cy,cz+sign*pw/2,'#443127');}
   }
   for(const yy of [lo+.22,hi-.22])k.cylinder(.015,.12,0,yy,0,'#887765');
   if(leaf===inner)for(const face of [-1,1])k.box(.035,.15,.028,face*.05,split+.10,dir*(leafWidth-.12),'#b4a68a');
   k.finish();
  }
 }
 let progress=0,target=0;
 const pose=()=>{const eased=progress*progress*(3-2*progress);for(const {outer,inner,dir}of pairs){const angle=side*dir*(Math.PI-.015)*eased;outer.rotation.y=angle;inner.rotation.y=-angle;}g.userData.door.progress=progress;g.updateMatrixWorld(true);};
 g.userData.openingDirection='outward-folding';g.userData.openAwayFrom=()=>{};
 g.userData.setOpen=open=>{progress=target=open?1:0;g.userData.door.open=!!open;pose();};
 g.userData.setProgress=value=>{progress=THREE.MathUtils.clamp(value,0,1);pose();};
 g.userData.requestOpen=open=>{target=open?1:0;g.userData.door.open=!!open;};
 g.userData.animateDoor=dt=>{const old=progress;progress+=Math.sign(target-progress)*Math.min(Math.abs(target-progress),dt/.75);if(old===progress)return false;pose();return true;};
 g.userData.reference={source:'P49',leaves:4,glassColumnsPerLeaf:2,solidLowerFraction:.34,pairedFoldEstimated:true};
 return g;
}
