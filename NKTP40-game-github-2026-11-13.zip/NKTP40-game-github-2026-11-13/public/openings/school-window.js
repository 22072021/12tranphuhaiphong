import {drawClassicTimberLeaf} from './classic-timber-leaf.js?v=245.0';
import {drawA2WindowIronwork} from './a2-window-ironwork.js?v=169.0';
import {OPENING_TEMPLATES} from './catalog.js?v=64.0';
import * as THREE from '../vendor/three.module.js';
import {geometryKit} from '../geometry-kit.js?v=222.0';
import {createGlassPane} from './glass.js?v=48.0';
// Classroom default: exterior timber shutters and interior iron bars, no glazing.
export function createSchoolWindow({side,wallX,u,y,width=1.8,height=1.65,open=true,glazed=false,color='#346454',leafCount=2,flushFrame=false,hingeAtFrame=false,referenceLouver=true}){
 const templateId=glazed?'school-wood-iron-glass-window':'school-wood-iron-window',profile=OPENING_TEMPLATES[templateId],g=new THREE.Group();g.name=glazed?'school-three-layer-window':'school-two-layer-window';g.position.set(side*wallX,y,u);g.scale.x=side;const k=geometryKit(g),green=color;
 const frameDepth=flushFrame?.16:.26,frameX=flushFrame?-.12:-.05;
 for(const z of [-width/2,width/2])k.box(frameDepth/4,height+.10,.065,frameX,0,z,green);for(const yy of [-height/2,height/2])k.box(frameDepth/4,.065,width+.10,frameX,yy,0,green);
 if(flushFrame)drawA2WindowIronwork(k,{width,height,x:profile.ironOffset});else {for(let z=-width/2+.16;z<width/2;z+=.22)k.box(.025,height-.06,.022,profile.ironOffset,0,z,'#4c5751');for(const yy of [-height*.22,height*.22])k.box(.025,.022,width-.07,profile.ironOffset,yy,0,'#4c5751');}
 if(glazed){createGlassPane(g,{x:profile.glassOffset,y:0,z:0,width:width-.08,height:height-.08,name:'school-inner-glass'});for(const z of [-width/4,0,width/4])k.box(.035,height,.035,-.17,0,z,green);k.box(.035,.035,width,-.17,0,0,green);}k.finish();
 const leaves=[],leafWidth=width/leafCount;
 function makeLeaf(parent,origin,dir,name){const leaf=new THREE.Group();leaf.name=name;leaf.position.set(0,0,origin);parent.add(leaf);const lk=geometryKit(leaf),zz=-dir*leafWidth/2;if(referenceLouver){drawClassicTimberLeaf(lk,{width:leafWidth-.025,height:height-.04,z:zz,color:green});lk.finish();return leaf;}lk.box(.045,height-.04,leafWidth-.025,0,0,zz,green);for(let r=0;r<13;r++)lk.withCollision('none',()=>lk.box(.02,.022,leafWidth-.10,.03,-height*.43+r*height*.068,zz,color==='#704137'?'#8b5042':'#527969'));lk.finish();return leaf;}
 for(const dir of [-1,1]){const pivot=new THREE.Group();pivot.name='school-outer-frame-hinge';pivot.position.set(.035,0,dir*width/2);g.add(pivot);makeLeaf(pivot,0,dir,'school-outer-timber-shutter');let inner=null;if(leafCount===4)inner=makeLeaf(pivot,-dir*leafWidth,dir,'school-folding-inner-shutter');leaves.push({pivot,inner,dir});}
 let progress=open?1:0,target=progress;const openingAngle=Math.PI;const pose=()=>{leaves.forEach(({pivot,inner,dir})=>{pivot.rotation.y=-dir*progress*openingAngle;if(inner)inner.rotation.y=dir*progress*Math.PI;});g.updateMatrixWorld(true);};
 g.userData={templateId,glazed,leafCount,referenceLouver,hinges:leafCount===4?'outer-frame-and-fold':'outer-frame',layers:glazed?['outer-timber','middle-iron','inner-glass']:['outer-timber','inner-iron'],operableWindow:true,movingAperture:true,glassProgress:progress};g.userData.setInitialOpen=open=>{progress=target=open?1:0;g.userData.glassProgress=progress;pose();};g.userData.toggleGlass=()=>target=target?0:1;g.userData.setGlassProgress=v=>{progress=v;g.userData.glassProgress=v;pose();};g.userData.updateGlass=dt=>{const old=progress;progress+=Math.sign(target-progress)*Math.min(Math.abs(target-progress),dt/.55);g.userData.glassProgress=progress;if(old===progress)return false;pose();return true;};pose();return g;
}
