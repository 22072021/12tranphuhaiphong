import {drawClassicTimberLeaf} from './classic-timber-leaf.js?v=245.0';
import {createGlassPane} from './glass.js?v=48.0';
import * as THREE from '../vendor/three.module.js';
import {geometryKit} from '../geometry-kit.js?v=222.0';
import {OPENING_TEMPLATES} from './catalog.js?v=50.0';
export function createStairDoor({side,wallX,u,y,v,width,height,color,grilled=false,glazed=false,single=false,swingDirection=1,heritagePanels=false,decorated=false,referenceLouver=false}){
 const templateId=grilled?'steel-grille-double-door':glazed?'wood-glass-double-door':'timber-louver-double-door',t=OPENING_TEMPLATES[templateId],g=new THREE.Group();g.name='interactive-stair-door';g.position.set(side*(wallX+v-.015),y,u);g.userData.door={open:false,progress:0,swingSign:swingDirection,width,height};g.userData.templateId=templateId;
 const leaves=[],leafHeight=height-2*t.clearance,leafWidth=single?width-2*t.clearance:(width-2*t.clearance-t.centreGap)/2;
 // Fixed rebated stop behind the cants covers the perimeter clearance without a gap.
 const stop=new THREE.Group();stop.name='door-rebated-stop';g.add(stop);const sk=geometryKit(stop);
 for(const z of [-width/2,width/2])sk.box(.02,height+.025,.028,-side*.075,0,z,color);for(const yy of [-height/2,height/2])sk.box(.02,.028,width+.028,-side*.075,yy,0,color);sk.finish();
 for(const direction of (single?[1]:[1,-1])){
  const leaf=new THREE.Group();leaf.name='door-leaf';leaf.position.z=-direction*(width/2-t.clearance);leaf.userData.hingeDirection=direction;g.add(leaf);leaves.push(leaf);const k=geometryKit(leaf),z=direction*leafWidth/2,lo=-leafHeight/2,hi=leafHeight/2;
  if(referenceLouver){drawClassicTimberLeaf(k,{width:leafWidth,height:leafHeight,z,color,door:true});}
  else if(grilled){for(const zz of [direction*t.stile/2,direction*(leafWidth-t.stile/2)])k.box(t.thickness,leafHeight,t.stile,0,0,zz,color);for(const yy of [lo+t.rail/2,0,hi-t.rail/2])k.box(t.thickness,t.rail,leafWidth,0,yy,z,color);for(let zz=.15;zz<leafWidth-.06;zz+=t.barSpacing)k.box(.035,leafHeight-.06,.025,0,0,direction*zz,color);}
  else if(decorated){
   const split=lo+leafHeight*.50,bottom=split+.04,top=hi-.06,iron='#393f3b';
   for(const zz of [direction*t.stile/2,direction*(leafWidth-t.stile/2)])k.box(t.thickness,leafHeight,t.stile,0,0,zz,color);
   for(const yy of [lo+t.rail/2,split,hi-t.rail/2])k.box(t.thickness,t.rail,leafWidth,0,yy,z,color);
   k.box(.035,split-lo-t.rail,leafWidth-2*t.stile,0,(lo+t.rail+split)/2,z,color);
   createGlassPane(leaf,{x:0,y:(bottom+top)/2,z,width:leafWidth-2*t.stile,height:top-bottom,name:'a2-decorative-door-glass'});
   const iw=leafWidth-2*t.stile,ih=top-bottom,ironColor='#c6ad69';
   const pt=(u,v)=>new THREE.Vector3(.025,bottom+v*ih,z+(u-.5)*iw);
   const line=points=>{for(let i=1;i<points.length;i++)k.beam(pt(...points[i-1]),pt(...points[i]),.012,ironColor);};
   k.withCollision('none',()=>{
    line([[0,0],[1,0],[1,1],[0,1],[0,0]]);
    for(let r=0;r<5;r++){const y=.07+r*.185;
     line([[0,y+.04],[.38,y+.04],[.5,y+.085],[.62,y+.04],[1,y+.04]]);line([[0,y+.13],[.38,y+.13],[.5,y+.085],[.62,y+.13],[1,y+.13]]);
     if(r<4){const yy=y+.17,hh=.035;const points=[];for(let n=0;n<=12;n++){const a=-Math.PI/2+n*Math.PI/12;points.push([.88+.10*Math.cos(a),yy+hh*Math.sin(a)]);}for(let n=0;n<=12;n++){const a=Math.PI/2+n*Math.PI/12;points.push([.12+.10*Math.cos(a),yy+hh*Math.sin(a)]);}points.push(points[0]);line(points);line([[.5,y+.13],[.5,yy-hh]]);}
    }
    const groove='#4d2923',panelW=(leafWidth-2*t.stile)*.42,panelH=(split-lo)*.65;
    for(const face of [-1,1])for(const dz of [-1,1]){const zz=z+dz*iw*.25,cy=lo+(split-lo)*.47;for(const sign of [-1,1]){k.box(.005,.009,panelW,face*.022,cy+sign*panelH/2,zz,groove);k.box(.005,panelH,.009,face*.022,cy,zz+sign*panelW/2,groove);}k.box(.006,.009,iw,face*.022,split-.075,z,groove);}
   });
  }
  else if(glazed){
   for(const zz of [direction*t.stile/2,direction*(leafWidth-t.stile/2)])k.box(t.thickness,leafHeight,t.stile,0,0,zz,color);
   const split=lo+leafHeight*(heritagePanels?.30:t.panelFraction),glassTop=hi-t.rail,glassBottom=split+t.rail/2,rows=heritagePanels?3:2;
   for(const yy of [lo+t.rail/2,split,hi-t.rail/2])k.box(t.thickness,t.rail,leafWidth,0,yy,z,color);
   k.box(.035,split-t.rail/2-(lo+t.rail),leafWidth-2*t.stile,0,(split-t.rail/2+lo+t.rail)/2,z,color);
   for(let row=0;row<rows;row++){const bottom=glassBottom+(glassTop-glassBottom)*row/rows+(row?t.rail/2:0),top=glassBottom+(glassTop-glassBottom)*(row+1)/rows-(row<rows-1?t.rail/2:0);createGlassPane(leaf,{x:0,y:(top+bottom)/2,z,width:leafWidth-2*t.stile,height:top-bottom,name:'door-glass-pane'});if(row)k.box(t.thickness,t.rail,leafWidth,0,glassBottom+(glassTop-glassBottom)*row/rows,z,color);}
   if(!heritagePanels)k.box(.065,glassTop-glassBottom,.03,0,(glassTop+glassBottom)/2,z,color);

  }else{
   k.box(t.thickness,leafHeight,leafWidth,0,0,z,color);for(const face of [-1,1])for(let j=0;j<t.slats;j++)k.withCollision('none',()=>k.box(.018,.022,leafWidth*.82,face*.035,-leafHeight*.33+j*leafHeight*.042,z,'#8a7168'));
  }
  // Rebate on the meeting edge seals the centre line while remaining part of the leaf.
  if(!single&&direction===1)k.box(.018,leafHeight,t.overlap,side*.035,0,direction*leafWidth,color);
  for(const face of [-1,1]){if(referenceLouver){const knob=k.solid(new THREE.SphereGeometry(.026,8,6),'#a6a49a','P41-round-door-knob');knob.position.set(face*.054,-.1,direction*(leafWidth-.09));knob.userData.walkRole='none';}else k.box(.04,.13,.035,face*.055,-.1,direction*(leafWidth-.09),'#b9b7a3');}for(const yy of [lo+.20,hi-.20])k.cylinder(.018,.12,0,yy,0,'#756b5a');k.finish();
 }
 g.userData.referenceLouver=referenceLouver;g.userData.decorativeGlass=decorated;g.userData.fit={clearance:t.clearance,centreGap:single?0:t.centreGap,leafWidth,leafHeight,rebated:true};
 let progress=0,target=0;const pose=()=>{for(const leaf of leaves)leaf.rotation.y=side*g.userData.door.swingSign*leaf.userData.hingeDirection*Math.PI*.55*(progress*progress*(3-2*progress));g.updateMatrixWorld(true);};
 g.userData.openingDirection='outward';
 g.userData.openAwayFrom=()=>{g.userData.door.swingSign=swingDirection;};
 g.userData.setOpen=open=>{target=progress=open?1:0;g.userData.door.open=!!open;g.userData.door.progress=progress;pose();};g.userData.setProgress=value=>{progress=THREE.MathUtils.clamp(value,0,1);g.userData.door.progress=progress;pose();};g.userData.requestOpen=open=>{target=open?1:0;g.userData.door.open=!!open;};g.userData.animateDoor=dt=>{const old=progress;progress+=Math.sign(target-progress)*Math.min(Math.abs(target-progress),dt/.65);g.userData.door.progress=progress;if(old===progress)return false;pose();return true;};return g;
}
