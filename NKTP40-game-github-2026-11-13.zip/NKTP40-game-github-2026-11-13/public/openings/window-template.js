import {drawClassicTimberLeaf} from './classic-timber-leaf.js?v=245.0';
import * as THREE from '../vendor/three.module.js';
import {geometryKit} from '../geometry-kit.js?v=222.0';
import {OPENING_TEMPLATES} from './catalog.js?v=50.0';
export const ADMIN_WINDOW=OPENING_TEMPLATES['square-glass-timber-window'];
// Glass outer sashes and permanently open inner timber shutters share the same grid.
export function createAdministrationWindow({side,wallX,u,level=0,size=ADMIN_WINDOW.size,top=ADMIN_WINDOW.top}){
 const root=new THREE.Group();root.name='admin-double-layer-window';root.position.set(side*wallX,level+top-size/2,u);root.scale.x=side;root.scale.z=.8;
 const frame='#6b4836',wood='#946447',darkWood='#6d4833',border=.065,cell=(size-2*border)/4,lowerH=3*cell,lo=-size/2+border,split=lo+lowerH;
 const fixed=geometryKit(root);for(const z of [-size/2+border/2,size/2-border/2])fixed.box(.0675,size,border,-.085,0,z,frame);for(const y of [-size/2+border/2,size/2-border/2])fixed.box(.0675,border,size,-.085,y,0,frame);
 fixed.box(.0675,.055,size,-.085,split,0,frame);for(let j=1;j<4;j++)fixed.box(.0625,cell,.045,-.085,split+cell/2,-size/2+border+j*cell,frame);
 const glassMat=new THREE.MeshStandardMaterial({color:'#718d91',transparent:true,opacity:.48,roughness:.24,metalness:.08,side:THREE.DoubleSide,depthWrite:false});
 function glass(parent,x,y,z,width,height){const pane=new THREE.Mesh(new THREE.BoxGeometry(.012,height,width),glassMat);pane.position.set(x,y,z);pane.name='outer-glass-pane';pane.receiveShadow=true;parent.add(pane);}
 for(let j=0;j<4;j++){const z=lo+(j+.5)*cell;glass(root,.025,split+cell/2,z,cell-.045,cell-.045);fixed.box(.032,cell-.045,cell-.045,-.215,split+cell/2,z,wood);}
 fixed.finish();const outside=[],inside=[];
 for(let col=0;col<4;col++){
  const direction=col%2===0?1:-1,center=lo+(col+.5)*cell,hinge=center-direction*cell/2;
  for(const layer of ['glass','wood']){
   const leaf=new THREE.Group();leaf.name=layer==='glass'?'admin-outer-glass-sash':'admin-open-inner-wood-shutter';leaf.position.set(layer==='glass'?.025:-.24,lo+lowerH/2,hinge);leaf.userData={layer,hingeDirection:direction,rows:3};root.add(leaf);const k=geometryKit(leaf),z=direction*cell/2,c=layer==='wood'?wood:frame;
   if(layer==='wood'){drawClassicTimberLeaf(k,{width:cell,height:lowerH,z,color:wood});}else{
   for(const zz of [direction*.025,direction*(cell-.025)])k.box(.045,lowerH,.05,0,0,zz,c);
   for(let row=0;row<=3;row++)k.box(.045,.05,cell,0,-lowerH/2+row*cell,z,c);
   for(let row=0;row<3;row++){const y=-lowerH/2+(row+.5)*cell;if(layer==='glass')glass(leaf,0,y,z,cell-.065,cell-.065);else{k.box(.028,cell-.075,cell-.075,0,y,z,wood);for(const zz of [z-(cell-.12)/2,z+(cell-.12)/2])k.box(.038,cell-.12,.018,-.018,y,zz,darkWood);}}
   }
   k.box(.035,.11,.025,layer==='glass'?.04:-.035,-.05,direction*(cell-.09),'#b7afa0');for(const yy of [-lowerH*.32,lowerH*.32])k.cylinder(.016,.11,0,yy,0,'#736c5d');k.finish();
   if(layer==='wood'){leaf.rotation.y=direction*ADMIN_WINDOW.woodAngle;inside.push(leaf);}else outside.push(leaf);
  }
 }
 let progress=0,target=0;const pose=()=>{const t=progress*progress*(3-2*progress);outside.forEach(o=>o.rotation.y=o.userData.hingeDirection*t*Math.PI*.44);root.updateMatrixWorld(true);};
 root.userData={templateId:'square-glass-timber-window',operableWindow:true,movingAperture:true,size,top:level+top,columns:4,rows:4,fixedTopRow:true,innerWoodAlwaysOpen:true,glassOpen:false,glassProgress:0};
 root.userData.toggleGlass=()=>{target=target?0:1;root.userData.glassOpen=!!target;};root.userData.setGlassProgress=v=>{progress=v;root.userData.glassProgress=v;pose();};
 root.userData.updateGlass=dt=>{const old=progress;progress+=Math.sign(target-progress)*Math.min(Math.abs(target-progress),dt/.6);root.userData.glassProgress=progress;if(old===progress)return false;pose();return true;};return root;
}
