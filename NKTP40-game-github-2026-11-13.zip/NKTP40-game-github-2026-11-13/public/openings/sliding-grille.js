import * as THREE from '../vendor/three.module.js';
import {geometryKit} from '../geometry-kit.js?v=222.0';
// Steel gate slides horizontally; use the existing doorway controller and its safety checks.
export function createSlidingGrille({side,wallX,u,y,v,width,height,color='#c6ad69'}){
 const g=new THREE.Group();g.name='a2-sliding-stair-grille';g.position.set(side*(wallX+v-.015),y,u);
 g.userData.door={open:false,progress:0,width,height};g.userData.templateId='a2-sliding-stair-grille';
 // Reusable four-panel drawing: rounded slots and a ring with curved diamond.
 function stroke(kit,points,x,closed=false){const curve=new THREE.CatmullRomCurve3(points.map(([z,y])=>new THREE.Vector3(x,y,z)),closed,'centripetal');kit.curved(new THREE.TubeGeometry(curve,Math.max(24,points.length*4),.011,6,closed),color,'A2-reference-ironwork');}
 function capsule(kit,x,z,mid,halfHeight,r){const points=[];for(let i=0;i<=12;i++){const a=Math.PI*i/12;points.push([z+Math.cos(a)*r,mid+halfHeight-r+Math.sin(a)*r]);}for(let i=0;i<=12;i++){const a=Math.PI+Math.PI*i/12;points.push([z+Math.cos(a)*r,mid-halfHeight+r+Math.sin(a)*r]);}stroke(kit,points,x,true);}
 function ringAndDiamond(kit,x,z,y,r){const circle=[];for(let i=0;i<48;i++){const a=i*2*Math.PI/48;circle.push([z+r*Math.cos(a),y+r*Math.sin(a)]);}stroke(kit,circle,x,true);const verts=[[z,y+r],[z+r,y],[z,y-r],[z-r,y],[z,y+r]],points=[];for(let k=0;k<4;k++){const [ax,ay]=verts[k],[bx,by]=verts[k+1],cx=z+(ax-z+bx-z)*.32,cy=y+(ay-y+by-y)*.32;for(let j=0;j<10;j++){const t=j/10;points.push([(1-t)**2*ax+2*(1-t)*t*cx+t*t*bx,(1-t)**2*ay+2*(1-t)*t*cy+t*t*by]);}}stroke(kit,points,x,true);}
 function ornament(kit,x,z0,z1,y0,y1,outer,centralRing=true){const mid=(z0+z1)/2,pitch=z1-z0,halfH=(y1-y0)*.40,r=Math.min(pitch*.09,.07),medallion=Math.min(pitch*.22,.15);kit.withCollision('none',()=>{if(outer){capsule(kit,x,mid+(z0-mid)*.42,(y0+y1)/2,halfH,r);capsule(kit,x,mid+(z1-mid)*.42,(y0+y1)/2,halfH,r);}else capsule(kit,x,mid,(y0+y1)/2,halfH,r);if(centralRing)ringAndDiamond(kit,x,mid,(y0+y1)/2,medallion);});}
 const lowerH=Math.min(height-.30,2.18),half=width/2,splitY=-height/2+lowerH;
 const fixed=geometryKit(g),fx=-side*.06;
 for(const z of [-width/2,0,width/2])fixed.box(.07,height+.08,.055,fx,0,z,color);
 fixed.box(.07,height+.08,.055,fx,0,-width/4,color);fixed.box(.07,height-lowerH,.055,fx,(splitY+height/2)/2,width/4,color);
 for(const yy of [-height/2,splitY,height/2])fixed.box(.07,.06,width,fx,yy,0,color);
 for(let z=-width/2+.13;z<width/2-.08;z+=.13){fixed.box(.045,height-lowerH-.04,.028,fx,(splitY+height/2)/2,z,color);if(z<-.04)fixed.box(.045,lowerH-.06,.028,fx,(-height/2+splitY)/2,z,color);}
 ornament(fixed,fx,-width/2,-width/4,-height/2,splitY,true);ornament(fixed,fx,-width/4,0,-height/2,splitY,false,false);
 ornament(fixed,fx,-width/2,-width/4,splitY,height/2,true);ornament(fixed,fx,-width/4,0,splitY,height/2,false);ornament(fixed,fx,0,width/4,splitY,height/2,false);ornament(fixed,fx,width/4,width/2,splitY,height/2,true);
 fixed.finish();
 const leaf=new THREE.Group();leaf.name='sliding-grille-panel';leaf.position.x=side*.015;g.add(leaf);const k=geometryKit(leaf),cz=width/4,cy=-height/2+lowerH/2;
 for(const z of [.025,half/2,half-.025])k.box(.065,lowerH-.04,.055,0,cy,z,color);
 for(const yy of [-height/2+.04,splitY-.04])k.box(.065,.065,half-.04,0,yy,cz,color);
 for(let z=.13;z<half-.08;z+=.13)k.box(.045,lowerH-.12,.028,0,cy,z,color);
 ornament(k,0,0,half/2,-height/2,splitY,false,false);ornament(k,0,half/2,half,-height/2,splitY,true);k.box(.08,.15,.05,0,cy,half-.16,'#b9b7a3');k.finish();
 let progress=0,target=0;const pose=()=>{leaf.position.z=-(half+.02)*progress;g.updateMatrixWorld(true);};
 g.userData.setOpen=open=>{target=progress=open?1:0;g.userData.door.open=!!open;g.userData.door.progress=progress;pose();};
 g.userData.setProgress=value=>{progress=THREE.MathUtils.clamp(value,0,1);g.userData.door.progress=progress;pose();};
 g.userData.requestOpen=open=>{target=open?1:0;g.userData.door.open=!!open;};
 g.userData.animateDoor=dt=>{const old=progress;progress+=Math.sign(target-progress)*Math.min(Math.abs(target-progress),dt/.7);g.userData.door.progress=progress;if(old===progress)return false;pose();return true;};return g;
}
