// Edit one shared profile to update every instance using that template.
const door={clearance:.004,centreGap:.006,stile:.055,rail:.065,thickness:.055,overlap:.018};
export const OPENING_TEMPLATES=Object.freeze({
 'wood-glass-double-door':Object.freeze({...door,panelFraction:.34,glassRows:2}),
 'timber-louver-double-door':Object.freeze({...door,slats:16}),
 'steel-grille-double-door':Object.freeze({...door,barSpacing:.15}),
 'school-wood-iron-window':Object.freeze({outerOffset:.09,ironOffset:-.04,openingAngle:Math.PI*.44,glazed:false}),
 'school-wood-iron-glass-window':Object.freeze({outerOffset:.09,ironOffset:-.04,glassOffset:-.15,openingAngle:Math.PI*.44}),
 'square-glass-timber-window':Object.freeze({size:2.72,top:3.465,columns:4,rows:4,fixedRows:1,woodAngle:80*Math.PI/180})
});
