import * as THREE from '../vendor/three.module.js';
const batches=new WeakMap();
// Batch glazing per parent; keep moving leaves separate from fixed transoms.
export function createGlassPane(parent,{x,y,z,width,height,depth=.018,name='clear-glass-pane'}){
 let pane=batches.get(parent);if(!pane){pane=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshStandardMaterial({color:'#8aa6a4',transparent:true,opacity:.28,roughness:.16,metalness:.06,side:THREE.DoubleSide,depthWrite:false}),64);pane.count=0;pane.name=name;pane.userData.glazing=true;parent.add(pane);batches.set(parent,pane);}
 if(pane.count>=64)throw new Error('Glazing batch capacity exceeded');
 const m=new THREE.Matrix4().makeScale(depth,height,width);m.setPosition(x,y,z);pane.setMatrixAt(pane.count++,m);pane.instanceMatrix.needsUpdate=true;pane.computeBoundingBox();pane.computeBoundingSphere();return pane;
}
