import {walkSpawn} from './layout-state.js';
import {LANGUAGE_ALLEY} from './foreign-language-alley-layout.js';
import {a1HallLinkPlan} from './a1-hall-link.js';
// Same destination identifiers as the existing quick-travel menu. The client
// resolves a clear standing point; the server confines it to that destination.
export function bicycleTravelTarget(layout,id,root){
 if(!Array.isArray(root)||root.length!==4||!root.every(Number.isFinite))return false;
 const [x,y,z]=root;if(Math.abs(x)>500||Math.abs(z)>500||y<-.1||y>100)return false;
 if(id==='gate'){const p=walkSpawn(layout);return!!p&&Math.hypot(x-p.x,z-p.z)<1&&Math.abs(y)<1;}
 if(id==='LANGUAGE-ALLEY')return Math.hypot(x-LANGUAGE_ALLEY.startX-2,z-LANGUAGE_ALLEY.entryZ)<1&&Math.abs(y)<1;
 if(id==='A1-H-LINK'){const p=a1HallLinkPlan(layout);return!!p&&Math.hypot(x-p.entry.x,z-p.entry.z-.75)<1&&Math.abs(y-p.high)<.5;}
 const b=layout?.buildings?.find(b=>b.id===id);if(!b)return false;const a=(b.rotation||0)*Math.PI/180,dx=x-b.x,dz=z-b.z,lx=Math.cos(a)*dx+Math.sin(a)*dz,lz=-Math.sin(a)*dx+Math.cos(a)*dz;
 return Math.abs(lx)<b.width/2+12&&Math.abs(lz)<b.length/2+5&&y<=(b.baseElevation||0)+b.height+2;
}
