import * as T from './vendor/three.module.js';
export const PLAYER_LABEL_HEAD_GAP=.04;
export const CHAT_BUBBLE_DURATION_MS=10000;
export function teacherLabelLines(profile,gender='male'){
 if(profile.teacherVerified!==true)return ['',''];
 const prefix=gender==='female'?'Cô':'Thầy',name=String(profile.name||'').trim().replace(/^(thầy|cô)\s+/iu,'');
 const subject=String(profile.subject||'').trim().replace(/^giáo viên\s+/iu,'');
 return [name?prefix+' '+name:'',subject?'Giáo viên '+subject:''];
}
const sizes=new WeakMap();
function retainSize(container){let s=sizes.get(container);if(!s){s={width:container.clientWidth,height:container.clientHeight,refs:0};s.observer=new ResizeObserver(()=>{s.width=container.clientWidth;s.height=container.clientHeight;});s.observer.observe(container);sizes.set(container,s);}s.refs++;return s;}
export function createPlayerLabel(container,{local=false,clock=Date.now}={}){
 const size=retainSize(container);let lastLeft='',lastTop='';const root=document.createElement('div');root.className='player-label';root.hidden=true;
 const name=document.createElement('div'),viewport=document.createElement('div'),note=document.createElement('span');viewport.className='player-note';viewport.append(note);root.append(viewport,name);container.append(root);
 const muted=document.createElement('div');muted.style.cssText='color:#ffd78b;font-size:11px';muted.textContent='Đang bị cấm chat';root.append(muted);
 const bubble=document.createElement('div');bubble.className='player-chat-bubble';bubble.hidden=true;root.prepend(bubble);let chatUntil=0;const showChat=(text,expires=clock()+CHAT_BUBBLE_DURATION_MS)=>{bubble.textContent=String(text||'');chatUntil=expires;bubble.hidden=!bubble.textContent||clock()>=chatUntil;};const localChat=e=>showChat(e.detail.text,e.detail.expires);if(local)window.addEventListener('nktp-local-chat',localChat);
 const point=new T.Vector3();let text='',dirty=true,profile={},gender='male';
 function refresh(){
  const teacher=profile.role==='teacher';
  root.classList.toggle('teacher-label',teacher);
  if(profile.isAdmin){name.textContent=profile.name||'';note.textContent=profile.note||'';root.append(viewport,name);}
  else if(teacher){const lines=teacherLabelLines(profile,gender);name.textContent=lines[0];note.textContent=lines[1];root.append(name,viewport);}
  else{name.textContent=[profile.name,[profile.className,/^\d{4}$/.test(String(profile.grade))?String(profile.grade).slice(-2):profile.grade].filter(Boolean).join(' ')].filter(Boolean).join(' - ');note.textContent=profile.note||'';root.append(viewport,name);}
  muted.hidden=!(profile.chatMutedUntil>clock());root.append(muted);text=name.textContent+note.textContent+(muted.hidden?'':muted.textContent);dirty=true;
 }
 return{showChat,setProfile(p){profile=p;refresh();},update(camera,avatar,visible,detail=2){
  muted.hidden=!(profile.chatMutedUntil>clock());bubble.hidden=!bubble.textContent||clock()>=chatUntil;
  const nextGender=avatar.root?.userData?.appearance==='female'?'female':'male';if(nextGender!==gender){gender=nextGender;if(profile.role==='teacher')refresh();}
  viewport.hidden=detail<2;name.hidden=detail<1;if(!visible||(!text&&bubble.hidden)){root.hidden=true;return;}
  avatar.getLabelPosition(point,PLAYER_LABEL_HEAD_GAP);point.project(camera);root.hidden=point.z<-1||point.z>1;
  if(!root.hidden){if(dirty){const overflow=note.scrollWidth-viewport.clientWidth;viewport.style.setProperty('--note-travel',-Math.max(0,overflow)+'px');viewport.classList.toggle('scrolling',profile.role!=='teacher'&&overflow>1);dirty=false;}const left=Math.round((point.x+1)*.5*size.width*2)/2+'px',top=Math.round((1-point.y)*.5*size.height*2)/2+'px';if(left!==lastLeft)root.style.left=lastLeft=left;if(top!==lastTop)root.style.top=lastTop=top;}
 },dispose(){if(--size.refs===0){size.observer.disconnect();sizes.delete(container);}if(local)window.removeEventListener('nktp-local-chat',localChat);root.remove();}};
}
