// Owner-approved continuous rear bicycle parking strip, reached beside the WC.
export const CAMPUS_GROUND_BOUNDS={xmin:-76,xmax:38.32,zmin:-54.72,zmax:79};
export const CAMPUS_REAR={b2:38.2,a2:38.2,passage:38.2,from:-13.25,to:11.3};
export function rearLimit(z){return z<CAMPUS_REAR.from?CAMPUS_REAR.b2+.12:z>CAMPUS_REAR.to?CAMPUS_REAR.a2+.12:CAMPUS_REAR.passage+.12;}
export const CAMPUS_GROUND_OUTLINE=[[-76,-34.2],[-63.9,-34.2],[-63.9,-30],[-42.8,-30],[-42.8,-31.75],[-22.351399221789883,-31.75],[-22.351399221789883,-36.75],[-14.8,-36.75],[-14.8,-54.72],[38.32,-54.72],[38.32,63.75],[26,61.8],[13.4,69.1],[15.8,70.5],[-11.8,78.2],[-16.7,66.8],[-47.8,70.6],[-53,58],[-65.4,53.5],[-76,53.5]];

export function insideCampusGround(x,z,radius=0){
 const inside=(x,z)=>{let hit=false;const p=CAMPUS_GROUND_OUTLINE;for(let i=0,j=p.length-1;i<p.length;j=i++){const [xi,zi]=p[i],[xj,zj]=p[j];if((zi>z)!==(zj>z)&&x<(xj-xi)*(z-zi)/(zj-zi)+xi)hit=!hit;}return hit;};
 return [[0,0],[radius,0],[-radius,0],[0,radius],[0,-radius]].every(([dx,dz])=>inside(x+dx,z+dz));
}
