import {batchStaticVisuals} from './static-visual-batch.js';
import * as T from './vendor/three.module.js';
import {createBicycle} from './furniture/bicycle.js';
import {createFootShuttle,orientShuttle} from './sports-equipment.js';
import {applySportsMotion} from './sports-motion.js';
import {createSportsSlots,sportsClock} from './sports-slots.js';
import {importAsset,assetFailure} from './asset-retry.js';
import {registerNPC} from './npc-animation.js';
export function createBicycleShuttleGames(layout){
 const root=new T.Group();root.name='bicycle-net-shuttle-games';
 for(const id of ['A2','B2']){
  const b=layout.buildings.find(b=>b.id===id);if(!b)continue;
  const a=b.rotation*Math.PI/180,c=Math.cos(a),s=Math.sin(a),x=(b.frontSide||-1)*(b.width/2+8),z=id==='A2'?-9:9;
  const g=new T.Group();g.name='bicycle-net-shuttle-'+id;g.position.set(b.x+c*x-s*z,.03,b.z+s*x+c*z);g.rotation.y=-a+Math.PI/2;g.userData={building:id,animationRadius:6};root.add(g);
  for(let i=0;i<3;i++){const bike=createBicycle({mini:true,color:['#6b8882','#af5349','#4975a0'][i],lowDetail:true});bike.name='shuttle-net-bicycle-'+(i+1);bike.userData.rideBikeId='shuttle:'+id+':'+i;bike.rotation.y=Math.PI/2;bike.position.z=(i-1)*1.95;bike.traverse(o=>{if(o.isMesh){o.castShadow=false;o.userData.walkSupport=false;}});g.add(bike);batchStaticVisuals(bike);}
  const state={},reach=3.2,slots=createSportsSlots(g,state,[new T.Vector3(-reach,0,1.2),new T.Vector3(reach,0,-1.2)],{kind:'shuttlecock',title:'Đá cầu qua xe đạp'});
  // Ground under this group is already offset .03m; marker is another .025m above it.
  slots.forEach(slot=>{slot.marker.position.y=.025;slot.targetLocal.set(slot.index===0?reach:-reach,0,0);});
  g.userData.textureReady=importAsset(new URL('./student/student.js',import.meta.url).href).then(async({createStudent,badgeReady})=>{
   await badgeReady;for(let p=g;p;p=p.parent)if(p.userData.disposed)return;
   const actors=[];for(const side of [-1,1]){const actor=createStudent({gender:side<0?'male':'female',season:'summer',scale:.93});actor.root.name='bicycle-shuttle-npc-'+side;actor.root.position.set(side*reach,0,side*1.2);actor.root.rotation.y=side<0?Math.PI/2:-Math.PI/2;actor.root.userData.walkIgnore=true;g.add(actor.root);actors.push({actor,side});}
   const shuttle=createFootShuttle();shuttle.userData.walkIgnore=true;g.add(shuttle);
   const endpoint=side=>{const slot=slots.find(v=>Math.sign(v.marker.position.x)===side&&v.occupied);return{slot,p:slot?slot.marker.position.clone().setY(0):new T.Vector3(side*reach,0,side*1.2)};};
   const tick=time=>{const {n,u}=sportsClock(state,time,1.8),from=n%2===0?-1:1,to=-from,start=endpoint(from),end=endpoint(to);state.target=end.slot;state.previousTarget=state.target;state.previousRound=n;
    for(const {actor,side}of actors){actor.update(time,'idle');applySportsMotion(actor.joints,{kind:'shuttlecock',swing:!start.slot&&side===from?Math.max(0,1-u/.36):0,anticipation:!end.slot&&side===to?T.MathUtils.smoothstep(u,.65,1):0});}
    const flight=T.MathUtils.clamp((u-.15)/.85,0,1),p=start.p.clone(),q=end.p.clone();p.x-=Math.sign(p.x)*.35;q.x-=Math.sign(q.x)*.35;shuttle.position.lerpVectors(p,q,flight);shuttle.position.y=.48+Math.sin(flight*Math.PI)*1.9;orientShuttle(shuttle,new T.Vector3(q.x-p.x,1.9*Math.PI*Math.cos(flight*Math.PI),q.z-p.z));g.userData.pass={from,to,targetSlot:end.slot?.index??null,progress:u};
   };tick(0);registerNPC(g,tick);g.userData.ready=true;
  }).catch(error=>assetFailure(g,error));slots.forEach(slot=>slot.textureReady=g.userData.textureReady);
 }
 return root;
}
