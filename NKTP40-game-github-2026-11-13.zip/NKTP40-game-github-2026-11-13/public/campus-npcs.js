import {importAsset,assetFailure} from './asset-retry.js';
import * as T from './vendor/three.module.js';
import {ENTRANCE} from './entrance-layout.js';

// Owner stall photos and R75 (owner-identified guard) guide NPC clothing and appearance.
export function createCampusNPC({id,name,female=false,seated=false,seatHeight=.46754,clothingPalette={},guardStyle=id==='khuyen'}={}){
 const root=new T.Group();root.name='npc-'+id;root.userData={npc:true,displayName:name,reference:id==='khuyen'?'R75 · Cuvwo4GrbLU 06:54 · guard identified by owner':'owner street-stall photographs'};
 const blocker=new T.Mesh(new T.BoxGeometry(.44,seated?1.05:1.55,.44),new T.MeshBasicMaterial({visible:false}));blocker.position.y=seated?.525:.775;blocker.userData.walkRole='barrier';root.add(blocker);
 if(typeof document==='undefined')return root;
 root.userData.textureReady=importAsset(new URL('./visitor-avatar.js',import.meta.url).href).then(async({createVisitorAvatar})=>{
  const avatar=createVisitorAvatar({appearance:female?'female':'male',season:'summer'});await avatar.ready;if(rootDisposed(root)){avatar.dispose();return;}root.add(avatar.root);
  const state={x:0,z:0,feet:0,dx:0,dz:0,velocity:0,seated,seatKind:'plastic',seatHeight,seatSize:.4,seatYaw:0};avatar.reset(state,0);for(let i=0;i<100;i++)avatar.update(1/60,state,()=>0);
  if(seated){
   const figure=avatar.root.children.find(o=>o.name.startsWith('student-')),pelvis=figure.getObjectByName('pelvis');
   for(const side of ['left','right']){figure.getObjectByName(side+'-hip').rotation.x=-1.3;figure.getObjectByName(side+'-knee').rotation.x=1.3;figure.getObjectByName(side+'-ankle').rotation.x=0;figure.getObjectByName(side+'-shoulder').rotation.x=-.25;figure.getObjectByName(side+'-elbow').rotation.x=-.70;}
   figure.updateMatrixWorld(true);const hip=figure.getObjectByName('left-hip'),p=hip.getWorldPosition(new T.Vector3());pelvis.position.y+=(root.getWorldPosition(new T.Vector3()).y+seatHeight+.065-p.y)/figure.scale.y;
   avatar.root.updateMatrixWorld(true);
   const floor=root.getWorldPosition(new T.Vector3()).y;
   for(const side of ['left','right']){const h=figure.getObjectByName(side+'-hip'),k=figure.getObjectByName(side+'-knee'),a=figure.getObjectByName(side+'-ankle');h.rotation.x=k.rotation.x=a.rotation.x=0;avatar.root.updateMatrixWorld(true);const hp=h.getWorldPosition(new T.Vector3()),kp=k.getWorldPosition(new T.Vector3()),ap=a.getWorldPosition(new T.Vector3()),shoe=a.children.find(o=>o.isMesh);shoe.geometry.computeBoundingBox();const sole=ap.y-shoe.geometry.boundingBox.clone().applyMatrix4(shoe.matrixWorld).min.y,upper=hp.distanceTo(kp),lower=kp.distanceTo(ap),angle=Math.acos(T.MathUtils.clamp((hp.y-floor-lower-sole)/upper,-1,1));h.rotation.x=-angle;k.rotation.x=angle;}
   avatar.root.updateMatrixWorld(true);
  }
  const original={shirt:new T.Color('#F4F5F7'),pants:new T.Color('#303044'),hair:new T.Color('#222220'),navy:new T.Color('#202D4A'),shoe:new T.Color('#F4F4F2')};
  const palette=id==='to'?{shirt:'#a4a5a0',pants:'#655e53',hair:'#77756e',shoe:'#414039'}:female?{shirt:'#326ba4',pants:'#343c49',hair:'#242323',navy:'#326ba4',shoe:'#414039'}:{shirt:'#808fdb',pants:'#434c38',hair:'#737574',shoe:'#292d28'};
  Object.assign(palette,clothingPalette);
  avatar.root.traverse(o=>{if(o.name.includes('badge'))o.visible=false;if(!o.isMesh||!o.geometry.attributes.color)return;o.geometry=o.geometry.clone();o.geometry.userData.shared=false;const c=o.geometry.attributes.color;for(let n=0;n<c.count;n++){const value=new T.Color().fromBufferAttribute(c,n);for(const key in palette)if(Math.abs(value.r-original[key].r)+Math.abs(value.g-original[key].g)+Math.abs(value.b-original[key].b)<.005){let color=new T.Color(palette[key]);if(id==='to'&&key==='shirt')color.multiplyScalar(.82+((n*37)%19)/60);c.setXYZ(n,color.r,color.g,color.b);break;}}c.needsUpdate=true;});
  const head=avatar.root.getObjectByName('head');
  function mesh(geometry,color,x,y,z){const m=new T.Mesh(geometry,new T.MeshStandardMaterial({color,roughness:.9}));m.position.set(x,y,z);head.add(m);return m;}
  if(id==='to'){
   mesh(new T.SphereGeometry(.173,12,8,0,Math.PI*2,0,Math.PI/2),id==='to'?'#353b39':'#344d60',0,.278,0);
   const brim=mesh(new T.SphereGeometry(1,12,6),id==='to'?'#353b39':'#344d60',0,.284,.133);brim.scale.set(.158,.014,.112);
  }
  if(guardStyle){
   const figure=avatar.root.children.find(o=>o.name.startsWith('student-')),torso=figure.getObjectByName('torso');
   head.scale.set(.95,.96,.95);figure.scale.x*=1.10;figure.scale.z*=1.06;
   // Shorten the sleeve geometry and extend bare forearms; no painted gradient.
   figure.traverse(o=>{if(!o.isMesh)return;if(o.name.endsWith('-elbow-surface')){o.visible=false;return;}const sleeve=o.name.startsWith('continuous-sleeve-'),bare=o.name.startsWith('arm-skin-');if(!sleeve&&!bare)return;const pos=o.geometry.attributes.position,c=o.geometry.attributes.color;let hi=-Infinity;for(let i=0;i<pos.count;i++)hi=Math.max(hi,pos.getY(i));for(let i=0;i<pos.count;i++){const y=pos.getY(i);if(sleeve){pos.setY(i,Math.max(y,1.005));const color=new T.Color('#808fdb');c.setXYZ(i,color.r,color.g,color.b);}else if(y>.72)pos.setY(i,.72+(y-.72)*(1.005-.72)/(hi-.72));}pos.needsUpdate=true;if(c)c.needsUpdate=true;o.geometry.computeVertexNormals();});
   for(const side of [-1,1]){const pocket=new T.Mesh(new T.BoxGeometry(.090,.075,.008),new T.MeshStandardMaterial({color:'#8291d8',roughness:1}));pocket.position.set(side*.082,.209,.097);torso.add(pocket);const flap=new T.Mesh(new T.BoxGeometry(.096,.016,.011),new T.MeshStandardMaterial({color:'#7381c6',roughness:1}));flap.position.set(side*.082,.244,.100);torso.add(flap);}
   root.userData.referenceDetails=['no hat','short salt-and-pepper hair','blue-violet short-sleeve two-pocket shirt','olive trousers','dark shoes'];
  }
  if(id==='khuyen')for(const side of [-1,1]){const lip=mesh(new T.CapsuleGeometry(.008,.057,3,8),'#37312c',side*.032,.080,.124);lip.rotation.z=side*1.42;}
  root.userData.seatContact=avatar.root.userData.seatContact;root.userData.ready=true;
 }).catch(error=>assetFailure(root,error));return root;
}
export function createGuardNPC(){const root=new T.Group();root.name='guard-npc-placement';const q=ENTRANCE.guard;const doorU=(q.width/2+(-.85+1.4/2))/2;root.position.set(ENTRANCE.x+q.x+doorU+1.0,0,ENTRANCE.z+q.z-q.length/2-1.15);root.rotation.y=Math.PI;root.userData.placementReference='owner1000030823: left of guard door, facing courtyard';root.add(createCampusNPC({id:'khuyen',name:'Bác Khuyến'}));return root;}

function rootDisposed(root){for(let p=root;p;p=p.parent)if(p.userData.disposed)return true;return false;}
