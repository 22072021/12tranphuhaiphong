import {createOnlineGiftNotice} from './online-gift-notice.js';
import * as T from './vendor/three.module.js';
import {createTPCDisplay} from './admin-tpc-formation.js';
import {gateNow} from './main-gate-schedule.js';
import {insideCampusGround} from './campus-limits.js';
import {ENTRANCE} from './entrance-layout.js';
import {ceremonyRemaining} from './flag-ceremony-plan.js';
export const TPC_EVENT=Object.freeze({id:'tpc-2026-11-09',startAt:Date.parse('2026-11-09T18:00:00+07:00')});
export function insideTPCEventCampus(state){return !!state&&Number.isFinite(state.x)&&Number.isFinite(state.z)&&state.x>ENTRANCE.x+.25&&insideCampusGround(state.x,state.z);}
export function createTPCEvent(scene,container,{now=gateNow,plan=TPC_EVENT,onSceneChange=()=>{}}={}){
 const gift=createOnlineGiftNotice(container,{now});
 const display=createTPCDisplay(scene),counter=document.createElement('div');counter.className='tpc-event-countdown';counter.dataset.photoExclude='true';counter.hidden=true;
 counter.style.cssText='position:absolute;z-index:9;pointer-events:none;transform:translate(-50%,-100%);width:max-content;text-align:center;color:#fff;text-shadow:0 2px 4px #163d32,0 0 8px #163d32;font-family:system-ui;line-height:1.45';
 const title=document.createElement('div'),date=document.createElement('div'),remaining=document.createElement('div');title.textContent='Xếp chữ TPC';title.style.cssText='font-size:clamp(19.55px,3.4vw,37.4px);font-weight:800';date.textContent='18h00 ngày 09/11 (Giờ Việt Nam)';date.style.cssText='font-size:clamp(10.2px,1.7vw,17.85px);font-weight:600;white-space:nowrap';remaining.style.cssText='font-size:clamp(14.45px,2.38vw,25.5px);font-weight:650';counter.append(title,date,remaining);container.append(counter);
 let models=null,campus=null,layout=null,active=false,lastSecond=-1,disposed=false;const anchor=new T.Vector3();
 function check(){if(disposed)return;const next=now()>=plan.startAt;if(next===active||!layout)return;active=next;display.setEnabled(active);display.bind(models,campus);onSceneChange(active,display.targets);}
 // Scene switches even if the player leaves the tab idle; clock comes from existing server sync.
 const timer=setInterval(check,1000);
 return{restore:display.restore,enforce:display.enforce,bind(m,c,l){models=m;campus=c;layout=l;gift.bind(l);active=now()>=plan.startAt;display.setEnabled(active);display.bind(models,campus);},update(camera,state){check();gift.update(camera,insideTPCEventCampus(state)?state:null);counter.hidden=true;},dispose(){disposed=true;gift.dispose();clearInterval(timer);display.dispose();counter.remove();}};
}
