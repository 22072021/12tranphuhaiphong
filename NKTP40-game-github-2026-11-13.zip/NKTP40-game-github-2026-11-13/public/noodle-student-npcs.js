import * as T from './vendor/three.module.js';
import {importAsset,assetFailure} from './asset-retry.js';
import {registerNPC} from './npc-animation.js';

// In stall coordinates the pavement is +Z, school interior is -Z.
export function createNoodleStudents(){
 const group=new T.Group();group.name='noodle-student-customers';group.userData={npc:true,walkIgnore:true,animationRadius:2.5,placement:'inside fence, facing noodle vendor'};
 if(typeof document==='undefined')return group;
 group.userData.textureReady=importAsset(new URL('./student/student.js',import.meta.url).href).then(async({createStudent,badgeReady})=>{
  await badgeReady;for(let p=group;p;p=p.parent)if(p.userData.disposed)return;
  const actors=[];
  for(let i=0;i<2;i++){
   const actor=createStudent({gender:i?'female':'male',season:'summer'});actor.root.name='noodle-eating-student-'+(i+1);actor.root.position.set(i? .72:-.18,-.048,-3.12);group.add(actor.root);
   const bowl=new T.Group();bowl.name='fish-noodle-bowl';actor.root.add(bowl);bowl.position.set(.11,.98,.22);
   const ceramic=new T.MeshStandardMaterial({color:'#eee9db',roughness:.45,side:T.DoubleSide});
   const profile=[[.043,0],[.058,.008],[.083,.04],[.104,.077],[.108,.09]].map(([x,y])=>new T.Vector2(x,y));bowl.add(new T.Mesh(new T.LatheGeometry(profile,24),ceramic));
   const soup=new T.Mesh(new T.CircleGeometry(.098,24),new T.MeshStandardMaterial({color:'#bca36b',roughness:.65}));soup.rotation.x=-Math.PI/2;soup.position.y=.079;bowl.add(soup);
   for(let n=0;n<5;n++){const noodle=new T.Mesh(new T.TorusGeometry(.025+n*.008,.002,4,16,Math.PI*1.6),new T.MeshStandardMaterial({color:'#eee6c7'}));noodle.rotation.x=Math.PI/2;noodle.position.set(0,.082,0);bowl.add(noodle);}
   for(let n=0;n<3;n++){const fish=new T.Mesh(new T.BoxGeometry(.033,.009,.016),new T.MeshStandardMaterial({color:n===2?'#4d773c':'#dab473'}));fish.position.set((n-1)*.033,.086,.025);fish.rotation.y=n*.8;bowl.add(fish);}
   const sticks=new T.Group();sticks.name='chopsticks';actor.root.getObjectByName('right-hand').add(sticks);for(const x of [-.008,.008]){const stick=new T.Mesh(new T.CylinderGeometry(.002,.002,.22,6),new T.MeshStandardMaterial({color:'#8e663c'}));stick.position.set(x,-.025,.09);stick.rotation.x=Math.PI/2;sticks.add(stick);}
   actors.push({actor,bowl,i});
  }
  // Solve both arms to explicit targets: left hand supports bowl; right lifts food to mouth.
  function reach(actor,side,target){const shoulder=actor.joints[side+'Shoulder'],elbow=actor.joints[side+'Elbow'];const origin=new T.Vector3(side==='left'?.177:-.177,1.19,0),v=target.clone().sub(origin),d=Math.min(.448,v.length()),dir=v.normalize(),along=(.235**2-.214**2+d*d)/(2*d),bend=Math.sqrt(Math.max(0,.235**2-along*along)),axis=new T.Vector3(0,0,1).cross(dir).normalize().multiplyScalar(side==='right'?-1:1),e=dir.clone().multiplyScalar(along).addScaledVector(axis,bend);shoulder.quaternion.setFromUnitVectors(new T.Vector3(0,-1,0),e.clone().normalize());elbow.quaternion.setFromUnitVectors(new T.Vector3(0,-1,0),dir.multiplyScalar(d).sub(e).normalize().applyQuaternion(shoulder.quaternion.clone().invert()));}
  const tick=time=>{for(const {actor,i}of actors){actor.update(time+i,'idle');const lift=(1-Math.cos((time+i*1.9)*1.4))/2;reach(actor,'left',new T.Vector3(.11,.98,.22));reach(actor,'right',new T.Vector3(-.04,1.04+lift*.18,.25-lift*.10));actor.joints.head.rotation.x=.12*(1-lift);actor.root.updateMatrixWorld(true);}};
  tick(0);registerNPC(group,tick);group.userData.ready=true;
 }).catch(error=>assetFailure(group,error));return group;
}
