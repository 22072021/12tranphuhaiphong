import {createFlagpoleTeacher} from './flagpole-teacher-npc.js';
import {createFenceClimbSite} from './fence-climb-site.js';
import {createForeignLanguageAlley} from './foreign-language-alley.js';
import {createBicycleShuttleGames} from './bicycle-shuttle-games.js';
import {createShuttlecockGroups} from './shuttlecock-npcs.js';
import {createNoticeStudentNPCs} from './notice-student-npcs.js';
import {createFrontageLeftHouses} from './frontage-left-houses.js';
import {createGuardNPC} from './campus-npcs.js';
import {createA1AudienceSeating} from './a1-audience-seating.js';
import {createR16CourtyardTrees} from './courtyard-trees.js';
import {createLeftBoundaryInfill} from './left-boundary-infill.js';
import {createGateSideStalls} from './gate-side-stalls.js';
import {createStreetSurfaces} from './street-surfaces.js';
import {createOldCampusTree} from './old-campus-tree.js';
import {applyConcreteSlabs} from './concrete-slabs.js';
import {campusBoundaryPlan,createCampusBoundary} from './campus-boundary.js?v=241.0';
import {createSharedClassroomStudy} from './shared-classroom-study.js?v=223.0';
import {createA1HallLink} from './a1-hall-link.js?v=228.0';
import {paintGateSign} from './gate-sign.js?v=222.0';
import {corridorPattern} from './corridor-tiles.js?v=222.0';
import {drawClassroomStairs,CLASSROOM_STAIR_TEMPLATE} from './stair-design.js?v=244.0';
import {FACADE_PROFILES} from './facade-profile.js?v=217.0';
import {createRaisedPlatform} from './raised-platform.js?v=223.0';
import {makeOpeningWall} from './wall-openings.js?v=222.0';
import {createApprovedAdditions} from './approved-additions.js?v=223.0';
import {createEntrance} from './entrance.js?v=225.0';
import {ENTRANCE} from './entrance-layout.js?v=34.0';
import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
import {containsPoint} from './layout-state.js?v=127.1';
export const SITE_FEATURE_BASIS='Cổng và cảnh quan đặt theo liên kết ảnh mặt đất; tọa độ và kích thước vẫn là phương án ước định.';
function sign(kit,text,x,y,z,width,height,color,ry=0){const m=kit.solid(new THREE.PlaneGeometry(width,height),color,'site-sign');m.position.set(x,y,z);m.rotation.y=ry;m.userData.signText=text;if(text==='TRẦN PHÚ')m.userData.textColor='#8e3d43';if(text.startsWith('TRƯỜNG TRUNG'))m.userData.textColor='#568794';return m;}
export function decorateSigns(root){if(typeof document==='undefined')return;const pending=[];root.traverse(o=>{if(o.userData.gateSign){const ready=paintGateSign(o);if(ready)pending.push(ready);return;}if(!o.userData.signText)return;const lines=o.userData.signLines,c=document.createElement('canvas');c.width=lines?1536:1024;c.height=lines?512:128;const t=c.getContext('2d');if(!o.userData.transparentSign){t.fillStyle='#'+o.material.color.getHexString();t.fillRect(0,0,c.width,c.height);}t.fillStyle=o.userData.textColor||'white';t.textAlign='center';t.textBaseline='middle';if(lines){t.font='54px Arial';lines.forEach((line,i)=>t.fillText(line,768,150+i*96,1450));t.font='italic 43px Arial';t.fillText(o.userData.signAuthor||'',768,390,1400);}else{t.font='bold 62px Arial';t.fillText(o.userData.signText,512,64,990);}const tx=new THREE.CanvasTexture(c);tx.colorSpace=THREE.SRGBColorSpace;o.material.map=tx;o.material.color.set('white');o.material.needsUpdate=true;});return Promise.all(pending);}
const CAMPUS_TREES=[[-50,8,3],[-25,15,3],[-30,24,5],[4,12,4],[4,27,6],[4,44,4.5],[10,38,3.5],[-16,61,4],[-51,-24,5]];
export function campusFeatureKey(layout){return JSON.stringify([layout.buildings.filter(b=>['A1','A2','H','B1','B2'].includes(b.id)),CAMPUS_TREES.filter(([x,z])=>!layout.buildings.some(b=>containsPoint(x,z,b,1.4)))]);}
export function createCampusFeatures(layout,{gateAngle=0}={}){
 const group=new THREE.Group(),kit=geometryKit(group),{box,beam,ring}=kit;group.name='campus-reference-features';group.userData.basis=SITE_FEATURE_BASIS;
 const yellow='#dec78b',green='#28594b',cream='#e6d6ac',brick='#975f4c';
 const boundary=campusBoundaryPlan(layout);
 group.add(createEntrance({gateAngle,fenceFrom:boundary?.fenceFrom}));
 group.add(createCampusBoundary(boundary));group.add(createNoticeStudentNPCs(boundary));group.add(createFlagpoleTeacher(layout));group.add(createLeftBoundaryInfill());group.add(createStreetSurfaces());group.add(createGateSideStalls(layout));
 group.add(createBicycleShuttleGames(layout));group.add(createShuttlecockGroups(layout));group.add(createGuardNPC());group.add(createFenceClimbSite());group.add(createA1AudienceSeating(layout));group.add(createR16CourtyardTrees());group.add(createFrontageLeftHouses());
 group.add(createForeignLanguageAlley());group.add(createBicycleParking(layout));group.add(createHeritageBasketball(layout));group.add(createA1HallLink(layout));
 group.add(createApprovedAdditions());group.add(createRaisedPlatform(layout));
 // V12: the speculative extra shed and three background masses were removed
 // against the user's red roof outlines. Only the ten identified main blocks
 // and entrance remain. D01–D03 now enter separately with explicit user approval.
 group.userData.removedSpeculativeStructures=['EXTRA_SHED','CONTEXT_1','CONTEXT_2','CONTEXT_3'];
 const courts=[{x:-32,z:18,w:17,l:29},{x:5,z:32,w:14,l:32}];
 for(const c of courts){box(c.w,.035,c.l,c.x,-.025,c.z,'#92988a');for(const s of [-1,1]){box(.055,.025,c.l-.4,c.x+s*(c.w/2-.2),.01,c.z,'#d9dbca');box(c.w-.4,.025,.055,c.x,.01,c.z+s*(c.l/2-.2),'#d9dbca');}box(c.w-.4,.025,.055,c.x,.011,c.z,'#d9dbca');}
 const trees=CAMPUS_TREES.filter(([x,z])=>!layout.buildings.some(b=>containsPoint(x,z,b,1.4)));
 for(const [x,z]of trees)if(x===-30&&z===24)group.add(createOldCampusTree({x,z:15.688826}));
 group.userData.pendingReplacementTrees=trees.filter(([x,z])=>!(x===-30&&z===24)).map(([x,z])=>({x,z}));kit.finish();for(const m of group.children)if(m.isMesh&&m.material?.color?.getHexString()==='92988a')applyConcreteSlabs(m.material);return group;
}
function darkColor(){return '#34483e';}
// These are explicitly labelled interior studies. They are not asserted to be
// surveyed rooms or silently assigned to an unknown room/floor in the campus.
export function createInteriorStudy(kind){
 if(kind==='classroom')return createSharedClassroomStudy();
 const g=new THREE.Group();g.name=kind;g.userData.study=true;const kit=geometryKit(g,{floorPattern:corridorPattern(kind.replace('corridor-',''))}),{box,beam,ring}=kit,wall='#d8b865',white='#e1e4d3',green='#366858',dark='#334d45';
 function window(x,y,z,w,h,axis='z',frame=green){if(axis==='x')x+=x>0?.02:-.02;box(axis==='z'?w:.12,h,axis==='z'?.12:w,x,y,z,frame);box(axis==='z'?w-.12:.14,h-.12,axis==='z'?.14:w-.12,x,y,z,'#79978f');for(let j=0;j<9;j++)box(axis==='z'?w:.17,.035,axis==='z'?.17:w,x,y-h*.43+j*h*.108,z,white);box(axis==='z'?.055:.18,h,axis==='z'?.18:.055,x,y,z,white);}
 function desk(x,z){box(1.65,.07,.55,x,.76,z,'#b18550');box(1.65,.07,.27,x,.45,z+.65,'#b18550');for(const a of [-.65,.65]){box(.045,.72,.045,x+a,.36,z,'#a3b0ac');box(.045,.43,.045,x+a,.215,z+.65,'#a3b0ac');}box(1.65,.17,.04,x,.64,z+.78,'#b18550');}
 function lamp(x,y,z){box(.95,.08,.18,x,y,z,white);for(const a of [-.35,.35])box(.025,.45,.025,x+a,y+.23,z,'#a5a495');}
 if(kind.startsWith('corridor')){
  const b1=kind.endsWith('B1');box(2.4,.12,25,0,-.06,0,'#bb9271');box(2.4,.13,25,0,3.25,0,white);const corridorHoles=[];for(let z=-11;z<=11;z+=3.4){corridorHoles.push({u:z+.8,y:1.6,width:1.45,height:1.55,kind:'window'},{u:z-1.0,y:1.16,width:.95,height:2.32,kind:'door'});}makeOpeningWall(g,{side:-1,wallX:-1.195,faceV:0,from:-12.5,to:12.5,height:3.3,color:wall,openings:corridorHoles});
  for(let z=-11;z<=11;z+=3.4){box(.20,3.3,.22,-1.15,1.65,z,wall);box(2.4,.20,.25,0,3.12,z,white);window(1.17,1.6,z+.8,1.45,1.55,'x',kind.endsWith('A1')?green:'#76564b');box(.12,.12,1.65,1.16,2.75,z+.8,white);for(let j=0;j<15;j++)box(.04,.035,1.25,1.13,1.0+j*.08,z+.8,green);for(const a of [-1,1])box(.13,2.36,.06,1.17,1.18,z-1.0+a*.49,green);box(.13,.06,1.04,1.17,2.35,z-1.0,green);box(.07,2.22,.84,1.15,1.15,z-1.0,kind.endsWith('A1')?green:'#76564b');lamp(0,3.05,z+.8);}
  for(let z=-12;z<12;z+=.40){box(.11,.30,.37,-1.15,.15,z,wall);if(kind.endsWith('A1'))box(.12,.22,.37,-1.15,.48,z,wall);else{for(const y of [.40,.72])box(.10,.035,.26,-1.15,y,z,white);for(const a of [-.13,.13])box(.10,.32,.035,-1.15,.56,z+a,white);}}
  box(.15,.12,25,-1.15,.85,0,'#7c615b');
  if(['corridor-A2','corridor-B2'].includes(kind))for(let z=-3;z<=3;z+=1){window(-1.17,1.75,z,.95,2.0,'x','#4b5f62');}
 }else if(kind.startsWith('stairs')){
  box(4.7,.15,8,0,-.115,0,'#a8997d');box(.15,5.5,8,2.45,2.75,0,wall);box(.15,5.5,8,-2.45,2.75,0,wall);
  const id=kind.slice(7),profile=FACADE_PROFILES[id]||FACADE_PROFILES.A1,model={id,width:8,length:4.7/profile.coreSpan,height:8.16,floors:2,frontSide:-1},stairs=new THREE.Group();stairs.name='shared-stair-study';stairs.rotation.y=Math.PI/2;g.add(stairs);const sk=geometryKit(stairs),plan=drawClassroomStairs(sk,model);sk.finish();stairs.position.x=-plan.center;stairs.userData.plan=plan;g.userData.stairTemplate=CLASSROOM_STAIR_TEMPLATE.topology;
  if(kind==='stairs-A1'){for(let j=-5;j<=5;j++)for(let k=0;k<14;k++){const x=j*.39,y=.4+k*.39;const rr=kit.solid(new THREE.TorusGeometry(.115,.035,5,14),white,'stair-breeze-ring');rr.position.set(x,y,-3.8);box(.39,.035,.13,x,y-.195,-3.8,white);box(.035,.39,.13,x-.195,y,-3.8,white);}}
  else for(let j=-4;j<=4;j++){const x=j*.5,z=-3.8+.24*(x*x);window(x,3,z,.48,3.8,'z','#4f6263');}
 }else if(kind==='heritage-corridor'){
  box(1.9,.12,12,0,-.06,0,'#a6aaa0');box(1.9,.10,12,0,2.95,0,white);for(const x of [-1.02,1.02]){box(.12,3,12,x,1.5,0,wall);for(const z of [-4,0,4]){window(x,1.6,z,1.1,1.8,'x',white);box(.12,2.2,.8,x,.0+1.1,z+1.5,white);}}for(let x=-.9;x<=.9;x+=.6)box(.025,.025,12,x,2.88,0,'#9da593');for(let z=-6;z<=6;z+=.6)box(1.9,.025,.025,0,2.88,z,'#9da593');
 }else if(kind==='hall-interior'){
  box(10,.12,34,0,-.06,0,'#a28b65');box(10,.12,34,0,6.0,0,'#d3d8c9');for(const x of [-5.1,5.1]){box(.15,6.0,34,x,3,0,'#a9c1ab');for(let z=-14;z<=14;z+=4)window(x,3.0,z,2.1,3.3,'x','#775a4f');}for(let z=-15;z<=15;z+=.16)box(9.9,.01,.015,0,.006,z,'#8a795c');box(10,6,.15,0,3,-17,'#a9c1ab');window(0,2,-16.9,3.8,3.8,'z','#775a4f');
 }else{
  const heritage=kind==='heritage-room',width=heritage?5:8,length=heritage?7:9,height=heritage?3.5:3.8;
  box(width,.14,length,0,-.07,0,heritage?'#b4b9ad':'#b28a5d');box(width,.12,length,0,height,0,white);
  for(const x of [-width/2-.1,width/2+.1]){box(.15,height,length,x,height/2,0,wall);for(const z of [-2.3,.8])window(x,1.8,z,1.4,1.8,'x',heritage?white:green);}
  box(width,height,.15,0,height/2,-length/2,wall);if(heritage)for(const x of [-1.4,1.4])window(x,1.9,-length/2+.1,1.2,1.9,'z',white);else{box(1.5,.95,.08,.5,1.85,-length/2+.12,'#c6d2c6');const clock=kit.solid(new THREE.CylinderGeometry(.19,.19,.08,24),'#3f4a3e','classroom-clock');clock.rotation.x=Math.PI/2;clock.position.set(.5,2.9,-length/2+.15);for(const x of [-1.8,1.8]){box(.04,.5,.04,x,height-.25,0,'#44624e');for(let j=0;j<3;j++)box(1.1,.035,.13,x,height-.5,0,'#44624e',0,j*Math.PI*2/3,0);}}
  box(width,height,.15,0,height/2,length/2,wall);box(heritage?2:3,.95,.10,0,1.9,length/2-.12,'#3b5847');
  for(let row=0;row<(heritage?3:5);row++)for(let col=0;col<(heritage?2:3);col++)desk((col-(heritage?.5:1))*2.0,-length/2+1.4+row*1.25);
  box(1.3,.75,.65,0,.375,length/2-1.2,'#a77f4e');for(const x of [-2,2])for(const z of [-2,1.5])lamp(x,height-.35,z);
  if(heritage){for(let x=-width/2;x<=width/2;x+=.60)box(.025,.025,length,x,height-.08,0,'#a1aaa0');for(let z=-length/2;z<=length/2;z+=.60)box(width,.025,.025,0,height-.08,z,'#a1aaa0');}
 }
 if(!kind.startsWith('stairs')){const cw=kind.startsWith('corridor')?2.4:kind==='heritage-corridor'?1.9:kind==='hall-interior'?10:kind==='heritage-room'?5:8,cl=kind.startsWith('corridor')?25:kind==='heritage-corridor'?12:kind==='hall-interior'?34:kind==='heritage-room'?7:9,ch=kind.startsWith('corridor')?3.25:kind==='heritage-corridor'?2.95:kind==='hall-interior'?6:kind==='heritage-room'?3.5:3.8;const ceiling=new THREE.Mesh(new THREE.PlaneGeometry(cw,cl),new THREE.MeshBasicMaterial({color:'#dedfd0',side:THREE.DoubleSide}));ceiling.rotation.x=Math.PI/2;ceiling.position.y=ch-.10;g.add(ceiling);}
 kit.finish();return g;
}

import {createBicycleParking} from './bicycle-parking.js';
import {createHeritageBasketball} from './heritage-basketball.js';
