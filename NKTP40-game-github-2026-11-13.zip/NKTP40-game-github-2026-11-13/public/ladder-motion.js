import * as T from './vendor/three.module.js';
const rigCache=new WeakMap();
const smooth=t=>{t=T.MathUtils.clamp(t,0,1);return t*t*t*(t*(t*6-15)+10);};
// Analytic two-link IK in the limb's forward plane; no iterative solver per frame.
function limb(upper,lower,target,L1,L2,bend,weight){
 const p=upper.parent.worldToLocal(target.clone()).sub(upper.position),r=T.MathUtils.clamp(Math.hypot(p.y,p.z),.035,L1+L2-.0005);
 const b=bend*Math.acos(T.MathUtils.clamp((r*r-L1*L1-L2*L2)/(2*L1*L2),-1,1));
 const a=Math.atan2(-p.z,-p.y)-Math.atan2(L2*Math.sin(b),L1+L2*Math.cos(b));
 upper.rotation.set(T.MathUtils.lerp(upper.rotation.x,a,weight),0,0);lower.rotation.set(T.MathUtils.lerp(lower.rotation.x,b,weight),0,0);
}
export function applyLadderPose(root,student,state,baseHip){
 const f=state.climbFrame;if(!f)return;
 const j=student.joints;let rig=rigCache.get(student);if(!rig){rig={};for(const side of ['left','right']){const hand=j[side+'Elbow'].children.find(o=>o.isBone),mesh=hand.children.find(o=>o.isMesh),shoe=j[side+'Ankle'].children.find(o=>o.isMesh);mesh.geometry.computeBoundingBox();shoe.geometry.computeBoundingBox();const palm=mesh.geometry.boundingBox.getCenter(new T.Vector3()),sole=new T.Vector3(0,shoe.geometry.boundingBox.min.y,.038);rig[side]={hand,palm,sole,arm1:j[side+'Elbow'].position.length(),arm2:hand.position.length()-palm.y,leg1:j[side+'Knee'].position.length(),leg2:j[side+'Ankle'].position.length()};}rigCache.set(student,rig);}const p=f.spec,scale=student.root.scale.y,pitch=(p.top-p.bottom-.25)/(f.rungs-1),rank=(f.height-p.bottom)/pitch;
 const transfer=f.stage==='exit',t=f.progress,blend=transfer?1-smooth((t-.22)/.66):f.stage==='approach'?smooth(t):1;
 const exitDirection=new T.Vector3(p.exitSide,0,0).transformDirection(f.matrix),exitYaw=Math.atan2(exitDirection.x,exitDirection.z),turn=transfer?smooth((t-.40)/.60):0;root.rotation.y=state.climbYaw+Math.atan2(Math.sin(exitYaw-state.climbYaw),Math.cos(exitYaw-state.climbYaw))*turn;root.position.set(state.x,state.feet,state.z).add(new T.Vector3(0,0,.07*blend).applyAxisAngle(new T.Vector3(0,1,0),state.climbYaw));
 j.pelvis.position.y=T.MathUtils.lerp(baseHip,baseHip-.10-(transfer?.08*Math.sin(Math.PI*t):0),blend);j.pelvis.rotation.set(0,0,0);j.torso.rotation.set(-(transfer?.035+.25*Math.sin(Math.PI*t):.035)*blend,0,0);j.head.rotation.set(.10*blend,0,0);root.updateMatrixWorld(true);
 const contact=(offset,hand)=>{const phase=(rank-offset)/2,k=Math.floor(phase),u=phase-k,s=smooth((u-.56)/.44),index=T.MathUtils.clamp(2*k+offset+(hand?4:0)+2*s,0,f.rungs-1),lift=Math.sin(Math.PI*s);return{y:p.bottom+.25+index*pitch,z:p.z+.20+(hand?.06:.10)*lift,swing:s>0&&s<1};};
 const targets=[];
 for(const [i,side]of ['left','right'].entries()){
  const r=rig[side],sign=i?-1:1,hand=contact(i,true),foot=contact(1-i,false),matrix=f.matrix;
  let hp=new T.Vector3(p.x-sign*.165,hand.y,hand.z).applyMatrix4(matrix),fp=new T.Vector3(p.x-sign*.074,foot.y,foot.z).applyMatrix4(matrix);
  if(transfer){const v=smooth((t-(i?.28:0))/.52),exit=new T.Vector3(p.exit.x-sign*.075,p.exit.y,p.exit.z).applyMatrix4(matrix);fp.lerp(exit,v);fp.y+=Math.sin(Math.PI*v)*.19;hp=new T.Vector3(p.x-sign*.165,p.top-.12,p.z+.20).applyMatrix4(matrix);}
  // Shoe sole/toe and hand palm, rather than joint origins, meet the steel rung.
  const ankle=fp.clone().add(new T.Vector3(0,-r.sole.y*scale,0)).add(new T.Vector3(0,0,-r.sole.z*scale).applyAxisAngle(new T.Vector3(0,1,0),state.climbYaw));
  limb(j[side+'Hip'],j[side+'Knee'],ankle,r.leg1,r.leg2,1,blend);root.updateMatrixWorld(true);j[side+'Ankle'].rotation.x=-(j[side+'Hip'].rotation.x+j[side+'Knee'].rotation.x)*blend;
  limb(j[side+'Shoulder'],j[side+'Elbow'],hp,r.arm1,r.arm2,-1,blend);root.updateMatrixWorld(true);
  targets.push({side,hand:hp.toArray(),foot:fp.toArray(),palmBone:r.hand.name,palmTip:r.palm.toArray(),soleTip:r.sole.toArray(),handPlanted:!hand.swing,footPlanted:!foot.swing});
 }
 root.userData.ladderContacts={stage:f.stage,blend,targets};
}
