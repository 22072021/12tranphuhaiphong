// Shared administration stair finish: reddish terrazzo centre, 15cm yellow edges.
// Splitting the solid volume avoids overlapping surfaces and flicker.
export const STAIR_STONE=Object.freeze({id:'admin-red-yellow-stone',red:'#b77d80',yellow:'#b77d80',border:.30});
export const STUDENT_STAIR_STONE=Object.freeze({...STAIR_STONE,id:'student-pink-yellow-granito',red:'#b77d80',yellow:'#c5af83'});
export function drawStoneStep(k,{x,y,z,width,depth,thickness=.16,axis='x',finish=STAIR_STONE,riserColor=null,nosing=0}){
 if(riserColor){const cap=Math.min(.035,thickness*.35),body=thickness-cap;if(body>0){if(axis==='x')k.box(depth,body,width,x,y-cap-body/2,z,riserColor);else k.box(width,body,depth,x,y-cap-body/2,z,riserColor);}drawStoneStep(k,{x,y,z,width,depth:depth+2*nosing,thickness:cap,axis,finish});return finish.id;}
 const border=Math.min(finish.border,width*.44),pieces=[{offset:0,width:width-2*border,color:finish.red},{offset:-(width-border)/2,width:border,color:finish.yellow},{offset:(width-border)/2,width:border,color:finish.yellow}];
 for(const p of pieces.filter(p=>p.width>1e-6))if(axis==='x')k.box(depth,thickness,p.width,x,y-thickness/2,z+p.offset,p.color);else k.box(p.width,thickness,depth,x+p.offset,y-thickness/2,z,p.color);
 return finish.id;
}

// Flush terrazzo slabs: pink centre and a continuous yellow perimeter.
export function drawStoneLanding(k,{x,y,z,width,depth,thickness=.16,finish=STAIR_STONE}){
 const b=Math.min(.40,width*.40,depth*.40),red=finish.red,yellow=finish.yellow;
 k.box(width-2*b,thickness,depth-2*b,x,y-thickness/2,z,red);
 for(const sign of [-1,1]){k.box(b,thickness,depth,x+sign*(width-b)/2,y-thickness/2,z,yellow);k.box(width-2*b,thickness,b,x,y-thickness/2,z+sign*(depth-b)/2,yellow);}
}

export const AGED_A2_STONE=Object.freeze({...STAIR_STONE,red:'#b77d80',yellow:'#b77d80'});
