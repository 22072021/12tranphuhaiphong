import * as T from './vendor/three.module.js';
// Interaction anchor only; keeps the approved chair/table geometry unchanged.
export function registerTeacherChair(parent,{x,z,level=0,end}){
 const seat=new T.Group();seat.name='teacher-chair-seat';seat.position.set(x,level,z);
 seat.userData.seatLanes=[{kind:'teacher',centered:true,xmin:-.215,xmax:.215,z:0,height:.4525,end,size:.43}];parent.add(seat);return seat;
}
