// User approved D01/D02/D03 on 2026-10-27. Approval covers presence;
// dimensions and concealed construction remain estimated from photographs.
export const APPROVED_ADDITIONS=[
 {id:'D01',name:'Dãy nhà nối LAB–nhà xe',kind:'connector',x:-56.55,z:48.049056741,width:6.3,length:17.898113483,height:3.32,rotation:0,photos:['P10','P11'],status:'approved',basis:'V50: theo ảnh người dùng, dãy nhà ngang và mái nối tiếp nhà xe, tường bao kín. Kích thước/phần khuất ước lượng.'},
 {id:'D04',name:'Phòng nước uống',kind:'water',x:29.4,z:58.75,width:7.5,length:5.5,height:3.4,rotation:0,photos:['P18','P19','P66'],status:'approved',basis:'Nhà một tầng nối đầu phải A2 trong DSC_1788/1791, biển PHÒNG NƯỚC UỐNG TINH KHIẾT; kích thước và mặt sau ước lượng.'}
];
