import {ENTRANCE} from './entrance-layout.js';
import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
import {makeOpeningWall} from './wall-openings.js?v=222.0';
// Relative to the entrance origin. Presence/order from June 2017 panorama;
// widths, depth and concealed rear elevations are estimates, not a 2015 survey.
export const STREET_SHOPS=[
 {id:'S01',length:4.2,height:3.65,kind:'closed',wall:'#96998d',sign:'#888c80',label:''},
 {id:'S02',length:4.1,height:3.55,kind:'open',wall:'#a7a58a',sign:'#b5a974',label:'CỬA HÀNG'},
 {id:'S03',length:3,height:3.65,kind:'grille',wall:'#a7a08b',sign:'#ba9f8a',label:''},
 {id:'S04',length:4.8,height:3.75,kind:'glass',wall:'#d8d6c4',sign:'#e1dfc9',label:'ÁO CƯỚI'},
 {id:'S05',length:3.4,height:3.65,kind:'closed',wall:'#a39b78',sign:'#b7a13d',label:'ĐẠI LÝ VÉ MÁY BAY'},
 {id:'S07',length:2.4755,height:3.55,kind:'closed',wall:'#b6ad8f',sign:'#ab9a75',label:''},
 {id:'S08',length:2.4755,height:3.6,kind:'grille',wall:'#c5b997',sign:'#a7997d',label:''},
 {id:'S09',length:1.285,height:3.5,kind:'closed',wall:'#b5ad94',sign:'#a89b7b',label:''},
 {id:'S10',length:4.05,height:3.7,kind:'open',wall:'#c3b596',sign:'#897e64',label:''},
 {id:'S12',length:5.379,height:3.6,kind:'closed',wall:'#b8b19c',sign:'#9b998a',label:''},
 {id:'S11',length:4.05,height:3.6,kind:'closed',wall:'#b8b19c',sign:'#9b998a',label:''},
 {id:'S06',length:4.5,height:3.55,kind:'open',wall:'#8e9c88',sign:'#3e7253',label:'DỊCH VỤ'}
];
STREET_SHOPS.sort((a,b)=>a.id.localeCompare(b.id));
export function createStreetShops(){const root=new THREE.Group();root.name='street-shops';root.position.x=4.2;root.userData={id:'STREET_SHOPS',source:'Google Street View Jun 2017 / sZfHUylQuLnuAmPL_0kTwQ',estimated:true};const first=ENTRANCE.guard.z+ENTRANCE.guard.length/2;let start=first;
 for(const b of STREET_SHOPS){const g=new THREE.Group();g.name=b.id;g.userData={id:b.id,kind:'street-context',estimated:true};const width=3.5,half=b.length/2,h=b.height;g.position.set(-width/2,0,start+half);root.add(g);const k=geometryKit(g),x=-width/2;
  k.box(.20,h,b.length,width/2-.1,h/2,0,b.wall);for(const z of [-half+.1,half-.1])k.box(width,h,.20,0,h/2,z,b.wall);
  k.box(width,.12,b.length,0,.06,0,'#96968b');k.box(width+.12,.16,b.length+.12,0,h+.08,0,'#73776d');k.box(.2,.55,b.length+.1,x+.05,h+.32,0,b.wall);
  makeOpeningWall(g,{side:-1,wallX:width/2,faceV:0,from:-half,to:half,height:h,color:b.wall,openings:[{u:0,y:1.43,width:b.length-.42,height:2.62,kind:'door'}]});
  const doorWidth=b.length-.46;
  if(b.kind==='closed'){
   k.box(.06,2.56,doorWidth,x+.10,1.43,0,b.id==='S01'?'#8e9390':'#63745c');for(let y=.2;y<2.7;y+=.065)k.box(.025,.013,doorWidth,x+.055,y,0,'#6e776e');k.box(.035,.08,doorWidth,x+.05,.16,0,'#4c554e');
  }else if(b.kind==='grille'){
   k.box(.035,2.55,doorWidth,x+.18,1.43,0,'#526254');for(let z=-doorWidth/2;z<doorWidth/2;z+=.14){k.box(.035,2.56,.025,x+.06,1.43,z,'#7e8a74');}for(let y=.2;y<2.7;y+=.22)k.box(.035,.025,doorWidth,x+.04,y,0,'#7e8a74');
  }else if(b.kind==='glass'){
   k.box(.035,2.55,doorWidth,x+.12,1.43,0,'#435954');for(const z of [-doorWidth/2,0,doorWidth/2])k.box(.11,2.6,.06,x+.06,1.43,z,'#e4e1d3');for(const y of [.15,2.72])k.box(.11,.07,doorWidth,x+.06,y,0,'#e4e1d3');for(const z of [-.09,.09])k.box(.13,.42,.025,x-.015,1.5,z,'#a7aaa0');
  }else{
   // Recessed shaded shop, counter and separate shelf levels visible from the road.
   k.box(.04,2.50,doorWidth,width/2-.23,1.4,0,'#414b40');for(const y of [.45,1.1,1.75]){k.box(1.1,.08,doorWidth-.2,width/2-.75,y,0,'#817d65');for(let z=-doorWidth/2+.25;z<doorWidth/2-.1;z+=.32)k.box(.19,.25,.20,width/2-.5,y+.165,z,['#708b64','#b79460','#5c8791'][Math.round(y*2)%3]);}k.box(.60,.85,doorWidth*.42,x+.65,.55,doorWidth*.23,'#7f866d');
  }
  k.box(.14,.59,b.length-.12,x-.08,3.10,0,b.sign);if(b.label){const sign=k.solid(new THREE.PlaneGeometry(b.length-.20,.48),b.sign,'shop-sign');sign.rotation.y=-Math.PI/2;sign.position.set(x-.16,3.10,0);sign.userData.signText=b.label;sign.userData.textColor=b.kind==='glass'?'#a64935':'#eee5bf';}
  // Shallow common fascia/awning, not the parking roof behind it.
  k.box(.75,.10,b.length+.04,x-.25,3.52,0,'#696d60',0,0,-.08);for(const z of [-half+.15,half-.15])k.beam(new THREE.Vector3(x-.02,2.95,z),new THREE.Vector3(x-.58,3.44,z),.035,'#5f665b');k.finish();start+=b.length;
 }
 root.userData.length=start-first;return root;
}
