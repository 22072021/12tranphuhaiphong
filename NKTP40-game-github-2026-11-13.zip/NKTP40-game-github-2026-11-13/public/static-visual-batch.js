import * as T from './vendor/three.module.js';
import {mergeGeometries} from './vendor/BufferGeometryUtils.js';
// Opt-in for immutable props. Keep source objects for exact collision/name queries.
export function batchStaticVisuals(root){
 root.updateWorldMatrix(true,true);const inverse=root.matrixWorld.clone().invert(),matrix=new T.Matrix4(),buckets=new Map();
 root.traverse(o=>{if(!o.isMesh||o.isSkinnedMesh||o.isInstancedMesh||Array.isArray(o.material)||!o.visible)return;for(let p=o.parent;p&&p!==root;p=p.parent)if(!p.visible)return;
 const m=o.material;if(m.map||m.normalMap||m.transparent||m.vertexColors)return;
 const key=JSON.stringify([m.type,m.color?.getHex(),m.roughness,m.metalness,m.side,m.opacity,o.castShadow,o.receiveShadow,!!o.geometry.index,Object.keys(o.geometry.attributes).sort()]);
 if(!buckets.has(key))buckets.set(key,{material:m,objects:[],geometries:[],cast:o.castShadow,receive:o.receiveShadow});const b=buckets.get(key),g=o.geometry.clone();matrix.multiplyMatrices(inverse,o.matrixWorld);g.applyMatrix4(matrix);b.geometries.push(g);b.objects.push(o);
 });
 let reduced=0;for(const b of buckets.values()){if(b.objects.length<2){b.geometries.forEach(g=>g.dispose());continue;}const geometry=mergeGeometries(b.geometries);b.geometries.forEach(g=>g.dispose());if(!geometry)continue;const mesh=new T.Mesh(geometry,b.material);mesh.name='static-visual-batch';mesh.castShadow=b.cast;mesh.receiveShadow=b.receive;mesh.userData.walkRole='none';for(const o of b.objects){o.visible=false;o.userData.batchedVisual=true;}root.add(mesh);reduced+=b.objects.length-1;}root.userData.visualDrawsSaved=reduced;return reduced;
}
// Freeze only explicitly static NPCs after their final pose has been applied.
export function freezeStaticAvatar(root){
 // SkinnedMesh updates bindMatrixInverse in updateMatrixWorld, not updateWorldMatrix.
 // Refresh it after the NPC has been placed/rotated, before sampling posed vertices.
 root.updateWorldMatrix(true,true);root.updateMatrixWorld(true);const inverse=root.matrixWorld.clone().invert(),matrix=new T.Matrix4(),v=new T.Vector3(),buckets=new Map();
 root.traverse(o=>{if(!o.isMesh||o.isInstancedMesh||Array.isArray(o.material)||!o.visible)return;for(let p=o.parent;p&&p!==root;p=p.parent)if(!p.visible)return;
 const g=o.geometry.clone();if(o.isSkinnedMesh){o.skeleton.update();const pos=g.attributes.position;for(let i=0;i<pos.count;i++){o.getVertexPosition(i,v);pos.setXYZ(i,v.x,v.y,v.z);}g.deleteAttribute('skinIndex');g.deleteAttribute('skinWeight');g.computeVertexNormals();}
 matrix.multiplyMatrices(inverse,o.matrixWorld);g.applyMatrix4(matrix);const flat=g.index?g.toNonIndexed():g;if(flat!==g)g.dispose();
 const key=o.material.uuid+':'+Object.keys(flat.attributes).sort().join(',')+':'+o.castShadow+':'+o.receiveShadow;
 if(!buckets.has(key))buckets.set(key,{material:o.material,geometries:[],objects:[],cast:o.castShadow,receive:o.receiveShadow});const b=buckets.get(key);b.geometries.push(flat);b.objects.push(o);
 });
 for(const b of buckets.values()){const geometry=mergeGeometries(b.geometries);b.geometries.forEach(g=>g.dispose());if(!geometry)continue;const mesh=new T.Mesh(geometry,b.material);mesh.name='frozen-npc-visual';mesh.userData.walkRole='none';mesh.castShadow=b.cast;mesh.receiveShadow=b.receive;for(const o of b.objects)o.visible=false;root.add(mesh);}
 root.userData.frozenPose=true;
}
