import {applyConcreteSlabs} from './concrete-slabs.js';
import {hallFrontProfile} from './hall-front-profile.js';
import {drawUnifiedPorchSteps} from './porch-unified-steps.js?v=218.0';
import {a1GroundEntries} from './a1-ground-entries.js?v=217.0';
import {drawStoneStep,STAIR_STONE} from './stair-stone.js?v=247.0';
import {corridorPattern} from './corridor-tiles.js?v=222.0';
import {administrationPlan} from './admin-design.js?v=56.0';
import * as THREE from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js?v=222.0';
import {FACADE_PROFILES} from './facade-profile.js?v=217.0';

// Visible level changes are photograph-derived; heights are estimates in metres.
const HEIGHTS={A1:.45,A2:.45,B1:.30,B2:.45,ADMIN:.45,LAB:.30,H:.45,TRADITION:.30,WC:.45,PARKING:.12,D04:.45};
export function buildingBaseProfile(b){
 const height=Number.isFinite(b.plinthHeight)?b.plinthHeight:(HEIGHTS[b.id]??.30),side=b.frontSide===1?1:b.frontSide===-1?-1:b.kind==='admin'?1:-1;
 const corridor=Math.min(2.25,b.width*.22),p=FACADE_PROFILES[b.id],core=b.id==='B1'&&Number.isFinite(b.stairCoreWidth)?b.stairCoreWidth:p?b.length*p.coreSpan:Math.min(4,b.length*.13),center=p?-side*(p.coreCentre-.5)*b.length:0;
 const stairs=(u,width,front,back=0,face='front',sign=side)=>({u,width,front,back,face,sign,steps:3,tread:.30,height});
 let accesses=[];
 if(b.kind==='classroom'){
  if(b.id==='A2'){const pitch=b.length/15;accesses=[stairs(center,4*pitch,2.9,-corridor),...[-1,1].map(wing=>stairs(center+wing*4*pitch,pitch-.24,.18,-corridor)),...[-1,1].map(sign=>({...stairs(side*(b.width/2+1.45),2.9,.02,0,'end',sign),edgeBase:sign*center+2*pitch}))];}
  else if(b.id==='B2'){const pitch=(b.length-core)/12;accesses=[stairs(center,4*pitch,2.9,-corridor),...[-1,1].map(sign=>stairs(sign*(b.length/2-2.5*pitch),pitch-.24,.18,-corridor)),...[-1,1].map(sign=>({...stairs(side*(b.width/2+1.45),2.9,.02,0,'end',sign),edgeBase:sign*center+2*pitch}))];}
  else if(b.id==='B1'){const pitch=(b.length-core)/12;accesses=[{...stairs(center,core-.22,-.90,-corridor),steps:1,tread:.90,riseDivisor:2},...[-1,1].map(sign=>({...stairs(center+sign*(core/2+3.5*pitch),pitch-.28,.08,-corridor),steps:1,tread:.32,riseDivisor:2}))];}
  else if(b.id==='A1')accesses=[stairs(0,Math.min(4.6,b.length*.20),.22,-corridor),...a1GroundEntries(b).map(e=>({...stairs(e.u,e.width,.22,-corridor),steps:e.steps}))];
  else accesses=[stairs(0,Math.min(4.6,b.length*.20),.22,-corridor)];
 }else if(b.kind==='admin'){
  const p=administrationPlan(b);accesses=[stairs(p.u(3/7),2*p.bay+.95,1.65,-p.corridor),stairs(p.wellU,p.stairBay-.25,.15,-p.corridor)];
 }else if(b.kind==='lab')accesses=[{...stairs(0,b.length,.12,-Math.min(1.6,b.width*.24)),steps:1}];
 else if(b.kind==='heritage'){
  accesses=[stairs(0,2.0,.22,-.12)];
  // Ground the feet of both existing exterior flights on the raised foundation.
  for(const sign of [-1,1])accesses.push(stairs(sign*3.65,1.40,4.12,0));
  accesses.push({...stairs(0,2.10,.32,-.08,'front',-side),edgeBase:b.width/2-b.width*.18});
 }
 else if(b.kind==='hall'){
  const back=-5.1+hallFrontProfile(b).forwardShift;accesses=[{...stairs(0,b.length,3.10,back),steps:0},stairs(0,Math.min(6.2,b.length*.72),3.10,back)];
  for(const sign of [-1,1])for(const u of [-b.width*.25,b.width*.25])accesses.push({...stairs(u,1.65,.10,-.12,'end',sign),steps:0});
  for(const sign of [-1,1])accesses.push({...stairs(sign*(b.length/2-1.55),2.7,2.25,0),steps:0});
 }else if(b.kind==='toilet')accesses=[];
 else if(b.kind==='water')accesses=[{...stairs(0,2.45,1.25,-.12),steps:0}];
 return{height,side,accesses,bodyMargin:b.kind==='admin'?Math.max(.28,administrationPlan(b).columnWidth/2+.06):.08,datum:'height above supporting terrain; not a surveyed value'};
}

export function createBuildingBase(b){
 const q=buildingBaseProfile(b),g=new THREE.Group();g.name='raised-building-base';g.userData={...q};
 const k=geometryKit(g,{floorPattern:b.kind==='hall'?'a2-aged-floral':corridorPattern(b.id),floorOuterLimit:b.id==='A1'?{side:b.frontSide,limit:b.width/2-.29}:null,corridorEdges:b.kind==='hall'?[q.side*(b.width/2+.20),q.side*(b.width/2+2.98)]:b.id==='A1'?[b.frontSide*(b.width/2-.41),b.frontSide*(b.width/2-Math.min(2.25,b.width*.22)+.12)]:null}),gray='#a9a69a';
 // The concrete stops below the tile bedding: no coplanar gray top.
 const entry=q.accesses[0],cut=b.id==='B1'?{x0:Math.min(q.side*(b.width/2-.90),q.side*(b.width/2+.12)),x1:Math.max(q.side*(b.width/2-.90),q.side*(b.width/2+.12)),z0:entry.u-entry.width/2,z1:entry.u+entry.width/2}:null;
 const body={x0:-b.width/2-q.bodyMargin+.02,x1:b.width/2+q.bodyMargin-.02,z0:-b.length/2-q.bodyMargin+.02,z1:b.length/2+q.bodyMargin-.02};
 const heritageNotch=b.kind==='heritage'?{x0:q.side<0?b.width/2-b.width*.18:body.x0,x1:q.side<0?body.x1:-b.width/2+b.width*.18,z0:body.z0,z1:b.length/2-b.length*2/5}:null;
 const bodyPieces=heritageNotch?subtractFloorRect(body,heritageNotch):[body];
 for(const r of bodyPieces.flatMap(r=>cut?subtractFloorRect(r,cut):[r]))k.box(r.x1-r.x0,q.height-.035,r.z1-r.z0,(r.x0+r.x1)/2,(q.height-.035)/2,(r.z0+r.z1)/2,gray);
 if(b.kind==='hall')g.userData.porchTiles={pattern:'a2-aged-floral',border:'photo-reference-pending',source:'R38 / A2 classroom'};
 const covered=[];
 const finish=(x0,x1,z0,z1,color=b.kind==='heritage'?'#b3ada0':b.kind==='hall'?gray:'#bb9271')=>{let pieces=cut?subtractFloorRect({x0,x1,z0,z1},cut):[{x0,x1,z0,z1}];for(const old of covered)pieces=pieces.flatMap(r=>subtractFloorRect(r,old));for(const r of pieces)k.box(r.x1-r.x0,.025,r.z1-r.z0,(r.x0+r.x1)/2,q.height-.0125,(r.z0+r.z1)/2,b.kind==='parking'?gray:color);covered.push({x0,x1,z0,z1});};
 const hallPorchCut=b.kind==='hall'?{x0:Math.min(q.side*(b.width/2-5.1+hallFrontProfile(b).forwardShift),q.side*(b.width/2+3.10)),x1:Math.max(q.side*(b.width/2-5.1+hallFrontProfile(b).forwardShift),q.side*(b.width/2+3.10)),z0:-b.length/2,z1:b.length/2}:null;
 if(hallPorchCut){for(const r of subtractFloorRect(body,hallPorchCut))finish(r.x0,r.x1,r.z0,r.z1);}else if(heritageNotch)for(const r of bodyPieces)finish(r.x0,r.x1,r.z0,r.z1);else finish(-b.width/2-q.bodyMargin,b.width/2+q.bodyMargin,-b.length/2-q.bodyMargin,b.length/2+q.bodyMargin);
 if(b.kind==='heritage'){
  const rear=-q.side*(b.width/2-b.width*.18),wing=-q.side*b.width/2,dir=-q.side,returnZ=b.length/2-b.length*2/5,outline=d=>[[rear,-1.05-d],[rear,returnZ],[wing,returnZ],[wing,.40-d],[rear+dir*(1.10+d),.40-d],[rear+dir*(1.10+d),-1.05-d]];
  const volume=(points,bottom,top,color,name)=>{const shape=new THREE.Shape();points.forEach(([x,z],i)=>i?shape.lineTo(x,z):shape.moveTo(x,z));shape.closePath();const geo=new THREE.ExtrudeGeometry(shape,{depth:top-bottom,bevelEnabled:false}),p=geo.attributes.position;for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getY(i),d=p.getZ(i);p.setXYZ(i,x,top-d,z);}geo.computeVertexNormals();k.curved(geo,color,name);};
  for(let j=0;j<3;j++){const d=(2-j)*.30,top=(q.height+.04)*(j+1)/3;volume(outline(d),0,top-.025,'#dec17a','heritage-rear-L-yellow-riser');volume(outline(d+.01),top-.025,top,'#b77d80','heritage-rear-L-granito-tread');}
  g.userData.heritageRearSteps={shape:'L',count:3,rise:(q.height+.04)/3,connectedDoors:2};
 }
 for(const a of q.accesses){
  // Heritage exterior flights descend directly to ground; no second plinth stair beneath them.
  if(b.kind==='heritage'&&(a.u!==0||a.sign!==q.side))continue;
  const half=a.edgeBase??(a.face==='front'?b.width/2:b.length/2);
  const slab=(u,v,width,depth,height,color)=>a.face==='front'?k.box(depth,height,width,a.sign*(half+v),height/2,u,color):k.box(width,height,depth,u,height/2,a.sign*(half+v),color);
  slab(a.u,(a.front+a.back)/2,a.width,a.front-a.back,q.height-.025,gray);
  // Each solid tread meets the next; the highest tread meets the landing.
  for(let j=0;j<a.steps&&!((b.id==='A2'||b.id==='B2')&&(a===q.accesses[0]||a.face==='end'));j++){
   const top=q.height*(j+1)/(a.riseDivisor??(b.id==='A1'&&a.steps===1?2:a.steps)),v=a.front+(a.steps-j-.5)*a.tread;
   const edge=a.sign*(half+v);
   drawStoneStep(k,{riserColor:b.kind==='heritage'?'#dec17a':null,nosing:b.kind==='heritage'?.01:0,finish:b.kind==='heritage'?{...STAIR_STONE,red:'#b77d80',yellow:'#b77d80',border:0}:b.id==='B1'?{...STAIR_STONE,red:gray,yellow:gray}:STAIR_STONE,x:a.face==='front'?edge:a.u,z:a.face==='front'?a.u:edge,y:top+.012,width:a.width,depth:a.tread+.002,thickness:top+.012,axis:a.face==='front'?'x':'z'});
  }
  // Patterned landing, finishing flush with the threshold and column feet.
  const v=(a.front+a.back)/2;
  if(a.face==='front'){const x=a.sign*(half+v),d=(a.front-a.back)/2;finish(x-d,x+d,a.u-a.width/2,a.u+a.width/2,b.kind==='heritage'?'#b77d80':b.kind==='hall'?'#bb9271':undefined);}
  else {const z=a.sign*(half+v),d=(a.front-a.back)/2;finish(a.u-a.width/2,a.u+a.width/2,z-d,z+d);}
 }
 if(b.id==='A2'||b.id==='B2'){const pitch=b.id==='A2'?b.length/15:(b.length-b.length*FACADE_PROFILES.B2.coreSpan)/12,profile=FACADE_PROFILES[b.id],center=-q.side*(profile.coreCentre-.5)*b.length;
  drawUnifiedPorchSteps(k,b,q,pitch,center,STAIR_STONE.red);
  g.userData.continuousPorchCorners=true;
 }
 if(b.kind==='parking'){

  function ramp(parent,name,x,z0,z1,run){
   const top=q.height,kit=geometryKit(parent),vertices=[x,top,z0,x+run,0,z0,x+run,0,z1,x,top,z1,x,0,z0,x,0,z1];
   const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geometry.setIndex([0,2,1,0,3,2,4,1,0,5,3,2,5,2,4,4,2,1,4,0,3,4,3,5]);geometry.computeVertexNormals();
   const mesh=kit.solid(geometry,'#96988e',name);mesh.userData.walkRole='none';mesh.userData.walkRamp={x0:x,x1:x+run,z0,z1,height:top};
  }
  ramp(g,'parking-concrete-ramp',b.width/2,-b.length/2,b.length/2,2);
  // Additional end access beside the guard house, in the uncovered courtyard strip.
  const end=new THREE.Group();end.name='parking-end-access';end.rotation.y=Math.PI/2;g.add(end);
  ramp(end,'parking-end-ramp',b.length/2,.8,b.width/2-.08,2);
  g.userData.parkingRamp={run:2,rise:q.height,side:1,endAccess:true};
 }

 g.userData.floorFinishRegions=covered; k.finish();if(b.kind==='hall')for(const m of g.children)if(m.isMesh&&m.material?.color?.getHexString()===gray.slice(1))applyConcreteSlabs(m.material,{pitch:2.40});return g;
}

// Returns the same tread/landing elevation used by the mesh, for walk mode.
export function buildingAccessHeight(x,z,b){
 const angle=-b.rotation*Math.PI/180,dx=x-b.x,dz=z-b.z,c=Math.cos(angle),s=Math.sin(angle),lx=c*dx-s*dz,lz=s*dx+c*dz,q=buildingBaseProfile(b);
 const terrain=Number.isFinite(b.baseElevation)?b.baseElevation:0;
 let y=Math.abs(lx)<=b.width/2+q.bodyMargin&&Math.abs(lz)<=b.length/2+q.bodyMargin?q.height:0;
 if(b.id==='B1'){const a=q.accesses[0],v=q.side*lx-b.width/2;if(Math.abs(lz-a.u)<=a.width/2&&v>=-.90&&v<=.12)y=0;}
 for(const a of q.accesses){
  // Heritage exterior flights descend directly to ground; no second plinth stair beneath them.
  if(b.kind==='heritage'&&(a.u!==0||a.sign!==q.side))continue;const u=a.face==='front'?lz:lx,v=a.sign*(a.face==='front'?lx:lz)-(a.edgeBase??(a.face==='front'?b.width/2:b.length/2));if(Math.abs(u-a.u)>a.width/2||v<a.back||v>a.front+a.steps*a.tread)continue;
  const divisor=a.riseDivisor??(b.id==='A1'&&a.steps===1?2:a.steps),local=v<=a.front?q.height:q.height*Math.min(a.steps,Math.max(1,Math.ceil((a.front+a.steps*a.tread-v)/a.tread)))/divisor;y=Math.max(y,local);
 }
 if(b.id==='A2'||b.id==='B2'){const pitch=b.id==='A2'?b.length/15:(b.length-b.length*FACADE_PROFILES.B2.coreSpan)/12,center=-q.side*(FACADE_PROFILES[b.id].coreCentre-.5)*b.length,outX=q.side*lx-(b.width/2+2.9);for(const sign of [-1,1]){const outZ=sign*(lz-center)-2*pitch,d=Math.max(outX,outZ);if(outX>=0&&outZ>=0&&d<=.9)y=Math.max(y,q.height*Math.max(1,3-Math.floor(d/.30))/3);}}
 return y>0?terrain+y:0;
}

// Partition the union of plinth and door landings: one visible tile face per point.
export function subtractFloorRect(r,b){
 const x0=Math.max(r.x0,b.x0),x1=Math.min(r.x1,b.x1),z0=Math.max(r.z0,b.z0),z1=Math.min(r.z1,b.z1);
 if(x1<=x0||z1<=z0)return[r];
 return [{x0:r.x0,x1:x0,z0:r.z0,z1:r.z1},{x0:x1,x1:r.x1,z0:r.z0,z1:r.z1},{x0,x1,z0:r.z0,z1:z0},{x0,x1,z0:z1,z1:r.z1}].filter(a=>a.x1-a.x0>1e-7&&a.z1-a.z0>1e-7);
}
