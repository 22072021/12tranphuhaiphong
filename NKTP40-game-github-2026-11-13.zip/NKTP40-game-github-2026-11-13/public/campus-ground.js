import {CAMPUS_GROUND_BOUNDS as B,CAMPUS_GROUND_OUTLINE} from './campus-limits.js';
import {applyConcreteSlabs} from './concrete-slabs.js';
import * as THREE from './vendor/three.module.js';
// One definition for the published visitor view and the full-campus review.
export function createCampusGround(){
 const shape=new THREE.Shape();CAMPUS_GROUND_OUTLINE.forEach(([x,z],i)=>i?shape.lineTo(x,-z):shape.moveTo(x,-z));shape.closePath();const geometry=new THREE.ExtrudeGeometry(shape,{depth:1,bevelEnabled:false});geometry.rotateX(-Math.PI/2);geometry.translate(0,-1,0);
 const ground=new THREE.Mesh(geometry,new THREE.MeshStandardMaterial({color:'#cdd5bd',roughness:1}));ground.receiveShadow=true;ground.name='campus-ground';
 const paving=new THREE.Mesh(new THREE.BoxGeometry(52,.1,102),new THREE.MeshStandardMaterial({color:'#858b87',roughness:1}));paving.position.set(0,-.02,6);paving.receiveShadow=true;paving.name='campus-paving';
 applyConcreteSlabs(ground.material);applyConcreteSlabs(paving.material);
 return {ground,paving};
}
