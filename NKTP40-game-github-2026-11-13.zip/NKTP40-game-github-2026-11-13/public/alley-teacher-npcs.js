import * as T from './vendor/three.module.js';
import {importAsset,assetFailure} from './asset-retry.js';
import {LANGUAGE_ALLEY as A,GAME_CAFE,GAME_CAFE_2} from './foreign-language-alley-layout.js';

// Reuse existing rigs; static poses require no animation loop or network state.
export function createAlleyTeacherGroup(){
 const root=new T.Group();root.name='alley-teacher-student-group';
 const gapStart=(GAME_CAFE_2.firstBay+GAME_CAFE_2.bays)*A.houseUnit,gapEnd=GAME_CAFE.firstBay*A.houseUnit;
 root.position.set((gapStart+gapEnd)/2,.035,0);root.userData={students:4,teacher:1,placement:'between game cafes, along right facade; opposite side remains clear'};
 const actors=[];
 for(let i=0;i<5;i++){
  const teacher=i===4,g=new T.Group();g.name=teacher?'alley-discipline-teacher':'alley-disciplined-student-'+(i+1);g.position.set(teacher?0:(i-1.5)*.72,0,teacher?.65:1.63);g.rotation.y=teacher?0:Math.PI;
  g.userData.pose=teacher?'standing-facing-students':'bowed-head-arms-down';if(teacher){g.userData.npc=true;g.userData.dialogue='Các anh theo tôi đi về lập biên bản!';}
  const blocker=new T.Mesh(new T.BoxGeometry(.44,1.55,.44),new T.MeshBasicMaterial({visible:false}));blocker.position.y=.775;blocker.userData.walkRole='barrier';g.add(blocker);root.add(g);actors.push({g,teacher,i});
 }
 if(typeof document==='undefined')return root;
 root.userData.textureReady=Promise.all([importAsset(new URL('./student/student.js',import.meta.url).href),importAsset(new URL('./characters/teacher.js',import.meta.url).href)]).then(async([{createStudent,badgeReady},{createTeacher}])=>{
  await badgeReady;for(let p=root;p;p=p.parent)if(p.userData.disposed)return;
  for(const {g,teacher,i}of actors){
   const avatar=teacher?createTeacher({gender:'female',studentScale:.93,aoDaiColor:'#667da0'}):createStudent({gender:'male',season:i%2?'summer':'winter',scale:.93});
   avatar.root.userData.walkIgnore=true;g.add(avatar.root);avatar.update(0,'idle');
   const j=avatar.joints;if(!teacher){j.head.rotation.x=.24+(i%2)*.035;j.torso.rotation.x=.025;for(const side of['left','right']){j[side+'Shoulder'].rotation.set(-.06,0,side==='left'?-.035:.035);j[side+'Elbow'].rotation.x=-.035;}}
   avatar.root.updateMatrixWorld(true);
  }root.userData.ready=true;
 }).catch(error=>assetFailure(root,error));return root;
}
