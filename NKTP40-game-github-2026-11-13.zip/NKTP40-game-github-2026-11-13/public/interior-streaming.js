import * as T from './vendor/three.module.js';
import {disposeObject} from './building-cache.js';
const slots=new Set(),worldBox=new T.Box3(),near=new T.Vector3(),schedules=new WeakMap();
export function lazyFloor(root,specs,build){root.userData.buildInterior=build;const slot={ref:new WeakRef(root),specs,lastNear:0,box:new T.Box3(new T.Vector3(Math.min(...specs.map(v=>v.xmin)),specs[0].level||0,Math.min(...specs.map(v=>v.zmin))),new T.Vector3(Math.max(...specs.map(v=>v.xmax)),(specs[0].level||0)+3.8,Math.max(...specs.map(v=>v.zmax))))};slots.add(slot);root.userData.interiorSlot=true;}
export function updateInteriorStreaming(scene,camera,time,{moving=false,budgetMs=Infinity,onChange=()=>{}}={}){
 const schedule=schedules.get(scene)||{next:0};schedules.set(scene,schedule);if(time<schedule.next)return false;schedule.next=time+.20;
 const loaded=[],pending=[];for(const s of slots){const g=s.ref.deref();if(!g){slots.delete(s);continue;}let p=g;while(p&&p!==scene)p=p.parent;if(p!==scene)continue;g.updateWorldMatrix(true,false);worldBox.copy(s.box).applyMatrix4(g.matrixWorld);worldBox.clampPoint(camera.position,near);const d=near.distanceTo(camera.position);if(d<25){s.lastNear=time;if(!g.children.length)pending.push({s,d,g,vertical:Math.max(worldBox.min.y-camera.position.y,camera.position.y-worldBox.max.y,0)});}if(g.children.length)loaded.push({s,d,g});}
 // Preload one nearest floor at a time while idle; urgent approach still loads before entry.
 pending.sort((a,b)=>a.d-b.d);const first=pending.find(p=>{const urgent=p.d<7&&p.vertical<1.5;return(!moving||urgent)&&(budgetMs>0||urgent);});if(first){const start=performance.now(),child=first.g.userData.buildInterior();child.userData.streamingChunk=true;first.g.add(child);first.g.updateMatrixWorld(true);onChange({added:[child],removed:[]});if(performance.now()-start>16)schedule.next=time+.5;return true;}
 // Retire one distant floor per idle slice, never a room around the visitor.
 if(!moving){loaded.sort((a,b)=>a.d-b.d);const old=loaded.find(({s,d},i)=>d>45&&(time-s.lastNear>90||i>=8));if(old){const child=old.g.children[0];onChange({added:[],removed:[child]});child.removeFromParent();disposeObject(child);return true;}}
 return false;
}
