import {FACADE_PROFILES} from './facade-profile.js?v=217.0';
// The original entry is in the second outer bay on each wing; match the column grid.
export function a1GroundEntries(b){const l=b.length/2,side=b.frontSide===1?1:-1,p=FACADE_PROFILES.A1,center=-side*(p.coreCentre-.5)*b.length,span=b.length*p.coreSpan,wings=[[-l,center-span/2],[center+span/2,l]];return wings.map(([lo,hi],i)=>{const bay=(hi-lo)/4,a=i===0?lo+bay:hi-2*bay,z=a+bay;return{u:(a+z)/2,width:bay-.25,steps:1};});}
