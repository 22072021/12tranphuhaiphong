// Daily Vietnam time window, inclusive 07:00, exclusive 07:10.
export function isMainGateLocked(time=gateNow()){
 const minutes=((Math.floor(time/60000)+7*60)%1440+1440)%1440;
 return minutes>=420&&minutes<430;
}
let serverBase=null,perfBase=0,busy=false,lastSync=0;
export function gateNow(){return serverBase===null?Date.now():serverBase+performance.now()-perfBase;}
async function sync(){
 if(busy)return;busy=true;const sent=performance.now();
 try{const r=await fetch('/api/flag-ceremony-clock',{cache:'no-store',credentials:'omit',signal:AbortSignal.timeout(8000)});if(!r.ok)return;const data=await r.json(),received=performance.now();if(Number.isFinite(data.serverNow)){serverBase=data.serverNow;perfBase=(sent+received)/2;lastSync=received;}}
 catch{}finally{busy=false;}
}
if(typeof window!=='undefined'){
 sync();
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&performance.now()-lastSync>300000)sync();});
}
