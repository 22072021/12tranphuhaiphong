// Re-enable with: node local-runtime/set-cohort-rooms.mjs on
export const COHORT_ROOMS_ENABLED=false;
