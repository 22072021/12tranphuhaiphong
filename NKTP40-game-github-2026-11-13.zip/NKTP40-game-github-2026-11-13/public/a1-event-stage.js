import {createStagePerformers} from './a1-stage-performers.js';
import * as T from './vendor/three.module.js';
import {geometryKit} from './geometry-kit.js';
// Owner explicitly authorized R83 event dressing on the reviewed A1 stage.
export function createA1EventStage({side,back,center,width,depth,baseY}){
 const g=new T.Group();g.name='a1-r83-event-stage-dressing';const k=geometryKit(g),top=.47-baseY;const show=new T.Group();show.name='a1-ceremony-hide-stage-show';g.add(show);const showKit=geometryKit(show);
 // R83: red stage surface, blue pleated apron on front and side edges.
 k.box(depth,.012,width,side*(back+depth/2),top+.006,center,'#a8333b');
 k.withCollision('none',()=>{
  k.box(.02,.36,width,side*(back+depth+.015),top-.19,center,'#327fa0');
  for(let z=-width/2+.045;z<width/2;z+=.09)k.box(.025,.35,.025,side*(back+depth+.03),top-.19,center+z,'#5798ad');
  for(const sign of [-1,1])k.box(depth,.36,.02,side*(back+depth/2),top-.19,center+sign*(width/2+.01),'#327fa0');
  for(const sign of [-1,1])showKit.withCollision('none',()=>showKit.box(.035,width/2+.12,.035,side*(back+.045),top+width/4,center+sign*(width/2+.025),'#686c64'));
  showKit.withCollision('none',()=>showKit.box(.035,.035,width+.08,side*(back+.045),top+width/2+.025,center,'#686c64'));
 });
 k.finish();showKit.finish();const material=new T.MeshBasicMaterial({color:'white',toneMapped:false,side:T.DoubleSide});
 const banner=new T.Mesh(new T.PlaneGeometry(width,width/2),material);banner.name='r83-owner-original-backdrop';banner.position.set(side*(back+.07),top+width/4,center);banner.rotation.y=side*Math.PI/2;banner.userData.walkRole='none';
 if(typeof document!=='undefined')banner.userData.textureReady=new T.TextureLoader().loadAsync(new URL('./assets/runtime/event-backdrop.webp',import.meta.url).href).then(tx=>{tx.colorSpace=T.SRGBColorSpace;tx.anisotropy=8;material.map=tx;material.needsUpdate=true;});
 const blocker=new T.Mesh(new T.BoxGeometry(.12,width/2,width),new T.MeshBasicMaterial({visible:false}));blocker.name='r83-backdrop-solid-collision';blocker.position.copy(banner.position);blocker.userData.walkRole='barrier';show.add(blocker);
 show.add(banner);show.add(createStagePerformers({side,back,center,width,depth,top}));g.userData={source:'R83 plus owner supplied full backdrop',temporaryEventDressing:true,uncroppedImage:true,imageAspect:2,structuralStairAccessUnchanged:true};return g;
}
