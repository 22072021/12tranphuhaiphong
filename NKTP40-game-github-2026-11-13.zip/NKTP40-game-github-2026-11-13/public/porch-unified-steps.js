import * as THREE from './vendor/three.module.js';
export function drawUnifiedPorchSteps(k,b,q,pitch,center,color){
 const front=2.9,half=2*pitch;
 for(let level=1;level<=3;level++){const outer=(4-level)*.30,inner=(3-level)*.30,top=q.height*level/3+.012,outline=[[front+outer,-half-outer],[front+outer,half+outer],[0,half+outer],[0,half+inner],[front+inner,half+inner],[front+inner,-half-inner],[0,-half-inner],[0,-half-outer]],points=outline.map(([v,u])=>new THREE.Vector2(q.side*(b.width/2+v),center+u)),triangles=THREE.ShapeUtils.triangulateShape(points,[]),vertices=[];
  for(const t of triangles){for(const i of [...t].reverse())vertices.push(points[i].x,top,points[i].y);for(const i of t)vertices.push(points[i].x,0,points[i].y);}
  for(let i=0;i<points.length;i++){const a=points[i],c=points[(i+1)%points.length];vertices.push(a.x,0,a.y,c.x,0,c.y,c.x,top,c.y,a.x,0,a.y,c.x,top,c.y,a.x,top,a.y);}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.computeVertexNormals();const mesh=k.solid(geo,color,'unified-porch-step-'+level);mesh.userData.walkParts=[[front+inner,front+outer,-half-outer,half+outer],[0,front+inner,half+inner,half+outer],[0,front+inner,-half-outer,-half-inner]].map(([v0,v1,u0,u1])=>({bounds:new THREE.Box3(new THREE.Vector3(Math.min(q.side*(b.width/2+v0),q.side*(b.width/2+v1)),top-.16,center+u0),new THREE.Vector3(Math.max(q.side*(b.width/2+v0),q.side*(b.width/2+v1)),top,center+u1)),walkRole:'solid'}));
 }
}
