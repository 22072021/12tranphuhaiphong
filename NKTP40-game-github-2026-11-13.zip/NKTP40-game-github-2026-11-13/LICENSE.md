# Giấy phép chia sẻ phi thương mại

Áp dụng cho phần mã nguồn, mô hình và nội dung gốc thuộc quyền của chủ dự án **12 Trần Phú – Đã lâu không gặp**, được cung cấp trong gói này.

Được phép tải, nghiên cứu, chỉnh sửa và chia sẻ lại cho mục đích phi thương mại, kèm ghi nguồn dự án và giữ thông báo giấy phép này. Khi chia sẻ bản chỉnh sửa, phải ghi rõ các thay đổi và tiếp tục giới hạn việc sử dụng phần nội dung gốc vào mục đích phi thương mại.

Không được bán, cho thuê, thu phí truy cập, khai thác quảng cáo hoặc sử dụng phần nội dung gốc cho hoạt động thương mại nếu chưa được chủ dự án đồng ý bằng văn bản. Không được tuyên bố bản chỉnh sửa là website chính thức của nhà trường hoặc của chủ dự án.

Phần mềm được cung cấp nguyên trạng, không bảo đảm, không cam kết vận hành hay hỗ trợ. Quyền đối với tên/logo trường, bản nhạc, hình game và tài sản bên thứ ba không được chuyển giao bởi giấy phép này. Các tài sản đó giữ giấy phép/quyền riêng; xem THIRD_PARTY_NOTICES.md và các tệp SOURCES/LICENSE/OFL đi kèm. Không áp dụng hạn chế phi thương mại này để thay thế giấy phép gốc của thư viện bên thứ ba.

Đây là chia sẻ mã nguồn có giới hạn phi thương mại; không phải tuyên bố đáp ứng định nghĩa giấy phép phần mềm nguồn mở OSI.
